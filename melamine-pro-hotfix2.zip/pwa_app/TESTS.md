# الاختبارات (Tests)

تمت إضافة طبقة اختبارات وحدات باستخدام **Vitest** تغطّي المنطق الجوهري للأعمال.

## التشغيل
```bash
npm install        # لتثبيت vitest (مضاف إلى devDependencies)
npm test           # وضع المراقبة
npm run test:run   # تشغيل مرة واحدة
npm run test:coverage
```

## ما يُغطّى
لتمكين الاختبار، استُخرج المنطق الحسّاس إلى وحدات نقية (دون تغيير السلوك)
وتُستدعى من `AppDataContext`:

- `src/utils/invoicing.ts` ← قاعدة الإيراد (المرحلة 2): الفاتورة تطابق الطلب
  (ضريبة 0 → الإجمالي = إجمالي الطلب)، وتَحمل المدفوع وتُطالب بالمتبقّي فقط.
  اختبار: `src/utils/invoicing.test.ts`
- `src/utils/bom.ts` ← اختيار المواد (وصفة المنتج أو القياسية بالأكواد) وخصم المخزون.
  اختبار: `src/utils/bom.test.ts`
- `src/utils/payroll.ts` ← احتساب الراتب من الحضور (حضور/غياب/تأخير/إضافي/خصومات).
  اختبار: `src/utils/payroll.test.ts` (تحقّق رقمي دقيق)
- `src/utils/oee.ts` ← الفعالية الكلية للمعدات. اختبار: `src/utils/oee.test.ts`
- `src/lib/permissions.ts` ← الصلاحيات الدقيقة و`computeCan`.
  اختبار: `src/lib/permissions.test.ts`
- `src/contexts/appData.helpers.ts` ← genId/today/ts وتحويل المواد.
  اختبار: `src/contexts/appData.helpers.test.ts`

## ملاحظات
- بيئة الاختبار `node` (منطق نقي بلا DOM)، سريعة وخفيفة.
- ملفات الاختبار لا تدخل في حزمة الإنتاج (vite build لا يستوردها).
- لاختبارات واجهة لاحقاً: التبديل إلى بيئة `jsdom` + React Testing Library.
