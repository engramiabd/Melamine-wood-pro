# ملاحظات التحسين الشاملة — ميلامين برو
**تاريخ الفحص:** 28 يونيو 2026  
**الإصدار المفحوص:** ما بعد جميع إصلاحات Session 2026  
**المفحوص:** AppDataContext (582L) + 15 hook + 35 صفحة + بنية المشروع

---

## ملخص سريع

| الأولوية | المشاكل | الحالة |
|----------|---------|--------|
| 🔴 حرج | 2 | يجب إصلاحه فوراً قبل الإنتاج |
| 🟠 عالية | 4 | يؤثر على الأداء أو الأمان بشكل ملحوظ |
| 🟡 متوسطة | 7 | تحسينات مهمة للجودة طويل الأمد |
| 🟢 منخفضة | 5 | تحسينات اختيارية / nice-to-have |

---

## 🔴 حرج — يجب إصلاحه قبل الإنتاج

---

### 🔴-1 — `vite-plugin-singlefile` يكسر `fetch('/archive-data.json')`

**الملف:** `vite.config.ts` + `src/lib/archiveLoader.ts`

**المشكلة:**  
`vite-plugin-singlefile` يُدمج كل JavaScript وCSS داخل `index.html` ملفاً واحداً.
لكن `fetch('/archive-data.json')` يحتاج **خادم ويب** لخدمة الملف.  
إذا فتح المستخدم `index.html` مباشرة من الجهاز (بروتوكول `file:///`) — الـfetch يفشل صامتاً وتبدأ البيانات التجريبية فارغة.  
الـService Worker يكاشف `/archive-data.json` خارج قائمة `APP_SHELL` فلا يُخزَّن مؤقتاً.

**الخيارات:**
```
أ) إزالة vite-plugin-singlefile → نشر مع خادم (Vercel / Nginx / Netlify)
   → الأفضل طويلاً: code splitting + lazy loading يعملان بشكل صحيح

ب) Vite virtual module (يبقى offline بدون خادم):
   في vite.config.ts:
   plugins: [
     { name: 'archive-json',
       resolveId: id => id === 'virtual:archive' ? id : null,
       load: id => id === 'virtual:archive'
         ? `export default ${fs.readFileSync('public/archive-data.json','utf8')}`
         : null },
   ]
   ثم: import archiveData from 'virtual:archive'
   (يعيد ~236KB للbundle لكن يعمل offline 100%)

ج) إضافة archive-data.json لقائمة APP_SHELL في sw.js:
   const APP_SHELL = ['/', '/archive-data.json', ...];
   → يعمل بعد أول زيارة online فقط
```

---

### 🔴-2 — كلمات المرور نصاً صريحاً في `AuthContext.tsx`

**الملف:** `src/contexts/AuthContext.tsx` (سطور 9, 16, 23, 30, 37, 44)

**المشكلة:**
```ts
{ email: 'admin@demo.com', password: 'demo123', role: 'admin' }
```
كلمات المرور مخزَّنة كنص صريح في JavaScript bundle.  
أي شخص يفتح DevTools → Sources يرى جميع الحسابات التجريبية وكلماتها.  
كذلك `app_user_passwords` في localStorage يخزّن كلمات مرور المستخدمين الجدد نصاً.

**الإصلاح الصحيح:**
```ts
// بدلاً من المقارنة المباشرة
a.password === password

// استخدم hash بسيط (SHA-256 via Web Crypto):
const hash = async (s: string) =>
  [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))]
    .map(b => b.toString(16).padStart(2,'0')).join('');

// خزّن: await hash('demo123')
// قارن: await hash(inputPassword) === storedHash
```
في بيئة Supabase الفعلية: لا يجب تخزين كلمات مرور نهائياً في localStorage.

---

## 🟠 عالية — تؤثر على الأداء أو الأمان

---

### 🟠-3 — حزم مثبَّتة لكن غير مستخدمة (حجم bundle مجاني)

**الملفات:** `package.json`

| الحزمة | الاستخدامات | الحجم المقدَّر |
|--------|-------------|---------------|
| `@tanstack/react-query` | **0** | ~45 KB gzip |
| `@tanstack/react-query-devtools` | **0** | ~15 KB gzip |
| `react-swipeable` | **0** (بعد إعادة كتابة PullToRefresh) | ~5 KB gzip |

**الإصلاح:**
```bash
npm uninstall @tanstack/react-query @tanstack/react-query-devtools react-swipeable
```
**التوفير المتوقع:** ~65 KB من الـbundle (مضغوط).

---

### 🟠-4 — Context واحد لـ36 مستهلكاً = إعادة رسم كارثية

**الملفات:** `src/contexts/AppDataContext.tsx` + جميع الصفحات

**المشكلة:**  
كل تغيير في أي state (مثلاً تحديث طلب واحد) يُعيد رسم **كل 36 مكوّناً** يستخدم `useAppData()`.  
لا توجد `React.memo` على أي صفحة من الـ35 صفحة.

**الأثر الفعلي:**  
عند تسجيل حضور موظف → DashboardPage + ReportsPage + HRPage + ProductionLinesPage... كلها تُعاد.

**الحل المقترح (مرحلتان):**

**المرحلة 1 — سريعة (ساعة واحدة):**
```tsx
// أضف React.memo للصفحات الثقيلة:
export default React.memo(DashboardPage);    // 1168 سطر
export default React.memo(ReportsPage);      // 1031 سطر
export default React.memo(ProductionLinesPage); // 959 سطر
export default React.memo(HRPage);           // 1006 سطر
export default React.memo(OrderDetailPage);  // 1109 سطر
```

**المرحلة 2 — متقدمة (تقسيم Context):**
```
AppDataContext الحالي → 5 contexts مستقلة:
  ProductionContext   (lines, batches, plans, errorLog)
  FinanceContext      (invoices, payments, journal, wallets, advances)
  HRContext           (employees, leaves, attendance)
  InventoryContext    (inventoryItems, managedProducts, suppliers)
  OrdersContext       (orders, customers, orderPayments)
```
كل صفحة تستهلك فقط Context المتعلقة بها → 80% تخفيض في re-renders.

---

### 🟠-5 — Service Worker لا يُخزِّن `archive-data.json`

**الملف:** `public/sw.js` (سطر 8)

**المشكلة:**
```js
const APP_SHELL = [
  '/', '/index.html', '/manifest.json',
  '/favicon.svg', '/icon-192.png', ...
  // archive-data.json غائب!
];
```
عند أول استخدام offline (بعد تثبيت PWA) لن تُحمَّل بيانات الأرشيف.

**الإصلاح:**
```js
const APP_SHELL = [
  '/', '/index.html', '/manifest.json',
  '/archive-data.json',  // ← أضف هذا
  '/favicon.svg', ...
];
```
وتأكد من تحديث `CACHE = 'melamine-pro-v2'` حتى يُعاد بناء الـcache.

---

### 🟠-6 — صلاحيات RBAC مخزَّنة في localStorage (قابلة للتلاعب)

**الملف:** `src/contexts/usePermissionsData.ts`

**المشكلة:**
```ts
const [rolePermissions, setRolePermissions] = useState(
  () => load('app_role_permissions', defaultPermissions)
);
```
أي مستخدم يفتح DevTools → Application → localStorage يستطيع تعديل `app_role_permissions`
وإعطاء نفسه صلاحيات admin.

**الإصلاح (للبيئة الإنتاجية مع Supabase):**  
- قواعد RLS في Supabase تُطبَّق server-side بغض النظر عن localStorage.
- وظيفة `can()` تتحقق من جدول Supabase مباشرة بدلاً من localStorage.
- للوضع التجريبي: مقبول حالياً، لكن يجب توثيقه بوضوح.

---

## 🟡 متوسطة — جودة الكود وقابلية الصيانة

---

### 🟡-7 — الصفحات العملاقة بحاجة تقسيم داخلي

| الصفحة | الأسطر | المشكلة |
|--------|--------|---------|
| `DashboardPage.tsx` | 1168 | 8 Charts + KPIs + LiveClock + لوحات إحصاء كلها في ملف واحد |
| `AdminPage.tsx` | 937 | Import/Export + RBAC + Users + Audit كلها مضمَّنة |
| `OrderDetailPage.tsx` | 1109 | 5 tabs + تعديل + مدفوعات + timeline |
| `HRPage.tsx` | 1006 | Employees + Leaves + Advances + Payroll |
| `ReportsPage.tsx` | 1031 | 6 reports tabs بمخططات recharts |

**الحل:** تقسيم كل صفحة إلى sub-components في مجلد خاص:
```
src/pages/Dashboard/
  DashboardPage.tsx      (shell + routing بين tabs)
  DashboardKPIs.tsx
  DashboardCharts.tsx
  DashboardLiveLines.tsx
  DashboardRecentOrders.tsx
```

---

### 🟡-8 — تغطية الاختبارات محدودة جداً

**الوضع الحالي:**
- 12 ملف اختبار — جميعها لـ`utils/` و`lib/` فقط
- 0 اختبارات للـ15 hook مستخرج
- 0 اختبارات مكوّنات (لا React Testing Library)
- 0 اختبارات تكامل للسيناريوهات الحرجة

**الأولوية القصوى للإضافة:**
```
useOrdersData.test.ts    → addOrder, generateInvoiceFromOrder, updateOrderStatus
useWalletData.test.ts    → processPayroll, requestAdvance, approveAdvance
useProductionData.test.ts → addProductionBatch (يخصم مواد + يُنتج ميلامين)
useInventoryData.test.ts  → addInventoryTransaction (حدود الكمية)
```

---

### 🟡-9 — Recharts تُحمَّل في 10 صفحات دون lazy loading

**المشكلة:**  
Recharts تُضاف للبundle الرئيسي (يُقدَّر ~200KB gzip) رغم أن معظم المستخدمين لا يفتحون Reports أو Finance في كل جلسة.

**الحل:**
```tsx
// حالياً (ثقيل):
import { AreaChart, BarChart, PieChart } from 'recharts';

// بعد التحسين:
const RechartsArea = lazy(() =>
  import('recharts').then(m => ({ default: m.AreaChart }))
);
// أو تجميع Charts في ملف واحد:
const Charts = lazy(() => import('./DashboardCharts'));
```

---

### 🟡-10 — Accessibility ضعيف جداً

**الأرقام:**
- 26 سمة `aria-*` في 35 صفحة (أقل من 1 لكل صفحة)
- 0 سمة `alt=` للصور
- `BottomNav` و`TopBar` بدون `role="navigation"`
- أزرار Icon-only بدون `aria-label` في أماكن كثيرة

**الحد الأدنى المطلوب:**
```tsx
// BottomNav:
<nav role="navigation" aria-label="التنقل الرئيسي">

// أزرار الأيقونات:
<button aria-label="إضافة طلب جديد"><PlusIcon /></button>

// القوائم المنسدلة:
<ul role="listbox" aria-label="الإجراءات المتاحة">
```

---

### 🟡-11 — Sync Engine: الحذف لا يتزامن بين الأجهزة

**الملف:** `src/lib/syncEngine.ts` (موثَّق في الكود)

**المشكلة:**
```ts
// sync is a non-destructive UNION merge — Row deletions do not propagate in v1
```
إذا حذف المشرف طلباً من جهازه، يظل الطلب موجوداً على جهاز المحاسب.

**الحل (Soft Delete):**
```ts
// أضف حقل deleted_at: string | null لكل entity
// حذف منطقي:
setOrders(prev => prev.map(o => o.id === id ? {...o, deleted_at: ts()} : o));
// فلترة في الواجهة:
const activeOrders = orders.filter(o => !o.deleted_at);
// Sync engine يتزامن deleted_at عبر الأجهزة طبيعياً
```

---

### 🟡-12 — localStorage دون مراقبة الحصة

**المشكلة:**  
بعد 6-12 شهراً من الاستخدام الحقيقي:  
- سجل التدقيق: 150 سجل حالياً → قد يصل 5000+
- قيود اليومية: تنمو بكل عملية
- معاملات المحفظة: تنمو شهرياً

استخدام الـlocalStorage 5% حالياً لكن ليس هناك حد أقصى أو تحذير.

**الإصلاح:**
```ts
// في appData.helpers.ts أضف:
export function getStorageUsage(): { usedKB: number; limitKB: number; percent: number } {
  const used = Object.keys(localStorage)
    .reduce((sum, key) => sum + (localStorage[key]?.length || 0) * 2, 0); // UTF-16
  const limit = 5 * 1024 * 1024; // 5MB conservative
  return { usedKB: Math.round(used/1024), limitKB: 5120, percent: used/limit*100 };
}

// في AdminPage أو SettingsPage: أضف شريط استخدام مع تحذير عند > 70%
```

---

## 🟢 منخفضة — تحسينات اختيارية

---

### 🟢-13 — أيقونات PNG وSVG معاً (68KB زائدة)

**الملفات:** `public/`

```
icon-192.png  21 KB  ← غير ضروري
icon-192.svg   4 KB  ✓
icon-512.png  47 KB  ← غير ضروري
icon-512.svg   8 KB  ✓
```

المتصفحات الحديثة تقبل SVG في manifest.json.  
**التوفير:** 68KB من مجلد public (لا تأثير على bundle لكن يُقلّل التحميل الأولي للأصول).

---

### 🟢-14 — `date-fns` مستورد لكن الاستخدام محدود

**المشكلة:**  
`date-fns` حزمة كاملة (~20KB gzip) لكن غالبية التنسيق يعتمد على `toLocaleString` الأصلي.

**الفحص:**
```bash
grep -rn "from 'date-fns'" src/ | wc -l  # عدد الاستخدامات الفعلية
```
إذا كانت < 5 استخدامات، فالنسخة الأصلية `Intl.DateTimeFormat` تكفي.

---

### 🟢-15 — `AssistantPage` يحتاج مراجعة أمان API Key

**الملف:** `src/pages/AssistantPage.tsx`

**الفحص:**
```bash
grep -n "ANTHROPIC\|API_KEY\|api.anthropic" src/pages/AssistantPage.tsx
```
API Key للـAI Assistant يجب ألا يُدمج في bundle أو يُخزَّن في localStorage.  
يجب توجيهه عبر Supabase Edge Functions أو proxy.

---

### 🟢-16 — تعريف `factoryConfig.ts` مضمَّن في الكود

**الملف:** `src/lib/factoryConfig.ts`

بيانات المصنع (اسمه، موقعه، ضريبته) مضمَّنة في الكود.  
يجب الانتقال إلى `systemSettings` في Supabase ليتمكن المدير من تعديلها بدون إعادة بناء.

---

## خطة العمل المقترحة

### الأسبوع 1 — الإصلاحات الحرجة
```
🔴-1  إصلاح singlefile + archive-data.json (الخيار ب أو أ)
🔴-2  hash كلمات مرور الديمو بـWeb Crypto API
🟠-3  npm uninstall للحزم غير المستخدمة (5 دقائق)
🟠-5  إضافة archive-data.json لـSW cache
```

### الأسبوع 2 — الأداء
```
🟠-4  React.memo على الصفحات الثقيلة (مرحلة 1)
🟡-9  Lazy loading لـRecharts
🟢-13 حذف PNG assets الزائدة
```

### الشهر 1 — الجودة
```
🟡-8  اختبارات للـhooks الحرجة
🟡-7  تقسيم DashboardPage و HRPage
🟡-10 إضافة aria-* الأساسية
🟡-12 مراقبة localStorage
```

### المدى البعيد — البنية
```
🟠-4  تقسيم AppDataContext (مرحلة 2)
🟡-11 Soft delete للمزامنة
🟠-6  صلاحيات server-side مع Supabase RLS
```

---

## ملخص النقاط الإيجابية (ما يعمل جيداً)

- ✅ **AppDataContext مُقسَّم** إلى 15 hook (−53% من الحجم)
- ✅ **archiveData.ts محذوف** من bundle، lazy loader بـcache ذكي
- ✅ **BottomSheet إيماءات صحيحة** — pointer events فقط، بدون تضاعف
- ✅ **PullToRefresh مُعاد كتابته** — native touch, لا تعارض مع scroll
- ✅ **AnimatePresence mode="sync"** — صفحات تظهر فوراً بدون انتظار exit
- ✅ **Lazy loading للصفحات** — جميع الـ35 صفحة بـ`React.lazy()`
- ✅ **offline-first** — يعمل 100% بدون Supabase
- ✅ **RTL كامل** بـdir="rtl" وتنسيق عربي
- ✅ **Service Worker** موجود ويعمل
- ✅ **12 ملف اختبار** للدوال الحسابية الحرجة
- ✅ **Error Boundary** على مستويين (App + AppLayout)
- ✅ **TypeScript** في كل الكود (0 ملفات `.js`)
