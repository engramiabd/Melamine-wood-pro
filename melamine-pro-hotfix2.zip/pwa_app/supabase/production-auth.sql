-- ============================================================================
--  ميلامين برو — تشديد الأمان للإنتاج (Supabase Auth + RLS)
--  Run AFTER schema.sql, only when you're ready to switch from the open
--  demo policies to authenticated-only access.
--
--  ⚠️ بعد تشغيل هذا الملف، لن تعمل المزامنة إلا لمستخدم مسجّل دخوله عبر
--     Supabase Auth (الحسابات التجريبية المحلية تبقى للعرض بلا مزامنة سحابية).
-- ============================================================================

-- ── ١) جدول الملفّات الشخصية (يطابق نوع User في التطبيق) ─────────────────────
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text,
  full_name   text,
  role        text not null default 'worker'
              check (role in ('admin','manager','production_supervisor','worker','accountant','hr')),
  phone       text,
  department  text,
  avatar_url  text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- كل مستخدم يقرأ/يعدّل ملفّه فقط
drop policy if exists profiles_self_select on public.profiles;
create policy profiles_self_select on public.profiles
  for select using (auth.uid() = id);

drop policy if exists profiles_self_update on public.profiles;
create policy profiles_self_update on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- إنشاء ملف تلقائياً عند تسجيل مستخدم جديد في Auth
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', new.email))
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ── ٢) تبديل سياسات جداول البيانات إلى «مستخدم مسجّل فقط» ────────────────────
do $$
declare t text;
  tables text[] := array[
    'orders','production_lines','production_batches','production_plans',
    'inventory_items','products','suppliers','purchase_orders',
    'customers','invoices','invoice_payments','order_payments',
    'journal_entries','wallets','wallet_transactions',
    'employees','attendance_records','leave_requests','advance_requests',
    'audit_log','kv_store'
  ];
begin
  foreach t in array tables loop
    -- احذف سياسة العرض المفتوحة
    execute format('drop policy if exists %I on public.%I;', t || '_all', t);
    -- سياسة جديدة: السماح لأي مستخدم مسجّل دخوله
    execute format('drop policy if exists %I on public.%I;', t || '_authed', t);
    execute format(
      'create policy %I on public.%I for all to authenticated using (true) with check (true);',
      t || '_authed', t);
  end loop;
end $$;

-- ============================================================================
--  ملاحظات
--  • هذه السياسة تسمح لأي مستخدم مسجّل بالوصول الكامل (مناسب لفريق موثوق داخل
--    منشأة واحدة). لعزل البيانات حسب المنشأة/الفرع، أضِف عمود org_id إلى كل
--    جدول واربط السياسة به:  using (org_id = auth.jwt() ->> 'org_id').
--  • أنشئ المستخدمين من Supabase → Authentication → Users، وعيّن الدور في
--    public.profiles (role). يدخل المستخدم بالبريد/كلمة المرور فيتفعّل التزامن.
-- ============================================================================
