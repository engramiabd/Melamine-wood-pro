-- ============================================================================
--  ميلامين برو — مخطّط قاعدة بيانات Supabase
--  Melamine Pro — Supabase schema (v1, JSONB document model)
--
--  شغّل هذا الملف مرّة واحدة في:  Supabase Dashboard → SQL Editor → New query
--  Run once in the Supabase SQL Editor.
--
--  النموذج: كل جدول يخزّن السجلّات كمستندات JSONB، فلا حاجة لمزامنة كل عمود.
--    id          : المعرّف الفريد للسجلّ (نفسه في التطبيق)
--    doc         : السجلّ كاملاً (JSONB)
--    updated_at  : وقت آخر تعديل
-- ============================================================================

-- دالة مشتركة لتحديث updated_at تلقائياً
create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

-- ماكرو يدوي: ننشئ كل جدول بنفس البنية عبر DO block
do $$
declare t text;
  tables text[] := array[
    'orders','production_lines','production_batches','production_plans',
    'inventory_items','products','suppliers','purchase_orders',
    'customers','invoices','invoice_payments','order_payments',
    'journal_entries','wallets','wallet_transactions',
    'employees','attendance_records','leave_requests','advance_requests',
    'audit_log'
  ];
begin
  foreach t in array tables loop
    execute format($f$
      create table if not exists public.%I (
        id          text primary key,
        doc         jsonb not null,
        deleted_at  timestamptz,
        updated_at  timestamptz not null default now()
      );
    $f$, t);

    -- لو كان الجدول موجوداً مسبقاً بنسخة أقدم بلا عمود الحذف
    execute format('alter table public.%I add column if not exists deleted_at timestamptz;', t);

    -- فهرس على updated_at للسحب التزايدي مستقبلاً
    execute format('create index if not exists %I on public.%I (updated_at);', t || '_updated_idx', t);

    -- محفّز updated_at
    execute format('drop trigger if exists %I on public.%I;', t || '_set_updated', t);
    execute format(
      'create trigger %I before update on public.%I for each row execute function set_updated_at();',
      t || '_set_updated', t);

    -- تفعيل RLS
    execute format('alter table public.%I enable row level security;', t);

    -- سياسة v1: السماح الكامل (للتجربة السريعة بالمفتاح المجهول/anon).
    -- ⚠️ للإنتاج: استبدلها بسياسة تعتمد auth.uid() بعد ربط Supabase Auth.
    execute format('drop policy if exists %I on public.%I;', t || '_all', t);
    execute format(
      'create policy %I on public.%I for all using (true) with check (true);',
      t || '_all', t);
  end loop;
end $$;

-- ── جدول المفاتيح/القيم للإعدادات المفردة (الإعدادات + صلاحيات الأدوار) ──────
create table if not exists public.kv_store (
  key         text primary key,
  value       jsonb,
  updated_at  timestamptz not null default now()
);
drop trigger if exists kv_store_set_updated on public.kv_store;
create trigger kv_store_set_updated before update on public.kv_store
  for each row execute function set_updated_at();
alter table public.kv_store enable row level security;
drop policy if exists kv_store_all on public.kv_store;
create policy kv_store_all on public.kv_store for all using (true) with check (true);

-- ============================================================================
--  ملاحظات أمنية مهمّة
--  • السياسات أعلاه «مفتوحة» (using true) لتسهيل التجربة الفورية بالمفتاح anon.
--    هذا مناسب لبيئة تجريبية فقط.
--  • للإنتاج: فعّل Supabase Auth في التطبيق، ثم بدّل السياسات إلى شيء مثل:
--        create policy "..." on public.orders for all
--          using (auth.role() = 'authenticated')
--          with check (auth.role() = 'authenticated');
--    أو اربط الصفوف بالمستخدم/المنشأة حسب حاجتك.
--  • كلمات المرور وسجلّ الأخطاء والصور الشخصية لا تُرفع أبداً إلى السحابة.
-- ============================================================================
