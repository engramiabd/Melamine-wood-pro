import { defineConfig } from 'vitest/config';

// Tests target pure business logic (no DOM), so the lightweight 'node'
// environment is enough and fast. UI/component tests (if added later) can
// switch to 'jsdom'.
export default defineConfig({
  test: {
    environment: 'node',
    include: ['src/**/*.test.ts'],
  },
});
