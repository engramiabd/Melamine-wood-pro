import path from "path";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Removed vite-plugin-singlefile: the app is deployed on a web server
// (Vercel / Netlify / Nginx) so code splitting + lazy loading work correctly,
// public assets (archive-data.json, sw.js, icons) are served normally,
// and the initial JS payload is split into per-route chunks automatically.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
  build: {
    // Raise the chunk-size warning threshold — recharts alone is ~200KB;
    // the warning fires at 500KB by default which is appropriate.
    chunkSizeWarningLimit: 600,
    rollupOptions: {
      output: {
        // Explicit manual chunks so Recharts + Framer-Motion load only
        // when a chart/animation page is first visited.
        manualChunks: {
          "vendor-react":   ["react", "react-dom", "react-router-dom"],
          "vendor-charts":  ["recharts"],
          "vendor-motion":  ["framer-motion"],
          "vendor-supabase":["@supabase/supabase-js"],
          "vendor-forms":   ["react-hook-form", "@hookform/resolvers", "zod"],
          "vendor-ui":      [
            "@radix-ui/react-dialog",
            "@radix-ui/react-dropdown-menu",
            "@radix-ui/react-tabs",
            "@radix-ui/react-slot",
            "lucide-react",
          ],
        },
      },
    },
  },
});
