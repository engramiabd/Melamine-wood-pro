# تقسيم AppDataContext — سجل التغييرات

## الملخص
تقسيم `AppDataContext.tsx` من 1235 سطر إلى 582 سطر (−53%) عبر استخراج 15 custom hook.
واجهة `useAppData()` لم تتغير — صفر تعديلات على المكونات المستهلكة (36 مكوّن).

## الملفات المُضافة (`src/contexts/`)

| الملف | السطور | المحتوى |
|-------|--------|---------|
| `useNotifications.ts` | 66 | الإشعارات (موجود مسبقاً) |
| `useOpsData.ts` | 55 | تخطيط الإنتاج + سجل الأخطاء |
| `useSuppliersData.ts` | 89 | الموردون + أوامر الشراء |
| `useCustomersData.ts` | 40 | العملاء CRUD |
| `useManagedProductsData.ts` | 42 | المنتجات + BOM |
| `useLeavesData.ts` | 40 | الإجازات |
| `useAttendanceData.ts` | 72 | الحضور + تزامن offline |
| `useEmployeesData.ts` | 48 | الموظفون (setWallets مُحقَن) |
| `useWalletData.ts` | 201 | المحافظ + السلف + الرواتب |
| `usePermissionsData.ts` | 74 | الصلاحيات + adminSetUserPassword |
| `useInventoryData.ts` | 103 | addInventoryTransaction + CRUD |
| `useProductionData.ts` | 192 | خطوط الإنتاج + الدفعات + إعادة الضبط اليومية |
| `useInvoicesData.ts` | 114 | الفواتير + المدفوعات |
| `useOrdersData.ts` | 210 | الطلبات + مدفوعات الطلبات + توليد الفاتورة |
| `useSettingsData.ts` | 60 | الإعدادات + الملف الشخصي + تغيير كلمة المرور |

## تسلسل الاستدعاء في Provider

```
useAuth → useNotifications → logAudit/logAuditRef →
usePermissionsData → useSettingsData → useOpsData →
useCustomersData → useInvoicesData → useManagedProductsData →
useOrdersData → useInventoryData → useProductionData →
useEmployeesData → useLeavesData → useAttendanceData →
useWalletData → useSuppliersData
```

## التحقق
- توازن كامل للأقواس في جميع الملفات
- صفر تعريفات مكررة
- صفر TDZ (كل hook يُستدعى بعد تعريف اعتمادياته)
- صفر تغييرات على المكونات المستهلكة

## قبل النشر
```bash
npm install && npm run build && npm test
```

---

# إصلاحات الأداء والإيماءات — Performance & Touch Fixes

## المشاكل التي أُصلحت

### 1. بطء التنقل بين الصفحات
- **السبب**: `AnimatePresence mode="wait"` كان يمنع الصفحة الجديدة من الظهور حتى تكتمل أنيميشن خروج الصفحة القديمة.
- **الحل**: تغيير إلى `mode="sync"` + تبسيط الأنيميشن إلى opacity فقط (مدة 0.15s بدلاً من 0.24s مع حركة y).

### 2. أخطاء Swipe في BottomSheet
- **السبب**: الـhandle كان يسجّل كلاً من `onPointerDown` + `onTouchStart`، والـglobal listeners كانت تسجّل `pointermove/pointerup` + `touchmove/touchend` → كل لمسة تُشغّل الـhandler **مرتين**.
- **الحل**: إزالة touch events بالكامل، الإبقاء على pointer events فقط (تعمل على كل الأجهزة) + إضافة `setPointerCapture` + `pointercancel`.

### 3. تعارض PullToRefresh مع Scroll
- **السبب**: `react-swipeable` يختطف جميع touch events قبل المتصفح، مما يتعارض مع native scroll.
- **الحل**: إعادة كتابة كاملة بـnative touch events مباشرة على الـscroll container. `{ passive: false }` فقط على `touchmove` (لاستدعاء `preventDefault` عند الـpull)، `pan-y` يتيح scroll العادي.

### 4. إعادة رسم غير ضرورية في AppDataContext
- **الحل**: تغليف كائن `value` بـ`useMemo` مع deps كاملة.

### 5. أداء CSS
- `contain: layout style` على `.main-content` و`.page-wrapper` → عزل paint وlayout عن باقي الشجرة.
- تسريع spring في BottomModal (stiffness 400, damping 32, mass 0.75).
- تسريع فتح/إغلاق BottomSheet (0.30s/0.26s).
