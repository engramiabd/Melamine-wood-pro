/* ميلامين برو — Service Worker
 * Hand-rolled (no build plugin required, works with vite-plugin-singlefile).
 * Caches the app shell so the PWA loads and runs fully offline, while always
 * letting Supabase / cross-origin API calls hit the network.
 */
const CACHE = 'melamine-pro-v2';
const APP_SHELL = [
  '/', '/index.html', '/manifest.json',
  '/archive-data.json',
  '/favicon.svg', '/icon-192.png', '/icon-512.png', '/icon-192.svg', '/icon-512.svg',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(APP_SHELL)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  // Cross-origin (e.g. Supabase) → always network, never cache.
  if (url.origin !== self.location.origin) return;

  // Page navigations → network-first, fall back to the cached shell offline.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put('/index.html', copy)).catch(() => {});
          return res;
        })
        .catch(() => caches.match('/index.html').then((r) => r || caches.match('/')))
    );
    return;
  }

  // Same-origin static assets → cache-first with background refresh.
  event.respondWith(
    caches.match(request).then((cached) => {
      const network = fetch(request)
        .then((res) => {
          if (res && res.status === 200) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(request, copy)).catch(() => {});
          }
          return res;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});

// ─── Push notifications (Phase 4) ───────────────────────────────────────────
// Handles messages delivered by a push service (requires a backend + VAPID to
// actually send). The in-app stream also shows local notifications directly.
self.addEventListener('push', (event) => {
  let data = { title: 'ميلامين برو', body: 'لديك تحديث جديد', url: '/' };
  try { if (event.data) data = Object.assign(data, event.data.json()); } catch (_e) { /* plain text */ }
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      dir: 'rtl',
      lang: 'ar',
      data: { url: data.url || '/' },
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if ('focus' in client) { if (client.navigate) client.navigate(url); return client.focus(); }
      }
      if (self.clients.openWindow) return self.clients.openWindow(url);
    })
  );
});
