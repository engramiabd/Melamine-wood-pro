import React, { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { CurrencyProvider } from './contexts/CurrencyContext';
import { AppDataProvider } from './contexts/AppDataContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { AppLayout } from './components/layout/AppLayout';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { ErrorBoundary } from './components/ui/ErrorBoundary';
import { LoadingScreen } from './components/ui/LoadingScreen';
import { PageSkeleton } from './components/ui/Skeleton';

// ── Pages ─────────────────────────────────────────────────────────────────────
// Auth/entry pages stay eager (needed at first paint); the rest are lazy-loaded
// so each screen's code is only initialised when first visited.
import { LoginPage }               from './pages/LoginPage';
import { DemoPage }                from './pages/DemoPage';
import { NotFoundPage }            from './pages/NotFoundPage';
import { UnauthorizedPage }        from './pages/UnauthorizedPage';

// Lazy helper that works for both named and default exports.
const page = <T,>(factory: () => Promise<Record<string, unknown>>, name: string) =>
  lazy(() => factory().then(m => ({ default: (m[name] || m.default) as React.ComponentType<T> })));

const DashboardPage           = page(() => import('./pages/DashboardPage'), 'DashboardPage');
const OrdersPage              = page(() => import('./pages/OrdersPage'), 'OrdersPage');
const NewOrderPage            = page(() => import('./pages/NewOrderPage'), 'NewOrderPage');
const OrderDetailPage         = page(() => import('./pages/OrderDetailPage'), 'OrderDetailPage');
const ProductionLinesPage     = page(() => import('./pages/ProductionLinesPage'), 'ProductionLinesPage');
const InventoryPage           = page(() => import('./pages/InventoryPage'), 'InventoryPage');
const JournalPage             = page(() => import('./pages/JournalPage'), 'JournalPage');
const WalletPage              = page(() => import('./pages/WalletPage'), 'WalletPage');
const AttendancePage          = page(() => import('./pages/AttendancePage'), 'AttendancePage');
const AttendanceDashboardPage = page(() => import('./pages/AttendanceDashboardPage'), 'AttendanceDashboardPage');
const HRPage                  = page(() => import('./pages/HRPage'), 'HRPage');
const AdminPage               = page(() => import('./pages/AdminPage'), 'AdminPage');
const CostPage                = page(() => import('./pages/CostPage'), 'CostPage');
const FinancePage             = page(() => import('./pages/FinancePage'), 'FinancePage');
const SettingsPage            = page(() => import('./pages/SettingsPage'), 'SettingsPage');
const CustomersPage           = page(() => import('./pages/CustomersPage'), 'CustomersPage');
const ProductsPage            = page(() => import('./pages/ProductsPage'), 'ProductsPage');
const InvoicesPage            = page(() => import('./pages/InvoicesPage'), 'InvoicesPage');
const ProfilePage             = page(() => import('./pages/ProfilePage'), 'ProfilePage');
const NotificationsPage       = page(() => import('./pages/NotificationsPage'), 'NotificationsPage');
const ReportsPage             = page(() => import('./pages/ReportsPage'), 'ReportsPage');
const AuditLogPage            = page(() => import('./pages/AuditLogPage'), 'AuditLogPage');
const SuppliersPage           = page(() => import('./pages/SuppliersPage'), 'SuppliersPage');
const PermissionsPage         = page(() => import('./pages/PermissionsPage'), 'PermissionsPage');
const ProductionPlanPage      = page(() => import('./pages/ProductionPlanPage'), 'ProductionPlanPage');
const ErrorLogPage            = page(() => import('./pages/ErrorLogPage'), 'ErrorLogPage');
const SearchPage              = page(() => import('./pages/SearchPage'), 'SearchPage');
const AssistantPage           = page(() => import('./pages/AssistantPage'), 'AssistantPage');
const LoyaltyPage             = page(() => import('./pages/LoyaltyPage'), 'LoyaltyPage');

import { Toaster } from 'sonner';

// ── All Roles ─────────────────────────────────────────────────────────────────
const ALL_ROLES = ['admin', 'manager', 'production_supervisor', 'worker', 'accountant', 'hr'] as const;

// ── Routes wrapped with auth loading ─────────────────────────────────────────
const AppRoutes: React.FC = () => {
  const { isLoading } = useAuth();

  if (isLoading) {
    return <LoadingScreen message="جاري التحقق من الجلسة..." />;
  }

  return (
    <Suspense fallback={<PageSkeleton />}>
    <Routes>
      {/* ── Public Routes ───────────────────────────────────── */}
      <Route path="/login"        element={<LoginPage />} />
      <Route path="/demo"         element={<DemoPage />} />
      <Route path="/unauthorized" element={<UnauthorizedPage />} />
      <Route path="/404"          element={<NotFoundPage />} />

      {/* ── All Authenticated Users ─────────────────────────── */}
      <Route element={<ProtectedRoute allowedRoles={[...ALL_ROLES]} />}>
        <Route element={<AppLayout />}>
          <Route path="/"                  element={<DashboardPage />} />
          <Route path="/search"            element={<SearchPage />} />
          <Route path="/assistant"         element={<AssistantPage />} />
          <Route path="/loyalty"           element={<LoyaltyPage />} />
          <Route path="/settings"          element={<SettingsPage />} />
          <Route path="/profile"           element={<ProfilePage />} />
          <Route path="/notifications"     element={<NotificationsPage />} />
          <Route path="/attendance"        element={<AttendancePage />} />
          <Route path="/wallet"            element={<WalletPage />} />
        </Route>
      </Route>

      {/* ── Orders ─────────────────────────────────────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'manager', 'production_supervisor', 'accountant']} />}>
        <Route element={<AppLayout />}>
          <Route path="/orders"     element={<OrdersPage />} />
          <Route path="/orders/:id" element={<OrderDetailPage />} />
          <Route path="/customers"  element={<CustomersPage />} />
        </Route>
      </Route>

      <Route element={<ProtectedRoute allowedRoles={['admin', 'manager']} />}>
        <Route element={<AppLayout />}>
          <Route path="/orders/new" element={<NewOrderPage />} />
        </Route>
      </Route>

      {/* ── Production Lines ────────────────────────────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'manager', 'production_supervisor', 'worker']} />}>
        <Route element={<AppLayout />}>
          <Route path="/production-lines"     element={<ProductionLinesPage />} />
          <Route path="/production-lines/:id" element={<ProductionLinesPage />} />
        </Route>
      </Route>

      {/* ── Inventory ───────────────────────────────────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'manager', 'production_supervisor']} />}>
        <Route element={<AppLayout />}>
          <Route path="/inventory" element={<InventoryPage />} />
        </Route>
      </Route>

      {/* ── Suppliers, Archive & Finance views ──────────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'manager', 'accountant']} />}>
        <Route element={<AppLayout />}>
          <Route path="/suppliers" element={<SuppliersPage />} />
        </Route>
      </Route>

      {/* ── Operations: production plan ── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'manager', 'production_supervisor', 'accountant']} />}>
        <Route element={<AppLayout />}>
          <Route path="/production-plan" element={<ProductionPlanPage />} />
        </Route>
      </Route>

      {/* ── Products ────────────────────────────────────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'manager']} />}>
        <Route element={<AppLayout />}>
          <Route path="/products" element={<ProductsPage />} />
        </Route>
      </Route>

      {/* ── Journal ─────────────────────────────────────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'accountant', 'manager']} />}>
        <Route element={<AppLayout />}>
          <Route path="/journal" element={<JournalPage />} />
          <Route path="/invoices" element={<InvoicesPage />} />
        </Route>
      </Route>

      {/* ── Attendance Dashboard (Supervisor/Admin) ──────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'manager', 'hr', 'production_supervisor']} />}>
        <Route element={<AppLayout />}>
          <Route path="/attendance/dashboard" element={<AttendanceDashboardPage />} />
        </Route>
      </Route>

      {/* ── HR ──────────────────────────────────────────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'hr', 'manager']} />}>
        <Route element={<AppLayout />}>
          <Route path="/hr/employees" element={<HRPage />} />
          <Route path="/hr/leaves"    element={<HRPage />} />
          <Route path="/hr/payroll"   element={<HRPage />} />
        </Route>
      </Route>

      {/* ── Costs, Finance, Sales & Reports ─────────────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin', 'manager', 'accountant']} />}>
        <Route element={<AppLayout />}>
          <Route path="/costs"   element={<CostPage />} />
          <Route path="/finance" element={<FinancePage />} />
          <Route path="/reports" element={<ReportsPage />} />
        </Route>
      </Route>

      {/* ── Admin Panel ─────────────────────────────────────── */}
      <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
        <Route element={<AppLayout />}>
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/audit" element={<AuditLogPage />} />
          <Route path="/admin/permissions" element={<PermissionsPage />} />
          <Route path="/errors" element={<ErrorLogPage />} />
        </Route>
      </Route>

      {/* ── Catch-all ───────────────────────────────────────── */}
      <Route path="*" element={<Navigate to="/404" replace />} />
    </Routes>
    </Suspense>
  );
};

// ── App Root ──────────────────────────────────────────────────────────────────
export function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
      <BrowserRouter>
        <AuthProvider>
          <AppDataProvider>
            <CurrencyProvider>
            <Toaster
              position="top-center"
              richColors
              toastOptions={{
                style: {
                  fontFamily: "'IBM Plex Sans Arabic', 'Segoe UI', sans-serif",
                  direction: 'rtl',
                  textAlign: 'right',
                },
                duration: 3500,
              }}
            />
            <AppRoutes />
          </CurrencyProvider>
          </AppDataProvider>
        </AuthProvider>
      </BrowserRouter>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
