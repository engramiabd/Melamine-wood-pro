// ========== USER & AUTH TYPES ==========
export type UserRole = 'admin' | 'manager' | 'production_supervisor' | 'worker' | 'accountant' | 'hr';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  avatar_url?: string;
  phone?: string;
  department?: string;
  is_active: boolean;
  created_at: string;
}

// ========== CURRENCY TYPES ==========
export type Currency = 'USD' | 'SYP';

export interface CurrencySettings {
  primary: Currency;
  exchangeRate: number; // SYP per 1 USD
}

// ========== PRODUCT TYPES ==========
export type MelamineThickness = string;
export type MelamineSize = '244x122' | '183x122' | '244x183';
export type MelamineFinish = 'مطفي' | 'لامع' | 'خشبي' | 'سادة';

// ========== BILL OF MATERIALS ==========
// A product's recipe: how much of each raw material is consumed to produce
// ONE finished board. Used to auto-deduct inventory when production is logged.
export interface BOMComponent {
  material_id: string;
  quantity: number; // raw-material units consumed per 1 produced board
}

export interface Product {
  id: string;
  name: string;
  code: string;
  thickness: MelamineThickness;
  size: MelamineSize;
  finish: MelamineFinish;
  color: string;
  price_usd: number;
  price_syp: number;
  cost_usd: number;
  stock_quantity: number;
  min_stock: number;
  description?: string;
  bom?: BOMComponent[]; // optional production recipe (falls back to a standard recipe)
  // ── Factory model (P0): real melamine attributes ──────────────────────────
  faces?: 'وجه' | 'وجهين';   // one face / two faces — drives paper consumption
  grade?: string;            // النخب: نخب أول / ثاني / كسر / صيني / أخضر
  thickness_mm?: number;     // numeric thickness (e.g. 15.5) for matching MDF
  color_number?: number;     // paper colour number (= numeric part of the code)
  created_at: string;
}

// ========== ORDER TYPES ==========
export type OrderStatus = 'pending' | 'in_production' | 'quality_check' | 'completed' | 'cancelled' | 'on_hold';
export type OrderPriority = 'low' | 'normal' | 'high' | 'urgent';

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product?: Product;
  quantity: number;
  unit_price_usd: number;
  unit_price_syp: number;
  total_usd: number;
  total_syp: number;
  /** Soft-delete — sync-safe: set instead of removing */
  deleted_at?: string | null;
}

export type PaymentStatus = 'unpaid' | 'partial' | 'paid';

export interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone?: string;
  customer_address?: string;
  customer_id?: string; // links to Customer entity when selected from the customer database
  status: OrderStatus;
  priority: OrderPriority;
  items: OrderItem[];
  total_usd: number;
  total_syp: number;
  paid_usd: number;       // cumulative amount paid against this order
  payment_status: PaymentStatus;
  notes?: string;
  production_line_id?: string;
  assigned_to?: string;
  created_by: string;
  /** Who moved the order into production (accepted it) and when. */
  accepted_by?: string;
  accepted_at?: string;
  due_date?: string;
  completed_at?: string;
  created_at: string;
  updated_at: string;
}

export interface OrderPayment {
  id: string;
  order_id: string;
  amount_usd: number;
  amount_syp: number;
  method: 'cash' | 'bank_transfer' | 'check' | 'other';
  date: string;
  notes?: string;
  created_at: string;
}

// ========== PRODUCTION LINE TYPES ==========
export type ProductionLineStatus = 'active' | 'idle' | 'maintenance' | 'stopped';

export interface ProductionLine {
  id: string;
  name: string;
  code: string;
  status: ProductionLineStatus;
  capacity_per_day: number;
  current_order_id?: string;
  operator_id?: string;
  efficiency_percentage: number;
  last_maintenance?: string;
  notes?: string;
  created_at: string;
}

export interface ProductionStep {
  id: string;
  order_id: string;
  line_id: string;
  step_name: string;
  step_order: number;
  status: 'pending' | 'in_progress' | 'completed' | 'skipped';
  started_at?: string;
  completed_at?: string;
  notes?: string;
}

// ========== INVENTORY TYPES ==========
export type MaterialCategory = 'raw_material' | 'chemical' | 'packaging' | 'spare_part' | 'other';
export type TransactionType = 'in' | 'out' | 'adjustment' | 'return';

export interface RawMaterial {
  id: string;
  name: string;
  code: string;
  category: MaterialCategory;
  unit: string;
  current_stock: number;
  min_stock: number;
  max_stock: number;
  unit_cost_usd: number;
  unit_cost_syp: number;
  supplier?: string;
  location?: string;
  last_updated: string;
}

export interface InventoryTransaction {
  id: string;
  material_id: string;
  material?: RawMaterial;
  type: TransactionType;
  quantity: number;
  unit_cost_usd: number;
  notes?: string;
  created_by: string;
  created_at: string;
}

// ========== JOURNAL TYPES ==========
export type JournalEntryType = 'income' | 'expense' | 'transfer';
export type PaymentMethod = 'cash' | 'bank_transfer' | 'check' | 'other';

export interface JournalEntry {
  id: string;
  entry_number: string;
  type: JournalEntryType;
  category: string;
  amount_usd: number;
  amount_syp: number;
  currency: Currency;
  payment_method: PaymentMethod;
  description: string;
  reference?: string;
  order_id?: string;
  created_by: string;
  entry_date: string;
  created_at: string;
}

// ========== WORKER WALLET TYPES ==========
export type WalletTransactionType = 'salary' | 'advance' | 'bonus' | 'deduction' | 'overtime';

export interface WorkerWallet {
  id: string;
  worker_id: string;
  worker?: User;
  balance_usd: number;
  balance_syp: number;
  total_earned_usd: number;
  total_deductions_usd: number;
  last_updated: string;
}

export interface WalletTransaction {
  id: string;
  wallet_id: string;
  type: WalletTransactionType;
  amount_usd: number;
  amount_syp: number;
  currency: Currency;
  description: string;
  approved_by?: string;
  created_at: string;
}

// ========== ATTENDANCE TYPES ==========
export type AttendanceStatus = 'present' | 'absent' | 'late' | 'half_day' | 'on_leave';

export interface AttendanceRecord {
  id: string;
  worker_id: string;
  worker?: User;
  date: string;
  check_in?: string;
  check_out?: string;
  status: AttendanceStatus;
  location_lat?: number;
  location_lng?: number;
  notes?: string;
  created_at: string;
}

// ========== HR TYPES ==========
export type LeaveType = 'annual' | 'sick' | 'emergency' | 'unpaid' | 'maternity';
export type LeaveStatus = 'pending' | 'approved' | 'rejected';

export interface Employee {
  id: string;
  user_id: string;
  user?: User;
  employee_number: string;
  department: string;
  position: string;
  hire_date: string;
  salary_usd: number;
  salary_syp: number;
  working_hours: number;
  is_active: boolean;
  /** Soft-delete — sync-safe: set instead of removing */
  deleted_at?: string | null;
}

export interface LeaveRequest {
  id: string;
  employee_id: string;
  employee?: Employee;
  leave_type: LeaveType;
  start_date: string;
  end_date: string;
  days_count: number;
  reason: string;
  status: LeaveStatus;
  approved_by?: string;
  created_at: string;
}

// ========== DASHBOARD TYPES ==========
export interface DashboardStats {
  total_orders: number;
  active_orders: number;
  completed_today: number;
  total_revenue_usd: number;
  total_revenue_syp: number;
  active_production_lines: number;
  total_workers: number;
  present_today: number;
  low_stock_items: number;
  pending_orders: number;
}

// ========== DEMO ACCOUNTS ==========
export interface DemoAccount {
  email: string;
  /** SHA-256 hex digest — never store plaintext passwords */
  passwordHash: string;
  role: UserRole;
  full_name: string;
  description: string;
}

// ========== CUSTOMER TYPES ==========
export type CustomerStatus = 'active' | 'inactive' | 'vip';

export interface Customer {
  id: string;
  name: string;
  phone: string;
  phone2?: string;
  email?: string;
  address?: string;
  city?: string;
  company?: string;
  status: CustomerStatus;
  credit_limit_usd: number;
  balance_usd: number; // outstanding balance (positive = owes us)
  notes?: string;
  created_at: string;
  updated_at: string;
  /** Soft-delete — sync-safe: set instead of removing */
  deleted_at?: string | null;
}

// ========== INVOICE TYPES ==========
export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'partial' | 'overdue' | 'cancelled';
export type InvoiceType = 'sale' | 'quotation';

export interface InvoicePayment {
  id: string;
  invoice_id: string;
  amount_usd: number;
  amount_syp: number;
  method: 'cash' | 'bank_transfer' | 'check' | 'other';
  date: string;
  notes?: string;
  created_at: string;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  type: InvoiceType;
  order_id?: string;
  customer_id: string;
  customer_name: string;
  customer_phone?: string;
  customer_address?: string;
  items: InvoiceItem[];
  subtotal_usd: number;
  subtotal_syp: number;
  tax_rate: number;       // percentage e.g. 0, 5, 10
  tax_usd: number;
  tax_syp: number;
  discount_usd: number;
  discount_syp: number;
  total_usd: number;
  total_syp: number;
  paid_usd: number;
  remaining_usd: number;
  status: InvoiceStatus;
  due_date?: string;
  notes?: string;
  created_by: string;
  issued_date: string;
  created_at: string;
  updated_at: string;
}

export interface InvoiceItem {
  id: string;
  invoice_id: string;
  product_id?: string;
  description: string;
  quantity: number;
  unit_price_usd: number;
  unit_price_syp: number;
  total_usd: number;
  total_syp: number;
}

// ========== PRODUCT MANAGEMENT TYPES ==========
// Extended to support full CRUD (products were previously static demo data)
export interface ProductCategory {
  id: string;
  name: string;
  color: string;
}

// ========== AUDIT LOG (Phase 3) ==========
// Immutable trail of significant actions across the system, for accountability.
export interface AuditEntry {
  id: string;
  timestamp: string;
  actor: string;          // who performed it (user full name, or 'النظام')
  actor_role?: string;
  action: string;         // machine key, e.g. 'order.status', 'invoice.payment'
  entity_type: string;    // 'order' | 'invoice' | 'inventory' | 'production' | 'purchase' | 'wallet'
  entity_id?: string;
  summary: string;        // human-readable Arabic description
  amount_usd?: number;    // optional monetary value involved
}

// ========== SUPPLIERS & PURCHASING (Phase 3) ==========
export interface Supplier {
  id: string;
  name: string;
  contact_person?: string;
  phone?: string;
  email?: string;
  address?: string;
  category?: string;          // what they supply (e.g. خشب، كيماويات)
  balance_usd: number;        // outstanding amount we owe them
  notes?: string;
  is_active: boolean;
  created_at: string;
}

export type PurchaseOrderStatus = 'draft' | 'sent' | 'received' | 'cancelled';

export interface PurchaseOrderItem {
  material_id: string;        // links to an inventory item
  material_name: string;
  quantity: number;
  unit: string;
  unit_cost_usd: number;
  total_usd: number;
}

export interface PurchaseOrder {
  id: string;
  po_number: string;
  supplier_id: string;
  supplier_name: string;
  items: PurchaseOrderItem[];
  total_usd: number;
  total_syp: number;
  status: PurchaseOrderStatus;
  order_date: string;
  received_date?: string;
  notes?: string;
  created_by: string;
  created_at: string;
}

// ========== PAYROLL FROM ATTENDANCE (Phase 3) ==========
export interface PayrollBreakdown {
  employee_id: string;
  employee_name: string;
  year: number;
  month: number;            // 1-12
  working_days: number;     // scheduled working days counted
  present_days: number;
  absent_days: number;
  late_days: number;
  leave_days: number;
  worked_hours: number;
  expected_hours: number;
  overtime_hours: number;
  base_salary_usd: number;
  overtime_pay_usd: number;
  absence_deduction_usd: number;
  late_deduction_usd: number;
  net_salary_usd: number;
}

// ========== STOCKTAKE / RECONCILIATION (P2) ==========
export type StocktakeWarehouse = 'melamine' | 'mdf' | 'paper';
export interface StocktakeLine {
  ref_id: string;          // inventory item id (mdf/paper) or product id (melamine)
  name: string;
  code: string;
  unit: string;
  system_qty: number;
  counted_qty: number;
}
export interface Stocktake {
  id: string;
  date: string;
  warehouse: StocktakeWarehouse;
  status: 'draft' | 'applied';
  lines: StocktakeLine[];
  created_by: string;
  notes?: string;
  created_at: string;
}

// ========== PRODUCTION PLANNING (P2) ==========
export interface PlanItem {
  product_id: string;
  product_name: string;
  code: string;
  target_qty: number;
}
export interface ProductionPlan {
  id: string;
  title: string;
  plan_date: string;
  status: 'active' | 'completed';
  items: PlanItem[];
  created_by: string;
  notes?: string;
  created_at: string;
}

// ========== OPERATIONAL ERROR LOG (P3-partial) ==========
export interface ErrorLogEntry {
  id: string;
  timestamp: string;
  level: 'error' | 'warning';
  source: string;   // the operation/function that failed
  message: string;
  context?: string;
}
