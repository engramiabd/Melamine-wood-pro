// ── Optional AI layer ────────────────────────────────────────────────────────
// Forwards free-form questions to a configurable LLM endpoint. No keys are
// bundled: the admin provides an endpoint + key (stored locally). When nothing
// is configured the assistant stays fully functional on the local insights
// engine and simply tells the user the AI service is off.
//
// The request uses the Anthropic Messages API shape; point `ai_endpoint` either
// at a self-hosted proxy (recommended, keeps the key off the client) or, for
// internal use, directly at the provider.

const KEYS = {
  endpoint: 'ai_endpoint',
  apiKey: 'ai_api_key',
  model: 'ai_model',
} as const;

export interface AIConfig {
  endpoint: string;
  apiKey: string;
  model: string;
}

export function getAIConfig(): AIConfig {
  let endpoint = '', apiKey = '', model = '';
  try {
    endpoint = localStorage.getItem(KEYS.endpoint) || '';
    apiKey = localStorage.getItem(KEYS.apiKey) || '';
    model = localStorage.getItem(KEYS.model) || '';
  } catch { /* storage unavailable */ }
  return { endpoint, apiKey, model: model || 'claude-haiku-4-5-20251001' };
}

export function setAIConfig(cfg: Partial<AIConfig>): void {
  try {
    if (cfg.endpoint !== undefined) localStorage.setItem(KEYS.endpoint, cfg.endpoint);
    if (cfg.apiKey !== undefined) localStorage.setItem(KEYS.apiKey, cfg.apiKey);
    if (cfg.model !== undefined) localStorage.setItem(KEYS.model, cfg.model);
  } catch { /* ignore */ }
}

export function isAIConfigured(): boolean {
  const c = getAIConfig();
  return Boolean(c.endpoint && c.apiKey);
}

export interface AIResult {
  ok: boolean;
  text?: string;
  reason?: 'not_configured' | 'network' | 'bad_response';
}

const SYSTEM = [
  'أنت مساعد ذكي داخل تطبيق إدارة مصنع ميلامين.',
  'تجيب بالعربية بإيجاز ودقّة، معتمداً فقط على «بيانات المصنع» المرفقة.',
  'إن لم تكفِ البيانات للإجابة، قل ذلك بوضوح ولا تختلق أرقاماً.',
].join(' ');

export async function askAI(question: string, contextSummary: string, timeoutMs = 20000): Promise<AIResult> {
  const cfg = getAIConfig();
  if (!cfg.endpoint || !cfg.apiKey) return { ok: false, reason: 'not_configured' };

  const body = {
    model: cfg.model,
    max_tokens: 1024,
    system: SYSTEM,
    messages: [
      { role: 'user', content: `بيانات المصنع الحالية:\n${contextSummary}\n\nالسؤال: ${question}` },
    ],
  };

  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    const res = await fetch(cfg.endpoint, {
      method: 'POST',
      signal: ctrl.signal,
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': cfg.apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify(body),
    });
    clearTimeout(timer);
    if (!res.ok) return { ok: false, reason: 'bad_response' };
    const data = await res.json();
    // Anthropic shape: { content: [{ type:'text', text:'...' }] }
    const text = Array.isArray(data?.content)
      ? data.content.filter((b: { type?: string }) => b?.type === 'text').map((b: { text?: string }) => b.text || '').join('\n').trim()
      : (data?.text || data?.message || '');
    if (!text) return { ok: false, reason: 'bad_response' };
    return { ok: true, text };
  } catch {
    return { ok: false, reason: 'network' };
  }
}
