// ── Predictive shortage forecasting ──────────────────────────────────────────
// Estimates when each finished product will run out, using real demand from
// order history (order items + dates) — not just "already below minimum". This
// turns the static low-stock list into a forward-looking "will run out in N days".

import type { Order, Product } from '../types';

export interface ProductForecast {
  productId: string;
  name: string;
  stock: number;
  dailyDemand: number;       // average units/day over the window
  daysLeft: number;          // Infinity when there is no recent demand
  stockoutDate: string | null;
  severity: 'critical' | 'warning' | 'ok';
}

const DAY = 86_400_000;

/**
 * Average daily demand per product from non-cancelled orders within the trailing
 * `windowDays`, projected against current stock to estimate days-to-stockout.
 */
export function productDemandForecast(orders: Order[], products: Product[], windowDays = 30): ProductForecast[] {
  const now = Date.now();
  const cutoff = now - windowDays * DAY;

  const demand = new Map<string, number>();
  for (const o of orders) {
    if (o.status === 'cancelled') continue;
    const t = Date.parse(o.created_at || '');
    if (!isFinite(t) || t < cutoff) continue;
    for (const it of o.items || []) {
      if (!it.product_id) continue;
      demand.set(it.product_id, (demand.get(it.product_id) || 0) + (it.quantity || 0));
    }
  }

  const out: ProductForecast[] = [];
  for (const p of products) {
    const total = demand.get(p.id) || 0;
    const dailyDemand = total / windowDays;
    const daysLeft = dailyDemand > 0 ? p.stock_quantity / dailyDemand : Infinity;
    let severity: ProductForecast['severity'] = 'ok';
    if (dailyDemand > 0) {
      if (daysLeft <= 7) severity = 'critical';
      else if (daysLeft <= 14) severity = 'warning';
    }
    const stockoutDate = isFinite(daysLeft)
      ? new Date(now + daysLeft * DAY).toISOString().slice(0, 10)
      : null;
    out.push({ productId: p.id, name: p.name, stock: p.stock_quantity, dailyDemand, daysLeft, stockoutDate, severity });
  }

  return out
    .filter(f => f.dailyDemand > 0)
    .sort((a, b) => a.daysLeft - b.daysLeft);
}

export function atRisk(forecasts: ProductForecast[]) {
  return {
    critical: forecasts.filter(f => f.severity === 'critical'),
    warning: forecasts.filter(f => f.severity === 'warning'),
  };
}
