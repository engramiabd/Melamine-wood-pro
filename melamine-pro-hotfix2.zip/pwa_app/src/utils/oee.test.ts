import { describe, it, expect } from 'vitest';
import { computeOEE, oeeColor } from './oee';
import type { ProductionLineExtended } from '../lib/demoData';

const line = (over: Partial<ProductionLineExtended>): ProductionLineExtended =>
  ({
    id: 'pl', name: 'L', code: 'L', status: 'active', capacity_per_day: 200,
    efficiency_percentage: 0, created_at: '', operating_cost_usd: 0,
    total_produced_today: 0, total_defective_today: 0, production_speed: 0,
    ...over,
  } as ProductionLineExtended);

const shift = { workStartTime: '08:00', workEndTime: '17:00' }; // 540 min

describe('computeOEE', () => {
  it('combines availability × performance × quality', () => {
    const r = computeOEE(
      line({ capacity_per_day: 200, total_produced_today: 150, total_defective_today: 10, stop_duration: '01:00:00' }),
      shift,
    );
    expect(r.availability).toBeCloseTo(480 / 540, 4); // 60 min downtime
    expect(r.performance).toBeCloseTo(0.75, 4);        // 150/200
    expect(r.quality).toBeCloseTo(140 / 150, 4);       // good/total
    expect(r.oee).toBeCloseTo(r.availability * r.performance * r.quality, 6);
  });

  it('is 0 when nothing produced, with quality defaulting to 1', () => {
    const r = computeOEE(line({ total_produced_today: 0, total_defective_today: 0 }), shift);
    expect(r.performance).toBe(0);
    expect(r.quality).toBe(1);
    expect(r.oee).toBe(0);
  });

  it('clamps all factors to the 0..1 range', () => {
    const r = computeOEE(
      line({ capacity_per_day: 100, total_produced_today: 500, stop_duration: '99:00:00' }),
      shift,
    );
    expect(r.performance).toBeLessThanOrEqual(1);
    expect(r.availability).toBeGreaterThanOrEqual(0);
  });
});

describe('oeeColor', () => {
  it('bands OEE into world-class / acceptable / poor', () => {
    expect(oeeColor(0.9)).toBe('#16a34a');
    expect(oeeColor(0.7)).toBe('#f59e0b');
    expect(oeeColor(0.4)).toBe('#ef4444');
  });
});
