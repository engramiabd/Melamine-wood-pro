import { describe, it, expect, vi, afterEach } from 'vitest';
import { fetchUsdToSypRate } from './exchangeRate';

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('fetchUsdToSypRate', () => {
  it('returns a rounded rate on success', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => ({
      ok: true,
      json: async () => ({ rates: { SYP: 14500.6 } }),
    })));
    const r = await fetchUsdToSypRate(100);
    expect(r).not.toBeNull();
    expect(r!.rate).toBe(14501);
    expect(typeof r!.fetchedAt).toBe('string');
  });

  it('returns null when every provider throws', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => { throw new Error('offline'); }));
    const r = await fetchUsdToSypRate(50);
    expect(r).toBeNull();
  });

  it('returns null on malformed data', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => ({ ok: true, json: async () => ({ rates: {} }) })));
    const r = await fetchUsdToSypRate(50);
    expect(r).toBeNull();
  });

  it('skips a non-ok response', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => ({ ok: false, json: async () => ({}) })));
    const r = await fetchUsdToSypRate(50);
    expect(r).toBeNull();
  });
});
