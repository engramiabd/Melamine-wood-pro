import { describe, it, expect } from 'vitest';
import { computePayroll } from './payroll';
import type { Employee, AttendanceRecord } from '../types';

const emp: Employee = {
  id: 'e1', user_id: 'u1', employee_number: 'EMP-1', department: 'prod',
  position: 'مشغّل', hire_date: '2024-01-01', salary_usd: 3000, salary_syp: 0,
  working_hours: 8, is_active: true,
};

const rec = (over: Partial<AttendanceRecord>): AttendanceRecord => ({
  id: Math.random().toString(), worker_id: 'u1', date: '2026-03-01',
  status: 'present', created_at: '', ...over,
});

const records: AttendanceRecord[] = [
  rec({ date: '2026-03-01', status: 'present', check_in: '08:00', check_out: '17:00' }), // 9h → +1 overtime
  rec({ date: '2026-03-02', status: 'absent' }),
  rec({ date: '2026-03-03', status: 'late', check_in: '09:00', check_out: '17:00' }),    // 8h
  rec({ date: '2026-03-04', status: 'on_leave' }),
  rec({ date: '2026-03-05', status: 'present', worker_id: 'u2' }),  // other worker — ignored
  rec({ date: '2026-02-10', status: 'present' }),                   // other month — ignored
];

describe('computePayroll', () => {
  const pr = computePayroll(emp, records, 2026, 3);

  it('counts each attendance status for the correct worker and month', () => {
    expect(pr.present_days).toBe(2); // present + late
    expect(pr.absent_days).toBe(1);
    expect(pr.late_days).toBe(1);
    expect(pr.leave_days).toBe(1);
    expect(pr.working_days).toBe(4); // present + absent + leave
  });

  it('derives worked hours and overtime from check-in/out times', () => {
    expect(pr.worked_hours).toBe(17);   // 9 + 8
    expect(pr.overtime_hours).toBe(1);  // 17 - 2*8
    expect(pr.expected_hours).toBe(24); // (present 2 + absent 1) * 8
  });

  it('applies overtime pay and absence/late deductions to the net', () => {
    // perDay = 3000/4 = 750 ; perHour = 93.75
    expect(pr.overtime_pay_usd).toBeCloseTo(140.63, 2);   // 1 * 93.75 * 1.5
    expect(pr.absence_deduction_usd).toBe(750);           // 1 day
    expect(pr.late_deduction_usd).toBeCloseTo(46.88, 2);  // 93.75 * 0.5
    expect(pr.net_salary_usd).toBeCloseTo(2343.75, 2);    // 3000 + 140.625 - 750 - 46.875
  });

  it('never returns a negative net salary', () => {
    const broke: Employee = { ...emp, salary_usd: 100 };
    const many = Array.from({ length: 20 }, (_, i) =>
      rec({ date: `2026-03-${String(i + 1).padStart(2, '0')}`, status: 'absent' }));
    expect(computePayroll(broke, many, 2026, 3).net_salary_usd).toBeGreaterThanOrEqual(0);
  });
});
