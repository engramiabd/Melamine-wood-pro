import type { ProductionLineExtended } from '../lib/demoData';

// ─── OEE (Overall Equipment Effectiveness) ──────────────────────────────────
// OEE = Availability × Performance × Quality. A single, industry-standard
// health score for a production line. Computed from the data the app already
// tracks (downtime, output, defects, capacity) plus the shift length.

export interface OEEResult {
  availability: number; // 0..1 — uptime vs planned time
  performance: number;  // 0..1 — actual output vs ideal output
  quality: number;      // 0..1 — good units vs total produced
  oee: number;          // 0..1 — the product of the three
}

function durationToMinutes(hhmmss?: string): number {
  if (!hhmmss) return 0;
  const parts = hhmmss.split(':').map(Number);
  if (parts.some((n) => Number.isNaN(n))) return 0;
  const [h = 0, m = 0, s = 0] = parts;
  return h * 60 + m + s / 60;
}

function plannedMinutes(workStart: string, workEnd: string): number {
  const toMin = (t: string) => {
    const [h, m] = (t || '').split(':').map(Number);
    return (h || 0) * 60 + (m || 0);
  };
  const diff = toMin(workEnd) - toMin(workStart);
  return diff > 0 ? diff : 540; // default to a 9-hour shift
}

export function computeOEE(
  line: ProductionLineExtended,
  opts: { workStartTime: string; workEndTime: string },
): OEEResult {
  const planned = plannedMinutes(opts.workStartTime, opts.workEndTime);
  const downtime = durationToMinutes(line.stop_duration);
  const availability = planned > 0 ? Math.max(0, Math.min(1, (planned - downtime) / planned)) : 0;

  const produced = line.total_produced_today || 0;
  const defective = line.total_defective_today || 0;
  const capacity = line.capacity_per_day || 0;

  // Performance: produced vs the ideal full-shift capacity.
  const performance = capacity > 0 ? Math.max(0, Math.min(1, produced / capacity)) : 0;
  // Quality: good boards / total produced (1 when nothing produced yet).
  const quality = produced > 0 ? Math.max(0, Math.min(1, (produced - defective) / produced)) : 1;

  return { availability, performance, quality, oee: availability * performance * quality };
}

// World-class OEE is ~85%. These bands drive the colour coding in the UI.
export function oeeColor(oee: number): string {
  if (oee >= 0.85) return '#16a34a'; // green — world class
  if (oee >= 0.6) return '#f59e0b';  // amber — acceptable
  return '#ef4444';                  // red — needs attention
}
