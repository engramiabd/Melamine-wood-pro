// ── WhatsApp notifications (click-to-send) ───────────────────────────────────
// Uses wa.me deep links — no API key, no backend, works offline-first. Opens
// WhatsApp (app or web) with the recipient + a pre-filled Arabic message that
// the user reviews and sends. Ideal for order updates, invoices, reminders.

/** Normalise a local phone number to international digits (default Syria 963). */
export function normalizePhone(phone: string, defaultCountry = '963'): string {
  let p = (phone || '').replace(/[^\d+]/g, '');
  if (p.startsWith('+')) return p.slice(1);
  if (p.startsWith('00')) return p.slice(2);
  if (p.startsWith('0')) return defaultCountry + p.slice(1);     // 09xx → 9639xx
  if (p.startsWith(defaultCountry)) return p;
  // Bare local mobile (e.g. 9xxxxxxxx) → prepend country code.
  if (p.length && !p.startsWith(defaultCountry)) return defaultCountry + p;
  return p;
}

export function buildWhatsAppLink(phone: string, message: string): string {
  const to = normalizePhone(phone);
  return `https://wa.me/${to}?text=${encodeURIComponent(message)}`;
}

/** Opens WhatsApp with the message pre-filled. Returns false if no phone. */
export function sendWhatsApp(phone: string, message: string): boolean {
  if (!phone || !normalizePhone(phone)) return false;
  const url = buildWhatsAppLink(phone, message);
  try { window.open(url, '_blank', 'noopener'); return true; } catch { return false; }
}

// ── Message templates (Arabic) ───────────────────────────────────────────────

const ORDER_STATUS_AR: Record<string, string> = {
  pending: 'قيد المراجعة',
  in_production: 'قيد الإنتاج',
  quality_check: 'قيد فحص الجودة',
  completed: 'جاهز للتسليم',
  on_hold: 'مُعلّق مؤقتاً',
  cancelled: 'ملغى',
};

export function orderStatusMessage(opts: {
  factory: string; customerName: string; orderNumber: string; status: string;
}): string {
  const st = ORDER_STATUS_AR[opts.status] || opts.status;
  return `مرحباً ${opts.customerName}،\n`
    + `طلبكم رقم ${opts.orderNumber} لدى ${opts.factory}.\n`
    + `الحالة الحالية: ${st}.\n`
    + `شكراً لتعاملكم معنا.`;
}

export function invoiceMessage(opts: {
  factory: string; customerName: string; invoiceNumber: string; total: string; remaining: string;
}): string {
  return `مرحباً ${opts.customerName}،\n`
    + `فاتورتكم رقم ${opts.invoiceNumber} من ${opts.factory}.\n`
    + `الإجمالي: ${opts.total} • المتبقّي: ${opts.remaining}.\n`
    + `للاستفسار يرجى التواصل معنا.`;
}

export function paymentReminderMessage(opts: {
  factory: string; customerName: string; amount: string;
}): string {
  return `تذكير ودّي من ${opts.factory}.\n`
    + `مرحباً ${opts.customerName}، لديكم مبلغ مستحق قدره ${opts.amount}.\n`
    + `نرجو ترتيب السداد في أقرب وقت ممكن. شكراً لكم.`;
}
