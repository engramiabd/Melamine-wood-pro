// Live USD→SYP reference rate (offline-first).
//
// IMPORTANT: public FX APIs report the *official* Syrian Pound rate, which can
// differ substantially from the local market rate a factory actually uses.
// Therefore the fetched value is treated as a *reference for the admin to
// review and confirm* — never an automatic, silent override of the configured
// rate. On any failure (offline, blocked, malformed) we return null so the
// caller keeps the manually configured `systemSettings.exchangeRate`.

export interface RateResult {
  rate: number;       // USD → SYP, rounded
  source: string;     // provider host
  fetchedAt: string;  // ISO timestamp
}

const ENDPOINTS = [
  'https://open.er-api.com/v6/latest/USD',
  'https://api.exchangerate.host/latest?base=USD&symbols=SYP',
];

function extractSyp(data: unknown): number | null {
  const rates = (data as { rates?: Record<string, number> })?.rates;
  const v = rates?.SYP;
  return typeof v === 'number' && isFinite(v) && v > 0 ? v : null;
}

/**
 * Try each provider in order with a timeout. Returns the first valid rate, or
 * null if every provider fails (so the caller falls back to the manual rate).
 */
export async function fetchUsdToSypRate(timeoutMs = 8000): Promise<RateResult | null> {
  for (const url of ENDPOINTS) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeoutMs);
      const res = await fetch(url, { signal: ctrl.signal });
      clearTimeout(timer);
      if (!res.ok) continue;
      const data = await res.json();
      const rate = extractSyp(data);
      if (rate == null) continue;
      let host = 'مزوّد خارجي';
      try { host = new URL(url).host; } catch { /* ignore */ }
      return { rate: Math.round(rate), source: host, fetchedAt: new Date().toISOString() };
    } catch {
      // try next endpoint
    }
  }
  return null;
}
