import { describe, it, expect } from 'vitest';
import { computeInvoiceFromOrder } from './invoicing';
import type { Order } from '../types';

const order = (over: Partial<Order>): Order => ({
  id: 'o1', order_number: 'ORD-1', customer_name: 'عميل', status: 'completed',
  priority: 'normal', payment_status: 'partial',
  items: [
    { product_id: 'p1', product: { name: 'لوح' } as any, quantity: 2, unit_price_usd: 100, unit_price_syp: 0, total_usd: 200, total_syp: 0 },
    { product_id: 'p2', quantity: 1, unit_price_usd: 800, unit_price_syp: 0, total_usd: 800, total_syp: 0 },
  ],
  total_usd: 1000, total_syp: 0, paid_usd: 400, created_at: '',
  ...over,
} as Order);

describe('computeInvoiceFromOrder', () => {
  it('mirrors the order total exactly (tax 0) — the anti double-count rule', () => {
    const fin = computeInvoiceFromOrder(order({}));
    expect(fin.tax_rate).toBe(0);
    expect(fin.total_usd).toBe(1000);
    expect(fin.subtotal_usd).toBe(1000);
  });

  it('carries the already-paid amount and bills only the remainder', () => {
    const fin = computeInvoiceFromOrder(order({ paid_usd: 400 }));
    expect(fin.paid_usd).toBe(400);
    expect(fin.remaining_usd).toBe(600);
    expect(fin.status).toBe('partial');
  });

  it('marks fully paid orders as paid with no remainder', () => {
    const fin = computeInvoiceFromOrder(order({ paid_usd: 1000 }));
    expect(fin.remaining_usd).toBe(0);
    expect(fin.status).toBe('paid');
  });

  it('marks unpaid orders as sent with the full amount outstanding', () => {
    const fin = computeInvoiceFromOrder(order({ paid_usd: 0 }));
    expect(fin.remaining_usd).toBe(1000);
    expect(fin.status).toBe('sent');
  });

  it('maps order items into invoice lines', () => {
    const fin = computeInvoiceFromOrder(order({}));
    expect(fin.items).toHaveLength(2);
    expect(fin.items[0].description).toBe('لوح');
    expect(fin.items[1].description).toBe('منتج'); // fallback when product missing
  });
});
