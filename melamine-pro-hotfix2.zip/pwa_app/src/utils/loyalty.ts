// ── Loyalty & rewards engine ─────────────────────────────────────────────────
// Pure, offline computation of worker attendance points, streaks, tiers and
// badges from the existing AttendanceRecord data. Positive-reinforcement by
// design: points are a reward *on top of* wages, approved leave is neutral
// (never breaks a streak), and absence is the only thing that resets streaks.
// All numbers are configurable (admin), stored locally.

import type { AttendanceRecord } from '../types';

export interface LoyaltyConfig {
  points: { present: number; late: number; halfDay: number; onLeave: number; absent: number };
  weekStreakBonus: number;   // per completed 6-day run
  monthStreakBonus: number;  // per completed 26-day run
  pointValueUsd: number;     // 1 point → USD (for reward payout)
  tiers: { name: string; min: number; color: string; icon: string }[];
}

export const DEFAULT_LOYALTY_CONFIG: LoyaltyConfig = {
  points: { present: 10, late: 3, halfDay: 5, onLeave: 0, absent: -10 },
  weekStreakBonus: 20,
  monthStreakBonus: 100,
  pointValueUsd: 0.1,
  tiers: [
    { name: 'برونزي', min: 0, color: '#cd7f32', icon: '🥉' },
    { name: 'فضّي', min: 200, color: '#9ca3af', icon: '🥈' },
    { name: 'ذهبي', min: 400, color: '#f59e0b', icon: '🥇' },
    { name: 'بلاتيني', min: 600, color: '#22d3ee', icon: '💎' },
  ],
};

const CONFIG_KEY = 'loyalty_config';

export function getLoyaltyConfig(): LoyaltyConfig {
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_LOYALTY_CONFIG, ...parsed, points: { ...DEFAULT_LOYALTY_CONFIG.points, ...(parsed.points || {}) } };
    }
  } catch { /* ignore */ }
  return DEFAULT_LOYALTY_CONFIG;
}

export function setLoyaltyConfig(cfg: LoyaltyConfig): void {
  try { localStorage.setItem(CONFIG_KEY, JSON.stringify(cfg)); } catch { /* ignore */ }
}

export interface Badge { id: string; label: string; icon: string }

export interface WorkerLoyalty {
  workerId: string;
  totalPoints: number;
  basePoints: number;
  streakBonus: number;
  currentStreak: number;
  longestStreak: number;
  tier: { name: string; color: string; icon: string };
  nextTier: { name: string; min: number } | null;
  toNextTier: number;
  badges: Badge[];
  counts: { present: number; late: number; halfDay: number; absent: number; onLeave: number; total: number };
  rewardUsd: number;
}

function dayPoints(status: AttendanceRecord['status'], cfg: LoyaltyConfig): number {
  switch (status) {
    case 'present': return cfg.points.present;
    case 'late': return cfg.points.late;
    case 'half_day': return cfg.points.halfDay;
    case 'on_leave': return cfg.points.onLeave;
    case 'absent': return cfg.points.absent;
    default: return 0;
  }
}

const isGood = (s: AttendanceRecord['status']) => s === 'present' || s === 'late' || s === 'half_day';

export function tierFor(points: number, cfg: LoyaltyConfig) {
  const sorted = [...cfg.tiers].sort((a, b) => a.min - b.min);
  let current = sorted[0];
  for (const t of sorted) if (points >= t.min) current = t;
  const next = sorted.find(t => t.min > current.min) || null;
  return { current, next };
}

export function computeWorkerLoyalty(
  workerId: string,
  records: AttendanceRecord[],
  cfg: LoyaltyConfig = getLoyaltyConfig(),
): WorkerLoyalty {
  const mine = records
    .filter(r => r.worker_id === workerId)
    .sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));

  const counts = { present: 0, late: 0, halfDay: 0, absent: 0, onLeave: 0, total: mine.length };
  let basePoints = 0;
  let longestStreak = 0;
  let run = 0;

  for (const r of mine) {
    basePoints += dayPoints(r.status, cfg);
    if (r.status === 'present') counts.present++;
    else if (r.status === 'late') counts.late++;
    else if (r.status === 'half_day') counts.halfDay++;
    else if (r.status === 'absent') counts.absent++;
    else if (r.status === 'on_leave') counts.onLeave++;

    if (r.status === 'absent') run = 0;
    else if (isGood(r.status)) { run++; if (run > longestStreak) longestStreak = run; }
    // on_leave: neutral — neither breaks nor extends
  }

  // current streak: walk back from the latest record until an absence
  let currentStreak = 0;
  for (let i = mine.length - 1; i >= 0; i--) {
    const s = mine[i].status;
    if (s === 'absent') break;
    if (isGood(s)) currentStreak++;
    // on_leave: skip
  }

  const weekBlocks = Math.floor(longestStreak / 6);
  const monthBlocks = Math.floor(longestStreak / 26);
  const streakBonus = weekBlocks * cfg.weekStreakBonus + monthBlocks * cfg.monthStreakBonus;

  const totalPoints = Math.max(0, basePoints + streakBonus);
  const { current, next } = tierFor(totalPoints, cfg);

  const badges: Badge[] = [];
  if (counts.absent === 0 && counts.total >= 5) badges.push({ id: 'perfect', label: 'حضور مثالي', icon: '🌟' });
  if (counts.late === 0 && counts.present >= 5) badges.push({ id: 'punctual', label: 'ملتزم بالمواعيد', icon: '⏰' });
  if (currentStreak >= 6) badges.push({ id: 'week', label: 'سلسلة أسبوع', icon: '🔥' });
  if (longestStreak >= 26) badges.push({ id: 'month', label: 'سلسلة شهر', icon: '🏆' });
  if (totalPoints >= 400) badges.push({ id: 'champion', label: 'عامل متميّز', icon: '💪' });

  return {
    workerId,
    totalPoints,
    basePoints,
    streakBonus,
    currentStreak,
    longestStreak,
    tier: { name: current.name, color: current.color, icon: current.icon },
    nextTier: next ? { name: next.name, min: next.min } : null,
    toNextTier: next ? Math.max(0, next.min - totalPoints) : 0,
    badges,
    counts,
    rewardUsd: Math.round(totalPoints * cfg.pointValueUsd * 100) / 100,
  };
}

/** Leaderboard across all worker ids that appear in the records (or a given list). */
export function computeLeaderboard(
  records: AttendanceRecord[],
  workerIds?: string[],
  cfg: LoyaltyConfig = getLoyaltyConfig(),
): WorkerLoyalty[] {
  const ids = workerIds && workerIds.length
    ? workerIds
    : Array.from(new Set(records.map(r => r.worker_id)));
  return ids
    .map(id => computeWorkerLoyalty(id, records, cfg))
    .sort((a, b) => b.totalPoints - a.totalPoints);
}

// ── Redemption tracking ──────────────────────────────────────────────────────
// Points are recomputed from attendance every time, so to avoid paying the same
// points twice we remember how many points each worker has already been paid for.
// "Unredeemed" points = totalPoints − redeemed.

const REDEEM_KEY = 'loyalty_redeemed';

function readRedeemed(): Record<string, number> {
  try { return JSON.parse(localStorage.getItem(REDEEM_KEY) || '{}') || {}; } catch { return {}; }
}

export function getRedeemed(workerId: string): number {
  return readRedeemed()[workerId] || 0;
}

export function setRedeemed(workerId: string, points: number): void {
  try {
    const all = readRedeemed();
    all[workerId] = points;
    localStorage.setItem(REDEEM_KEY, JSON.stringify(all));
  } catch { /* ignore */ }
}

export function unredeemed(workerId: string, totalPoints: number): number {
  return Math.max(0, totalPoints - getRedeemed(workerId));
}

// ── Employee of the month ────────────────────────────────────────────────────

/** 'YYYY-MM' for a date (defaults to now). */
export function currentMonthKey(d: Date = new Date()): string {
  return d.toISOString().slice(0, 7);
}

/** Records whose date falls in the given 'YYYY-MM'. */
export function filterByMonth(records: AttendanceRecord[], ym: string): AttendanceRecord[] {
  return records.filter(r => (r.date || '').slice(0, 7) === ym);
}

/** Top worker for a given month (or null if no one scored above zero). */
export function monthlyChampion(
  records: AttendanceRecord[],
  workerIds: string[],
  ym: string = currentMonthKey(),
  cfg: LoyaltyConfig = getLoyaltyConfig(),
): WorkerLoyalty | null {
  const board = computeLeaderboard(filterByMonth(records, ym), workerIds, cfg);
  const top = board[0];
  return top && top.totalPoints > 0 ? top : null;
}

// ── Tier-up detection (for notifications) ────────────────────────────────────

const TIER_KEY = 'loyalty_last_tier';

function readLastTiers(): Record<string, string> {
  try { return JSON.parse(localStorage.getItem(TIER_KEY) || '{}') || {}; } catch { return {}; }
}

/**
 * Compares a worker's current tier against the last one we recorded. Returns the
 * new tier name only when the worker moved UP a tier (and persists it), so the
 * caller can fire a one-time congratulation. Returns null otherwise.
 */
export function detectTierUp(workerId: string, currentTier: string, cfg: LoyaltyConfig = getLoyaltyConfig()): string | null {
  const order = [...cfg.tiers].sort((a, b) => a.min - b.min).map(t => t.name);
  const all = readLastTiers();
  const prev = all[workerId];
  const prevIdx = prev ? order.indexOf(prev) : -1;
  const curIdx = order.indexOf(currentTier);
  if (curIdx > prevIdx) {
    all[workerId] = currentTier;
    try { localStorage.setItem(TIER_KEY, JSON.stringify(all)); } catch { /* ignore */ }
    // Only announce a real upgrade (not the first-ever baseline record).
    return prev !== undefined ? currentTier : null;
  }
  return null;
}
