import { describe, it, expect } from 'vitest';
import { resolveConsumption, deductStock, STANDARD_BOM_BY_CODE, resolveFactoryConsumption, hasFactoryBom } from './bom';
import type { Product } from '../types';
import type { InventoryItem } from '../contexts/appData.types';

const item = (id: string, code: string): InventoryItem => ({
  id, name: id, code, unit: 'u', stock_quantity: 100, reorder_level: 10,
  max_quantity: 1000, current_price: 1, category: 'raw_material', created_at: '', updated_at: '',
});

const inventory: InventoryItem[] = [
  item('m1', 'RAW-MPW'), item('m2', 'RAW-HDF18'), item('m3', 'CHEM-MR'),
  item('m4', 'CHEM-UF'), item('m5', 'RAW-PVC-W'), item('m6', 'PKG-BOX'),
];

describe('resolveConsumption', () => {
  it('uses the product BOM when present', () => {
    const product = { id: 'p1', bom: [{ material_id: 'm2', quantity: 3 }] } as Product;
    expect(resolveConsumption(product, inventory)).toEqual([{ id: 'm2', qty: 3 }]);
  });

  it('falls back to the standard recipe resolved by code', () => {
    const res = resolveConsumption(undefined, inventory);
    expect(res).toHaveLength(STANDARD_BOM_BY_CODE.length);
    expect(res.find((c) => c.id === 'm2')).toEqual({ id: 'm2', qty: 1 });
    expect(res.find((c) => c.id === 'm6')).toEqual({ id: 'm6', qty: 0.1 });
  });

  it('skips standard materials missing from inventory', () => {
    const partial = [item('m2', 'RAW-HDF18')];
    expect(resolveConsumption(undefined, partial)).toEqual([{ id: 'm2', qty: 1 }]);
  });
});

describe('deductStock', () => {
  it('subtracts perBoard × produced', () => {
    expect(deductStock(100, 0.5, 10)).toBe(95);
  });
  it('never goes below zero', () => {
    expect(deductStock(3, 1, 10)).toBe(0);
  });
});

describe('resolveFactoryConsumption', () => {
  const stock = [
    { ...item('mdf155', 'MDF-15.5') },
    { ...item('p16', 'PAPER-16') },
    { ...item('p7', 'PAPER-7') },
  ];
  const prod = (over: Partial<Product>): Product => ({
    id: 'x', thickness_mm: 15.5, color_number: 16, faces: 'وجهين', ...over,
  } as Product);

  it('two-faced board → 1 MDF + 2 paper of the matching colour/thickness', () => {
    expect(resolveFactoryConsumption(prod({}), stock)).toEqual([
      { id: 'mdf155', qty: 1 },
      { id: 'p16', qty: 2 },
    ]);
  });

  it('one-faced board → 1 paper sheet', () => {
    const r = resolveFactoryConsumption(prod({ color_number: 7, faces: 'وجه' }), stock);
    expect(r).toEqual([{ id: 'mdf155', qty: 1 }, { id: 'p7', qty: 1 }]);
  });

  it('skips missing materials (no paper colour in stock)', () => {
    const r = resolveFactoryConsumption(prod({ color_number: 999 }), stock);
    expect(r).toEqual([{ id: 'mdf155', qty: 1 }]);
  });

  it('returns nothing without factory attributes', () => {
    expect(hasFactoryBom({ id: 'y' } as Product)).toBe(false);
    expect(resolveFactoryConsumption({ id: 'y' } as Product, stock)).toEqual([]);
  });
});
