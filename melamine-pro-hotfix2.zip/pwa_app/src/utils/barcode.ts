// ─── Code39 barcode (pure, dependency-free) + product label printing ─────────
// Code39 encodes 0-9, A-Z, space and - . $ / + % plus the * start/stop guard.
// Each character is 9 elements (bar/space alternating, starting with a bar);
// three of the nine are "wide". We render black bars as SVG rects.

const C39: Record<string, string> = {
  '0': 'nnnwwnwnn', '1': 'wnnwnnnnw', '2': 'nnwwnnnnw', '3': 'wnwwnnnnn',
  '4': 'nnnwwnnnw', '5': 'wnnwwnnnn', '6': 'nnwwwnnnn', '7': 'nnnwnnwnw',
  '8': 'wnnwnnwnn', '9': 'nnwwnnwnn', 'A': 'wnnnnwnnw', 'B': 'nnwnnwnnw',
  'C': 'wnwnnwnnn', 'D': 'nnnnwwnnw', 'E': 'wnnnwwnnn', 'F': 'nnwnwwnnn',
  'G': 'nnnnnwwnw', 'H': 'wnnnnwwnn', 'I': 'nnwnnwwnn', 'J': 'nnnnwwwnn',
  'K': 'wnnnnnnww', 'L': 'nnwnnnnww', 'M': 'wnwnnnnwn', 'N': 'nnnnwnnww',
  'O': 'wnnnwnnwn', 'P': 'nnwnwnnwn', 'Q': 'nnnnnnwww', 'R': 'wnnnnnwwn',
  'S': 'nnwnnnwwn', 'T': 'nnnnwnwwn', 'U': 'wwnnnnnnw', 'V': 'nwwnnnnnw',
  'W': 'wwwnnnnnn', 'X': 'nwnnwnnnw', 'Y': 'wwnnwnnnn', 'Z': 'nwwnwnnnn',
  '-': 'nwnnnnwnw', '.': 'wwnnnnwnn', ' ': 'nwwnnnwnn', '*': 'nwnnwnwnn',
};

// Returns an SVG markup string for the given value (no surrounding text).
export function code39SVG(value: string, opts?: { height?: number; narrow?: number; wide?: number }): string {
  const height = opts?.height ?? 46;
  const N = opts?.narrow ?? 2;
  const W = opts?.wide ?? 5;
  const clean = (value || '').toUpperCase().replace(/[^0-9A-Z\-. ]/g, '');
  const chars = `*${clean}*`.split('');
  let x = 0;
  const rects: string[] = [];
  chars.forEach((ch, ci) => {
    const pat = C39[ch] || C39['-'];
    for (let i = 0; i < pat.length; i++) {
      const w = pat[i] === 'w' ? W : N;
      const isBar = i % 2 === 0; // even index = bar (black)
      if (isBar) rects.push(`<rect x="${x}" y="0" width="${w}" height="${height}" fill="#111"/>`);
      x += w;
    }
    if (ci < chars.length - 1) x += N; // inter-character gap
  });
  return `<svg viewBox="0 0 ${x} ${height}" width="100%" height="${height}" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">${rects.join('')}</svg>`;
}

type LabelProduct = {
  code: string; name: string; thickness?: string;
  faces?: string; grade?: string;
};

// Opens a print window with a grid of product labels (each with a barcode).
export function printProductLabels(products: LabelProduct[], factoryName = 'شركة عبد الهادي للصناعة'): void {
  const esc = (s: unknown) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const cards = products.map(p => `
    <div class="lbl">
      <div class="f">${esc(factoryName)}</div>
      <div class="cd">${esc(p.code)}</div>
      <div class="nm">${esc(p.name)}</div>
      <div class="sp">${esc(p.thickness || '')} ${esc(p.faces || '')} ${p.grade ? '• ' + esc(p.grade) : ''}</div>
      <div class="bc">${code39SVG(p.code)}</div>
      <div class="bt">${esc(p.code)}</div>
    </div>`).join('');
  const html = `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>ملصقات المنتجات</title>
<style>
  *{font-family:'Segoe UI',Tahoma,Arial,sans-serif;box-sizing:border-box}
  body{margin:8mm;background:#fff}
  .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6mm}
  .lbl{border:1px solid #cbd5e1;border-radius:8px;padding:8px;text-align:center;page-break-inside:avoid}
  .f{font-size:8px;color:#64748b;font-weight:700}
  .cd{font-size:20px;font-weight:900;color:#0f172a;margin:2px 0}
  .nm{font-size:10px;color:#334155;height:26px;overflow:hidden}
  .sp{font-size:9px;color:#0d9488;font-weight:700;margin-bottom:4px}
  .bc{height:46px}
  .bt{font-family:monospace;font-size:11px;letter-spacing:2px;margin-top:2px}
  @media print{body{margin:6mm}}
</style></head><body>
  <div class="grid">${cards}</div>
  <script>window.onload=function(){window.print();}</script>
</body></html>`;
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.write(html);
  w.document.close();
}
