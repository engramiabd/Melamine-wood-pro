import { describe, it, expect } from 'vitest';
import {
  financialSummary, lowStock, overdueInvoices, attendanceToday, answerQuestion,
  generateInsights,
  type InsightData,
} from './insights';

const fmt = (n: number) => `$${Math.round(n)}`;
const today = new Date().toISOString().slice(0, 10);

// Minimal fixtures (cast — tests only exercise the fields the engine reads).
const data: InsightData = {
  orders: [
    { status: 'completed', total_usd: 1000, paid_usd: 1000, customer_name: 'A' },
    { status: 'completed', total_usd: 500, paid_usd: 200, customer_name: 'B' },
    { status: 'in_production', total_usd: 300, paid_usd: 0, customer_name: 'A' },
  ] as any,
  invoices: [
    { remaining_usd: 400, status: 'partial', due_date: '2000-01-01' },
    { remaining_usd: 0, status: 'paid' },
  ] as any,
  products: [
    { stock_quantity: 2, min_stock: 10, name: 'P1' },   // critical (<=50% of min)
    { stock_quantity: 8, min_stock: 10, name: 'P2' },   // low
    { stock_quantity: 50, min_stock: 10, name: 'P3' },  // good
  ] as any,
  inventory: [
    { stock_quantity: 1, reorder_level: 20, name: 'I1' }, // critical
  ] as any,
  attendance: [
    { date: today, status: 'present', worker_id: 'w1' },
    { date: today, status: 'absent', worker_id: 'w2' },
    { date: today, status: 'late', worker_id: 'w3' },
  ] as any,
};

describe('financialSummary', () => {
  it('sums completed revenue and collected', () => {
    const f = financialSummary(data.orders, data.invoices);
    expect(f.revenue).toBe(1500);
    expect(f.completedCount).toBe(2);
    expect(f.collected).toBe(1200);
    expect(f.outstanding).toBe(400);
  });
});

describe('lowStock', () => {
  it('counts low and critical across inventory + products', () => {
    const s = lowStock(data.inventory, data.products);
    expect(s.total).toBe(3);      // I1 + P1 + P2
    expect(s.critical).toBe(2);   // I1 + P1
  });
});

describe('overdueInvoices', () => {
  it('flags past-due invoices with remaining balance', () => {
    expect(overdueInvoices(data.invoices).length).toBe(1);
  });
});

describe('attendanceToday', () => {
  it('counts by status for today', () => {
    const a = attendanceToday(data.attendance);
    expect(a.total).toBe(3);
    expect(a.present).toBe(1);
    expect(a.absent).toBe(1);
    expect(a.late).toBe(1);
  });
});

describe('answerQuestion', () => {
  it('answers a revenue question locally', () => {
    const ans = answerQuestion('كم الإيرادات؟', data, fmt);
    expect(ans).toContain('1500');
  });
  it('returns null for unknown questions', () => {
    expect(answerQuestion('ما هي عاصمة فرنسا؟', data, fmt)).toBeNull();
  });

  it('denies financial questions when finance permission is missing', () => {
    const ans = answerQuestion('كم الإيرادات؟', data, fmt, { finance: false, orders: true, inventory: true });
    expect(ans).toContain('غير متاحة');
    expect(ans).not.toContain('1500');
  });

  it('still answers attendance for a worker (no finance/orders/inventory)', () => {
    const ans = answerQuestion('كيف الحضور اليوم؟', data, fmt, { finance: false, orders: false, inventory: false });
    expect(ans).toContain('حضور اليوم');
  });
});

describe('generateInsights permissions', () => {
  it('excludes revenue/finance cards for non-finance roles', () => {
    const ins = generateInsights(data, { finance: false, orders: false, inventory: false });
    const ids = ins.map(i => i.id);
    expect(ids).not.toContain('revenue');
    expect(ids).not.toContain('outstanding');
    expect(ids).not.toContain('lowstock');
    expect(ids).not.toContain('pending');
  });
  it('includes revenue for finance roles', () => {
    const ids = generateInsights(data, { finance: true, orders: true, inventory: true }).map(i => i.id);
    expect(ids).toContain('revenue');
  });
});
