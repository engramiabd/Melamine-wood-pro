// ── Local insights engine ────────────────────────────────────────────────────
// Pure, offline functions that turn the app's data into smart summaries,
// alerts and answers to common questions — no network or LLM required. The AI
// assistant layer (aiAssistant.ts) is optional and only used for free-form
// questions when an endpoint is configured.

import type { Order, Invoice, Product, AttendanceRecord } from '../types';
import type { InventoryItem } from '../contexts/appData.types';
import { productDemandForecast, atRisk } from './forecast';

export interface InsightData {
  orders: Order[];
  invoices: Invoice[];
  products: Product[];        // managedProducts
  inventory: InventoryItem[];
  attendance: AttendanceRecord[];
}

export type Severity = 'info' | 'good' | 'warning' | 'critical';

export interface Insight {
  id: string;
  title: string;
  value: string;
  detail?: string;
  severity: Severity;
}

const todayStr = () => new Date().toISOString().slice(0, 10);
const sum = (xs: number[]) => xs.reduce((a, b) => a + (b || 0), 0);

// ── Building blocks ──────────────────────────────────────────────────────────

export function financialSummary(orders: Order[], invoices: Invoice[]) {
  const completed = orders.filter(o => o.status === 'completed');
  const revenue = sum(completed.map(o => o.total_usd));
  const collected = sum(orders.map(o => o.paid_usd));
  const outstanding = sum(invoices.map(i => i.remaining_usd ?? 0));
  return { revenue, collected, outstanding, completedCount: completed.length };
}

export function lowStock(inventory: InventoryItem[], products: Product[]) {
  const invLow = inventory.filter(i => i.stock_quantity <= i.reorder_level);
  const prodLow = products.filter(p => p.stock_quantity <= p.min_stock);
  const critical = [
    ...invLow.filter(i => i.stock_quantity <= i.reorder_level * 0.5),
    ...prodLow.filter(p => p.stock_quantity <= p.min_stock * 0.5),
  ];
  return { invLow, prodLow, total: invLow.length + prodLow.length, critical: critical.length };
}

export function overdueInvoices(invoices: Invoice[]) {
  const t = todayStr();
  return invoices.filter(
    i => (i.remaining_usd ?? 0) > 0 &&
      (i.status === 'overdue' || (!!i.due_date && i.due_date < t && i.status !== 'paid' && i.status !== 'cancelled')),
  );
}

export function attendanceToday(attendance: AttendanceRecord[]) {
  const t = todayStr();
  const todays = attendance.filter(a => a.date === t);
  const by = (s: string) => todays.filter(a => a.status === s).length;
  return { present: by('present'), late: by('late'), absent: by('absent'), onLeave: by('on_leave'), total: todays.length };
}

export function pendingOrders(orders: Order[]) {
  return orders.filter(o => o.status === 'pending' || o.status === 'in_production' || o.status === 'quality_check');
}

export function topCustomers(orders: Order[], limit = 5) {
  const map = new Map<string, number>();
  for (const o of orders) map.set(o.customer_name, (map.get(o.customer_name) || 0) + (o.total_usd || 0));
  return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit).map(([name, total]) => ({ name, total }));
}

// ── Dashboard insight cards ──────────────────────────────────────────────────

// Which categories of insight a viewer is allowed to see. Defaults to all
// (back-compat); callers pass the current user's capabilities to hide content
// a role must not see (e.g. a worker must not see revenue/cost/finance).
export interface InsightPerms { finance?: boolean; orders?: boolean; inventory?: boolean }
const ALL_PERMS: InsightPerms = { finance: true, orders: true, inventory: true };

export function generateInsights(data: InsightData, perms: InsightPerms = ALL_PERMS): Insight[] {
  const out: Insight[] = [];
  const fin = financialSummary(data.orders, data.invoices);
  const stock = lowStock(data.inventory, data.products);
  const overdue = overdueInvoices(data.invoices);
  const att = attendanceToday(data.attendance);
  const pending = pendingOrders(data.orders);

  if (perms.finance) {
    out.push({
      id: 'revenue',
      title: 'إيرادات الطلبات المكتملة',
      value: `$${Math.round(fin.revenue).toLocaleString('en-US')}`,
      detail: `${fin.completedCount} طلب مكتمل`,
      severity: 'good',
    });

    if (fin.outstanding > 0) {
      out.push({
        id: 'outstanding',
        title: 'مستحقات غير محصّلة',
        value: `$${Math.round(fin.outstanding).toLocaleString('en-US')}`,
        detail: 'مجموع المتبقّي على الفواتير',
        severity: fin.outstanding > fin.revenue * 0.3 ? 'warning' : 'info',
      });
    }
  }

  if (perms.inventory && stock.total > 0) {
    out.push({
      id: 'lowstock',
      title: 'أصناف تحت حد إعادة الطلب',
      value: `${stock.total}`,
      detail: stock.critical > 0 ? `${stock.critical} منها حرجة` : 'راجِع المخزون',
      severity: stock.critical > 0 ? 'critical' : 'warning',
    });
  }

  if (perms.finance && overdue.length > 0) {
    out.push({
      id: 'overdue',
      title: 'فواتير متأخّرة السداد',
      value: `${overdue.length}`,
      detail: `$${Math.round(sum(overdue.map(i => i.remaining_usd ?? 0))).toLocaleString('en-US')} متبقّية`,
      severity: 'critical',
    });
  }

  if (perms.orders) {
    out.push({
      id: 'pending',
      title: 'طلبات قيد التنفيذ',
      value: `${pending.length}`,
      detail: 'بانتظار الإنتاج أو الفحص',
      severity: pending.length > 0 ? 'info' : 'good',
    });
  }

  if (att.total > 0) {
    out.push({
      id: 'attendance',
      title: 'حضور اليوم',
      value: `${att.present + att.late}/${att.total}`,
      detail: `${att.absent} غائب • ${att.late} متأخّر`,
      severity: att.absent > att.present ? 'warning' : 'good',
    });
  }

  // Predictive: products forecast to run out soon based on recent demand.
  if (perms.inventory) {
    const forecasts = productDemandForecast(data.orders, data.products);
    const risk = atRisk(forecasts);
    if (risk.critical.length + risk.warning.length > 0) {
      const soonest = forecasts[0];
      out.push({
        id: 'forecast',
        title: 'منتجات يُتوقّع نفادها قريباً',
        value: `${risk.critical.length + risk.warning.length}`,
        detail: soonest ? `الأقرب: ${soonest.name} خلال ~${Math.max(0, Math.round(soonest.daysLeft))} يوم` : undefined,
        severity: risk.critical.length > 0 ? 'critical' : 'warning',
      });
    }
  }

  return out;
}

// ── Natural-language-ish answers (keyword intent matching, offline) ──────────

export function answerQuestion(query: string, data: InsightData, fmt: (n: number) => string, perms: InsightPerms = ALL_PERMS): string | null {
  const q = query.toLowerCase();
  const has = (...words: string[]) => words.some(w => q.includes(w));
  const fin = financialSummary(data.orders, data.invoices);
  const denied = 'هذه المعلومات غير متاحة لصلاحياتك.';

  if (has('إيراد', 'مبيعات', 'دخل', 'revenue', 'sales')) {
    if (!perms.finance) return denied;
    return `إيرادات الطلبات المكتملة: ${fmt(fin.revenue)} من ${fin.completedCount} طلب. المحصّل: ${fmt(fin.collected)}.`;
  }
  if (has('مستحق', 'ديون', 'متبقّي', 'متبقي', 'outstanding', 'debt')) {
    if (!perms.finance) return denied;
    return `إجمالي المستحقات غير المحصّلة على الفواتير: ${fmt(fin.outstanding)}.`;
  }
  if (has('نواقص', 'مخزون', 'نقص', 'stock', 'inventory')) {
    if (!perms.inventory) return denied;
    const s = lowStock(data.inventory, data.products);
    if (s.total === 0) return 'لا توجد أصناف تحت حد إعادة الطلب حالياً. المخزون بحالة جيدة.';
    return `يوجد ${s.total} صنف تحت حد إعادة الطلب${s.critical ? `، منها ${s.critical} حرجة` : ''}. يُنصح بإعادة الطلب.`;
  }
  if (has('فواتير متأخّر', 'متأخر', 'overdue', 'متأخرة')) {
    if (!perms.finance) return denied;
    const ov = overdueInvoices(data.invoices);
    if (ov.length === 0) return 'لا توجد فواتير متأخّرة السداد. أحسنت!';
    return `يوجد ${ov.length} فاتورة متأخّرة، بمجموع متبقٍّ ${fmt(sum(ov.map(i => i.remaining_usd ?? 0)))}.`;
  }
  if (has('حضور', 'غياب', 'attendance', 'متأخر')) {
    const a = attendanceToday(data.attendance);
    if (a.total === 0) return 'لا توجد سجلات حضور لليوم بعد.';
    return `حضور اليوم: ${a.present + a.late} من ${a.total} (${a.absent} غائب، ${a.late} متأخّر، ${a.onLeave} إجازة).`;
  }
  if (has('طلبات', 'orders', 'قيد')) {
    if (!perms.orders) return denied;
    const p = pendingOrders(data.orders);
    return `يوجد ${p.length} طلب قيد التنفيذ (بانتظار الإنتاج أو الفحص).`;
  }
  if (has('أفضل عميل', 'أعلى عميل', 'top customer', 'كبار العملاء', 'أهم العملاء')) {
    if (!perms.finance) return denied;
    const tops = topCustomers(data.orders, 3);
    if (tops.length === 0) return 'لا توجد بيانات عملاء بعد.';
    return 'أعلى العملاء: ' + tops.map(c => `${c.name} (${fmt(c.total)})`).join('، ') + '.';
  }
  if (has('توقع', 'توقّع', 'ينفد', 'سينفد', 'نفاد', 'forecast', 'predict')) {
    if (!perms.inventory) return denied;
    const fc = productDemandForecast(data.orders, data.products);
    const r = atRisk(fc);
    if (r.critical.length + r.warning.length === 0) return 'لا توجد منتجات مهدّدة بالنفاد قريباً وفق الطلب الأخير.';
    const top = fc.slice(0, 3).map(f => `${f.name}: ~${Math.max(0, Math.round(f.daysLeft))} يوم`).join('، ');
    return `يُتوقّع نفاد ${r.critical.length + r.warning.length} منتج قريباً. الأقرب: ${top}.`;
  }
  return null; // no local match → caller may forward to the AI layer
}

// Compact textual context for the optional LLM layer.
export function buildContextSummary(data: InsightData, fmt: (n: number) => string, perms: InsightPerms = ALL_PERMS): string {
  const fin = financialSummary(data.orders, data.invoices);
  const stock = lowStock(data.inventory, data.products);
  const ov = overdueInvoices(data.invoices);
  const att = attendanceToday(data.attendance);
  const pending = pendingOrders(data.orders);
  const tops = topCustomers(data.orders, 3);
  const fc = productDemandForecast(data.orders, data.products);
  const risk = atRisk(fc);
  return [
    perms.finance ? `إيرادات الطلبات المكتملة: ${fmt(fin.revenue)} (${fin.completedCount} طلب).` : '',
    perms.finance ? `المحصّل: ${fmt(fin.collected)}. المستحقات غير المحصّلة: ${fmt(fin.outstanding)}.` : '',
    perms.orders ? `طلبات قيد التنفيذ: ${pending.length}.` : '',
    perms.inventory ? `أصناف تحت حد إعادة الطلب: ${stock.total} (حرجة: ${stock.critical}).` : '',
    perms.finance ? `فواتير متأخّرة: ${ov.length}.` : '',
    `حضور اليوم: ${att.present + att.late}/${att.total} (غياب ${att.absent}، تأخّر ${att.late}).`,
    perms.inventory && (risk.critical.length + risk.warning.length) ? `منتجات يُتوقّع نفادها قريباً: ${risk.critical.length + risk.warning.length}${fc[0] ? ` (الأقرب ${fc[0].name} ~${Math.max(0, Math.round(fc[0].daysLeft))} يوم)` : ''}.` : '',
    perms.finance && tops.length ? `أعلى العملاء: ${tops.map(c => `${c.name} ${fmt(c.total)}`).join('، ')}.` : '',
  ].filter(Boolean).join('\n');
}
