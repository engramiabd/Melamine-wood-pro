import { describe, it, expect } from 'vitest';
import {
  computeWorkerLoyalty, computeLeaderboard, tierFor, DEFAULT_LOYALTY_CONFIG,
  monthlyChampion, detectTierUp,
} from './loyalty';

const cfg = DEFAULT_LOYALTY_CONFIG;
const rec = (worker_id: string, date: string, status: string) => ({ id: date + worker_id, worker_id, date, status } as any);

describe('computeWorkerLoyalty', () => {
  it('awards base points + week streak bonus for 6 present days', () => {
    const records = ['01', '02', '03', '04', '05', '06'].map(d => rec('w1', `2026-01-${d}`, 'present'));
    const w = computeWorkerLoyalty('w1', records, cfg);
    expect(w.basePoints).toBe(60);            // 6 × 10
    expect(w.longestStreak).toBe(6);
    expect(w.streakBonus).toBe(20);           // one 6-day block
    expect(w.totalPoints).toBe(80);
    expect(w.currentStreak).toBe(6);
    expect(w.counts.present).toBe(6);
  });

  it('absence resets the streak and deducts points', () => {
    const records = [
      rec('w2', '2026-01-01', 'present'),
      rec('w2', '2026-01-02', 'absent'),
      rec('w2', '2026-01-03', 'present'),
    ];
    const w = computeWorkerLoyalty('w2', records, cfg);
    expect(w.basePoints).toBe(10);            // 10 - 10 + 10
    expect(w.longestStreak).toBe(1);
    expect(w.currentStreak).toBe(1);          // only the last present
    expect(w.counts.absent).toBe(1);
  });

  it('approved leave is neutral and does not break the streak', () => {
    const records = [
      rec('w3', '2026-01-01', 'present'),
      rec('w3', '2026-01-02', 'on_leave'),
      rec('w3', '2026-01-03', 'present'),
    ];
    const w = computeWorkerLoyalty('w3', records, cfg);
    expect(w.longestStreak).toBe(2);
    expect(w.currentStreak).toBe(2);
    expect(w.basePoints).toBe(20);            // 10 + 0 + 10
  });

  it('earns perfect-attendance and punctual badges', () => {
    const records = ['01', '02', '03', '04', '05'].map(d => rec('w4', `2026-01-${d}`, 'present'));
    const w = computeWorkerLoyalty('w4', records, cfg);
    const ids = w.badges.map(b => b.id);
    expect(ids).toContain('perfect');
    expect(ids).toContain('punctual');
  });
});

describe('tierFor', () => {
  it('maps points to the right tier', () => {
    expect(tierFor(50, cfg).current.name).toBe('برونزي');
    expect(tierFor(250, cfg).current.name).toBe('فضّي');
    expect(tierFor(450, cfg).current.name).toBe('ذهبي');
    expect(tierFor(700, cfg).current.name).toBe('بلاتيني');
  });
});

describe('computeLeaderboard', () => {
  it('sorts workers by total points descending', () => {
    const records = [
      ...['01', '02', '03'].map(d => rec('a', `2026-01-${d}`, 'present')),
      ...['01', '02', '03', '04', '05', '06'].map(d => rec('b', `2026-01-${d}`, 'present')),
    ];
    const board = computeLeaderboard(records, ['a', 'b'], cfg);
    expect(board[0].workerId).toBe('b');
    expect(board[1].workerId).toBe('a');
  });
});

describe('monthlyChampion', () => {
  it('picks the top worker for the given month only', () => {
    const records = [
      ...['01', '02', '03', '04'].map(d => rec('a', `2026-03-${d}`, 'present')), // March
      rec('b', '2026-03-01', 'present'),
      ...['01', '02', '03', '04', '05'].map(d => rec('b', `2026-02-${d}`, 'present')), // Feb (ignored)
    ];
    const champ = monthlyChampion(records, ['a', 'b'], '2026-03', cfg);
    expect(champ?.workerId).toBe('a');
  });
  it('returns null when nobody scored in the month', () => {
    expect(monthlyChampion([], ['a'], '2026-03', cfg)).toBeNull();
  });
});

describe('detectTierUp', () => {
  it('announces an upgrade only after a baseline is set', () => {
    localStorage.clear();
    expect(detectTierUp('w', 'برونزي', cfg)).toBeNull();   // first record = baseline, no announce
    expect(detectTierUp('w', 'فضّي', cfg)).toBe('فضّي');    // moved up → announce
    expect(detectTierUp('w', 'فضّي', cfg)).toBeNull();      // no change
  });
});
