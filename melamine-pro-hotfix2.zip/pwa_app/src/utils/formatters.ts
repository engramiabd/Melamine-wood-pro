/**
 * Formatters utility
 * All number / date / currency helpers used across the app.
 */

// ── Currency ────────────────────────────────────────────────────────────────

export const DEFAULT_EXCHANGE_RATE = 13_000; // SYP per 1 USD

export function formatUSD(amount: number, maxDecimals = 0): string {
  return `$${amount.toLocaleString('en-US', { maximumFractionDigits: maxDecimals })}`;
}

export function formatSYP(amount: number): string {
  return `${amount.toLocaleString('ar-SY', { maximumFractionDigits: 0 })} ل.س`;
}

export function formatCurrency(
  usd: number,
  currency: 'USD' | 'SYP',
  rate = DEFAULT_EXCHANGE_RATE,
  syp?: number,
): string {
  if (currency === 'USD') return formatUSD(usd);
  return formatSYP(syp ?? usd * rate);
}

// ── Numbers ─────────────────────────────────────────────────────────────────

export function formatNumber(n: number, decimals = 0): string {
  return n.toLocaleString('ar-SY', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function formatPercent(n: number, decimals = 1): string {
  return `${n.toFixed(decimals)}%`;
}

// ── Dates ───────────────────────────────────────────────────────────────────

export function formatDate(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('ar-SY', {
    year: 'numeric', month: 'long', day: 'numeric',
  });
}

export function formatDateShort(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('ar-SY', {
    year: 'numeric', month: '2-digit', day: '2-digit',
  });
}

export function formatDateTime(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleString('ar-SY', {
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

export function formatTime(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' });
}

export function formatRelativeTime(date: string | Date): string {
  const d    = typeof date === 'string' ? new Date(date) : date;
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60_000);
  if (mins < 1)  return 'الآن';
  if (mins < 60) return `منذ ${mins} دقيقة`;
  const hrs = Math.floor(mins / 60);
  if (hrs  < 24) return `منذ ${hrs} ساعة`;
  const days = Math.floor(hrs / 24);
  if (days < 7)  return `منذ ${days} يوم`;
  return formatDate(d);
}

export function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return [h, m, s].map(n => String(n).padStart(2, '0')).join(':');
}

// ── Greetings ────────────────────────────────────────────────────────────────

export function getGreeting(): string {
  const h = new Date().getHours();
  if (h <  5) return 'مرحباً';
  if (h < 12) return 'صباح الخير';
  if (h < 17) return 'مساء الخير';
  return 'مساء النور';
}

// ── Status / Colour Maps ─────────────────────────────────────────────────────

export const ORDER_STATUS_MAP: Record<string, { label: string; color: string; bg: string; border: string }> = {
  pending:       { label: 'معلق',        color: 'text-amber-700',   bg: 'bg-amber-50',   border: 'border-amber-200'  },
  in_production: { label: 'في الإنتاج', color: 'text-blue-700',    bg: 'bg-blue-50',    border: 'border-blue-200'   },
  quality_check: { label: 'مراجعة جودة', color: 'text-violet-700',  bg: 'bg-violet-50',  border: 'border-violet-200' },
  completed:     { label: 'مكتمل',       color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200'},
  cancelled:     { label: 'ملغي',        color: 'text-red-700',     bg: 'bg-red-50',     border: 'border-red-200'    },
  on_hold:       { label: 'موقوف',       color: 'text-gray-600',    bg: 'bg-gray-50',    border: 'border-gray-200'   },
};

export const PRIORITY_MAP: Record<string, { label: string; color: string; bg: string }> = {
  low:    { label: 'منخفضة', color: 'text-gray-600',   bg: 'bg-gray-100'   },
  normal: { label: 'عادية',  color: 'text-blue-600',   bg: 'bg-blue-100'   },
  high:   { label: 'عالية',  color: 'text-orange-600', bg: 'bg-orange-100' },
  urgent: { label: 'عاجل',   color: 'text-red-600',    bg: 'bg-red-100'    },
};

export const LINE_STATUS_MAP: Record<string, { label: string; color: string; bg: string; dot: string }> = {
  active:      { label: 'نشط',    color: 'text-emerald-700', bg: 'bg-emerald-50', dot: 'bg-emerald-500' },
  idle:        { label: 'خامل',   color: 'text-gray-500',    bg: 'bg-gray-50',    dot: 'bg-gray-400'    },
  maintenance: { label: 'صيانة',  color: 'text-amber-700',   bg: 'bg-amber-50',   dot: 'bg-amber-500'   },
  stopped:     { label: 'متوقف',  color: 'text-red-700',     bg: 'bg-red-50',     dot: 'bg-red-500'     },
};

export const ROLE_MAP: Record<string, string> = {
  admin:                'مدير النظام',
  manager:              'مدير',
  production_supervisor:'مشرف إنتاج',
  worker:               'عامل',
  accountant:           'محاسب',
  hr:                   'موارد بشرية',
};

// ── Inventory helpers ────────────────────────────────────────────────────────

export function calcStockLevel(current: number, min: number, max: number): number {
  return Math.round((current / (max || min * 5)) * 100);
}

export type StockStatus = 'good' | 'low' | 'critical';

export function getStockStatus(current: number, min: number): StockStatus {
  if (current <= min * 0.5) return 'critical';
  if (current <= min)       return 'low';
  return 'good';
}

export function getStockStatusLabel(status: StockStatus): string {
  return { good: 'جيد', low: 'منخفض', critical: 'حرج' }[status];
}

// ── Production helpers ────────────────────────────────────────────────────────

export function calcEfficiency(actual: number, target: number): number {
  if (!target) return 0;
  return Math.min(100, Math.round((actual / target) * 100));
}
