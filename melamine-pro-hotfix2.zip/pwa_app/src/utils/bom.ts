import type { Product } from '../types';
import type { InventoryItem } from '../contexts/appData.types';

// ─── Bill-of-materials consumption (pure logic, Phase 5/tests) ───────────────

export interface StdBomEntry { code: string; qty: number }
export interface Consumption { id: string; qty: number }

// Standard melamine-board recipe (fallback when a product has no explicit BOM).
// Resolved by material CODE so it survives id changes. Quantities are per board.
export const STANDARD_BOM_BY_CODE: StdBomEntry[] = [
  { code: 'RAW-HDF18', qty: 1 },    // 1 raw board per finished board
  { code: 'RAW-MPW',   qty: 0.5 },  // melamine paper (kg)
  { code: 'CHEM-MR',   qty: 0.2 },  // melamine resin (L)
  { code: 'CHEM-UF',   qty: 0.15 }, // urea-formaldehyde glue (kg)
  { code: 'RAW-PVC-W', qty: 2 },    // PVC edge (m)
  { code: 'PKG-BOX',   qty: 0.1 },  // packaging box (1 per 10 boards)
];

// Decide which materials (and how much per board) a run consumes:
// the product's own BOM if present, otherwise the standard recipe resolved
// against the current inventory by code.
export function resolveConsumption(
  product: Product | undefined,
  inventoryItems: InventoryItem[],
  standard: StdBomEntry[] = STANDARD_BOM_BY_CODE,
): Consumption[] {
  const consumption: Consumption[] = [];
  if (product?.bom && product.bom.length) {
    product.bom.forEach((c) => consumption.push({ id: c.material_id, qty: c.quantity }));
  } else {
    standard.forEach((b) => {
      const item = inventoryItems.find((i) => i.code === b.code);
      if (item) consumption.push({ id: item.id, qty: b.qty });
    });
  }
  return consumption;
}

// New stock level after consuming `perBoard * producedQty`, never below zero.
export function deductStock(currentStock: number, perBoard: number, producedQty: number): number {
  return Math.max(0, currentStock - perBoard * producedQty);
}

// ─── Factory BOM (P0): the real Abdul-Hadi recipe ───────────────────────────
// A melamine board consumes exactly one MDF board of the same thickness plus
// melamine paper of the matching colour number — one sheet per face
// (وجهين → 2, وجه → 1). Materials are resolved against the warehouse by code
// (MDF-{thickness}, PAPER-{colour}); any missing material is skipped, mirroring
// the factory's own "ميلامين بدون ورق" behaviour.
export function resolveFactoryConsumption(
  product: Product | undefined,
  inventoryItems: InventoryItem[],
): Consumption[] {
  if (!product || product.thickness_mm == null || product.color_number == null) return [];
  const consumption: Consumption[] = [];
  const thKey = String(product.thickness_mm).replace(/\.0$/, '');
  const mdf = inventoryItems.find(i => i.code === `MDF-${thKey}`);
  if (mdf) consumption.push({ id: mdf.id, qty: 1 });
  const paper = inventoryItems.find(i => i.code === `PAPER-${product.color_number}`);
  if (paper) consumption.push({ id: paper.id, qty: product.faces === 'وجهين' ? 2 : 1 });
  return consumption;
}

// True when a product carries the factory attributes needed for the real BOM.
export function hasFactoryBom(product: Product | undefined): boolean {
  return !!product && product.thickness_mm != null && product.color_number != null;
}
