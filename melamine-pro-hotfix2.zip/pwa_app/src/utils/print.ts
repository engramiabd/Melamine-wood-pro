// ── print.ts — Complete print and export utilities ────────────────────────────
import type { Order, JournalEntry, Employee, AttendanceRecord } from '../types';
import { formatUSD, formatSYP } from './formatters';
import { downloadCSV } from './exportReports';

// ── Shared style ─────────────────────────────────────────────────────────────
const BASE_STYLE = `
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Cairo', 'Segoe UI', sans-serif; direction: rtl; color: #1e293b; background: #fff; }
    .page { padding: 32px; max-width: 900px; margin: 0 auto; }
    h1 { font-size: 22px; font-weight: 800; color: #1e40af; margin-bottom: 4px; }
    h2 { font-size: 16px; font-weight: 700; color: #334155; margin: 20px 0 10px; border-bottom: 2px solid #e2e8f0; padding-bottom: 6px; }
    h3 { font-size: 13px; font-weight: 700; color: #475569; margin-bottom: 8px; }
    .sub { font-size: 12px; color: #64748b; margin-bottom: 16px; }
    .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
    .card { border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px; background: #f8fafc; }
    .kpi { text-align: center; }
    .kpi .val { font-size: 24px; font-weight: 900; color: #1e40af; }
    .kpi .lbl { font-size: 11px; color: #64748b; margin-top: 2px; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 20px; }
    th { background: #1e40af; color: white; padding: 8px 10px; text-align: right; font-weight: 700; }
    td { padding: 7px 10px; border-bottom: 1px solid #e2e8f0; }
    tr:nth-child(even) td { background: #f8fafc; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 700; }
    .badge-green { background: #dcfce7; color: #16a34a; }
    .badge-blue { background: #dbeafe; color: #1d4ed8; }
    .badge-yellow { background: #fef9c3; color: #a16207; }
    .badge-red { background: #fee2e2; color: #b91c1c; }
    .badge-gray { background: #f1f5f9; color: #475569; }
    .footer { margin-top: 32px; padding-top: 16px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #94a3b8; display: flex; justify-content: space-between; }
    .logo { font-size: 28px; font-weight: 900; color: #1e40af; margin-bottom: 2px; }
    .divider { border: none; border-top: 1px solid #e2e8f0; margin: 16px 0; }
    .total-row td { font-weight: 900; background: #eff6ff !important; color: #1e40af; font-size: 14px; }
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .no-print { display: none !important; }
    }
  </style>
`;

function openPrint(html: string) {
  const w = window.open('', '_blank', 'width=900,height=700');
  if (!w) return;
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 600);
}

function nowStr() {
  return new Date().toLocaleString('ar-SY', { calendar: 'gregory' });
}

// Fallback only — callers should always pass the live rate from CurrencyContext
// (systemSettings.exchangeRate). This default is used only if a caller forgets.
const FALLBACK_EXCHANGE_RATE = 13000;

// ── ORDER ─────────────────────────────────────────────────────────────────────
export function printOrder(order: Order, exchangeRate = FALLBACK_EXCHANGE_RATE) {
  const statusLabel: Record<string, string> = {
    pending: 'معلق', in_production: 'قيد الإنتاج', quality_check: 'فحص جودة',
    completed: 'مكتمل', cancelled: 'ملغي', on_hold: 'موقوف',
  };
  const statusClass: Record<string, string> = {
    pending: 'badge-yellow', in_production: 'badge-blue',
    quality_check: 'badge-yellow', completed: 'badge-green',
    cancelled: 'badge-red', on_hold: 'badge-gray',
  };
  const priorityLabel: Record<string, string> = { low: 'منخفضة', normal: 'عادية', high: 'عالية', urgent: 'عاجل' };

  const itemRows = (order.items || []).map((item, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${item.product?.name || item.product_id}</td>
      <td>${item.product?.thickness || '-'}</td>
      <td>${item.product?.size || '-'}</td>
      <td>${item.product?.finish || '-'}</td>
      <td>${item.quantity}</td>
      <td>$${item.unit_price_usd.toFixed(2)}</td>
      <td>$${item.total_usd.toFixed(2)}</td>
    </tr>
  `).join('');

  openPrint(`<!DOCTYPE html><html lang="ar">
  <head><meta charset="UTF-8"><title>طلب ${order.order_number}</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
  ${BASE_STYLE}</head>
  <body><div class="page">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px">
      <div>
        <div class="logo">ميلامين برو</div>
        <div class="sub">شركة عبد الهادي للصناعة</div>
      </div>
      <div style="text-align:left">
        <h1>${order.order_number}</h1>
        <div class="sub">تاريخ الإنشاء: ${new Date(order.created_at).toLocaleDateString('ar-SY')}</div>
        <span class="badge ${statusClass[order.status] || 'badge-gray'}">${statusLabel[order.status] || order.status}</span>
      </div>
    </div>
    <hr class="divider"/>
    <h2>بيانات العميل</h2>
    <div class="grid2">
      <div class="card"><h3>اسم العميل</h3><p>${order.customer_name}</p></div>
      <div class="card"><h3>رقم الهاتف</h3><p dir="ltr">${order.customer_phone || '-'}</p></div>
      <div class="card"><h3>الأولوية</h3><p>${priorityLabel[order.priority] || order.priority}</p></div>
      <div class="card"><h3>تاريخ التسليم</h3><p>${order.due_date ? new Date(order.due_date).toLocaleDateString('ar-SY') : 'غير محدد'}</p></div>
    </div>
    <h2>المنتجات المطلوبة</h2>
    <table>
      <thead><tr><th>#</th><th>المنتج</th><th>السماكة</th><th>المقاس</th><th>النوع</th><th>الكمية</th><th>سعر الوحدة</th><th>الإجمالي</th></tr></thead>
      <tbody>
        ${itemRows}
        <tr class="total-row">
          <td colspan="7" style="text-align:right">الإجمالي الكلي</td>
          <td>$${order.total_usd.toFixed(2)}</td>
        </tr>
        <tr class="total-row">
          <td colspan="7" style="text-align:right">بالليرة السورية</td>
          <td>${(order.total_syp || order.total_usd * exchangeRate).toLocaleString('ar-SY')} ل.س</td>
        </tr>
      </tbody>
    </table>
    ${order.notes ? `<div class="card" style="margin-bottom:16px"><h3>ملاحظات</h3><p>${order.notes}</p></div>` : ''}
    <div class="footer">
      <span>طبع بتاريخ: ${nowStr()}</span>
      <span>ميلامين برو — نظام إدارة مصنع الميلامين</span>
    </div>
  </div></body></html>`);
}

// ── INVOICE / QUOTATION ────────────────────────────────────────────────────────
export function printInvoice(invoice: import('../types').Invoice, factoryName = 'شركة عبد الهادي للصناعة') {
  const statusLabel: Record<string, string> = {
    draft: 'مسودة', sent: 'مُرسلة', paid: 'مدفوعة بالكامل',
    partial: 'مدفوعة جزئياً', overdue: 'متأخرة', cancelled: 'ملغاة',
  };
  const statusClass: Record<string, string> = {
    draft: 'badge-gray', sent: 'badge-blue', paid: 'badge-green',
    partial: 'badge-yellow', overdue: 'badge-red', cancelled: 'badge-red',
  };
  const docTitle = invoice.type === 'quotation' ? 'عرض سعر' : 'فاتورة مبيعات';

  const itemRows = invoice.items.map((item, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${item.description}</td>
      <td>${item.quantity}</td>
      <td>$${item.unit_price_usd.toFixed(2)}</td>
      <td>$${item.total_usd.toFixed(2)}</td>
    </tr>
  `).join('');

  openPrint(`<!DOCTYPE html><html lang="ar">
  <head><meta charset="UTF-8"><title>${docTitle} ${invoice.invoice_number}</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
  ${BASE_STYLE}</head>
  <body><div class="page">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px">
      <div>
        <div class="logo">ميلامين برو</div>
        <div class="sub">${factoryName}</div>
      </div>
      <div style="text-align:left">
        <h1>${docTitle}</h1>
        <div class="sub">رقم: ${invoice.invoice_number}</div>
        <div class="sub">التاريخ: ${new Date(invoice.issued_date).toLocaleDateString('ar-SY')}</div>
        ${invoice.due_date ? `<div class="sub">تاريخ الاستحقاق: ${new Date(invoice.due_date).toLocaleDateString('ar-SY')}</div>` : ''}
        <span class="badge ${statusClass[invoice.status] || 'badge-gray'}">${statusLabel[invoice.status] || invoice.status}</span>
      </div>
    </div>
    <hr class="divider"/>
    <h2>بيانات العميل</h2>
    <div class="grid2">
      <div class="card"><h3>اسم العميل</h3><p>${invoice.customer_name}</p></div>
      <div class="card"><h3>رقم الهاتف</h3><p dir="ltr">${invoice.customer_phone || '-'}</p></div>
      ${invoice.customer_address ? `<div class="card" style="grid-column:1/-1"><h3>العنوان</h3><p>${invoice.customer_address}</p></div>` : ''}
    </div>
    <h2>البنود</h2>
    <table>
      <thead><tr><th>#</th><th>الوصف</th><th>الكمية</th><th>سعر الوحدة</th><th>الإجمالي</th></tr></thead>
      <tbody>
        ${itemRows}
        <tr><td colspan="4" style="text-align:right">المجموع الفرعي</td><td>$${invoice.subtotal_usd.toFixed(2)}</td></tr>
        ${invoice.discount_usd > 0 ? `<tr><td colspan="4" style="text-align:right">الخصم</td><td>-$${invoice.discount_usd.toFixed(2)}</td></tr>` : ''}
        ${invoice.tax_rate > 0 ? `<tr><td colspan="4" style="text-align:right">الضريبة (${invoice.tax_rate}%)</td><td>$${invoice.tax_usd.toFixed(2)}</td></tr>` : ''}
        <tr class="total-row"><td colspan="4" style="text-align:right">الإجمالي الكلي</td><td>$${invoice.total_usd.toFixed(2)}</td></tr>
        <tr class="total-row"><td colspan="4" style="text-align:right">بالليرة السورية</td><td>${invoice.total_syp.toLocaleString('ar-SY')} ل.س</td></tr>
        ${invoice.paid_usd > 0 ? `
        <tr><td colspan="4" style="text-align:right">المدفوع</td><td style="color:#16a34a">$${invoice.paid_usd.toFixed(2)}</td></tr>
        <tr><td colspan="4" style="text-align:right">المتبقي</td><td style="color:${invoice.remaining_usd > 0 ? '#b91c1c' : '#16a34a'}">$${invoice.remaining_usd.toFixed(2)}</td></tr>
        ` : ''}
      </tbody>
    </table>
    ${invoice.notes ? `<div class="card" style="margin-bottom:16px"><h3>ملاحظات</h3><p>${invoice.notes}</p></div>` : ''}
    <div class="footer">
      <span>طبع بتاريخ: ${nowStr()}</span>
      <span>ميلامين برو — نظام إدارة مصنع الميلامين</span>
    </div>
  </div></body></html>`);
}

// ── CUSTOMER STATEMENT ───────────────────────────────────────────────────────
export function printCustomerStatement(
  customer: import('../types').Customer,
  orders: Order[],
  invoices: import('../types').Invoice[],
  factoryName = 'شركة عبد الهادي للصناعة',
) {
  // Build a unified, chronologically sorted ledger of orders and invoices.
  //
  // IMPORTANT: to avoid double-counting a sale that has BOTH an order and a
  // formal invoice issued for it, we only include an order's totals here if
  // it has no matching invoice (invoices.some(i => i.order_id === o.id)).
  // Orders that were later invoiced are represented solely by their invoice.
  type LedgerRow = { date: string; ref: string; description: string; debit: number; credit: number };
  const rows: LedgerRow[] = [];
  const invoicedOrderIds = new Set(invoices.map(i => i.order_id).filter(Boolean));

  orders.filter(o => !invoicedOrderIds.has(o.id)).forEach(o => {
    rows.push({ date: o.created_at, ref: o.order_number, description: `طلب — ${o.items.length} صنف`, debit: o.total_usd, credit: 0 });
    if (o.paid_usd > 0) {
      rows.push({ date: o.updated_at, ref: o.order_number, description: 'دفعة مستلمة على الطلب', debit: 0, credit: o.paid_usd });
    }
  });
  invoices.forEach(inv => {
    rows.push({ date: inv.issued_date, ref: inv.invoice_number, description: inv.type === 'quotation' ? 'عرض سعر' : 'فاتورة مبيعات', debit: inv.total_usd, credit: 0 });
    if (inv.paid_usd > 0) {
      rows.push({ date: inv.updated_at, ref: inv.invoice_number, description: 'دفعة مستلمة على الفاتورة', debit: 0, credit: inv.paid_usd });
    }
  });

  rows.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  let runningBalance = 0;
  const rowsHtml = rows.map(r => {
    runningBalance += r.debit - r.credit;
    return `
      <tr>
        <td>${new Date(r.date).toLocaleDateString('ar-SY')}</td>
        <td>${r.ref}</td>
        <td>${r.description}</td>
        <td>${r.debit > 0 ? `$${r.debit.toFixed(2)}` : '—'}</td>
        <td>${r.credit > 0 ? `$${r.credit.toFixed(2)}` : '—'}</td>
        <td>$${runningBalance.toFixed(2)}</td>
      </tr>`;
  }).join('');

  const totalDebit = rows.reduce((s, r) => s + r.debit, 0);
  const totalCredit = rows.reduce((s, r) => s + r.credit, 0);

  openPrint(`<!DOCTYPE html><html lang="ar">
  <head><meta charset="UTF-8"><title>كشف حساب ${customer.name}</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
  ${BASE_STYLE}</head>
  <body><div class="page">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px">
      <div>
        <div class="logo">ميلامين برو</div>
        <div class="sub">${factoryName}</div>
      </div>
      <div style="text-align:left">
        <h1>كشف حساب عميل</h1>
        <div class="sub">تاريخ الإصدار: ${new Date().toLocaleDateString('ar-SY')}</div>
      </div>
    </div>
    <hr class="divider"/>
    <h2>بيانات العميل</h2>
    <div class="grid2">
      <div class="card"><h3>اسم العميل</h3><p>${customer.name}</p></div>
      <div class="card"><h3>رقم الهاتف</h3><p dir="ltr">${customer.phone}</p></div>
      ${customer.company ? `<div class="card"><h3>الشركة</h3><p>${customer.company}</p></div>` : ''}
      <div class="card"><h3>الرصيد الحالي المستحق</h3><p style="color:${customer.balance_usd > 0 ? '#b91c1c' : '#16a34a'};font-weight:800">$${customer.balance_usd.toFixed(2)}</p></div>
    </div>
    <h2>كشف الحركات</h2>
    <table>
      <thead><tr><th>التاريخ</th><th>المرجع</th><th>البيان</th><th>مدين</th><th>دائن</th><th>الرصيد</th></tr></thead>
      <tbody>
        ${rowsHtml || '<tr><td colspan="6" style="text-align:center;color:#94a3b8">لا توجد حركات مسجلة</td></tr>'}
      </tbody>
      <tfoot>
        <tr class="total-row"><td colspan="3" style="text-align:right">الإجمالي</td><td>$${totalDebit.toFixed(2)}</td><td>$${totalCredit.toFixed(2)}</td><td>$${runningBalance.toFixed(2)}</td></tr>
      </tfoot>
    </table>
    <div class="footer">
      <span>طبع بتاريخ: ${nowStr()}</span>
      <span>ميلامين برو — نظام إدارة مصنع الميلامين</span>
    </div>
  </div></body></html>`);
}

// ── ORDER ─────────────────────────────────────────────────────────────────────
export function shareOrder(order: Order) {
  const text = `طلب رقم: ${order.order_number}
العميل: ${order.customer_name}
${order.customer_phone ? `الهاتف: ${order.customer_phone}` : ''}
المنتجات: ${(order.items || []).length} صنف
الإجمالي: $${order.total_usd.toFixed(2)}
الحالة: ${order.status}
التاريخ: ${new Date(order.created_at).toLocaleDateString('ar-SY')}`;

  if (navigator.share) {
    navigator.share({ title: `طلب ${order.order_number}`, text }).catch(() => {});
  } else {
    navigator.clipboard?.writeText(text).catch(() => {});
  }
}

// ── PAYROLL ───────────────────────────────────────────────────────────────────
export function printPayroll(
  employees: Employee[],
  wallets: { workerId: string; balanceUSD: number; balanceSYP: number }[],
  exchangeRate = FALLBACK_EXCHANGE_RATE
) {
  const rows = employees.map((e, i) => {
    const salary = e.salary_usd || 500;
    return `
    <tr>
      <td>${i + 1}</td>
      <td>${e.position || 'موظف'}</td>
      <td>${e.department || '-'}</td>
      <td>$${salary.toFixed(2)}</td>
      <td>$0.00</td>
      <td>$0.00</td>
      <td>$${salary.toFixed(2)}</td>
      <td><span class="badge badge-green">تم الصرف</span></td>
    </tr>`;
  }).join('');

  const total = employees.reduce((s, e) => s + (e.salary_usd || 500), 0);

  openPrint(`<!DOCTYPE html><html lang="ar">
  <head><meta charset="UTF-8"><title>كشف الرواتب</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
  ${BASE_STYLE}</head>
  <body><div class="page">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px">
      <div><div class="logo">ميلامين برو</div><div class="sub">شركة عبد الهادي للصناعة</div></div>
      <div style="text-align:left"><h1>كشف الرواتب الشهري</h1>
      <div class="sub">${new Date().toLocaleDateString('ar-SY', { month: 'long', year: 'numeric' })}</div></div>
    </div>
    <hr class="divider"/>
    <div class="grid2" style="grid-template-columns:repeat(3,1fr)">
      <div class="card kpi"><div class="val">${employees.length}</div><div class="lbl">عدد الموظفين</div></div>
      <div class="card kpi"><div class="val">$${total.toFixed(2)}</div><div class="lbl">إجمالي الرواتب</div></div>
      <div class="card kpi"><div class="val">${(total * exchangeRate).toLocaleString('ar-SY')} ل.س</div><div class="lbl">بالليرة السورية</div></div>
    </div>
    <h2>تفاصيل الرواتب</h2>
    <table>
      <thead><tr><th>#</th><th>الموظف</th><th>القسم</th><th>الراتب الأساسي</th><th>المكافآت</th><th>الخصومات</th><th>الصافي</th><th>الحالة</th></tr></thead>
      <tbody>
        ${rows}
        <tr class="total-row">
          <td colspan="3" style="text-align:right">الإجمالي</td>
          <td>$${total.toFixed(2)}</td><td>$0.00</td><td>$0.00</td>
          <td>$${total.toFixed(2)}</td><td></td>
        </tr>
      </tbody>
    </table>
    <div class="footer">
      <span>طبع بتاريخ: ${nowStr()}</span>
      <span>ميلامين برو</span>
    </div>
  </div></body></html>`);
}

// ── ATTENDANCE ────────────────────────────────────────────────────────────────
export function printAttendance(records: AttendanceRecord[], dateLabel = 'اليوم') {
  const rows = records.map((r, i) => {
    const checkIn = r.check_in
      ? (r.check_in.includes('T')
        ? new Date(r.check_in).toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' })
        : r.check_in)
      : '-';
    const checkOut = r.check_out
      ? (r.check_out.includes('T')
        ? new Date(r.check_out).toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' })
        : r.check_out)
      : '-';
    const hours = r.check_in && r.check_out && r.check_in.includes('T') && r.check_out.includes('T')
      ? ((new Date(r.check_out).getTime() - new Date(r.check_in).getTime()) / 3600000).toFixed(1)
      : '-';
    const statusLabel: Record<string, string> = { present: 'حاضر', absent: 'غائب', late: 'متأخر', on_leave: 'إجازة', half_day: 'نصف يوم' };
    const statusClass: Record<string, string> = { present: 'badge-green', absent: 'badge-red', late: 'badge-yellow', on_leave: 'badge-blue', half_day: 'badge-gray' };
    return `
    <tr>
      <td>${i + 1}</td>
      <td>${r.worker_id}</td>
      <td dir="ltr">${checkIn}</td>
      <td dir="ltr">${checkOut}</td>
      <td>${hours} ${hours !== '-' ? 'ساعة' : ''}</td>
      <td><span class="badge ${statusClass[r.status] || 'badge-gray'}">${statusLabel[r.status] || r.status}</span></td>
    </tr>`;
  }).join('');

  const present = records.filter(r => r.status === 'present').length;
  const late = records.filter(r => r.status === 'late').length;
  const absent = records.filter(r => r.status === 'absent').length;

  openPrint(`<!DOCTYPE html><html lang="ar">
  <head><meta charset="UTF-8"><title>سجل الحضور</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
  ${BASE_STYLE}</head>
  <body><div class="page">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px">
      <div><div class="logo">ميلامين برو</div></div>
      <div style="text-align:left"><h1>سجل الحضور — ${dateLabel}</h1>
      <div class="sub">تاريخ: ${new Date().toLocaleDateString('ar-SY')}</div></div>
    </div>
    <hr class="divider"/>
    <div class="grid2" style="grid-template-columns:repeat(4,1fr)">
      <div class="card kpi"><div class="val" style="color:#16a34a">${present}</div><div class="lbl">حاضر</div></div>
      <div class="card kpi"><div class="val" style="color:#d97706">${late}</div><div class="lbl">متأخر</div></div>
      <div class="card kpi"><div class="val" style="color:#dc2626">${absent}</div><div class="lbl">غائب</div></div>
      <div class="card kpi"><div class="val">${records.length}</div><div class="lbl">الإجمالي</div></div>
    </div>
    <h2>تفاصيل الحضور</h2>
    <table>
      <thead><tr><th>#</th><th>رقم الموظف</th><th>تسجيل الدخول</th><th>تسجيل الخروج</th><th>ساعات العمل</th><th>الحالة</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <div class="footer">
      <span>طبع بتاريخ: ${nowStr()}</span>
      <span>ميلامين برو</span>
    </div>
  </div></body></html>`);
}

// ── JOURNAL ───────────────────────────────────────────────────────────────────
export function printJournal(entries: JournalEntry[], period = 'الكل') {
  const income = entries.filter(e => e.type === 'income').reduce((s, e) => s + e.amount_usd, 0);
  const expense = entries.filter(e => e.type === 'expense').reduce((s, e) => s + e.amount_usd, 0);

  const rows = entries.slice(0, 100).map((e, i) => {
    const typeLabel = e.type === 'income' ? 'إيراد' : e.type === 'expense' ? 'مصروف' : 'تحويل';
    const typeClass = e.type === 'income' ? 'badge-green' : e.type === 'expense' ? 'badge-red' : 'badge-blue';
    return `
    <tr>
      <td>${e.entry_number}</td>
      <td>${new Date(e.entry_date).toLocaleDateString('ar-SY')}</td>
      <td><span class="badge ${typeClass}">${typeLabel}</span></td>
      <td>${e.category}</td>
      <td>${e.description}</td>
      <td>$${e.amount_usd.toFixed(2)}</td>
    </tr>`;
  }).join('');

  openPrint(`<!DOCTYPE html><html lang="ar">
  <head><meta charset="UTF-8"><title>السجل المحاسبي</title>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
  ${BASE_STYLE}</head>
  <body><div class="page">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px">
      <div><div class="logo">ميلامين برو</div></div>
      <div style="text-align:left"><h1>السجل المحاسبي</h1>
      <div class="sub">الفترة: ${period}</div></div>
    </div>
    <hr class="divider"/>
    <div class="grid2" style="grid-template-columns:repeat(3,1fr)">
      <div class="card kpi"><div class="val" style="color:#16a34a">$${income.toFixed(2)}</div><div class="lbl">إجمالي الإيرادات</div></div>
      <div class="card kpi"><div class="val" style="color:#dc2626">$${expense.toFixed(2)}</div><div class="lbl">إجمالي المصروفات</div></div>
      <div class="card kpi"><div class="val" style="color:${income-expense>=0?'#1e40af':'#dc2626'}">$${(income-expense).toFixed(2)}</div><div class="lbl">صافي الربح</div></div>
    </div>
    <h2>القيود المحاسبية (${entries.length} قيد)</h2>
    <table>
      <thead><tr><th>رقم القيد</th><th>التاريخ</th><th>النوع</th><th>الفئة</th><th>الوصف</th><th>المبلغ</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <div class="footer">
      <span>طبع بتاريخ: ${nowStr()}</span>
      <span>ميلامين برو</span>
    </div>
  </div></body></html>`);
}

// ── CSV EXPORT ────────────────────────────────────────────────────────────────
export function exportToCSV(data: Record<string, unknown>[], filename: string) {
  if (!data.length) return;
  const keys = Object.keys(data[0]);
  const rows = data.map(row => keys.map(k => {
    const v = row[k];
    return v === null || v === undefined ? '' : (v as string | number);
  }));
  // Single CSV engine (BOM + escaping + download) lives in exportReports.
  downloadCSV(filename, keys, rows);
}

// alias for backward compat
export const exportCSV = exportToCSV;

export function exportOrdersToCSV(orders: Order[]) {
  exportToCSV(orders.map(o => ({
    'رقم الطلب': o.order_number,
    'العميل': o.customer_name,
    'الهاتف': o.customer_phone || '',
    'الحالة': o.status,
    'الأولوية': o.priority,
    'الإجمالي USD': o.total_usd,
    'الإجمالي SYP': o.total_syp,
    'تاريخ الإنشاء': o.created_at,
    'تاريخ التسليم': o.due_date || '',
  })), 'orders');
}

export function exportJournalToCSV(entries: JournalEntry[]) {
  exportToCSV(entries.map(e => ({
    'رقم القيد': e.entry_number,
    'التاريخ': e.entry_date,
    'النوع': e.type,
    'الفئة': e.category,
    'الوصف': e.description,
    'المبلغ USD': e.amount_usd,
    'المبلغ SYP': e.amount_syp,
    'طريقة الدفع': e.payment_method,
  })), 'journal');
}

export function exportAttendanceToCSV(records: AttendanceRecord[]) {
  exportToCSV(records.map(r => ({
    'رقم الموظف': r.worker_id,
    'التاريخ': r.date,
    'الدخول': r.check_in || '',
    'الخروج': r.check_out || '',
    'الحالة': r.status,
  })), 'attendance');
}

export function exportEmployeesToCSV(employees: Employee[]) {
  exportToCSV(employees.map(e => ({
    'رقم الموظف': e.employee_number,
    'المسمى الوظيفي': e.position,
    'القسم': e.department,
    'الراتب الأساسي USD': e.salary_usd,
    'تاريخ التوظيف': e.hire_date,
    'حالة': e.is_active ? 'نشط' : 'غير نشط',
  })), 'employees');
}

// ── HAVERSINE DISTANCE ────────────────────────────────────────────────────────
export function haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ── RELATIVE TIME ─────────────────────────────────────────────────────────────
export function relativeTime(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  const hrs = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (mins < 1) return 'الآن';
  if (mins < 60) return `منذ ${mins} دقيقة`;
  if (hrs < 24) return `منذ ${hrs} ساعة`;
  if (days < 7) return `منذ ${days} يوم`;
  return new Date(dateStr).toLocaleDateString('ar-SY');
}

// ── FORMAT HELPERS ────────────────────────────────────────────────────────────
export function fmtUSD(v: number) {
  return formatUSD(v, 2);
}
export function fmtSYP(v: number) {
  return formatSYP(v);
}
