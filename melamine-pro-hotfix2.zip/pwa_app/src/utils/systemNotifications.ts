// ─── System notifications (Phase 4) ─────────────────────────────────────────
// Client-side foundation for "push"-style alerts using the Web Notifications
// API + the service worker registration. True server-pushed delivery additionally
// needs a backend with VAPID keys and a Push subscription; this module covers
// everything that runs on the device (permission + local system notifications),
// which the in-app notification stream now mirrors to the OS.

const STORAGE_KEY = 'app_system_notifications';

export function systemNotificationsEnabled(): boolean {
  try { return localStorage.getItem(STORAGE_KEY) !== 'off'; } catch { return true; }
}

export function setSystemNotificationsEnabled(on: boolean): void {
  try { localStorage.setItem(STORAGE_KEY, on ? 'on' : 'off'); } catch { /* noop */ }
}

export type PermissionState = NotificationPermission | 'unsupported';

export function notificationPermission(): PermissionState {
  if (typeof Notification === 'undefined') return 'unsupported';
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<PermissionState> {
  if (typeof Notification === 'undefined') return 'unsupported';
  try { return await Notification.requestPermission(); }
  catch { return Notification.permission; }
}

export async function showSystemNotification(title: string, body: string, tag?: string): Promise<void> {
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
  if (!systemNotificationsEnabled()) return;
  const opts: NotificationOptions = {
    body, tag, icon: '/icon-192.png', badge: '/icon-192.png', dir: 'rtl', lang: 'ar',
  };
  try {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.ready;
      await reg.showNotification(title, opts);
      return;
    }
  } catch { /* fall through to the basic Notification constructor */ }
  try { new Notification(title, opts); } catch { /* noop */ }
}
