import type { Order, Invoice, InvoiceItem } from '../types';

// ─── Invoice-from-order financials (pure logic, Phase 5/tests) ───────────────
// Encodes the Phase 2 revenue rule: the invoice mirrors the order exactly
// (tax 0 → total === order total) and carries the already-paid amount so only
// the unpaid remainder becomes a receivable. This is what prevents the old
// double-counting of revenue.

export type InvoiceLine = Omit<InvoiceItem, 'id' | 'invoice_id'>;

export interface InvoiceFinancials {
  items: InvoiceLine[];
  subtotal_usd: number;
  subtotal_syp: number;
  tax_rate: number;
  total_usd: number;
  total_syp: number;
  paid_usd: number;
  remaining_usd: number;
  status: Invoice['status'];
}

export function computeInvoiceFromOrder(order: Order): InvoiceFinancials {
  const items: InvoiceLine[] = order.items.map((it) => ({
    product_id: it.product_id,
    description: it.product?.name || 'منتج',
    quantity: it.quantity,
    unit_price_usd: it.unit_price_usd,
    unit_price_syp: it.unit_price_syp,
    total_usd: it.total_usd,
    total_syp: it.total_syp,
  }));

  const paid_usd = order.paid_usd || 0;
  const remaining_usd = Math.max(0, order.total_usd - paid_usd);
  const status: Invoice['status'] = remaining_usd <= 0 ? 'paid' : paid_usd > 0 ? 'partial' : 'sent';

  return {
    items,
    subtotal_usd: order.total_usd,
    subtotal_syp: order.total_syp,
    tax_rate: 0,
    total_usd: order.total_usd,
    total_syp: order.total_syp,
    paid_usd,
    remaining_usd,
    status,
  };
}
