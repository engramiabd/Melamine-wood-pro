import { describe, it, expect } from 'vitest';
import {
  formatUSD,
  formatPercent,
  formatDuration,
  getStockStatus,
  calcEfficiency,
  calcStockLevel,
} from './formatters';

describe('formatUSD', () => {
  it('rounds to whole dollars by default', () => {
    expect(formatUSD(1234.5)).toBe('$1,235');
    expect(formatUSD(1000)).toBe('$1,000');
  });
  it('respects maxDecimals', () => {
    expect(formatUSD(1234.5, 1)).toBe('$1,234.5');
    expect(formatUSD(1234.567, 2)).toBe('$1,234.57');
  });
});

describe('formatPercent', () => {
  it('formats with default 1 decimal', () => {
    expect(formatPercent(12.345)).toBe('12.3%');
  });
  it('respects decimals arg', () => {
    expect(formatPercent(50, 0)).toBe('50%');
  });
});

describe('formatDuration', () => {
  it('pads h:m:s', () => {
    expect(formatDuration(3661)).toBe('01:01:01');
    expect(formatDuration(0)).toBe('00:00:00');
    expect(formatDuration(59)).toBe('00:00:59');
  });
});

describe('getStockStatus', () => {
  it('critical at or below half of min', () => {
    expect(getStockStatus(5, 10)).toBe('critical');
    expect(getStockStatus(4, 10)).toBe('critical');
  });
  it('low at or below min (but above half)', () => {
    expect(getStockStatus(8, 10)).toBe('low');
    expect(getStockStatus(10, 10)).toBe('low');
  });
  it('good above min', () => {
    expect(getStockStatus(20, 10)).toBe('good');
  });
});

describe('calcEfficiency', () => {
  it('caps at 100 and handles zero target', () => {
    expect(calcEfficiency(50, 100)).toBe(50);
    expect(calcEfficiency(150, 100)).toBe(100);
    expect(calcEfficiency(5, 0)).toBe(0);
  });
});

describe('calcStockLevel', () => {
  it('uses max when provided', () => {
    expect(calcStockLevel(50, 10, 100)).toBe(50);
  });
  it('falls back to min*5 when max is 0', () => {
    expect(calcStockLevel(50, 10, 0)).toBe(100);
  });
});
