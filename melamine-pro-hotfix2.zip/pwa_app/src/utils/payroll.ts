import type { Employee, AttendanceRecord, PayrollBreakdown } from '../types';

// ─── Payroll from attendance (pure logic, Phase 5/tests) ─────────────────────

function parseDT(date: string, t?: string): Date | null {
  if (!t) return null;
  if (t.includes('T')) { const d = new Date(t); return isNaN(d.getTime()) ? null : d; }
  const tt = t.length === 5 ? `${t}:00` : t;
  const d = new Date(`${date}T${tt}`);
  return isNaN(d.getTime()) ? null : d;
}

const round = (n: number) => Math.round(n * 100) / 100;

export function computePayroll(
  emp: Employee,
  attendanceRecords: AttendanceRecord[],
  year: number,
  month: number,
): PayrollBreakdown {
  const workerId = emp.user_id;
  const recs = attendanceRecords.filter((r) => {
    if (r.worker_id !== workerId) return false;
    const d = new Date(r.date);
    return d.getFullYear() === year && d.getMonth() + 1 === month;
  });

  const present = recs.filter((r) => r.status === 'present' || r.status === 'late');
  const late = recs.filter((r) => r.status === 'late');
  const absent = recs.filter((r) => r.status === 'absent');
  const leave = recs.filter((r) => r.status === 'on_leave');

  const dailyHours = emp.working_hours || 8;
  let workedHours = 0;
  present.forEach((r) => {
    const ci = parseDT(r.date, r.check_in);
    const co = parseDT(r.date, r.check_out);
    if (ci && co) {
      const h = (co.getTime() - ci.getTime()) / 3600000;
      if (h > 0 && h < 24) { workedHours += h; return; }
    }
    workedHours += dailyHours; // assume a full day when times are missing
  });

  const workingDays = present.length + absent.length + leave.length;
  const expectedHours = (present.length + absent.length) * dailyHours;
  const overtimeHours = Math.max(0, workedHours - present.length * dailyHours);

  const base = emp.salary_usd;
  const perDay = workingDays > 0 ? base / workingDays : base / 30;
  const perHour = dailyHours > 0 ? perDay / dailyHours : 0;
  const overtimePay = overtimeHours * perHour * 1.5;
  const absenceDeduction = absent.length * perDay;
  const lateDeduction = late.length * perHour * 0.5;
  const net = Math.max(0, base + overtimePay - absenceDeduction - lateDeduction);

  return {
    employee_id: emp.id,
    employee_name: emp.user?.full_name || emp.position,
    year, month, working_days: workingDays,
    present_days: present.length, absent_days: absent.length,
    late_days: late.length, leave_days: leave.length,
    worked_hours: round(workedHours), expected_hours: expectedHours,
    overtime_hours: round(overtimeHours),
    base_salary_usd: base, overtime_pay_usd: round(overtimePay),
    absence_deduction_usd: round(absenceDeduction), late_deduction_usd: round(lateDeduction),
    net_salary_usd: round(net),
  };
}
