// ─── Report export (CSV, Excel-compatible) ───────────────────────────────────
// Client-side, dependency-free. Adds a UTF-8 BOM so Arabic renders correctly
// when the file is opened in Excel.

function escapeCell(v: unknown): string {
  const s = v == null ? '' : String(v);
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function toCSV(headers: string[], rows: (string | number)[][]): string {
  const lines = [headers.map(escapeCell).join(',')];
  rows.forEach(r => lines.push(r.map(escapeCell).join(',')));
  return '\uFEFF' + lines.join('\r\n'); // BOM for Excel/Arabic
}

export function downloadCSV(filename: string, headers: string[], rows: (string | number)[][]): void {
  const csv = toCSV(headers, rows);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// ─── Print / PDF export ───────────────────────────────────────────────────────
// Opens a styled, RTL, print-ready window. The user can then "Save as PDF" via
// the browser's print dialog — a real PDF export with no extra dependencies.
function esc(s: unknown): string {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

export function printReport(
  title: string,
  headers: string[],
  rows: (string | number)[][],
  opts?: { subtitle?: string; factoryName?: string },
): void {
  const factory = opts?.factoryName || 'شركة عبد الهادي للصناعة';
  const date = new Date().toLocaleString('ar-SY');
  const thead = headers.map(h => `<th>${esc(h)}</th>`).join('');
  const tbody = rows.map(r => `<tr>${r.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('');
  const html = `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>
  *{font-family:'Segoe UI',Tahoma,Arial,sans-serif;box-sizing:border-box}
  body{margin:24px;color:#1e293b}
  .hd{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid #0d9488;padding-bottom:10px;margin-bottom:6px}
  .hd h1{margin:0;font-size:20px}.hd .f{font-size:13px;color:#64748b;font-weight:700}
  .sub{font-size:12px;color:#94a3b8;margin-bottom:14px}
  table{width:100%;border-collapse:collapse;font-size:12px}
  th{background:#0d9488;color:#fff;padding:8px 10px;text-align:right;font-weight:700}
  td{padding:7px 10px;border-bottom:1px solid #e2e8f0;text-align:right}
  tr:nth-child(even) td{background:#f8fafc}
  .ft{margin-top:16px;font-size:11px;color:#94a3b8;text-align:center;border-top:1px solid #e2e8f0;padding-top:8px}
  @media print{body{margin:10mm}}
</style></head><body>
  <div class="hd"><h1>${esc(title)}</h1><span class="f">${esc(factory)}</span></div>
  <div class="sub">${opts?.subtitle ? esc(opts.subtitle) + ' • ' : ''}${esc(date)} • ${rows.length} سجل</div>
  <table><thead><tr>${thead}</tr></thead><tbody>${tbody}</tbody></table>
  <div class="ft">تقرير مُصدّر من نظام ميلامين برو — ${esc(factory)}</div>
  <script>window.onload=function(){window.print();}</script>
</body></html>`;
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.write(html);
  w.document.close();
}
