import { describe, it, expect } from 'vitest';
import { normalizePhone, buildWhatsAppLink } from './whatsapp';
import { productDemandForecast, atRisk } from './forecast';

describe('normalizePhone', () => {
  it('converts local 0-prefixed Syrian numbers', () => {
    expect(normalizePhone('0991234567')).toBe('963991234567');
  });
  it('strips + and 00 prefixes', () => {
    expect(normalizePhone('+963991234567')).toBe('963991234567');
    expect(normalizePhone('00963991234567')).toBe('963991234567');
  });
  it('keeps already-international numbers', () => {
    expect(normalizePhone('963991234567')).toBe('963991234567');
  });
});

describe('buildWhatsAppLink', () => {
  it('builds a wa.me link with encoded text', () => {
    const link = buildWhatsAppLink('0991234567', 'مرحباً');
    expect(link.startsWith('https://wa.me/963991234567?text=')).toBe(true);
    expect(link).toContain('%D9%85'); // encoded Arabic
  });
});

const daysAgo = (n: number) => new Date(Date.now() - n * 86_400_000).toISOString();

describe('productDemandForecast', () => {
  const products = [
    { id: 'p1', name: 'لوح أبيض', stock_quantity: 10 },
    { id: 'p2', name: 'لوح أزرق', stock_quantity: 1000 },
    { id: 'p3', name: 'بلا طلب', stock_quantity: 5 },
  ] as any;

  const orders = [
    { status: 'completed', created_at: daysAgo(5), items: [{ product_id: 'p1', quantity: 30 }] },
    { status: 'completed', created_at: daysAgo(10), items: [{ product_id: 'p1', quantity: 30 }, { product_id: 'p2', quantity: 10 }] },
    { status: 'cancelled', created_at: daysAgo(2), items: [{ product_id: 'p1', quantity: 999 }] }, // ignored
  ] as any;

  it('flags fast-moving low-stock products as at risk', () => {
    const fc = productDemandForecast(orders, products, 30);
    const p1 = fc.find(f => f.productId === 'p1')!;
    // 60 units / 30 days = 2/day; stock 10 → ~5 days → critical
    expect(p1.dailyDemand).toBeCloseTo(2, 5);
    expect(Math.round(p1.daysLeft)).toBe(5);
    expect(p1.severity).toBe('critical');
  });

  it('excludes products with no recent demand', () => {
    const fc = productDemandForecast(orders, products, 30);
    expect(fc.find(f => f.productId === 'p3')).toBeUndefined();
  });

  it('atRisk splits critical and warning', () => {
    const fc = productDemandForecast(orders, products, 30);
    const r = atRisk(fc);
    expect(r.critical.length).toBeGreaterThanOrEqual(1);
  });
});
