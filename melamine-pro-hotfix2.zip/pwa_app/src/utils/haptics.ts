// ─── Haptic feedback ─────────────────────────────────────────────────────────
// Thin wrapper over the Vibration API. No-op where unsupported (e.g. iOS Safari)
// so callers never need to guard. Patterns are short to feel native, not buzzy.

function vibrate(pattern: number | number[]): void {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      navigator.vibrate(pattern);
    }
  } catch { /* ignore */ }
}

export { vibrate };


export const haptics = {
  /** light tick for taps / navigation */
  tap: () => vibrate(10),
  /** very light tick for selection changes (tabs, toggles) */
  selection: () => vibrate(6),
  /** confirmation of a completed action */
  success: () => vibrate([12, 40, 14]),
  /** caution / validation issue */
  warning: () => vibrate([22, 60, 22]),
  /** error / blocked action */
  error: () => vibrate([40, 30, 40, 30, 40]),
  /** stop any ongoing vibration */
  off: () => vibrate(0),
};
