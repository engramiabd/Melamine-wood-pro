// ─── Shared geolocation helpers ──────────────────────────────────────────────
// Single source of truth for permission/availability checks and Arabic error
// messages, used by attendance check-in and the factory-location settings.

// Returns a blocking reason (Arabic) if geolocation can't be used, else null.
export function geoPreflight(): string | null {
  if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
    return 'المتصفح لا يدعم تحديد الموقع';
  }
  if (typeof window !== 'undefined' && !window.isSecureContext) {
    return 'يتطلّب تحديد الموقع اتصالاً آمناً (HTTPS)';
  }
  return null;
}

// Maps a GeolocationPositionError to a clear Arabic message.
export function geoErrorMessage(err: GeolocationPositionError): string {
  if (err.code === err.PERMISSION_DENIED) return 'تم رفض إذن الموقع — فعّله من إعدادات المتصفح';
  if (err.code === err.POSITION_UNAVAILABLE) return 'الموقع غير متاح حالياً — تحقق من GPS/الشبكة';
  if (err.code === err.TIMEOUT) return 'انتهت مهلة تحديد الموقع — أعد المحاولة';
  return 'تعذّر تحديد الموقع';
}

export const GEO_OPTIONS: PositionOptions = { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 };
