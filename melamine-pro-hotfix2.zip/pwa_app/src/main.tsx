import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import { App } from './App';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// ── Register the service worker (production only, to avoid interfering with
// Vite's dev HMR). Enables offline loading of the app shell. ──────────────────
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isProd = Boolean((import.meta as any).env?.PROD);
if (isProd && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => { /* SW is optional */ });
  });
}
