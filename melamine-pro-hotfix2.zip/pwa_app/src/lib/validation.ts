import { z } from 'zod';

// Reusable, app-wide validation schemas (zod). Written against the stable subset
// of the zod API that behaves identically in zod v3 and v4 (this project uses
// v4): no `invalid_type_error`/`required_error` params (removed in v4) and no
// `.email()` string method (moved in v4) — an email regex is used instead.

const M = {
  required: 'هذا الحقل مطلوب',
  tooShort: 'القيمة قصيرة جداً',
  positive: 'يجب أن تكون القيمة أكبر من صفر',
  nonNegative: 'لا يمكن أن تكون القيمة سالبة',
  phone: 'رقم هاتف غير صالح',
  email: 'بريد إلكتروني غير صالح',
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const nonEmptyString = z.string().trim().min(1, M.required);

export const phoneSchema = z
  .string()
  .trim()
  .regex(/^[+0-9\s-]{6,20}$/, M.phone);

export const emailSchema = z.string().trim().regex(EMAIL_RE, M.email);

export const positiveNumber = z.number().positive(M.positive);

export const nonNegativeNumber = z.number().min(0, M.nonNegative);

export const customerSchema = z.object({
  name: nonEmptyString.min(2, M.tooShort),
  phone: phoneSchema.optional().or(z.literal('')),
  email: emailSchema.optional().or(z.literal('')),
});

export const productSchema = z.object({
  name: nonEmptyString.min(2, M.tooShort),
  code: nonEmptyString,
  price_usd: nonNegativeNumber,
  cost_usd: nonNegativeNumber,
});

export const supplierSchema = z.object({
  name: nonEmptyString.min(2, M.tooShort),
  phone: phoneSchema.optional().or(z.literal('')),
});

export type CustomerInput = z.infer<typeof customerSchema>;
export type ProductInput = z.infer<typeof productSchema>;
export type SupplierInput = z.infer<typeof supplierSchema>;

/**
 * Run a schema and return a map of field → first error message (or null when
 * valid). Uses `.safeParse` + `.issues`, both stable across zod v3/v4.
 */
export function collectErrors<T>(schema: z.ZodType<T>, value: unknown): Record<string, string> | null {
  const res = schema.safeParse(value);
  if (res.success) return null;
  const out: Record<string, string> = {};
  for (const issue of res.error.issues) {
    const key = String(issue.path[0] ?? '_');
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}
