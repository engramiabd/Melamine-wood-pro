// ── Offline-first sync engine ────────────────────────────────────────────────
// The app is the source of truth in localStorage and works fully offline. When
// Supabase credentials are configured AND the device is online, this engine
// mirrors each table to Supabase and merges remote changes back.
//
// Model (v1): every table is stored in Supabase as JSONB documents
//   (id text primary key, doc jsonb, updated_at timestamptz)
// so the cloud schema never has to track every individual column.
//
// Sync is a non-destructive UNION merge:
//   • push: upsert local rows to the cloud (never deletes) ;
//   • pull: merge cloud rows back into local by id (cloud wins per-row).
// This guarantees no data is ever lost on first sync or across devices. Row
// deletions do not propagate in v1 (documented limitation).
//
// When Supabase is NOT configured every function here is a no-op, so the
// offline app behaves exactly as before.

import { supabase, isSupabaseConfigured } from './supabase';
import { load, persist } from '../contexts/appData.helpers';

export interface SyncTable { table: string; storageKey: string; idField: string }

// Business entity tables (arrays of records keyed by `id`).
export const SYNC_TABLES: SyncTable[] = [
  { table: 'orders',             storageKey: 'app_orders',           idField: 'id' },
  { table: 'production_lines',   storageKey: 'app_lines',            idField: 'id' },
  { table: 'production_batches', storageKey: 'app_batches',          idField: 'id' },
  { table: 'production_plans',   storageKey: 'app_production_plans', idField: 'id' },
  { table: 'inventory_items',    storageKey: 'app_inventory',        idField: 'id' },
  { table: 'products',           storageKey: 'app_products',         idField: 'id' },
  { table: 'suppliers',          storageKey: 'app_suppliers',        idField: 'id' },
  { table: 'purchase_orders',    storageKey: 'app_purchase_orders',  idField: 'id' },
  { table: 'customers',          storageKey: 'app_customers',        idField: 'id' },
  { table: 'invoices',           storageKey: 'app_invoices',         idField: 'id' },
  { table: 'invoice_payments',   storageKey: 'app_invoice_payments', idField: 'id' },
  { table: 'order_payments',     storageKey: 'app_order_payments',   idField: 'id' },
  { table: 'journal_entries',    storageKey: 'app_journal',          idField: 'id' },
  { table: 'wallets',            storageKey: 'app_wallets',          idField: 'id' },
  { table: 'wallet_transactions',storageKey: 'app_wallet_txs',       idField: 'id' },
  { table: 'employees',          storageKey: 'app_employees',        idField: 'id' },
  { table: 'attendance_records', storageKey: 'app_attendance',       idField: 'id' },
  { table: 'leave_requests',     storageKey: 'app_leaves',           idField: 'id' },
  { table: 'advance_requests',   storageKey: 'app_advances',         idField: 'id' },
  { table: 'audit_log',          storageKey: 'app_audit',            idField: 'id' },
];

// Singleton / config blobs stored in a key/value table.
export const KV_KEYS: string[] = ['app_settings', 'app_role_permissions'];

// NOTE: app_user_passwords, app_error_log and app_avatars are intentionally
// NEVER synced (security / large per-device data).

// ── Status ───────────────────────────────────────────────────────────────────
export interface SyncStatus {
  configured: boolean;
  online: boolean;
  syncing: boolean;
  pending: number;          // tables with unsynced local changes
  lastSyncedAt: string | null;
  error: string | null;
}

const META_KEY = 'app_sync_meta';
interface SyncMeta {
  hashes: Record<string, string>;
  /** ids this device has acknowledged per table (to detect local deletions). */
  ids: Record<string, string[]>;
  /** incremental-pull cursor: max server updated_at seen per table. */
  pulledAt: Record<string, string>;
  lastSyncedAt: string | null;
}
const loadMeta = (): SyncMeta => {
  const m = load<Partial<SyncMeta>>(META_KEY, {});
  return { hashes: m.hashes || {}, ids: m.ids || {}, pulledAt: m.pulledAt || {}, lastSyncedAt: m.lastSyncedAt ?? null };
};
const saveMeta = (m: SyncMeta) => persist(META_KEY, m);

let syncing = false;
let lastError: string | null = null;
const listeners = new Set<(s: SyncStatus) => void>();

function djb2(str: string): string {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}

function tableHash(key: string): string {
  try { return djb2(localStorage.getItem(key) || ''); } catch { return ''; }
}

/** Count of tables whose local data changed since the last successful sync. */
export function pendingCount(): number {
  const meta = loadMeta();
  let n = 0;
  for (const t of SYNC_TABLES) if (meta.hashes[t.table] !== tableHash(t.storageKey)) n++;
  for (const k of KV_KEYS) if (meta.hashes[`kv:${k}`] !== tableHash(k)) n++;
  return n;
}

export function getSyncStatus(): SyncStatus {
  return {
    configured: isSupabaseConfigured,
    online: typeof navigator === 'undefined' ? true : navigator.onLine,
    syncing,
    pending: isSupabaseConfigured ? pendingCount() : 0,
    lastSyncedAt: loadMeta().lastSyncedAt,
    error: lastError,
  };
}

function emit() { const s = getSyncStatus(); listeners.forEach(l => l(s)); }

export function subscribeSync(cb: (s: SyncStatus) => void): () => void {
  listeners.add(cb);
  cb(getSyncStatus());
  return () => { listeners.delete(cb); };
}

// After a pull, the app must re-read state from localStorage.
let hydrate: (() => void) | null = null;
export function setHydrateCallback(cb: () => void) { hydrate = cb; }

// ── Push / pull ──────────────────────────────────────────────────────────────
// NOTE: we never send `updated_at` from the client — the DB stamps it (default
// now() on insert, trigger on update) so the incremental-pull cursor is based on
// the server clock and is immune to device clock skew.
async function pushTable(t: SyncTable, meta: SyncMeta): Promise<void> {
  const rows = load<Record<string, unknown>[]>(t.storageKey, []);
  const alive = (Array.isArray(rows) ? rows : []).filter(r => r && r[t.idField] != null);

  const localIds = new Set(alive.map(r => String(r[t.idField])));
  const upserts = alive.map(r => ({ id: String(r[t.idField]), doc: r, deleted_at: null as string | null }));

  // Rows this device synced before but no longer has → propagate as tombstones.
  const prevIds = meta.ids[t.table] || [];
  const now = new Date().toISOString();
  const tombstones = prevIds
    .filter(id => !localIds.has(id))
    .map(id => ({ id, doc: { id }, deleted_at: now }));

  const payload = [...upserts, ...tombstones];
  if (payload.length === 0) return;
  const { error } = await supabase.from(t.table).upsert(payload, { onConflict: 'id' });
  if (error) throw new Error(`${t.table}: ${error.message}`);
}

/**
 * Incremental merge: fetch only rows whose `updated_at` advanced past our cursor,
 * apply them locally (deletions remove the row), and return the new cursor.
 */
async function pullTable(t: SyncTable, meta: SyncMeta): Promise<string | null> {
  const local = load<Record<string, unknown>[]>(t.storageKey, []);
  const localArr = Array.isArray(local) ? local : [];
  const cursor = meta.pulledAt[t.table];
  // If we lost local data, ignore the cursor and re-pull the whole table.
  const useCursor = cursor && localArr.length > 0;

  let q = supabase.from(t.table).select('id, doc, deleted_at, updated_at');
  if (useCursor) q = q.gte('updated_at', cursor);
  const { data, error } = await q;
  if (error) throw new Error(`${t.table}: ${error.message}`);
  const remote = (data || []) as { id: string; doc: Record<string, unknown>; deleted_at: string | null; updated_at: string }[];

  let maxTs = cursor || null;
  if (remote.length > 0) {
    const byId = new Map<string, Record<string, unknown>>();
    for (const r of localArr) if (r && r[t.idField] != null) byId.set(String(r[t.idField]), r);
    for (const row of remote) {
      if (row.deleted_at) byId.delete(String(row.id));
      else if (row.doc && row.doc[t.idField] != null) byId.set(String(row.id), row.doc);
      if (row.updated_at && (!maxTs || Date.parse(row.updated_at) > Date.parse(maxTs))) maxTs = row.updated_at;
    }
    persist(t.storageKey, Array.from(byId.values()));
  }
  return maxTs;
}

async function pushKV(key: string): Promise<void> {
  const value = load<unknown>(key, null);
  if (value == null) return;
  const { error } = await supabase.from('kv_store').upsert(
    { key, value, updated_at: new Date().toISOString() },
    { onConflict: 'key' },
  );
  if (error) throw new Error(`kv:${key}: ${error.message}`);
}

async function pullKV(key: string): Promise<void> {
  const { data, error } = await supabase.from('kv_store').select('value').eq('key', key).maybeSingle();
  if (error) throw new Error(`kv:${key}: ${error.message}`);
  if (data && (data as { value: unknown }).value != null) persist(key, (data as { value: unknown }).value);
}

// ── Orchestration ────────────────────────────────────────────────────────────
let flushTimer: ReturnType<typeof setTimeout> | null = null;

// Sync runs only for a real (non-demo) account that is online & configured.
// Demo accounts always stay local-only so they never hit RLS or pollute cloud.
function syncEnabled(): boolean {
  if (!isSupabaseConfigured) return false;
  if (typeof navigator !== 'undefined' && !navigator.onLine) return false;
  try { if (localStorage.getItem('melamine_demo_mode') === 'true') return false; } catch { /* ignore */ }
  return true;
}

/**
 * Full two-way sync: push changed tables, then merge remote back, then hydrate.
 * Safe to call anytime; becomes a no-op when offline / unconfigured / demo /
 * already running.
 */
export async function syncNow(opts: { pull?: boolean } = {}): Promise<boolean> {
  const doPull = opts.pull !== false;
  if (!syncEnabled()) return false;
  if (syncing) return false;

  syncing = true; lastError = null; emit();
  const meta = loadMeta();
  let ok = true;

  try {
    // 1) push every table/kv with local changes
    for (const t of SYNC_TABLES) {
      if (meta.hashes[t.table] === tableHash(t.storageKey)) continue;
      try { await pushTable(t, meta); } catch (e) { ok = false; lastError = (e as Error).message; }
    }
    for (const k of KV_KEYS) {
      if (meta.hashes[`kv:${k}`] === tableHash(k)) continue;
      try { await pushKV(k); } catch (e) { ok = false; lastError = (e as Error).message; }
    }

    // 2) pull + merge everything (incremental — only rows changed since cursor)
    const cursors: Record<string, string> = { ...meta.pulledAt };
    if (doPull) {
      for (const t of SYNC_TABLES) {
        try {
          const c = await pullTable(t, meta);
          if (c) cursors[t.table] = c;
        } catch (e) { ok = false; lastError = (e as Error).message; }
      }
      for (const k of KV_KEYS) {
        try { await pullKV(k); } catch (e) { ok = false; lastError = (e as Error).message; }
      }
    }

    // 3) record synced hashes + acknowledged ids + pull cursors (post-merge)
    const after: SyncMeta = { hashes: {}, ids: {}, pulledAt: cursors, lastSyncedAt: new Date().toISOString() };
    for (const t of SYNC_TABLES) {
      after.hashes[t.table] = tableHash(t.storageKey);
      const rows = load<Record<string, unknown>[]>(t.storageKey, []);
      after.ids[t.table] = (Array.isArray(rows) ? rows : [])
        .filter(r => r && r[t.idField] != null).map(r => String(r[t.idField]));
    }
    for (const k of KV_KEYS) after.hashes[`kv:${k}`] = tableHash(k);
    saveMeta(after);

    // 4) refresh app state from the merged localStorage
    if (doPull && hydrate) { try { hydrate(); } catch { /* ignore */ } }
  } finally {
    syncing = false; emit();
  }
  return ok;
}

/** Debounced push-only flush, triggered after local data changes. */
export function scheduleFlush() {
  if (!syncEnabled()) return;
  if (flushTimer) clearTimeout(flushTimer);
  flushTimer = setTimeout(() => { void syncNow({ pull: false }).then(() => emit()); }, 3000);
  emit(); // update pending count immediately
}

let initialized = false;
/** Wire online/offline + an initial full sync. Call once at startup. */
export function initSync() {
  if (initialized || typeof window === 'undefined') return;
  initialized = true;
  window.addEventListener('online', () => { emit(); void syncNow(); });
  window.addEventListener('offline', emit);
  // Re-evaluate after login/logout (demo → real account enables sync).
  window.addEventListener('melamine:auth', () => { emit(); void syncNow(); });
  if (syncEnabled()) {
    // small delay so the app finishes its first render/hydration first
    setTimeout(() => { void syncNow(); }, 1500);
  }
}
