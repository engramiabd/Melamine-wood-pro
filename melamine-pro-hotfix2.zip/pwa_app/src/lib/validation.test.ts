import { describe, it, expect } from 'vitest';
import { customerSchema, productSchema, collectErrors } from './validation';

describe('customerSchema', () => {
  it('accepts a valid customer', () => {
    expect(collectErrors(customerSchema, { name: 'مؤسسة النور', phone: '0991234567', email: '' })).toBeNull();
  });
  it('rejects an empty name', () => {
    const errs = collectErrors(customerSchema, { name: '', phone: '', email: '' });
    expect(errs).not.toBeNull();
    expect(errs!.name).toBeTruthy();
  });
  it('rejects a bad email', () => {
    const errs = collectErrors(customerSchema, { name: 'عميل', email: 'not-an-email' });
    expect(errs?.email).toBeTruthy();
  });
});

describe('productSchema', () => {
  it('accepts a valid product', () => {
    expect(collectErrors(productSchema, { name: 'لوح ميلامين', code: 'MEL-1', price_usd: 12, cost_usd: 8 })).toBeNull();
  });
  it('rejects a negative cost', () => {
    const errs = collectErrors(productSchema, { name: 'لوح', code: 'X', price_usd: 10, cost_usd: -1 });
    expect(errs?.cost_usd).toBeTruthy();
  });
});
