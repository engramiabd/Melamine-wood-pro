import { createClient } from '@supabase/supabase-js';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const env = (import.meta as any).env || {};

const supabaseUrl = env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = env.VITE_SUPABASE_ANON_KEY || 'placeholder-anon-key';

// True only when real Supabase credentials have been provided via .env
// (VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY). Until then, the app runs
// entirely on the bundled demo accounts + localStorage.
export const isSupabaseConfigured: boolean =
  Boolean(env.VITE_SUPABASE_URL) &&
  Boolean(env.VITE_SUPABASE_ANON_KEY) &&
  !String(env.VITE_SUPABASE_URL).includes('placeholder');

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
  },
});

export default supabase;
