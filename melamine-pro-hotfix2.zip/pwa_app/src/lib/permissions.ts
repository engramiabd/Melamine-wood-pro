import type { UserRole } from '../types';

// ─── Granular permission system (Phase 4) ───────────────────────────────────
// A real capability model: every sensitive action maps to a permission key.
// Each role has a default set, which an admin can override (stored per role).

export interface PermissionDef { key: string; label: string; }
export interface PermissionGroup { group: string; perms: PermissionDef[]; }

export const PERMISSION_GROUPS: PermissionGroup[] = [
  { group: 'الطلبات', perms: [
    { key: 'orders.view', label: 'عرض الطلبات' },
    { key: 'orders.create', label: 'إنشاء طلب' },
    { key: 'orders.edit', label: 'تعديل وحالة الطلب' },
    { key: 'orders.delete', label: 'حذف طلب' },
  ]},
  { group: 'الإنتاج', perms: [
    { key: 'production.view', label: 'عرض خطوط الإنتاج' },
    { key: 'production.manage', label: 'تشغيل وإيقاف الخطوط' },
    { key: 'production.batch', label: 'تسجيل دفعات الإنتاج' },
  ]},
  { group: 'المخزون والمشتريات', perms: [
    { key: 'inventory.view', label: 'عرض المخزون' },
    { key: 'inventory.manage', label: 'إدارة المخزون' },
    { key: 'purchasing.view', label: 'عرض المشتريات' },
    { key: 'purchasing.manage', label: 'إدارة الموردين والمشتريات' },
  ]},
  { group: 'المالية', perms: [
    { key: 'finance.view', label: 'عرض المالية' },
    { key: 'finance.manage', label: 'إدارة القيود المحاسبية' },
    { key: 'invoices.view', label: 'عرض الفواتير' },
    { key: 'invoices.manage', label: 'إدارة الفواتير والدفعات' },
  ]},
  { group: 'الموارد البشرية', perms: [
    { key: 'hr.view', label: 'عرض الموظفين' },
    { key: 'hr.manage', label: 'إدارة الموظفين والإجازات' },
    { key: 'payroll.process', label: 'صرف الرواتب' },
  ]},
  { group: 'التقارير والنظام', perms: [
    { key: 'reports.view', label: 'عرض التقارير' },
    { key: 'admin.users', label: 'إدارة المستخدمين' },
    { key: 'admin.settings', label: 'الإعدادات العامة' },
    { key: 'admin.audit', label: 'سجل التدقيق' },
  ]},
];

export const ALL_PERMISSION_KEYS: string[] = PERMISSION_GROUPS.flatMap((g) => g.perms.map((p) => p.key));

export const DEFAULT_ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  admin: [...ALL_PERMISSION_KEYS],
  manager: [
    'orders.view', 'orders.create', 'orders.edit', 'orders.delete',
    'production.view', 'production.manage', 'production.batch',
    'inventory.view', 'inventory.manage', 'purchasing.view', 'purchasing.manage',
    'finance.view', 'invoices.view', 'invoices.manage', 'hr.view', 'reports.view',
  ],
  production_supervisor: [
    'orders.view', 'orders.edit',
    'production.view', 'production.manage', 'production.batch', 'inventory.view',
  ],
  worker: ['production.view', 'production.batch'],
  accountant: [
    'finance.view', 'finance.manage', 'invoices.view', 'invoices.manage',
    'purchasing.view', 'reports.view', 'orders.view',
  ],
  hr: ['hr.view', 'hr.manage', 'payroll.process'],
};

// Resolve whether a role (with optional admin overrides) has a permission.
export function computeCan(
  role: UserRole | undefined,
  overrides: Record<string, string[]> | undefined,
  key: string,
): boolean {
  if (!role) return false;
  const source = overrides && overrides[role] ? overrides : DEFAULT_ROLE_PERMISSIONS;
  const list = (source as Record<string, string[]>)[role] || [];
  return list.includes(key);
}
