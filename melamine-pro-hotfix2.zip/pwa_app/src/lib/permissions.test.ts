import { describe, it, expect } from 'vitest';
import { computeCan, DEFAULT_ROLE_PERMISSIONS, ALL_PERMISSION_KEYS } from './permissions';

describe('DEFAULT_ROLE_PERMISSIONS', () => {
  it('grants admin every permission', () => {
    expect(DEFAULT_ROLE_PERMISSIONS.admin.sort()).toEqual([...ALL_PERMISSION_KEYS].sort());
  });

  it('restricts a worker to production only', () => {
    expect(DEFAULT_ROLE_PERMISSIONS.worker).toContain('production.batch');
    expect(DEFAULT_ROLE_PERMISSIONS.worker).not.toContain('finance.manage');
  });
});

describe('computeCan', () => {
  it('returns false for an unknown/empty role', () => {
    expect(computeCan(undefined, undefined, 'orders.view')).toBe(false);
  });

  it('uses role defaults when no override exists', () => {
    expect(computeCan('accountant', undefined, 'invoices.manage')).toBe(true);
    expect(computeCan('accountant', undefined, 'production.manage')).toBe(false);
  });

  it('lets an override fully replace the default set for that role', () => {
    const overrides = { manager: ['orders.view'] };
    expect(computeCan('manager', overrides, 'orders.view')).toBe(true);
    // a permission the manager had by default but not in the override is now denied
    expect(computeCan('manager', overrides, 'production.manage')).toBe(false);
  });

  it('falls back to defaults for roles not present in the overrides', () => {
    const overrides = { manager: ['orders.view'] };
    expect(computeCan('hr', overrides, 'payroll.process')).toBe(true);
  });
});
