/**
 * archiveLoader — Lazy singleton loader for /archive-data.json.
 *
 * WHY:
 *   archiveData.ts was 241 KB bundled with the app at all times, even for
 *   users who already have their own data in localStorage and never need it.
 *   Moving the data to /public and fetching it on demand means:
 *     • The initial JS bundle is ~236 KB lighter (gzip: ~30 KB saved).
 *     • The fetch only happens once, ever, thanks to the in-memory cache.
 *     • Subsequent loads read from localStorage, not from the archive at all.
 *
 * USAGE:
 *   const data = await loadArchiveData();
 *   setEmployees(data.employees);
 *
 * GUARANTEES:
 *   • Only one fetch in-flight at a time (concurrent callers share the promise).
 *   • Result is cached in memory for the lifetime of the page.
 *   • Fails gracefully — returns empty arrays on network error.
 */

import type { Employee, AuditEntry, Product } from '../types';
import type { InventoryItem, Customer } from '../contexts/appData.types';

export interface ArchiveData {
  employees: Employee[];
  inventory:  InventoryItem[];
  customers:  Customer[];
  products:   Product[];
  audit:      AuditEntry[];
}

const EMPTY: ArchiveData = {
  employees: [],
  inventory:  [],
  customers:  [],
  products:   [],
  audit:      [],
};

let _cache:   ArchiveData | null        = null;
let _promise: Promise<ArchiveData> | null = null;

export async function loadArchiveData(): Promise<ArchiveData> {
  if (_cache)   return _cache;
  if (_promise) return _promise;

  _promise = fetch('/archive-data.json')
    .then(r => {
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.json() as Promise<ArchiveData>;
    })
    .then(data => {
      _cache = data;
      return data;
    })
    .catch(err => {
      console.warn('[archiveLoader] Failed to load archive data:', err);
      _promise = null; // allow retry on next call
      return EMPTY;
    });

  return _promise;
}

/** Pre-warm the fetch without blocking (fire-and-forget). */
export function prefetchArchiveData(): void {
  if (_cache || _promise) return;
  loadArchiveData();
}
