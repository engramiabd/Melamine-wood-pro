import type { UserRole } from '../types';

// ── Per-role identity ────────────────────────────────────────────────────────
// Each role has its own avatar colour so a user's role is recognisable at a
// glance, even before a personal photo is uploaded.
export interface RoleMeta { label: string; gradient: string; ring: string }

export const ROLE_META: Record<UserRole, RoleMeta> = {
  admin:                 { label: 'مدير النظام',   gradient: 'linear-gradient(135deg,#ef4444,#b91c1c)', ring: '#dc2626' },
  manager:               { label: 'مدير تنفيذي',   gradient: 'linear-gradient(135deg,#3b82f6,#1d4ed8)', ring: '#2563eb' },
  production_supervisor: { label: 'مشرف إنتاج',    gradient: 'linear-gradient(135deg,#f59e0b,#b45309)', ring: '#d97706' },
  worker:                { label: 'عامل إنتاج',    gradient: 'linear-gradient(135deg,#10b981,#047857)', ring: '#059669' },
  accountant:            { label: 'محاسب',          gradient: 'linear-gradient(135deg,#8b5cf6,#6d28d9)', ring: '#7c3aed' },
  hr:                    { label: 'موارد بشرية',   gradient: 'linear-gradient(135deg,#ec4899,#be185d)', ring: '#db2777' },
};

const FALLBACK: RoleMeta = { label: '', gradient: 'linear-gradient(135deg,#64748b,#334155)', ring: '#64748b' };

export const roleMeta     = (role?: string): RoleMeta => ROLE_META[(role ?? '') as UserRole] ?? FALLBACK;
export const roleGradient = (role?: string): string   => roleMeta(role).gradient;
export const roleRing     = (role?: string): string   => roleMeta(role).ring;
export const roleLabel    = (role?: string): string   => roleMeta(role).label;

/** Up to two initials from an Arabic or Latin name. */
export function initials(name?: string): string {
  const parts = (name ?? '').trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'م';
  if (parts.length === 1) return parts[0].slice(0, 2);
  return (parts[0][0] ?? '') + (parts[1][0] ?? '');
}

// ── Personal-photo store ─────────────────────────────────────────────────────
// Photos are kept as data-URLs in localStorage, keyed by user id, so they
// survive logout/login (the session object is replaced on each login).
const KEY = 'app_avatars';
export const AVATAR_EVENT = 'avatar:changed';

type AvatarMap = Record<string, string>;

function readMap(): AvatarMap {
  try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch { return {}; }
}
function writeMap(map: AvatarMap) {
  try { localStorage.setItem(KEY, JSON.stringify(map)); } catch { /* quota */ }
}

export function getAvatar(userId?: string): string | null {
  if (!userId) return null;
  return readMap()[userId] ?? null;
}

export function setAvatar(userId: string, dataUrl: string) {
  const map = readMap();
  map[userId] = dataUrl;
  writeMap(map);
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(AVATAR_EVENT, { detail: { userId } }));
}

export function removeAvatar(userId: string) {
  const map = readMap();
  delete map[userId];
  writeMap(map);
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent(AVATAR_EVENT, { detail: { userId } }));
}

// ── Image processing ─────────────────────────────────────────────────────────
/**
 * Reads an uploaded image, center-crops it to a square and downscales it to
 * `size` px, returning a compressed JPEG data-URL small enough for localStorage.
 */
export function fileToAvatarDataUrl(file: File, size = 256): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) { reject(new Error('الملف ليس صورة')); return; }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('تعذّرت قراءة الصورة'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('تعذّر فتح الصورة'));
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = size; canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (!ctx) { reject(new Error('canvas غير مدعوم')); return; }
        // center-crop to square
        const s = Math.min(img.width, img.height);
        const sx = (img.width - s) / 2;
        const sy = (img.height - s) / 2;
        ctx.drawImage(img, sx, sy, s, s, 0, 0, size, size);
        try {
          resolve(canvas.toDataURL('image/jpeg', 0.85));
        } catch (e) {
          reject(e instanceof Error ? e : new Error('تعذّر تحويل الصورة'));
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}
