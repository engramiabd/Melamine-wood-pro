// Shared worker identity helpers. Worker identity across the app is the user id:
//   attendanceRecord.worker_id === user.id === employee.user_id

import type { UserRole } from '../types';

/** Maps demo user ids to their actual UserRole (for role-coloured avatars). */
const ID_ROLE_KEY: Record<string, UserRole> = {
  'demo-admin-001': 'admin',
  'demo-manager-002': 'manager',
  'demo-supervisor-003': 'production_supervisor',
  'demo-worker-004': 'worker',
  'demo-accountant-005': 'accountant',
  'demo-hr-006': 'hr',
};

/** Resolve the UserRole key for a worker id (used for avatar colour). */
export function resolveWorkerRoleKey(
  workerId: string,
  employees?: Array<{ user_id: string; role?: string }>,
): UserRole {
  if (ID_ROLE_KEY[workerId]) return ID_ROLE_KEY[workerId];
  const emp = employees?.find(e => e.user_id === workerId);
  if (emp?.role && ['admin', 'manager', 'production_supervisor', 'worker', 'accountant', 'hr'].includes(emp.role)) {
    return emp.role as UserRole;
  }
  const m = workerId.match(/demo-([a-z_]+)-/);
  if (m) {
    const k = m[1];
    if (k === 'supervisor') return 'production_supervisor';
    if (['admin', 'manager', 'worker', 'accountant', 'hr'].includes(k)) return k as UserRole;
  }
  return 'worker';
}

/** Resolve the display name for a created_by/accepted_by value that may be
 *  either a known user id or an already-readable name. */
export function resolveActorName(value?: string): string {
  if (!value || value === 'system') return '—';
  return WORKER_NAMES[value] || value;
}

export const WORKER_NAMES: Record<string, string> = {
  'demo-admin-001': 'أحمد المدير',
  'demo-manager-002': 'محمد المشرف',
  'demo-supervisor-003': 'خالد المراقب',
  'demo-worker-004': 'علي العامل',
  'demo-accountant-005': 'سمر المحاسبة',
  'demo-hr-006': 'ريم الموارد البشرية',
};

export const WORKER_ROLES: Record<string, string> = {
  'demo-admin-001': 'مدير عام',
  'demo-manager-002': 'مدير إنتاج',
  'demo-supervisor-003': 'مشرف إنتاج',
  'demo-worker-004': 'عامل إنتاج',
  'demo-accountant-005': 'محاسبة',
  'demo-hr-006': 'موارد بشرية',
};

/** Resolve a display name for a worker id, falling back to employees data. */
export function resolveWorkerName(
  workerId: string,
  employees?: Array<{ user_id: string; id: string; position?: string }>,
): string {
  if (WORKER_NAMES[workerId]) return WORKER_NAMES[workerId];
  const emp = employees?.find(e => e.user_id === workerId);
  if (emp) return `موظف ${emp.id}`;
  return 'موظف';
}

export function resolveWorkerRole(
  workerId: string,
  employees?: Array<{ user_id: string; position?: string }>,
): string {
  if (WORKER_ROLES[workerId]) return WORKER_ROLES[workerId];
  const emp = employees?.find(e => e.user_id === workerId);
  return emp?.position || 'موظف';
}
