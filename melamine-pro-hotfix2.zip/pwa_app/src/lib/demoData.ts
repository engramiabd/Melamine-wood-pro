import {
  Order, Product, ProductionLine, RawMaterial,
  JournalEntry, AttendanceRecord, Employee, LeaveRequest,
  WorkerWallet, DashboardStats, Customer
} from '../types';

// ========== PRODUCTS ==========
export const demoProducts: Product[] = [
  { id: 'p1', name: 'لوح ميلامين أبيض مطفي 18مم', code: 'MLM-W18-MT', thickness: '18mm', size: '244x122', finish: 'مطفي', color: 'أبيض', price_usd: 45, price_syp: 585000, cost_usd: 30, stock_quantity: 250, min_stock: 50, created_at: new Date().toISOString() },
  { id: 'p2', name: 'لوح ميلامين بيج لامع 16مم', code: 'MLM-B16-LM', thickness: '16mm', size: '244x122', finish: 'لامع', color: 'بيج', price_usd: 42, price_syp: 546000, cost_usd: 28, stock_quantity: 180, min_stock: 40, created_at: new Date().toISOString() },
  { id: 'p3', name: 'لوح ميلامين خشبي بلوط 18مم', code: 'MLM-O18-WD', thickness: '18mm', size: '244x122', finish: 'خشبي', color: 'بلوط فاتح', price_usd: 55, price_syp: 715000, cost_usd: 38, stock_quantity: 120, min_stock: 30, created_at: new Date().toISOString() },
  { id: 'p4', name: 'لوح ميلامين رمادي مطفي 25مم', code: 'MLM-G25-MT', thickness: '25mm', size: '244x122', finish: 'مطفي', color: 'رمادي', price_usd: 65, price_syp: 845000, cost_usd: 45, stock_quantity: 80, min_stock: 20, created_at: new Date().toISOString() },
  { id: 'p5', name: 'لوح ميلامين أسود لامع 12مم', code: 'MLM-BK12-LM', thickness: '12mm', size: '244x122', finish: 'لامع', color: 'أسود', price_usd: 38, price_syp: 494000, cost_usd: 25, stock_quantity: 15, min_stock: 30, created_at: new Date().toISOString() },
  { id: 'p6', name: 'لوح ميلامين خشبي جوز 18مم', code: 'MLM-W18-WN', thickness: '18mm', size: '244x122', finish: 'خشبي', color: 'جوز', price_usd: 58, price_syp: 754000, cost_usd: 40, stock_quantity: 95, min_stock: 25, created_at: new Date().toISOString() },
];

// ========== CUSTOMERS ==========
export const demoCustomers: Customer[] = [
  { id: 'cust1', name: 'شركة الأثاث الحديث', phone: '+963 11 111 2222', email: 'info@modern-furniture.sy', address: 'المنطقة الصناعية، دمشق', city: 'دمشق', company: 'شركة الأثاث الحديث', status: 'vip', credit_limit_usd: 5000, balance_usd: 0, created_at: '2025-09-01T08:00:00.000Z', updated_at: '2025-09-01T08:00:00.000Z' },
  { id: 'cust2', name: 'مكتبة النجوم', phone: '+963 11 333 4444', email: 'najoom@books.sy', address: 'شارع الثورة، دمشق', city: 'دمشق', company: 'مكتبة النجوم', status: 'active', credit_limit_usd: 2000, balance_usd: 0, created_at: '2025-09-15T08:00:00.000Z', updated_at: '2025-09-15T08:00:00.000Z' },
  { id: 'cust3', name: 'مؤسسة البناء الذهبي', phone: '+963 11 555 6666', company: 'مؤسسة البناء الذهبي', city: 'حلب', status: 'active', credit_limit_usd: 8000, balance_usd: 0, created_at: '2025-10-01T08:00:00.000Z', updated_at: '2025-10-01T08:00:00.000Z' },
  { id: 'cust4', name: 'محلات الأثاث الراقي', phone: '+963 11 777 8888', company: 'محلات الأثاث الراقي', city: 'حمص', status: 'active', credit_limit_usd: 3000, balance_usd: 0, created_at: '2025-10-20T08:00:00.000Z', updated_at: '2025-10-20T08:00:00.000Z' },
  { id: 'cust5', name: 'ديكور الشام', phone: '+963 11 999 0000', company: 'ديكور الشام', city: 'دمشق', status: 'vip', credit_limit_usd: 10000, balance_usd: 0, created_at: '2025-11-05T08:00:00.000Z', updated_at: '2025-11-05T08:00:00.000Z' },
];

// ========== ORDERS ==========
export const demoOrders: Order[] = [
  {
    id: 'o1', order_number: 'ORD-2024-001', customer_name: 'شركة الأثاث الحديث', customer_phone: '+963 11 111 2222',
    status: 'in_production', priority: 'high',
    items: [{ id: 'oi1', order_id: 'o1', product_id: 'p1', product: demoProducts[0], quantity: 50, unit_price_usd: 45, unit_price_syp: 585000, total_usd: 2250, total_syp: 29250000 }],
    total_usd: 2250, total_syp: 29250000, paid_usd: 1000, payment_status: 'partial', notes: 'تسليم عاجل', production_line_id: 'pl1',
    created_by: 'demo-admin-001', due_date: new Date(Date.now() + 2 * 24 * 3600000).toISOString(),
    created_at: new Date(Date.now() - 2 * 24 * 3600000).toISOString(), updated_at: new Date().toISOString()
  },
  {
    id: 'o2', order_number: 'ORD-2024-002', customer_name: 'مكتبة النجوم', customer_phone: '+963 11 333 4444',
    status: 'pending', priority: 'normal',
    items: [{ id: 'oi2', order_id: 'o2', product_id: 'p3', product: demoProducts[2], quantity: 30, unit_price_usd: 55, unit_price_syp: 715000, total_usd: 1650, total_syp: 21450000 }],
    total_usd: 1650, total_syp: 21450000, paid_usd: 0, payment_status: 'unpaid', production_line_id: 'pl2',
    created_by: 'demo-manager-002', due_date: new Date(Date.now() + 5 * 24 * 3600000).toISOString(),
    created_at: new Date(Date.now() - 1 * 24 * 3600000).toISOString(), updated_at: new Date().toISOString()
  },
  {
    id: 'o3', order_number: 'ORD-2024-003', customer_name: 'مؤسسة البناء الذهبي',
    status: 'completed', priority: 'normal',
    items: [{ id: 'oi3', order_id: 'o3', product_id: 'p2', product: demoProducts[1], quantity: 100, unit_price_usd: 42, unit_price_syp: 546000, total_usd: 4200, total_syp: 54600000 }],
    total_usd: 4200, total_syp: 54600000, paid_usd: 4200, payment_status: 'paid',
    created_by: 'demo-admin-001', due_date: new Date(Date.now() - 1 * 24 * 3600000).toISOString(),
    completed_at: new Date(Date.now() - 1 * 24 * 3600000).toISOString(),
    created_at: new Date(Date.now() - 7 * 24 * 3600000).toISOString(), updated_at: new Date().toISOString()
  },
  {
    id: 'o4', order_number: 'ORD-2024-004', customer_name: 'محلات الأثاث الراقي',
    status: 'quality_check', priority: 'urgent',
    items: [{ id: 'oi4', order_id: 'o4', product_id: 'p4', product: demoProducts[3], quantity: 40, unit_price_usd: 65, unit_price_syp: 845000, total_usd: 2600, total_syp: 33800000 }],
    total_usd: 2600, total_syp: 33800000, paid_usd: 0, payment_status: 'unpaid', notes: 'مراجعة جودة مطلوبة', production_line_id: 'pl3',
    created_by: 'demo-manager-002', due_date: new Date(Date.now() + 1 * 24 * 3600000).toISOString(),
    created_at: new Date(Date.now() - 3 * 24 * 3600000).toISOString(), updated_at: new Date().toISOString()
  },
  {
    id: 'o5', order_number: 'ORD-2024-005', customer_name: 'ديكور الشام',
    status: 'on_hold', priority: 'low',
    items: [{ id: 'oi5', order_id: 'o5', product_id: 'p6', product: demoProducts[5], quantity: 25, unit_price_usd: 58, unit_price_syp: 754000, total_usd: 1450, total_syp: 18850000 }],
    total_usd: 1450, total_syp: 18850000, paid_usd: 0, payment_status: 'unpaid', notes: 'في انتظار تأكيد العميل',
    created_by: 'demo-manager-002', due_date: new Date(Date.now() + 10 * 24 * 3600000).toISOString(),
    created_at: new Date(Date.now() - 1 * 24 * 3600000).toISOString(), updated_at: new Date().toISOString()
  },
];

// ========== PRODUCTION LINES ==========
export const demoProductionLines: ProductionLine[] = [
  { id: 'pl1', name: 'خط الإنتاج A', code: 'LINE-A', status: 'active', capacity_per_day: 200, current_order_id: 'o1', operator_id: 'demo-worker-004', efficiency_percentage: 87, last_maintenance: new Date(Date.now() - 14 * 24 * 3600000).toISOString(), created_at: new Date().toISOString() },
  { id: 'pl2', name: 'خط الإنتاج B', code: 'LINE-B', status: 'active', capacity_per_day: 180, current_order_id: 'o2', efficiency_percentage: 92, last_maintenance: new Date(Date.now() - 7 * 24 * 3600000).toISOString(), created_at: new Date().toISOString() },
  { id: 'pl3', name: 'خط الإنتاج C', code: 'LINE-C', status: 'maintenance', capacity_per_day: 220, efficiency_percentage: 0, last_maintenance: new Date().toISOString(), notes: 'صيانة دورية - استبدال بكرات الضغط', created_at: new Date().toISOString() },
  { id: 'pl4', name: 'خط الإنتاج D', code: 'LINE-D', status: 'idle', capacity_per_day: 160, efficiency_percentage: 0, last_maintenance: new Date(Date.now() - 30 * 24 * 3600000).toISOString(), created_at: new Date().toISOString() },
];

// ========== RAW MATERIALS ==========
export const demoMaterials: RawMaterial[] = [
  { id: 'm1', name: 'ورق الميلامين أبيض', code: 'RAW-MPW', category: 'raw_material', unit: 'كغ', current_stock: 5000, min_stock: 1000, max_stock: 10000, unit_cost_usd: 2.5, unit_cost_syp: 32500, supplier: 'شركة الورق الدولية', location: 'مستودع A-1', last_updated: new Date().toISOString() },
  { id: 'm2', name: 'لوح HDF 18مم خام', code: 'RAW-HDF18', category: 'raw_material', unit: 'لوح', current_stock: 800, min_stock: 200, max_stock: 2000, unit_cost_usd: 18, unit_cost_syp: 234000, supplier: 'مصنع الخشب المتحد', location: 'مستودع B-2', last_updated: new Date().toISOString() },
  { id: 'm3', name: 'راتنج الميلامين', code: 'CHEM-MR', category: 'chemical', unit: 'لتر', current_stock: 200, min_stock: 100, max_stock: 500, unit_cost_usd: 8, unit_cost_syp: 104000, supplier: 'شركة الكيماويات', location: 'مستودع كيميائي C-1', last_updated: new Date().toISOString() },
  { id: 'm4', name: 'صمغ يوريا فورمالديهايد', code: 'CHEM-UF', category: 'chemical', unit: 'كغ', current_stock: 150, min_stock: 200, max_stock: 600, unit_cost_usd: 3.5, unit_cost_syp: 45500, supplier: 'شركة الكيماويات', location: 'مستودع كيميائي C-2', last_updated: new Date().toISOString() },
  { id: 'm5', name: 'حافة PVC أبيض', code: 'RAW-PVC-W', category: 'raw_material', unit: 'متر', current_stock: 10000, min_stock: 2000, max_stock: 20000, unit_cost_usd: 0.15, unit_cost_syp: 1950, supplier: 'شركة البلاستيك', location: 'مستودع D-1', last_updated: new Date().toISOString() },
  { id: 'm6', name: 'صندوق تغليف كرتون', code: 'PKG-BOX', category: 'packaging', unit: 'صندوق', current_stock: 500, min_stock: 100, max_stock: 1000, unit_cost_usd: 1.2, unit_cost_syp: 15600, supplier: 'مصنع الكرتون', location: 'مستودع E-1', last_updated: new Date().toISOString() },
];

// ========== JOURNAL ENTRIES ==========
export const demoJournalEntries: JournalEntry[] = [
  { id: 'j1', entry_number: 'JNL-2024-001', type: 'income', category: 'مبيعات', amount_usd: 4200, amount_syp: 54600000, currency: 'USD', payment_method: 'bank_transfer', description: 'دفعة طلب ORD-2024-003', reference: 'ORD-2024-003', order_id: 'o3', created_by: 'demo-accountant-005', entry_date: new Date(Date.now() - 1 * 24 * 3600000).toISOString(), created_at: new Date().toISOString() },
  { id: 'j2', entry_number: 'JNL-2024-002', type: 'expense', category: 'مواد خام', amount_usd: 1800, amount_syp: 23400000, currency: 'USD', payment_method: 'cash', description: 'شراء ورق ميلامين', created_by: 'demo-accountant-005', entry_date: new Date(Date.now() - 2 * 24 * 3600000).toISOString(), created_at: new Date().toISOString() },
  { id: 'j3', entry_number: 'JNL-2024-003', type: 'expense', category: 'رواتب', amount_usd: 3500, amount_syp: 45500000, currency: 'USD', payment_method: 'bank_transfer', description: 'رواتب شهر يناير', created_by: 'demo-accountant-005', entry_date: new Date(Date.now() - 3 * 24 * 3600000).toISOString(), created_at: new Date().toISOString() },
  { id: 'j4', entry_number: 'JNL-2024-004', type: 'income', category: 'مبيعات', amount_usd: 2250, amount_syp: 29250000, currency: 'USD', payment_method: 'cash', description: 'دفعة مقدمة طلب ORD-2024-001', order_id: 'o1', created_by: 'demo-accountant-005', entry_date: new Date().toISOString(), created_at: new Date().toISOString() },
  { id: 'j5', entry_number: 'JNL-2024-005', type: 'expense', category: 'كهرباء', amount_usd: 450, amount_syp: 5850000, currency: 'USD', payment_method: 'bank_transfer', description: 'فاتورة كهرباء شهر يناير', created_by: 'demo-accountant-005', entry_date: new Date(Date.now() - 4 * 24 * 3600000).toISOString(), created_at: new Date().toISOString() },
];

// ========== EMPLOYEES ==========
export const demoEmployees: Employee[] = [
  { id: 'e1', user_id: 'demo-admin-001', employee_number: 'EMP-001', department: 'الإدارة', position: 'مدير عام', hire_date: '2020-01-01', salary_usd: 1500, salary_syp: 19500000, working_hours: 8, is_active: true },
  { id: 'e2', user_id: 'demo-manager-002', employee_number: 'EMP-002', department: 'الإنتاج', position: 'مدير إنتاج', hire_date: '2020-03-15', salary_usd: 1200, salary_syp: 15600000, working_hours: 8, is_active: true },
  { id: 'e3', user_id: 'demo-supervisor-003', employee_number: 'EMP-003', department: 'الإنتاج', position: 'مشرف خط إنتاج', hire_date: '2021-06-01', salary_usd: 900, salary_syp: 11700000, working_hours: 8, is_active: true },
  { id: 'e4', user_id: 'demo-worker-004', employee_number: 'EMP-004', department: 'خط الإنتاج A', position: 'عامل ماهر', hire_date: '2022-01-15', salary_usd: 600, salary_syp: 7800000, working_hours: 8, is_active: true },
  { id: 'e5', user_id: 'demo-accountant-005', employee_number: 'EMP-005', department: 'المالية', position: 'محاسب', hire_date: '2021-09-01', salary_usd: 950, salary_syp: 12350000, working_hours: 8, is_active: true },
  { id: 'e6', user_id: 'demo-hr-006', employee_number: 'EMP-006', department: 'الموارد البشرية', position: 'مسؤول موارد بشرية', hire_date: '2022-03-01', salary_usd: 850, salary_syp: 11050000, working_hours: 8, is_active: true },
];

// ========== ATTENDANCE ==========
const today = new Date().toISOString().split('T')[0];
const yesterday = new Date(Date.now() - 24 * 3600000).toISOString().split('T')[0];

export const demoAttendance: AttendanceRecord[] = [
  { id: 'a1', worker_id: 'demo-admin-001', date: today, check_in: today + 'T08:02:00', check_out: today + 'T17:05:00', status: 'present', location_lat: 33.5138, location_lng: 36.2765, created_at: new Date().toISOString() },
  { id: 'a2', worker_id: 'demo-manager-002', date: today, check_in: today + 'T08:15:00', status: 'present', location_lat: 33.5140, location_lng: 36.2768, created_at: new Date().toISOString() },
  { id: 'a3', worker_id: 'demo-worker-004', date: today, check_in: today + 'T07:55:00', check_out: today + 'T16:58:00', status: 'present', location_lat: 33.5135, location_lng: 36.2760, created_at: new Date().toISOString() },
  { id: 'a4', worker_id: 'demo-supervisor-003', date: today, status: 'absent', created_at: new Date().toISOString() },
  { id: 'a5', worker_id: 'demo-admin-001', date: yesterday, check_in: yesterday + 'T08:00:00', check_out: yesterday + 'T17:00:00', status: 'present', created_at: new Date().toISOString() },
  { id: 'a6', worker_id: 'demo-worker-004', date: yesterday, check_in: yesterday + 'T09:30:00', check_out: yesterday + 'T17:00:00', status: 'late', created_at: new Date().toISOString() },
];

// ========== LEAVE REQUESTS ==========
export const demoLeaveRequests: LeaveRequest[] = [
  { id: 'lr1', employee_id: 'e3', leave_type: 'annual', start_date: new Date(Date.now() + 7 * 24 * 3600000).toISOString().split('T')[0], end_date: new Date(Date.now() + 9 * 24 * 3600000).toISOString().split('T')[0], days_count: 3, reason: 'إجازة سنوية', status: 'pending', created_at: new Date().toISOString() },
  { id: 'lr2', employee_id: 'e4', leave_type: 'sick', start_date: today, end_date: today, days_count: 1, reason: 'مراجعة طبية', status: 'approved', approved_by: 'demo-hr-006', created_at: new Date().toISOString() },
];

// ========== WORKER WALLETS ==========
export const demoWallets: WorkerWallet[] = [
  { id: 'w1', worker_id: 'demo-worker-004', balance_usd: 350, balance_syp: 4550000, total_earned_usd: 1800, total_deductions_usd: 120, last_updated: new Date().toISOString() },
  { id: 'w2', worker_id: 'demo-supervisor-003', balance_usd: 500, balance_syp: 6500000, total_earned_usd: 2700, total_deductions_usd: 200, last_updated: new Date().toISOString() },
];

// ========== PRODUCTION BATCHES ==========
export interface ProductionBatch {
  id: string;
  line_id: string;
  order_id: string;
  product_name: string;
  product_id?: string; // links to the catalog product (for BOM / inventory deduction)
  planned_quantity: number;
  produced_quantity: number;
  defective_quantity: number;
  shift: 'morning' | 'evening' | 'night';
  start_time: string;
  end_time?: string;
  status: 'running' | 'completed' | 'paused';
  operator_name: string;
  notes?: string;
}

export const demoProductionBatches: ProductionBatch[] = [
  {
    id: 'b1', line_id: 'pl1', order_id: 'o1',
    product_name: 'لوح ميلامين أبيض مطفي 18مم',
    planned_quantity: 200, produced_quantity: 184, defective_quantity: 3,
    shift: 'morning', operator_name: 'علي العامل',
    start_time: new Date(Date.now() - 6 * 3600000).toISOString(),
    status: 'running', notes: 'الإنتاج يسير بشكل طبيعي',
  },
  {
    id: 'b2', line_id: 'pl2', order_id: 'o2',
    product_name: 'لوح ميلامين بيج لامع 16مم',
    planned_quantity: 180, produced_quantity: 156, defective_quantity: 2,
    shift: 'morning', operator_name: 'خالد المراقب',
    start_time: new Date(Date.now() - 5 * 3600000).toISOString(),
    status: 'running',
  },
  {
    id: 'b3', line_id: 'pl1', order_id: 'o3',
    product_name: 'لوح ميلامين أبيض مطفي 18مم',
    planned_quantity: 200, produced_quantity: 200, defective_quantity: 4,
    shift: 'evening', operator_name: 'علي العامل',
    start_time: new Date(Date.now() - 30 * 3600000).toISOString(),
    end_time: new Date(Date.now() - 22 * 3600000).toISOString(),
    status: 'completed',
  },
  {
    id: 'b4', line_id: 'pl2', order_id: 'o3',
    product_name: 'لوح ميلامين بيج لامع 16مم',
    planned_quantity: 180, produced_quantity: 178, defective_quantity: 1,
    shift: 'evening', operator_name: 'خالد المراقب',
    start_time: new Date(Date.now() - 29 * 3600000).toISOString(),
    end_time: new Date(Date.now() - 21 * 3600000).toISOString(),
    status: 'completed',
  },
];

export interface ProductionLineExtended {
  id: string;
  name: string;
  code: string;
  status: 'active' | 'idle' | 'maintenance' | 'stopped';
  capacity_per_day: number;
  current_order_id?: string;
  operator_id?: string;
  efficiency_percentage: number;
  last_maintenance?: string;
  notes?: string;
  created_at: string;
  // Extended fields
  operating_cost_usd: number;
  stop_reason?: string;
  stop_duration?: string; // HH:MM:SS
  stop_started_at?: string;
  total_produced_today: number;
  total_defective_today: number;
  production_speed: number; // boards per hour
  temperature?: number; // press temperature °C
  pressure?: number; // press pressure bar
}

export const demoProductionLinesExtended: ProductionLineExtended[] = [
  {
    id: 'pl1', name: 'خط الإنتاج A - ميلامين أبيض', code: 'LINE-A',
    status: 'active', capacity_per_day: 200,
    current_order_id: 'o1', operator_id: 'demo-worker-004',
    efficiency_percentage: 92, operating_cost_usd: 975,
    last_maintenance: new Date(Date.now() - 14 * 24 * 3600000).toISOString(),
    total_produced_today: 184, total_defective_today: 3,
    production_speed: 28, temperature: 165, pressure: 18,
    created_at: new Date().toISOString(),
  },
  {
    id: 'pl2', name: 'خط الإنتاج B - ميلامين لامع', code: 'LINE-B',
    status: 'stopped', capacity_per_day: 180,
    current_order_id: 'o2',
    efficiency_percentage: 0, operating_cost_usd: 820,
    stop_reason: 'نقص في الكهرباء - انتظار التوريد',
    stop_duration: '02:15:00',
    stop_started_at: new Date(Date.now() - 2.25 * 3600000).toISOString(),
    last_maintenance: new Date(Date.now() - 7 * 24 * 3600000).toISOString(),
    total_produced_today: 156, total_defective_today: 2,
    production_speed: 0,
    created_at: new Date().toISOString(),
  },
  {
    id: 'pl3', name: 'خط الإنتاج C - ميلامين خشبي', code: 'LINE-C',
    status: 'maintenance', capacity_per_day: 220,
    efficiency_percentage: 0, operating_cost_usd: 1100,
    last_maintenance: new Date().toISOString(),
    notes: 'صيانة دورية - استبدال بكرات الضغط',
    total_produced_today: 0, total_defective_today: 0,
    production_speed: 0,
    created_at: new Date().toISOString(),
  },
  {
    id: 'pl4', name: 'خط الإنتاج D - ميلامين رمادي', code: 'LINE-D',
    status: 'idle', capacity_per_day: 160,
    efficiency_percentage: 0, operating_cost_usd: 760,
    last_maintenance: new Date(Date.now() - 30 * 24 * 3600000).toISOString(),
    total_produced_today: 0, total_defective_today: 0,
    production_speed: 0,
    created_at: new Date().toISOString(),
  },
];

// ========== PRODUCTION HOURLY DATA (for charts) ==========
export const demoHourlyProduction = [
  { hour: '06:00', lineA: 22, lineB: 0, target: 25 },
  { hour: '07:00', lineA: 26, lineB: 20, target: 25 },
  { hour: '08:00', lineA: 28, lineB: 22, target: 25 },
  { hour: '09:00', lineA: 25, lineB: 18, target: 25 },
  { hour: '10:00', lineA: 30, lineB: 0, target: 25 },
  { hour: '11:00', lineA: 27, lineB: 0, target: 25 },
  { hour: '12:00', lineA: 26, lineB: 0, target: 25 },
];

// ========== DASHBOARD STATS ==========
export const demoDashboardStats: DashboardStats = {
  total_orders: 5,
  active_orders: 3,
  completed_today: 1,
  total_revenue_usd: 15750,
  total_revenue_syp: 204750000,
  active_production_lines: 2,
  total_workers: 6,
  present_today: 3,
  low_stock_items: 2,
  pending_orders: 2,
};
