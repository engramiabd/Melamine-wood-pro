// ─── إعدادات المصنع (P1) ─────────────────────────────────────────────────────
// ثوابت مستخرجة ومتحقَّق منها من أرشيف «شركة عبد الهادي للصناعة».
// 1 دزة = 180 ورقة، 1 صندوق = 9 دزة، 1 ربطة = 50 لوح MDF.

export const FACTORY = {
  mdfBundleSize: 50,        // لوح / ربطة
  paperSheetsPerDozen: 180, // ورقة / دزة
  paperDozensPerBox: 9,     // دزة / صندوق
  // الحدود الدنيا
  minMelamineBoards: 40,    // لوح ميلامين
  minMdfBundles: 2,         // ربطة
  minPaperDozens: 1,        // دزة
  // المازوت
  dieselMin: 500, dieselAvg: 2000, dieselMax: 10000, // لتر
  dieselPerHour: 45, dieselPerDay: 450, workHoursPerDay: 10,
} as const;

export const PAPER_SHEETS_PER_BOX = FACTORY.paperSheetsPerDozen * FACTORY.paperDozensPerBox; // 1620
export const MIN_MDF_BOARDS = FACTORY.mdfBundleSize * FACTORY.minMdfBundles;   // 100
export const MIN_PAPER_SHEETS = FACTORY.paperSheetsPerDozen * FACTORY.minPaperDozens; // 180

// عدد الأوراق → صندوق + دزة + ورقة
export function paperBreakdown(sheets: number): { box: number; dozen: number; sheet: number } {
  const s = Math.max(0, Math.round(sheets));
  const box = Math.floor(s / PAPER_SHEETS_PER_BOX);
  let rem = s - box * PAPER_SHEETS_PER_BOX;
  const dozen = Math.floor(rem / FACTORY.paperSheetsPerDozen);
  rem -= dozen * FACTORY.paperSheetsPerDozen;
  return { box, dozen, sheet: rem };
}

export function paperLabel(sheets: number): string {
  const b = paperBreakdown(sheets);
  const parts: string[] = [];
  if (b.box) parts.push(`${b.box} صندوق`);
  if (b.dozen) parts.push(`${b.dozen} دزة`);
  if (b.sheet || parts.length === 0) parts.push(`${b.sheet} ورقة`);
  return parts.join(' + ');
}

// عدد ألواح MDF → ربطة + فرط
export function mdfBundles(boards: number): { bundles: number; loose: number } {
  const n = Math.max(0, Math.round(boards));
  return { bundles: Math.floor(n / FACTORY.mdfBundleSize), loose: n % FACTORY.mdfBundleSize };
}

export function mdfLabel(boards: number): string {
  const { bundles, loose } = mdfBundles(boards);
  const parts: string[] = [];
  if (bundles) parts.push(`${bundles} ربطة`);
  if (loose || parts.length === 0) parts.push(`${loose} لوح`);
  return parts.join(' + ');
}

// حالة المازوت حسب العتبات
export function dieselStatus(liters: number): { label: string; color: string } {
  if (liters < FACTORY.dieselMin) return { label: 'حرج', color: '#dc2626' };
  if (liters < FACTORY.dieselAvg) return { label: 'منخفض', color: '#f59e0b' };
  return { label: 'جيد', color: '#16a34a' };
}

// ── Runtime overrides via SystemSettings ──────────────────────────────────────
// Prefer reading from systemSettings (stored in localStorage + Supabase) when
// available. The FACTORY constants above remain as fallback defaults.
// Usage in components: import { getFactoryFromSettings } from './factoryConfig'
// then: const f = getFactoryFromSettings(systemSettings);

import type { SystemSettings } from '../contexts/appData.types';

export interface RuntimeFactory {
  mdfBundleSize: number;
  paperSheetsPerDozen: number;
  paperDozensPerBox: number;
  paperSheetsPerBox: number;
  dieselMin: number;
  dieselAvg: number;
}

export function getFactoryFromSettings(s?: Partial<SystemSettings>): RuntimeFactory {
  const mdfBundleSize       = s?.mdfBundleSize       ?? FACTORY.mdfBundleSize;
  const paperSheetsPerDozen = s?.paperSheetsPerDozen  ?? FACTORY.paperSheetsPerDozen;
  const paperDozensPerBox   = s?.paperDozensPerBox    ?? FACTORY.paperDozensPerBox;
  return {
    mdfBundleSize,
    paperSheetsPerDozen,
    paperDozensPerBox,
    paperSheetsPerBox: paperSheetsPerDozen * paperDozensPerBox,
    dieselMin:  s?.dieselMinLiters ?? FACTORY.dieselMin,
    dieselAvg:  s?.dieselAvgLiters ?? FACTORY.dieselAvg,
  };
}
