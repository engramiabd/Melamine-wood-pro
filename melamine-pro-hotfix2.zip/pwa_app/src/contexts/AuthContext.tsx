import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

// ── Password hashing (Web Crypto API — runs in browser + Node 18+) ────────────
// Passwords are stored as SHA-256 hex digests, never as plaintext.
async function hashPassword(raw: string): Promise<string> {
  const buf = await crypto.subtle.digest(
    'SHA-256',
    new TextEncoder().encode(raw),
  );
  return Array.from(new Uint8Array(buf))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}
import { User, UserRole, DemoAccount } from '../types';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

// ── Demo Accounts (exported so LoginPage can use the SAME data) ───────────────
// SHA-256('demo123') — pre-computed so we never store plaintext
const DEMO_HASH = 'd3ad9315b7be5dd53b31a273b3b3aba5defe700808305aa16a3062b76658a791';

export const DEMO_ACCOUNTS: DemoAccount[] = [
  { email: 'admin@melamine.demo',      passwordHash: DEMO_HASH, role: 'admin',               full_name: 'أحمد المدير',            description: 'صلاحيات كاملة للنظام' },
  { email: 'manager@melamine.demo',    passwordHash: DEMO_HASH, role: 'manager',             full_name: 'محمد المشرف',            description: 'إدارة الطلبات والإنتاج' },
  { email: 'supervisor@melamine.demo', passwordHash: DEMO_HASH, role: 'production_supervisor',full_name: 'خالد المراقب',           description: 'الإشراف على خطوط الإنتاج' },
  { email: 'worker@melamine.demo',     passwordHash: DEMO_HASH, role: 'worker',              full_name: 'علي العامل',             description: 'تسجيل الحضور والإنتاج' },
  { email: 'accountant@melamine.demo', passwordHash: DEMO_HASH, role: 'accountant',          full_name: 'سمر المحاسبة',           description: 'إدارة الحسابات والمالية' },
  { email: 'hr@melamine.demo',         passwordHash: DEMO_HASH, role: 'hr',                  full_name: 'ريم الموارد البشرية',    description: 'إدارة الموظفين والإجازات' },
];

// ── Demo user profiles ─────────────────────────────────────────────────────────
const DEMO_USERS: Record<string, User> = {
  'admin@melamine.demo': {
    id: 'demo-admin-001',
    email: 'admin@melamine.demo',
    full_name: 'أحمد المدير',
    role: 'admin',
    phone: '+963 11 234 5678',
    department: 'الإدارة العليا',
    is_active: true,
    created_at: new Date().toISOString(),
  },
  'manager@melamine.demo': {
    id: 'demo-manager-002',
    email: 'manager@melamine.demo',
    full_name: 'محمد المشرف',
    role: 'manager',
    phone: '+963 11 234 5679',
    department: 'الإنتاج',
    is_active: true,
    created_at: new Date().toISOString(),
  },
  'supervisor@melamine.demo': {
    id: 'demo-supervisor-003',
    email: 'supervisor@melamine.demo',
    full_name: 'خالد المراقب',
    role: 'production_supervisor',
    phone: '+963 11 234 5680',
    department: 'الإنتاج',
    is_active: true,
    created_at: new Date().toISOString(),
  },
  'worker@melamine.demo': {
    id: 'demo-worker-004',
    email: 'worker@melamine.demo',
    full_name: 'علي العامل',
    role: 'worker',
    phone: '+963 11 234 5681',
    department: 'خط الإنتاج 1',
    is_active: true,
    created_at: new Date().toISOString(),
  },
  'accountant@melamine.demo': {
    id: 'demo-accountant-005',
    email: 'accountant@melamine.demo',
    full_name: 'سمر المحاسبة',
    role: 'accountant',
    phone: '+963 11 234 5682',
    department: 'المالية',
    is_active: true,
    created_at: new Date().toISOString(),
  },
  'hr@melamine.demo': {
    id: 'demo-hr-006',
    email: 'hr@melamine.demo',
    full_name: 'ريم الموارد البشرية',
    role: 'hr',
    phone: '+963 11 234 5683',
    department: 'الموارد البشرية',
    is_active: true,
    created_at: new Date().toISOString(),
  },
};

// ── Context Type ───────────────────────────────────────────────────────────────
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isDemoMode: boolean;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  loginDemo: (account: DemoAccount) => void;
  logout: () => void;
  hasRole: (roles: UserRole | UserRole[]) => boolean;
  updateUser: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

// ── Auth Provider ──────────────────────────────────────────────────────────────
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDemoMode, setIsDemoMode] = useState(false);

  // Restore persisted session on mount
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const savedUser = localStorage.getItem('melamine_user');
        const savedDemo = localStorage.getItem('melamine_demo_mode');
        if (savedUser) {
          const parsed = JSON.parse(savedUser) as User;
          const demo = savedDemo === 'true';

          // For real (non-demo) sessions, verify the Supabase session is still
          // valid before trusting the cached profile.
          if (!demo && isSupabaseConfigured) {
            const { data } = await supabase.auth.getSession();
            if (!data.session) {
              localStorage.removeItem('melamine_user');
              localStorage.removeItem('melamine_demo_mode');
              if (!cancelled) setIsLoading(false);
              return;
            }
          }

          if (!cancelled) {
            setUser(parsed);
            setIsDemoMode(demo);
          }
        }
      } catch {
        // Corrupted storage — clear it
        localStorage.removeItem('melamine_user');
        localStorage.removeItem('melamine_demo_mode');
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // ── login: checks demo accounts then would call Supabase ────────────────────
  const login = useCallback(async (
    email: string,
    password: string,
  ): Promise<{ error?: string }> => {
    setIsLoading(true);
    try {
      // Normalize input
      const normalizedEmail = email.trim().toLowerCase();

      // Check against all demo accounts
      // Hash the input before comparing — we never compare plaintext
      const inputHash = await hashPassword(password);
      const demoAccount = DEMO_ACCOUNTS.find(
        a => a.email.toLowerCase() === normalizedEmail && a.passwordHash === inputHash,
      );

      if (demoAccount) {
        const demoUser = DEMO_USERS[demoAccount.email];
        if (demoUser) {
          setUser(demoUser);
          setIsDemoMode(true);
          localStorage.setItem('melamine_user', JSON.stringify(demoUser));
          localStorage.setItem('melamine_demo_mode', 'true');
          return {};  // success
        }
      }

      // Not a demo account → use real Supabase auth if configured
      if (isSupabaseConfigured) {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: normalizedEmail,
          password,
        });
        if (error) {
          return { error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
        }
        if (data.user) {
          // Fetch the user's profile (role, name, department, etc.) from the
          // `profiles` table. The table is expected to mirror the `User` type
          // and be keyed by auth user id, with RLS scoping rows to the owner.
          const { data: profile, error: profileError } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', data.user.id)
            .single();

          if (profileError || !profile) {
            return { error: 'تعذر تحميل بيانات الحساب، يرجى التواصل مع المسؤول' };
          }

          const realUser = profile as User;
          setUser(realUser);
          setIsDemoMode(false);
          localStorage.setItem('melamine_user', JSON.stringify(realUser));
          localStorage.setItem('melamine_demo_mode', 'false');
          try { window.dispatchEvent(new Event('melamine:auth')); } catch { /* noop */ }
          return {};
        }
      }

      return { error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
    } catch {
      return { error: 'حدث خطأ في الاتصال، يرجى المحاولة مجدداً' };
    } finally {
      setIsLoading(false);
    }
  }, []);

  // ── loginDemo: instant login for demo mode ────────────────────────────────
  const loginDemo = useCallback((account: DemoAccount) => {
    const demoUser = DEMO_USERS[account.email];
    if (demoUser) {
      setUser(demoUser);
      setIsDemoMode(true);
      localStorage.setItem('melamine_user', JSON.stringify(demoUser));
      localStorage.setItem('melamine_demo_mode', 'true');
    }
  }, []);

  // ── logout ─────────────────────────────────────────────────────────────────
  const logout = useCallback(() => {
    if (isDemoMode === false && isSupabaseConfigured) {
      supabase.auth.signOut().catch(() => { /* ignore */ });
    }
    setUser(null);
    setIsDemoMode(false);
    localStorage.removeItem('melamine_user');
    localStorage.removeItem('melamine_demo_mode');
    try { window.dispatchEvent(new Event('melamine:auth')); } catch { /* noop */ }
  }, [isDemoMode]);

  // ── updateUser: patch in-memory profile + persisted session ─────────────────
  // Keeps the running UI (TopBar, Profile header, …) in sync the instant a
  // profile edit is saved, instead of only after a full page reload.
  const updateUser = useCallback((data: Partial<User>) => {
    setUser(prev => {
      if (!prev) return prev;
      const next = { ...prev, ...data };
      try { localStorage.setItem('melamine_user', JSON.stringify(next)); } catch { /* noop */ }
      return next;
    });
  }, []);

  // ── hasRole ────────────────────────────────────────────────────────────────
  const hasRole = useCallback((roles: UserRole | UserRole[]): boolean => {
    if (!user) return false;
    if (Array.isArray(roles)) return roles.includes(user.role);
    return user.role === roles;
  }, [user]);

  return (
    <AuthContext.Provider value={{
      user,
      isLoading,
      isDemoMode,
      login,
      loginDemo,
      logout,
      hasRole,
      updateUser,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

// ── useAuth hook ───────────────────────────────────────────────────────────────
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
