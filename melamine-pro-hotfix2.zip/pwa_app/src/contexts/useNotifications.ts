import { useCallback, useEffect, useState } from 'react';
import type { User } from '../types';
import { genId, load, persistDebounced, ts } from './appData.helpers';
import type { Notification } from './appData.types';
import { showSystemNotification } from '../utils/systemNotifications';

export type { Notification };

/**
 * Notifications domain: storage, visibility filtering (role/target aware),
 * and CRUD operations. Extracted from AppDataContext to keep that file
 * focused on business-domain state (orders, inventory, finance, HR...).
 */
export function useNotifications(user: User | null) {
  const [notifications, setNotifications] = useState<Notification[]>(() => load('app_notifications', []));

  useEffect(() => { persistDebounced('app_notifications', notifications); }, [notifications]);

  // A notification is visible to the current user if it's a broadcast ('all'),
  // targets their role, or targets them specifically via target_user_id.
  const isVisibleToCurrentUser = useCallback((n: Notification) => {
    if (n.target_user_id) return n.target_user_id === user?.id;
    if (n.role_target === 'all') return true;
    return n.role_target === user?.role;
  }, [user]);

  const visibleNotifications = notifications.filter(isVisibleToCurrentUser);
  const unreadCount = visibleNotifications.filter(n => !n.is_read).length;

  const addNotification = useCallback((n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => {
    const full: Notification = { ...n, id: genId('notif'), created_at: ts(), is_read: false };
    setNotifications(prev => [full, ...prev].slice(0, 100));
    // Mirror to a system notification when it's meant for the current user.
    const visible = full.target_user_id
      ? full.target_user_id === user?.id
      : (full.role_target === 'all' || full.role_target === user?.role);
    if (visible) void showSystemNotification(full.title, full.message, full.id);
  }, [user]);

  const markNotificationRead = useCallback((id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => isVisibleToCurrentUser(n) ? { ...n, is_read: true } : n));
  }, [isVisibleToCurrentUser]);

  const deleteNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearNotifications = useCallback(() => {
    // Keep notifications that don't belong to the current user; remove the rest.
    setNotifications(prev => prev.filter(n => !isVisibleToCurrentUser(n)));
  }, [isVisibleToCurrentUser]);

  const resetNotifications = useCallback((next: Notification[]) => {
    setNotifications(next);
  }, []);

  return {
    notifications, visibleNotifications, unreadCount,
    addNotification, markNotificationRead, markAllNotificationsRead,
    deleteNotification, clearNotifications, resetNotifications,
  };
}
