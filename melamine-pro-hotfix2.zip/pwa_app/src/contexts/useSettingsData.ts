import { useCallback, type Dispatch, type SetStateAction } from 'react';
import type { User } from '../types';
import type { SystemSettings } from './appData.types';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { load, persist } from './appData.helpers';

/** SHA-256 hex digest — mirrors AuthContext.hashPassword */
async function hashPassword(raw: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

/**
 * Settings & profile: updateSystemSettings, saveUserProfile, changePassword.
 *
 * No own state — systemSettings stays in AppDataContext so the persist effect,
 * hydrateFromStorage, and useWalletData (which updates lastPayrollPeriod via
 * setSystemSettings) all remain in one place.
 *
 * updateUser comes from useAuth (updateUser persists to melamine_user in
 * localStorage so the session restores correctly on reload).
 */
export function useSettingsData(
  user: User | null,
  isDemoMode: boolean,
  setSystemSettings: Dispatch<SetStateAction<SystemSettings>>,
  updateUser: (data: { full_name: string; phone?: string; email: string }) => void,
) {
  const updateSystemSettings = useCallback((s: Partial<SystemSettings>) => {
    setSystemSettings(prev => ({ ...prev, ...s }));
  }, [setSystemSettings]);

  const saveUserProfile = useCallback((data: { full_name: string; phone?: string; email: string }) => {
    // Update the in-memory auth user so the change propagates immediately
    // (TopBar, Profile header, etc.). updateUser also persists to localStorage.
    updateUser(data);
  }, [updateUser]);

  const changePassword = useCallback(async (
    current: string, next: string,
  ): Promise<{ success: boolean; error?: string }> => {
    if (isDemoMode || !isSupabaseConfigured) {
      // Demo mode: validate against the stored override, then persist the new one.
      // All stored passwords are SHA-256 hashes — never plaintext
      const DEMO_HASH = 'd3ad9315b7be5dd53b31a273b3b3aba5defe700808305aa16a3062b76658a791';
      try {
        const map = load<Record<string, string>>('app_user_passwords', {});
        const storedHash = user?.id ? (map[user.id] || DEMO_HASH) : DEMO_HASH;
        const currentHash = await hashPassword(current);
        if (currentHash !== storedHash) return { success: false, error: 'كلمة المرور الحالية غير صحيحة' };
        const nextHash = await hashPassword(next);
        if (user?.id) { map[user.id] = nextHash; persist('app_user_passwords', map); }
      } catch { return { success: false, error: 'حدث خطأ في المعالجة' }; }
      return { success: true };
    }
    try {
      const { error } = await supabase.auth.updateUser({ password: next });
      if (error) return { success: false, error: 'تعذّر تغيير كلمة المرور، يرجى المحاولة مجدداً' };
      return { success: true };
    } catch {
      return { success: false, error: 'حدث خطأ في الاتصال' };
    }
  }, [isDemoMode, user]);

  return { updateSystemSettings, saveUserProfile, changePassword };
}
