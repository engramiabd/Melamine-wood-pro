/**
 * useWalletData — financial logic unit tests.
 *
 * Covers:
 *  ✓ Advance request rules (cannot request more than salary)
 *  ✓ Repayment deduction (never below zero wallet balance)
 *  ✓ Payroll calculation (base salary − advance deductions)
 *  ✓ Wallet balance after bonuses and transactions
 */
import { describe, it, expect } from 'vitest';
import type { Wallet, AdvanceRequest } from '../types';

// ── Test helpers ─────────────────────────────────────────────────────────────

function makeWallet(over: Partial<Wallet> = {}): Wallet {
  return {
    id: 'wallet-1',
    employee_id: 'emp-1',
    employee_name: 'موظف الاختبار',
    balanceUSD: 0,
    balanceSYP: 0,
    total_received_usd: 0,
    total_received_syp: 0,
    total_advances_usd: 0,
    total_advances_syp: 0,
    created_at: '2026-01-01T00:00:00',
    updated_at: '2026-01-01T00:00:00',
    ...over,
  };
}

function makeAdvance(over: Partial<AdvanceRequest> = {}): AdvanceRequest {
  return {
    id: 'adv-1',
    employee_id: 'emp-1',
    employee_name: 'موظف الاختبار',
    amount_usd: 100,
    amount_syp: 0,
    reason: 'سلفة اختبار',
    status: 'approved',
    requested_at: '2026-01-01T00:00:00',
    ...over,
  };
}

// ── Pure payroll logic (mirrors useWalletData.processPayroll) ─────────────────

interface PayrollResult {
  grossUSD:      number;
  advanceDeduct: number;
  netUSD:        number;
  deductionsCap: boolean; // true if advances were capped at gross salary
}

function computePayroll(
  salarySYP: number,
  salaryUSD: number,
  pendingAdvancesUSD: number,
): PayrollResult {
  const grossUSD      = salaryUSD;
  // Advance deductions are capped at the gross salary (can't deduct more than earned)
  const advanceDeduct = Math.min(pendingAdvancesUSD, grossUSD);
  const netUSD        = Math.max(0, grossUSD - advanceDeduct);
  return {
    grossUSD,
    advanceDeduct,
    netUSD,
    deductionsCap: pendingAdvancesUSD > grossUSD,
  };
}

// ── Wallet balance logic ──────────────────────────────────────────────────────

function applyTransaction(
  wallet: Wallet,
  amountUSD: number,
  type: 'credit' | 'debit',
): { newBalance: number; allowed: boolean } {
  if (type === 'credit') {
    return { newBalance: wallet.balanceUSD + amountUSD, allowed: true };
  }
  // Debit: cannot go below zero
  const newBalance = wallet.balanceUSD - amountUSD;
  if (newBalance < 0) {
    return { newBalance: wallet.balanceUSD, allowed: false };
  }
  return { newBalance, allowed: true };
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('payroll calculation', () => {
  it('pays full salary when no pending advances', () => {
    const result = computePayroll(0, 500, 0);
    expect(result.netUSD).toBe(500);
    expect(result.advanceDeduct).toBe(0);
  });

  it('deducts pending advances from net salary', () => {
    const result = computePayroll(0, 500, 200);
    expect(result.grossUSD).toBe(500);
    expect(result.advanceDeduct).toBe(200);
    expect(result.netUSD).toBe(300);
  });

  it('caps advance deductions at salary — net never goes negative', () => {
    const result = computePayroll(0, 300, 500); // advances > salary
    expect(result.netUSD).toBe(0);
    expect(result.advanceDeduct).toBe(300); // capped at salary
    expect(result.deductionsCap).toBe(true);
  });

  it('handles zero salary gracefully', () => {
    const result = computePayroll(0, 0, 100);
    expect(result.netUSD).toBe(0);
    expect(result.advanceDeduct).toBe(0);
  });
});

describe('wallet balance — addWalletTransaction', () => {
  it('credits increase balance', () => {
    const wallet = makeWallet({ balanceUSD: 100 });
    const { newBalance, allowed } = applyTransaction(wallet, 50, 'credit');
    expect(allowed).toBe(true);
    expect(newBalance).toBe(150);
  });

  it('debits decrease balance', () => {
    const wallet = makeWallet({ balanceUSD: 200 });
    const { newBalance, allowed } = applyTransaction(wallet, 80, 'debit');
    expect(allowed).toBe(true);
    expect(newBalance).toBe(120);
  });

  it('debit is rejected if it would go below zero', () => {
    const wallet = makeWallet({ balanceUSD: 50 });
    const { newBalance, allowed } = applyTransaction(wallet, 100, 'debit');
    expect(allowed).toBe(false);
    expect(newBalance).toBe(50); // unchanged
  });

  it('zero-balance wallet can receive credit', () => {
    const wallet = makeWallet({ balanceUSD: 0 });
    const { newBalance, allowed } = applyTransaction(wallet, 1000, 'credit');
    expect(allowed).toBe(true);
    expect(newBalance).toBe(1000);
  });
});

describe('advance repayment', () => {
  function repayAdvance(
    wallet: Wallet,
    advance: AdvanceRequest,
  ): { walletAfter: number; advanceStatus: 'repaid' | 'insufficient_balance' } {
    if (wallet.balanceUSD < advance.amount_usd) {
      return { walletAfter: wallet.balanceUSD, advanceStatus: 'insufficient_balance' };
    }
    return {
      walletAfter: wallet.balanceUSD - advance.amount_usd,
      advanceStatus: 'repaid',
    };
  }

  it('repays advance and deducts from wallet', () => {
    const wallet  = makeWallet({ balanceUSD: 500 });
    const advance = makeAdvance({ amount_usd: 200 });
    const result  = repayAdvance(wallet, advance);
    expect(result.advanceStatus).toBe('repaid');
    expect(result.walletAfter).toBe(300);
  });

  it('blocks repayment if wallet balance is insufficient', () => {
    const wallet  = makeWallet({ balanceUSD: 50 });
    const advance = makeAdvance({ amount_usd: 200 });
    const result  = repayAdvance(wallet, advance);
    expect(result.advanceStatus).toBe('insufficient_balance');
    expect(result.walletAfter).toBe(50); // unchanged
  });

  it('allows exact repayment (balance = advance amount)', () => {
    const wallet  = makeWallet({ balanceUSD: 100 });
    const advance = makeAdvance({ amount_usd: 100 });
    const result  = repayAdvance(wallet, advance);
    expect(result.advanceStatus).toBe('repaid');
    expect(result.walletAfter).toBe(0);
  });
});

describe('advance approval rules', () => {
  function validateAdvanceRequest(
    amountUSD: number,
    employeeSalaryUSD: number,
    existingPendingUSD: number,
  ): { valid: boolean; reason?: string } {
    if (amountUSD <= 0) return { valid: false, reason: 'المبلغ يجب أن يكون أكبر من صفر' };
    // Cannot request more than monthly salary
    if (amountUSD > employeeSalaryUSD) {
      return { valid: false, reason: `المبلغ لا يتجاوز الراتب ($${employeeSalaryUSD})` };
    }
    // Total pending advances cannot exceed 2× salary
    if (existingPendingUSD + amountUSD > employeeSalaryUSD * 2) {
      return { valid: false, reason: 'إجمالي السلف يتجاوز ضعف الراتب' };
    }
    return { valid: true };
  }

  it('approves valid advance within salary', () => {
    expect(validateAdvanceRequest(200, 500, 0).valid).toBe(true);
  });

  it('rejects advance exceeding salary', () => {
    const r = validateAdvanceRequest(600, 500, 0);
    expect(r.valid).toBe(false);
    expect(r.reason).toMatch(/راتب/);
  });

  it('rejects if total pending would exceed 2× salary', () => {
    const r = validateAdvanceRequest(300, 500, 800); // 800+300=1100 > 1000
    expect(r.valid).toBe(false);
    expect(r.reason).toMatch(/ضعف/);
  });

  it('rejects zero amount', () => {
    const r = validateAdvanceRequest(0, 500, 0);
    expect(r.valid).toBe(false);
  });
});
