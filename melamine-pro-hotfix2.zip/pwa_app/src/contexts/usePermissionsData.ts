import { useCallback, type Dispatch, type MutableRefObject, type SetStateAction } from 'react';
import type { User } from '../types';
import type { Notification } from './appData.types';
import { DEFAULT_ROLE_PERMISSIONS, computeCan } from '../lib/permissions';
import { load, persist } from './appData.helpers';

async function hashPassword(raw: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

type LogAudit = (e: {
  action: string; entity_type: string; entity_id?: string; summary: string;
}) => void;
type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;

/**
 * Granular permissions (Phase 4): can(), toggleRolePermission,
 * resetRolePermissions, and the admin-initiated password reset.
 *
 * rolePermissions state stays in AppDataContext (needed by exportData /
 * importData / clearAllData / hydrateFromStorage). The setter is injected.
 */
export function usePermissionsData(
  user: User | null,
  rolePermissions: Record<string, string[]>,
  setRolePermissions: Dispatch<SetStateAction<Record<string, string[]>>>,
  logAuditRef: MutableRefObject<LogAudit>,
  addNotification: AddNotification,
) {
  const can = useCallback(
    (key: string): boolean => computeCan(user?.role, rolePermissions, key),
    [user, rolePermissions],
  );

  const toggleRolePermission = useCallback((role: string, key: string, enabled: boolean) => {
    setRolePermissions(prev => {
      const current = prev[role] || [];
      const next = enabled
        ? Array.from(new Set([...current, key]))
        : current.filter(k => k !== key);
      return { ...prev, [role]: next };
    });
    logAuditRef.current({
      action: 'permissions.update', entity_type: 'admin',
      summary: `${enabled ? 'منح' : 'سحب'} صلاحية «${key}» للدور «${role}»`,
    });
  }, [setRolePermissions, logAuditRef]);

  const resetRolePermissions = useCallback(() => {
    setRolePermissions({ ...DEFAULT_ROLE_PERMISSIONS });
    logAuditRef.current({
      action: 'permissions.reset', entity_type: 'admin',
      summary: 'إعادة ضبط الصلاحيات للوضع الافتراضي',
    });
  }, [setRolePermissions, logAuditRef]);

  // Admin-initiated password reset for another user. Persists a demo override
  // that the password-change flow honours. A real Supabase deployment would
  // additionally call the admin auth API server-side.
  const adminSetUserPassword = useCallback((userId: string, pwd: string) => {
    try {
      const map = load<Record<string, string>>('app_user_passwords', {});
      hashPassword(pwd).then(h => { map[userId] = h; persist('app_user_passwords', map); });
    } catch { /* storage unavailable */ }
    logAuditRef.current({
      action: 'user.password_reset', entity_type: 'admin',
      entity_id: userId, summary: 'إعادة تعيين كلمة مرور مستخدم',
    });
    addNotification({
      title: 'تم تحديث كلمة المرور',
      message: 'تم تعيين كلمة مرور جديدة للمستخدم',
      type: 'success', role_target: 'admin',
    });
  }, [logAuditRef, addNotification]);

  return { can, toggleRolePermission, resetRolePermissions, adminSetUserPassword };
}
