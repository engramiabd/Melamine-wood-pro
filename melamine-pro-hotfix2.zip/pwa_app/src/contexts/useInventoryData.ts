import { useCallback, type Dispatch, type MutableRefObject, type SetStateAction } from 'react';
import type { JournalEntry } from '../types';
import type { InventoryItem, Notification, SystemSettings } from './appData.types';
import { genId, ts, today } from './appData.helpers';

type LogAudit = (e: {
  action: string; entity_type: string; entity_id?: string;
  summary: string; amount_usd?: number;
}) => void;
type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;

/**
 * Inventory domain: addInventoryTransaction + item CRUD.
 *
 * addInventoryTransaction is intentionally exported so useSuppliersData can
 * call it when receiving a purchase order (which adds received quantities to
 * stock, books the purchase expense, and runs low-stock checks in one step).
 *
 * setJournalEntries is injected (cross-domain write) because incoming stock
 * purchases must be booked as an expense entry in the journal.
 * inventoryItems and systemSettings are passed as values so this hook never
 * imports from AppDataContext itself.
 */
export function useInventoryData(deps: {
  inventoryItems: InventoryItem[];
  systemSettings: SystemSettings;
  setInventoryItems: Dispatch<SetStateAction<InventoryItem[]>>;
  setJournalEntries: Dispatch<SetStateAction<JournalEntry[]>>;
  logAuditRef: MutableRefObject<LogAudit>;
  addNotification: AddNotification;
}) {
  const { inventoryItems, systemSettings, setInventoryItems, setJournalEntries, logAuditRef, addNotification } = deps;

  const addInventoryTransaction = useCallback((
    itemId: string, type: 'in' | 'out', qty: number, price?: number, note?: string,
  ) => {
    let itemName = '';
    let itemUnit = '';
    const lowStockAlerts: { name: string; unit: string; newQty: number; reorderLevel: number }[] = [];

    setInventoryItems(prev => prev.map(item => {
      if (item.id !== itemId) return item;
      itemName = item.name; itemUnit = item.unit;
      const newQty = type === 'in'
        ? item.stock_quantity + qty
        : Math.max(0, item.stock_quantity - qty);
      const updated = { ...item, stock_quantity: newQty, updated_at: ts(), ...(price ? { current_price: price } : {}) };
      if (newQty <= item.reorder_level) {
        lowStockAlerts.push({ name: item.name, unit: item.unit, newQty, reorderLevel: item.reorder_level });
      }
      return updated;
    }));

    // Side effects run after the state update is scheduled, not inside the
    // updater — updaters must be pure (React may invoke them more than once).
    lowStockAlerts.forEach(a => {
      if (systemSettings.notifyLowStock) {
        addNotification({
          title: 'مخزون منخفض',
          message: `${a.name}: ${a.newQty} ${a.unit} (الحد الأدنى: ${a.reorderLevel})`,
          type: 'warning', role_target: 'manager',
        });
      }
    });

    if (type === 'in' && price && itemName) {
      const entry = {
        id: genId('je'), entry_number: `JE-${Date.now().toString().slice(-6)}`,
        type: 'expense' as const, category: 'مواد خام',
        description: `شراء ${itemName} - ${qty} ${itemUnit}${note ? ` - ${note}` : ''}`,
        amount_usd: qty * price, amount_syp: qty * price * systemSettings.exchangeRate,
        currency: 'USD' as const, payment_method: 'cash' as const,
        created_by: 'النظام', entry_date: today(), created_at: ts(),
      } as JournalEntry;
      setJournalEntries(prev => [entry, ...prev]);
    }

    logAuditRef.current({
      action: type === 'in' ? 'inventory.in' : 'inventory.out',
      entity_type: 'inventory', entity_id: itemId,
      summary: `${type === 'in' ? 'إدخال' : 'صرف'} ${qty} ${itemUnit} من «${itemName}»${note ? ` — ${note}` : ''}`,
      amount_usd: type === 'in' && price ? qty * price : undefined,
    });
  }, [inventoryItems, systemSettings, setInventoryItems, setJournalEntries, logAuditRef, addNotification]);

  const addInventoryItem = useCallback((item: Omit<InventoryItem, 'id' | 'created_at' | 'updated_at'>) => {
    setInventoryItems(prev => [...prev, { ...item, id: genId('inv'), created_at: ts(), updated_at: ts() }]);
  }, [setInventoryItems]);

  const updateInventoryItem = useCallback((id: string, data: Partial<InventoryItem>) => {
    setInventoryItems(prev => prev.map(i => i.id === id ? { ...i, ...data, updated_at: ts() } : i));
  }, [setInventoryItems]);

  const deleteInventoryItem = useCallback((id: string) => {
    setInventoryItems(prev => prev.map(i =>
      i.id === id ? { ...i, deleted_at: new Date().toISOString(), updated_at: new Date().toISOString() } : i
    ));
    logAuditRef.current({
      action: 'inventory.delete', entity_type: 'inventory',
      entity_id: id, summary: 'حذف مادة من المخزون',
    });
  }, [setInventoryItems, logAuditRef]);

  const activeInventory = inventoryItems.filter(i => !i.deleted_at);
  return { inventoryItems: activeInventory, addInventoryTransaction, addInventoryItem, updateInventoryItem, deleteInventoryItem };
}
