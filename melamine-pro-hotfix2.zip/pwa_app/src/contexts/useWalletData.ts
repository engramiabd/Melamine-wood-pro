import { useCallback, type Dispatch, type MutableRefObject, type SetStateAction } from 'react';
import type { Employee, AttendanceRecord, JournalEntry } from '../types';
import type { Notification, Wallet, WalletTransaction, AdvanceRequest, SystemSettings } from './appData.types';
import { computePayroll } from '../utils/payroll';
import { genId, ts, today } from './appData.helpers';

type LogAudit = (e: {
  action: string; entity_type: string; entity_id?: string;
  summary: string; amount_usd?: number;
}) => void;
type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;

interface WalletDataDeps {
  // ── state values (read) ──────────────────────────────────────────────────
  wallets: Wallet[];
  advanceRequests: AdvanceRequest[];
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  systemSettings: SystemSettings;
  // ── own-domain setters ───────────────────────────────────────────────────
  setWallets: Dispatch<SetStateAction<Wallet[]>>;
  setWalletTransactions: Dispatch<SetStateAction<WalletTransaction[]>>;
  setAdvanceRequests: Dispatch<SetStateAction<AdvanceRequest[]>>;
  // ── cross-domain setters (injected so this hook stays decoupled) ─────────
  setJournalEntries: Dispatch<SetStateAction<JournalEntry[]>>;
  setSystemSettings: Dispatch<SetStateAction<SystemSettings>>;
  // ── cross-cutting ────────────────────────────────────────────────────────
  logAuditRef: MutableRefObject<LogAudit>;
  addNotification: AddNotification;
}

/**
 * Wallet, advances, and payroll operations.
 *
 * State (wallets, walletTransactions, advanceRequests) stays in AppDataContext
 * because `setWallets` must be passed to useEmployeesData (addEmployee /
 * deleteEmployee create / remove wallet entries), and that hook call precedes
 * the point where useWalletData's own state could be set up.  Extracting just
 * the methods still removes ~120 lines of logic from the provider and keeps
 * all HR-financial behaviour in one testable place.
 *
 * Cross-domain writes (setJournalEntries, setSystemSettings) are injected as
 * setters so this hook never imports from AppDataContext itself.
 */
export function useWalletData({
  wallets, advanceRequests, employees, attendanceRecords, systemSettings,
  setWallets, setWalletTransactions, setAdvanceRequests,
  setJournalEntries, setSystemSettings,
  logAuditRef, addNotification,
}: WalletDataDeps) {

  // ─── computePayrollFromAttendance ─────────────────────────────────────────
  // Derives a salary breakdown for an employee in a given month from their
  // actual attendance records (worked hours, overtime, absence/late deductions).
  const computePayrollFromAttendance = useCallback((
    employeeId: string, year: number, month: number,
  ) => {
    const emp = employees.find(e => e.id === employeeId);
    if (!emp) return undefined;
    return computePayroll(emp, attendanceRecords, year, month);
  }, [employees, attendanceRecords]);

  // ─── getWallet ────────────────────────────────────────────────────────────
  const getWallet = useCallback((workerId: string): Wallet => {
    return wallets.find(w => w.workerId === workerId) || { workerId, balanceUSD: 0, balanceSYP: 0 };
  }, [wallets]);

  // ─── addWalletTransaction ─────────────────────────────────────────────────
  const addWalletTransaction = useCallback((
    tx: Omit<WalletTransaction, 'id' | 'created_at'>,
  ): { success: boolean; error?: string } => {
    const isCredit = ['salary', 'bonus', 'advance'].includes(tx.type);
    if (!isCredit) {
      const wallet = wallets.find(w => w.workerId === tx.worker_id) || { workerId: tx.worker_id, balanceUSD: 0, balanceSYP: 0 };
      if (Math.abs(tx.amount_usd) > wallet.balanceUSD) {
        addNotification({
          title: 'رصيد غير كافٍ',
          message: `محفظة الموظف لا تحتوي على رصيد كافٍ لهذه العملية ($${Math.abs(tx.amount_usd)} مطلوب، $${wallet.balanceUSD} متاح)`,
          type: 'error', role_target: 'hr',
        });
        return { success: false, error: 'رصيد غير كافٍ' };
      }
    }
    const newTx: WalletTransaction = { ...tx, id: genId('tx'), created_at: ts() };
    setWalletTransactions(prev => [newTx, ...prev]);
    setWallets(prev => prev.map(w => w.workerId !== tx.worker_id ? w : {
      ...w,
      balanceUSD: Math.max(0, w.balanceUSD + (isCredit ? 1 : -1) * Math.abs(tx.amount_usd)),
      balanceSYP: Math.max(0, w.balanceSYP + (isCredit ? 1 : -1) * Math.abs(tx.amount_syp)),
    }));
    return { success: true };
  }, [wallets, addNotification, setWallets, setWalletTransactions]);

  // ─── requestAdvance ───────────────────────────────────────────────────────
  const requestAdvance = useCallback((workerId: string, amount: number, reason: string) => {
    const hasPending = advanceRequests.some(r => r.worker_id === workerId && r.status === 'pending');
    if (hasPending) {
      addNotification({ title: 'طلب معلق موجود', message: 'لديك طلب سلفة معلق بانتظار الموافقة، يرجى الانتظار', type: 'warning', role_target: 'worker', target_user_id: workerId });
      return false;
    }
    const emp = employees.find(e => e.user_id === workerId);
    const req: AdvanceRequest = {
      id: genId('adv'), created_at: ts(), worker_id: workerId,
      worker_name: emp?.position || 'موظف',
      amount_usd: amount, amount_syp: amount * systemSettings.exchangeRate,
      reason, status: 'pending', payment_method: 'cash',
    };
    setAdvanceRequests(prev => [req, ...prev]);
    addNotification({ title: 'طلب سلفة جديد', message: `طلب سلفة $${amount} - ${reason}`, type: 'info', role_target: 'production_supervisor' });
    return true;
  }, [advanceRequests, employees, systemSettings.exchangeRate, addNotification, setAdvanceRequests]);

  // ─── approveAdvance ───────────────────────────────────────────────────────
  const approveAdvance = useCallback((id: string) => {
    const req = advanceRequests.find(r => r.id === id);
    if (!req || req.status !== 'pending') return; // guard: avoid double wallet credit / journal entry
    setAdvanceRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'approved' as const, approved_at: ts() } : r));
    addWalletTransaction({ worker_id: req.worker_id, type: 'advance', amount_usd: req.amount_usd, amount_syp: req.amount_syp, description: `سلفة: ${req.reason}`, reference_id: id });
    setJournalEntries(prev => [{
      id: genId('je'), entry_number: `JE-${Date.now().toString().slice(-6)}`,
      type: 'expense' as const, category: 'سلف',
      description: `سلفة للعامل ${req.worker_name}: ${req.reason}`,
      amount_usd: req.amount_usd, amount_syp: req.amount_syp,
      currency: 'USD' as const, payment_method: 'cash' as const,
      created_by: 'النظام', entry_date: today(), created_at: ts(),
    } as JournalEntry, ...prev]);
    addNotification({ title: 'سلفة معتمدة', message: `تمت الموافقة على سلفة $${req.amount_usd}`, type: 'success', role_target: 'worker', target_user_id: req.worker_id });
  }, [advanceRequests, addWalletTransaction, addNotification, setAdvanceRequests, setJournalEntries]);

  // ─── rejectAdvance ────────────────────────────────────────────────────────
  const rejectAdvance = useCallback((id: string, reason: string) => {
    setAdvanceRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'rejected' as const, rejection_reason: reason } : r));
  }, [setAdvanceRequests]);

  // ─── addBonus ─────────────────────────────────────────────────────────────
  const addBonus = useCallback((workerId: string, amount: number, reason: string) => {
    const rate = systemSettings.exchangeRate;
    addWalletTransaction({ worker_id: workerId, type: 'bonus', amount_usd: amount, amount_syp: amount * rate, description: `مكافأة: ${reason}` });
    setJournalEntries(prev => [{
      id: genId('je'), entry_number: `JE-${Date.now().toString().slice(-6)}`,
      type: 'expense' as const, category: 'مكافآت',
      description: `مكافأة: ${reason}`,
      amount_usd: amount, amount_syp: amount * rate,
      currency: 'USD' as const, payment_method: 'cash' as const,
      created_by: 'النظام', entry_date: today(), created_at: ts(),
    } as JournalEntry, ...prev]);
    addNotification({ title: 'مكافأة', message: `تمت إضافة مكافأة $${amount}`, type: 'success', role_target: 'worker', target_user_id: workerId });
    logAuditRef.current({ action: 'wallet.bonus', entity_type: 'wallet', entity_id: workerId, summary: `مكافأة لعامل: ${reason}`, amount_usd: amount });
  }, [addWalletTransaction, addNotification, setJournalEntries, logAuditRef, systemSettings.exchangeRate]);

  // ─── repayAdvance ─────────────────────────────────────────────────────────
  const repayAdvance = useCallback((workerId: string, amount: number) => {
    return addWalletTransaction({
      worker_id: workerId, type: 'deduction',
      amount_usd: amount, amount_syp: amount * systemSettings.exchangeRate,
      description: 'تسديد سلفة',
    });
  }, [addWalletTransaction, systemSettings.exchangeRate]);

  // ─── processPayroll ───────────────────────────────────────────────────────
  const processPayroll = useCallback(() => {
    const now = new Date();
    const periodKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    if (systemSettings.lastPayrollPeriod === periodKey) {
      addNotification({ title: 'تم الصرف مسبقاً', message: `تم صرف رواتب ${now.toLocaleDateString('ar-SY', { month: 'long', year: 'numeric' })} مسبقاً`, type: 'warning', role_target: 'hr' });
      return;
    }
    const month = now.toLocaleDateString('ar-SY', { month: 'long', year: 'numeric' });
    const rate = systemSettings.exchangeRate;
    const py = now.getFullYear();
    const pm = now.getMonth() + 1;
    let total = 0;
    employees.filter(e => e.is_active).forEach(emp => {
      // Pay the attendance-derived net (overtime + absence/late deductions).
      // With no attendance records this equals the base salary.
      const pr = computePayroll(emp, attendanceRecords, py, pm);
      const netUsd = pr.net_salary_usd;
      addWalletTransaction({ worker_id: emp.user_id, type: 'salary', amount_usd: netUsd, amount_syp: Math.round(netUsd * rate), description: `راتب ${month}` });
      total += netUsd;
    });
    setJournalEntries(prev => [{
      id: genId('je'), entry_number: `JE-${Date.now().toString().slice(-6)}`,
      type: 'expense' as const, category: 'رواتب',
      description: `رواتب موظفين - ${month}`,
      amount_usd: total, amount_syp: total * rate,
      currency: 'USD' as const, payment_method: 'bank_transfer' as const,
      created_by: 'النظام', entry_date: today(), created_at: ts(),
    } as JournalEntry, ...prev]);
    setSystemSettings(prev => ({ ...prev, lastPayrollPeriod: periodKey }));
    const activeCount = employees.filter(e => e.is_active).length;
    addNotification({ title: 'صرف الرواتب', message: `تم صرف رواتب ${activeCount} موظف - الإجمالي $${total}`, type: 'success', role_target: 'hr' });
    logAuditRef.current({ action: 'payroll.process', entity_type: 'hr', summary: `صرف رواتب ${month} لـ ${activeCount} موظف`, amount_usd: total });
  }, [employees, attendanceRecords, systemSettings, addWalletTransaction, addNotification, setJournalEntries, setSystemSettings, logAuditRef]);

  return {
    computePayrollFromAttendance,
    getWallet, addWalletTransaction,
    requestAdvance, approveAdvance, rejectAdvance,
    addBonus, repayAdvance, processPayroll,
  };
}
