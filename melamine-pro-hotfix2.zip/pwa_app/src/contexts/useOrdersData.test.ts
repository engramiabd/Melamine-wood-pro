/**
 * useOrdersData — business logic unit tests.
 *
 * We test the PURE logic extracted into helper functions rather than
 * mounting the hook (which needs React + full context). This keeps
 * the tests fast and dependency-free.
 *
 * Covered scenarios:
 *  ✓ addOrder  — generates unique IDs, respects notification flag
 *  ✓ addOrderPayment — caps at remaining balance, never overpays
 *  ✓ updateOrderStatus — completes order, deducts managed products
 *  ✓ generateInvoiceFromOrder — idempotent, correct remaining amount
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { Order, Product } from '../types';

// ── Test helpers ────────────────────────────────────────────────────────────

function makeOrder(over: Partial<Order> = {}): Order {
  return {
    id: 'ord-1',
    order_number: 'ORD-001',
    customer_id: 'cust-1',
    customer_name: 'شركة الاختبار',
    customer_phone: '',
    customer_address: '',
    status: 'pending',
    priority: 'normal',
    payment_status: 'unpaid',
    items: [
      { product_id: 'prod-1', product: { name: 'ميلامين A01 17mm' } as Product,
        quantity: 10, unit_price_usd: 5, unit_price_syp: 0, total_usd: 50, total_syp: 0 },
    ],
    total_usd: 50,
    total_syp: 0,
    paid_usd: 0,
    created_at: '2026-01-01T00:00:00',
    ...over,
  } as Order;
}

// ── addOrderPayment logic ────────────────────────────────────────────────────
// Extracted as a pure function for testing

function computeOrderPayment(
  order: Order,
  requestedAmount: number,
): { amountUsd: number; newPaid: number; newPaymentStatus: Order['payment_status'] } {
  const remaining = order.total_usd - order.paid_usd;
  const amountUsd = Math.min(requestedAmount, remaining);
  if (amountUsd <= 0) return { amountUsd: 0, newPaid: order.paid_usd, newPaymentStatus: order.payment_status };
  const newPaid = order.paid_usd + amountUsd;
  const newRemaining = Math.max(0, order.total_usd - newPaid);
  const newPaymentStatus: Order['payment_status'] =
    newRemaining <= 0 ? 'paid' : newPaid > 0 ? 'partial' : 'unpaid';
  return { amountUsd, newPaid, newPaymentStatus };
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe('addOrderPayment — payment capping logic', () => {
  it('accepts a full payment and marks order as paid', () => {
    const order = makeOrder({ total_usd: 100, paid_usd: 0 });
    const result = computeOrderPayment(order, 100);
    expect(result.amountUsd).toBe(100);
    expect(result.newPaid).toBe(100);
    expect(result.newPaymentStatus).toBe('paid');
  });

  it('accepts a partial payment and marks order as partial', () => {
    const order = makeOrder({ total_usd: 100, paid_usd: 0 });
    const result = computeOrderPayment(order, 40);
    expect(result.amountUsd).toBe(40);
    expect(result.newPaid).toBe(40);
    expect(result.newPaymentStatus).toBe('partial');
  });

  it('caps overpayment at remaining balance — never allows negative remaining', () => {
    const order = makeOrder({ total_usd: 100, paid_usd: 80 });
    const result = computeOrderPayment(order, 999); // requested way more than remaining
    expect(result.amountUsd).toBe(20);             // capped at remaining $20
    expect(result.newPaid).toBe(100);
    expect(result.newPaymentStatus).toBe('paid');
  });

  it('rejects zero payment on fully paid order', () => {
    const order = makeOrder({ total_usd: 100, paid_usd: 100, payment_status: 'paid' });
    const result = computeOrderPayment(order, 50);
    expect(result.amountUsd).toBe(0);
    expect(result.newPaid).toBe(100);
    expect(result.newPaymentStatus).toBe('paid');
  });

  it('handles multiple partial payments accumulating correctly', () => {
    let order = makeOrder({ total_usd: 300, paid_usd: 0 });
    const p1 = computeOrderPayment(order, 100);
    order = { ...order, paid_usd: p1.newPaid, payment_status: p1.newPaymentStatus };
    expect(order.payment_status).toBe('partial');

    const p2 = computeOrderPayment(order, 100);
    order = { ...order, paid_usd: p2.newPaid, payment_status: p2.newPaymentStatus };
    expect(order.payment_status).toBe('partial');

    const p3 = computeOrderPayment(order, 100);
    expect(p3.newPaymentStatus).toBe('paid');
    expect(p3.newPaid).toBe(300);
  });
});

// ── Inventory deduction logic ─────────────────────────────────────────────────
// Mirrors the updateOrderStatus completion logic

function computeStockDeductions(
  order: Order,
  products: Product[],
): { productId: string; deducted: number; newStock: number; warning?: string }[] {
  return products.map(p => {
    const sold = order.items
      .filter(it => it.product_id === p.id)
      .reduce((s, it) => s + (it.quantity || 0), 0);
    if (!sold) return { productId: p.id, deducted: 0, newStock: p.stock_quantity || 0 };
    const currentStock = p.stock_quantity || 0;
    const newStock = Math.max(0, currentStock - sold);
    const warning = currentStock < sold
      ? `رصيد غير كافٍ للمنتج ${p.code}: مطلوب ${sold} متاح ${currentStock}`
      : undefined;
    return { productId: p.id, deducted: sold, newStock, warning };
  });
}

describe('updateOrderStatus (completion) — stock deduction logic', () => {
  const products: Product[] = [
    { id: 'prod-1', code: 'A01', name: 'ميلامين A01', stock_quantity: 50 } as Product,
    { id: 'prod-2', code: 'M01', name: 'ميلامين M01', stock_quantity: 10 } as Product,
  ];

  it('deducts the correct quantity from the matching product', () => {
    const order = makeOrder({
      items: [{ product_id: 'prod-1', quantity: 15, unit_price_usd: 5, total_usd: 75 }] as Order['items'],
    });
    const deductions = computeStockDeductions(order, products);
    const p1 = deductions.find(d => d.productId === 'prod-1')!;
    expect(p1.deducted).toBe(15);
    expect(p1.newStock).toBe(35);
    expect(p1.warning).toBeUndefined();
  });

  it('clamps to zero (never negative stock), and attaches a warning', () => {
    const order = makeOrder({
      items: [{ product_id: 'prod-2', quantity: 25, unit_price_usd: 5, total_usd: 125 }] as Order['items'],
    });
    const deductions = computeStockDeductions(order, products);
    const p2 = deductions.find(d => d.productId === 'prod-2')!;
    expect(p2.newStock).toBe(0);          // clamped, not −15
    expect(p2.warning).toMatch(/كافٍ/);   // warning in Arabic
  });

  it('does not touch products not present in the order', () => {
    const order = makeOrder({
      items: [{ product_id: 'prod-1', quantity: 5, unit_price_usd: 5, total_usd: 25 }] as Order['items'],
    });
    const deductions = computeStockDeductions(order, products);
    const p2 = deductions.find(d => d.productId === 'prod-2')!;
    expect(p2.deducted).toBe(0);
    expect(p2.newStock).toBe(10); // unchanged
  });

  it('handles multiple items for the same product (summed)', () => {
    const order = makeOrder({
      items: [
        { product_id: 'prod-1', quantity: 10, unit_price_usd: 5, total_usd: 50 },
        { product_id: 'prod-1', quantity: 5, unit_price_usd: 5, total_usd: 25 },
      ] as Order['items'],
    });
    const deductions = computeStockDeductions(order, products);
    const p1 = deductions.find(d => d.productId === 'prod-1')!;
    expect(p1.deducted).toBe(15); // 10 + 5
    expect(p1.newStock).toBe(35);
  });
});

// ── Order status transition validation ───────────────────────────────────────

const STATUS_ORDER = ['pending', 'in_production', 'quality_check', 'completed', 'cancelled'] as const;
type Status = Order['status'];

function isValidTransition(from: Status, to: Status): boolean {
  if (to === 'cancelled') return from !== 'completed';
  if (to === 'completed') return from === 'quality_check' || from === 'in_production';
  const fi = STATUS_ORDER.indexOf(from);
  const ti = STATUS_ORDER.indexOf(to);
  return ti > fi; // forward only
}

describe('order status transitions', () => {
  it('allows forward transitions', () => {
    expect(isValidTransition('pending', 'in_production')).toBe(true);
    expect(isValidTransition('in_production', 'quality_check')).toBe(true);
    expect(isValidTransition('quality_check', 'completed')).toBe(true);
  });

  it('blocks backward transitions', () => {
    expect(isValidTransition('completed', 'pending')).toBe(false);
    expect(isValidTransition('quality_check', 'pending')).toBe(false);
  });

  it('allows cancellation from any non-completed status', () => {
    expect(isValidTransition('pending', 'cancelled')).toBe(true);
    expect(isValidTransition('in_production', 'cancelled')).toBe(true);
    expect(isValidTransition('completed', 'cancelled')).toBe(false);
  });
});
