import { useCallback, useEffect, useState, type MutableRefObject } from 'react';
import type { Supplier, PurchaseOrder } from '../types';
import type { Notification } from './appData.types';
import { genId, ts, today, load, persistDebounced } from './appData.helpers';

type LogAudit = (e: {
  action: string; entity_type: string; entity_id?: string;
  summary: string; amount_usd?: number; actor?: string; actor_role?: string;
}) => void;

type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;
type AddInventoryTransaction = (itemId: string, type: 'in' | 'out', qty: number, price?: number, note?: string) => void;

const DEMO_SUPPLIERS: Supplier[] = [
  { id: 's1', name: 'مصنع الخشب المتحد', contact_person: 'أبو محمد', phone: '+963 11 555 1010', category: 'ألواح خام', balance_usd: 0, is_active: true, created_at: new Date().toISOString() },
  { id: 's2', name: 'شركة الكيماويات', contact_person: 'م. سامر', phone: '+963 11 555 2020', category: 'كيماويات وراتنج', balance_usd: 0, is_active: true, created_at: new Date().toISOString() },
  { id: 's3', name: 'شركة الورق الدولية', contact_person: 'هاني', phone: '+963 11 555 3030', category: 'ورق ميلامين', balance_usd: 0, is_active: true, created_at: new Date().toISOString() },
];

/**
 * Suppliers & Purchasing (Phase 3). Receiving a purchase order feeds the
 * received quantities into inventory via the injected `addInventoryTransaction`
 * (which also books the expense and runs low-stock checks). Extracted from
 * AppDataContext; cross-domain effects are passed in as dependencies so the
 * provider wires them to the live inventory/notification/audit handlers.
 */
export function useSuppliersData(
  logAuditRef: MutableRefObject<LogAudit>,
  addNotification: AddNotification,
  addInventoryTransaction: AddInventoryTransaction,
) {
  const [suppliers, setSuppliers] = useState<Supplier[]>(() => load('app_suppliers', DEMO_SUPPLIERS));
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(() => load('app_purchase_orders', []));

  useEffect(() => { persistDebounced('app_suppliers', suppliers); }, [suppliers]);
  useEffect(() => { persistDebounced('app_purchase_orders', purchaseOrders); }, [purchaseOrders]);

  const addSupplier = useCallback((s: Omit<Supplier, 'id' | 'created_at'>): Supplier => {
    const supplier: Supplier = { ...s, id: genId('sup'), created_at: ts() };
    setSuppliers(prev => [supplier, ...prev]);
    logAuditRef.current({ action: 'supplier.create', entity_type: 'supplier', entity_id: supplier.id, summary: `إضافة مورّد «${supplier.name}»` });
    return supplier;
  }, [logAuditRef]);

  const updateSupplier = useCallback((id: string, data: Partial<Supplier>) => {
    setSuppliers(prev => prev.map(s => s.id === id ? { ...s, ...data } : s));
  }, []);

  const deleteSupplier = useCallback((id: string) => {
    setSuppliers(prev => prev.filter(s => s.id !== id));
    logAuditRef.current({ action: 'supplier.delete', entity_type: 'supplier', entity_id: id, summary: 'حذف مورّد' });
  }, [logAuditRef]);

  const addPurchaseOrder = useCallback((po: Omit<PurchaseOrder, 'id' | 'po_number' | 'created_at' | 'status'> & { status?: PurchaseOrder['status'] }): PurchaseOrder => {
    const order: PurchaseOrder = {
      ...po,
      id: genId('po'),
      po_number: `PO-${Date.now().toString().slice(-6)}`,
      status: po.status || 'sent',
      created_at: ts(),
    };
    setPurchaseOrders(prev => [order, ...prev]);
    logAuditRef.current({ action: 'purchase.create', entity_type: 'purchase', entity_id: order.id, summary: `أمر شراء ${order.po_number} من «${order.supplier_name}»`, amount_usd: order.total_usd });
    return order;
  }, [logAuditRef]);

  // Receiving a PO adds each item's quantity to inventory (addInventoryTransaction
  // also books the purchase as an expense + runs low-stock checks), then marks
  // the PO as received.
  const receivePurchaseOrder = useCallback((poId: string) => {
    const po = purchaseOrders.find(p => p.id === poId);
    if (!po || po.status === 'received') return;
    po.items.forEach(it => {
      if (it.material_id) addInventoryTransaction(it.material_id, 'in', it.quantity, it.unit_cost_usd, `استلام ${po.po_number}`);
    });
    setPurchaseOrders(prev => prev.map(p => p.id === poId ? { ...p, status: 'received', received_date: today() } : p));
    logAuditRef.current({ action: 'purchase.receive', entity_type: 'purchase', entity_id: po.id, summary: `استلام أمر الشراء ${po.po_number} وإضافته للمخزون`, amount_usd: po.total_usd });
    addNotification({ title: 'استلام مشتريات', message: `تم استلام ${po.po_number} وتحديث المخزون`, type: 'success', role_target: 'manager' });
  }, [purchaseOrders, addInventoryTransaction, addNotification, logAuditRef]);

  const cancelPurchaseOrder = useCallback((poId: string) => {
    setPurchaseOrders(prev => prev.map(p => p.id === poId ? { ...p, status: 'cancelled' } : p));
  }, []);

  return {
    suppliers, setSuppliers, addSupplier, updateSupplier, deleteSupplier,
    purchaseOrders, setPurchaseOrders, addPurchaseOrder, receivePurchaseOrder, cancelPurchaseOrder,
  };
}
