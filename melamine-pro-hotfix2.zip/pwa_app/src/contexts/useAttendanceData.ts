import { useCallback, useEffect, useState } from 'react';
import type { AttendanceRecord } from '../types';
import type { Notification, SystemSettings } from './appData.types';
import { genId, ts, today, load, persistDebounced } from './appData.helpers';

type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;

/**
 * Attendance domain: state, persistence, check-in/out, and the online-sync
 * listener (which forces a re-render of attendance records after reconnection).
 *
 * Cross-cutting effects (low-stock startup alert, daily production counter
 * reset) remain in AppDataContext — they touch other domains' state and don't
 * belong here.
 *
 * setAttendanceRecords is exported for importData / clearAllData / resetToDemo.
 * attendanceRecords is read by computePayrollFromAttendance and processPayroll
 * in AppDataContext via the destructured return value.
 */
export function useAttendanceData(
  systemSettings: SystemSettings,
  addNotification: AddNotification,
) {
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(() => load('app_attendance', []));
  useEffect(() => { persistDebounced('app_attendance', attendanceRecords); }, [attendanceRecords]);

  // Re-stamp all records after going back online so any pending writes flush.
  useEffect(() => {
    const onOnline = () => setAttendanceRecords(prev => prev.map(r => r));
    window.addEventListener('online', onOnline);
    return () => window.removeEventListener('online', onOnline);
  }, []);

  const getTodayRecord = useCallback((workerId: string): AttendanceRecord | undefined => {
    return attendanceRecords.find(r => r.worker_id === workerId && r.date === today());
  }, [attendanceRecords]);

  const checkIn = useCallback((workerId: string, lat: number, lng: number): AttendanceRecord => {
    const [h, m] = systemSettings.workStartTime.split(':').map(Number);
    const expected = new Date(); expected.setHours(h, m, 0, 0);
    const isLate = new Date() > new Date(expected.getTime() + systemSettings.lateThresholdMinutes * 60000);
    const record: AttendanceRecord = {
      id: genId('att'), created_at: ts(),
      worker_id: workerId, date: today(),
      check_in: ts(), status: isLate ? 'late' as const : 'present' as const,
      location_lat: lat, location_lng: lng,
    };
    setAttendanceRecords(prev => [record, ...prev.filter(r => !(r.worker_id === workerId && r.date === today()))]);
    if (systemSettings.notifyAttendance) {
      addNotification({
        title: isLate ? 'حضور متأخر' : 'تسجيل حضور',
        message: `تسجيل حضور ${isLate ? '(متأخر)' : ''}`,
        type: isLate ? 'warning' : 'success',
        role_target: 'production_supervisor',
      });
    }
    return record;
  }, [systemSettings, addNotification]);

  const checkOut = useCallback((workerId: string, lat: number, lng: number) => {
    const t = today();
    setAttendanceRecords(prev => prev.map(r => {
      if (r.worker_id !== workerId || r.date !== t || r.check_out) return r;
      const hrs = r.check_in
        ? Math.round(((Date.now() - new Date(r.check_in).getTime()) / 3600000) * 10) / 10
        : 0;
      return { ...r, check_out: ts(), location_lat: lat, location_lng: lng, notes: `${hrs} ساعة عمل` };
    }));
  }, []);

  return { attendanceRecords, setAttendanceRecords, getTodayRecord, checkIn, checkOut };
}
