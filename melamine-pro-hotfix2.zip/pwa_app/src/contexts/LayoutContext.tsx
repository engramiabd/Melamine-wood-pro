import React, { createContext, useContext, useState, useCallback, useRef } from 'react';

interface LayoutContextValue {
  barsVisible: boolean;
  setBarsVisible: (v: boolean) => void;
  scrollContainerRef: React.RefObject<HTMLDivElement | null>;
  notifyScroll: (scrollTop: number) => void;
}

const LayoutContext = createContext<LayoutContextValue>({
  barsVisible: true,
  setBarsVisible: () => {},
  scrollContainerRef: { current: null },
  notifyScroll: () => {},
});

export const useLayout = () => useContext(LayoutContext);

export const LayoutProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [barsVisible, setBarsVisible] = useState(true);
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const lastScrollTop  = useRef(0);
  const lastDir        = useRef<'up' | 'down'>('up');
  const accumulated    = useRef(0);

  const notifyScroll = useCallback((scrollTop: number) => {
    const delta = scrollTop - lastScrollTop.current;
    const dir   = delta > 0 ? 'down' : 'up';

    if (dir !== lastDir.current) {
      accumulated.current = 0;
      lastDir.current     = dir;
    }
    accumulated.current += Math.abs(delta);

    if (scrollTop <= 8) {
      setBarsVisible(true);
    } else if (dir === 'down' && accumulated.current > 12) {
      setBarsVisible(false);
    } else if (dir === 'up' && accumulated.current > 30) {
      setBarsVisible(true);
    }

    lastScrollTop.current = scrollTop;
  }, []);

  return (
    <LayoutContext.Provider value={{ barsVisible, setBarsVisible, scrollContainerRef, notifyScroll }}>
      {children}
    </LayoutContext.Provider>
  );
};
