import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

type Theme = 'light' | 'dark' | 'system';
type ResolvedTheme = 'light' | 'dark';

interface ThemeContextType {
  theme: Theme;               // user preference: light / dark / system
  resolvedTheme: ResolvedTheme; // what's actually applied right now
  setTheme: (t: Theme) => void;
  toggleTheme: () => void;    // quick light<->dark toggle (ignores 'system')
}

const ThemeContext = createContext<ThemeContextType | null>(null);

function getSystemPreference(): ResolvedTheme {
  if (typeof window === 'undefined' || !window.matchMedia) return 'light';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>(() => {
    try {
      const saved = localStorage.getItem('melamine_theme') as Theme | null;
      return saved === 'light' || saved === 'dark' || saved === 'system' ? saved : 'light';
    } catch { return 'light'; }
  });

  const [resolvedTheme, setResolvedTheme] = useState<ResolvedTheme>(() =>
    theme === 'system' ? getSystemPreference() : theme as ResolvedTheme
  );

  // Apply resolvedTheme to <html data-theme="..."> and keep in sync with
  // system preference changes when theme === 'system'.
  useEffect(() => {
    const apply = () => {
      const next = theme === 'system' ? getSystemPreference() : (theme as ResolvedTheme);
      setResolvedTheme(next);
      document.documentElement.setAttribute('data-theme', next);
      // Keep the browser UI (status bar etc.) in sync with the theme
      const meta = document.querySelector('meta[name="theme-color"]');
      if (meta) meta.setAttribute('content', next === 'dark' ? '#0f172a' : '#1d4ed8');
    };
    apply();
    if (theme !== 'system' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, [theme]);

  const setTheme = useCallback((t: Theme) => {
    setThemeState(t);
    try { localStorage.setItem('melamine_theme', t); } catch { /* noop */ }
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(resolvedTheme === 'dark' ? 'light' : 'dark');
  }, [resolvedTheme, setTheme]);

  return (
    <ThemeContext.Provider value={{ theme, resolvedTheme, setTheme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
};
