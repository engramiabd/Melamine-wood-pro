import { useCallback, useEffect, useState } from 'react';
import type { Customer } from '../types';
import type { Notification } from './appData.types';
import { loadArchiveData } from '../lib/archiveLoader';
import { genId, ts, load, persistDebounced } from './appData.helpers';

type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;

/**
 * Customers domain: state, persistence, and CRUD operations.
 *
 * NOTE: `setCustomers` is intentionally exported so the invoices domain
 * (addInvoice, deleteInvoice, addInvoicePayment, generateInvoiceFromOrder)
 * can update the customer's running balance without this hook knowing about
 * invoices. Cross-domain writes stay in AppDataContext and are injected as
 * setter calls; this hook owns the state, not the full write surface.
 */
export function useCustomersData(addNotification: AddNotification) {
  const [customers, setCustomers] = useState<Customer[]>(() => load('app_customers', []));
  useEffect(() => {
    setCustomers(prev => {
      if (prev.length > 0) return prev;
      loadArchiveData().then(d => { if (d.customers.length) setCustomers(d.customers); });
      return prev;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => { persistDebounced('app_customers', customers); }, [customers]);

  const addCustomer = useCallback((c: Omit<Customer, 'id' | 'created_at' | 'updated_at'>): Customer => {
    const customer: Customer = { ...c, id: genId('cust'), created_at: ts(), updated_at: ts() };
    setCustomers(prev => [customer, ...prev]);
    addNotification({ title: 'عميل جديد', message: `تمت إضافة ${customer.name}`, type: 'success', role_target: 'manager' });
    return customer;
  }, [addNotification]);

  const updateCustomer = useCallback((id: string, data: Partial<Customer>) => {
    setCustomers(prev => prev.map(c => c.id === id ? { ...c, ...data, updated_at: ts() } : c));
  }, []);

  const deleteCustomer = useCallback((id: string) => {
    setCustomers(prev => prev.map(c =>
      c.id === id ? { ...c, deleted_at: new Date().toISOString(), updated_at: new Date().toISOString() } : c
    ));
  }, []);

  const getCustomer = useCallback((id: string) => customers.find(c => c.id === id), [customers]);

  const activeCustomers = customers.filter(c => !c.deleted_at);
  return { customers: activeCustomers, setCustomers, addCustomer, updateCustomer, deleteCustomer, getCustomer };
}
