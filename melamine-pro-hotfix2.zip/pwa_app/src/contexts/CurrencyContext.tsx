import React, { createContext, useContext, useState, useCallback } from 'react';
import type { Currency } from '../types';
import { useAppData } from './AppDataContext';
import { formatUSD as fmtUSDBase, formatSYP as fmtSYPBase } from '../utils/formatters';

interface CurrencyContextType {
  currency:       Currency;
  exchangeRate:   number;
  setCurrency:    (c: Currency) => void;
  toggleCurrency: () => void;
  setExchangeRate:(rate: number) => void;
  toDisplay:      (usd: number, syp: number) => number;
  symbol:         string;
  format:         (usd: number, syp?: number) => string;
  /** @deprecated use format() */
  formatUSD:      (amount: number) => string;
  /** @deprecated use format() */
  formatSYP:      (amount: number) => string;
}

const CurrencyContext = createContext<CurrencyContextType | null>(null);

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { systemSettings, updateSystemSettings } = useAppData();

  const [currency, setCurrencyState] = useState<Currency>(() => {
    try { return (localStorage.getItem('melamine_currency') as Currency) ?? 'USD'; }
    catch { return 'USD'; }
  });

  // ── Single source of truth: systemSettings.exchangeRate ──────────────────
  // Both Settings and Admin pages write to systemSettings via updateSystemSettings,
  // so CurrencyContext simply mirrors that value instead of keeping its own copy.
  const exchangeRate = systemSettings.exchangeRate;

  const setCurrency = useCallback((c: Currency) => {
    setCurrencyState(c);
    try { localStorage.setItem('melamine_currency', c); } catch { /* noop */ }
  }, []);

  const toggleCurrency = useCallback(() => {
    setCurrency(currency === 'USD' ? 'SYP' : 'USD');
  }, [currency, setCurrency]);

  const setExchangeRate = useCallback((rate: number) => {
    updateSystemSettings({ exchangeRate: rate });
  }, [updateSystemSettings]);

  const toDisplay = useCallback(
    (usd: number, syp: number) => (currency === 'USD' ? usd : syp),
    [currency],
  );

  const symbol = currency === 'USD' ? '$' : 'ل.س';

  const formatUSD = useCallback((amount: number) => fmtUSDBase(amount), []);

  const formatSYP = useCallback((amount: number) => fmtSYPBase(amount), []);

  const format = useCallback(
    (usd: number, syp?: number): string => {
      if (currency === 'USD') return formatUSD(usd);
      return formatSYP(syp ?? usd * exchangeRate);
    },
    [currency, exchangeRate, formatUSD, formatSYP],
  );

  return (
    <CurrencyContext.Provider value={{
      currency, exchangeRate,
      setCurrency, toggleCurrency, setExchangeRate,
      toDisplay, symbol, format, formatUSD, formatSYP,
    }}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = (): CurrencyContextType => {
  const ctx = useContext(CurrencyContext);
  if (!ctx) throw new Error('useCurrency must be used within CurrencyProvider');
  return ctx;
};
