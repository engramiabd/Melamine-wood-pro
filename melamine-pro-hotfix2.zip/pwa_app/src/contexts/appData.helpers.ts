import type { RawMaterial } from '../types';
import type { InventoryItem } from './appData.types';

export function genId(prefix = 'id') {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}
export function ts() { return new Date().toISOString(); }
export function today() { return new Date().toISOString().split('T')[0]; }

export function load<T>(key: string, fallback: T): T {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
  catch { return fallback; }
}

export function persist(key: string, val: unknown) {
  try { localStorage.setItem(key, JSON.stringify(val)); }
  catch (e) {
    // Storage unavailable or quota exceeded — never crash the app. Surface a
    // diagnostic so a full quota (e.g. after importing a large archive) is
    // visible, and signal listeners that may want to warn the user.
    try {
      console.warn(`[storage] failed to persist "${key}" — quota or availability issue`, e);
      if (e instanceof DOMException && (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED')) {
        window.dispatchEvent(new CustomEvent('app:storage-full', { detail: { key } }));
      }
    } catch { /* noop */ }
  }
}

// Debounced persistence: batches rapid successive writes to the same key
// (e.g. several order/status updates in a row) into a single localStorage write.
const persistTimers: Record<string, ReturnType<typeof setTimeout>> = {};
const persistPending: Record<string, unknown> = {};
export function persistDebounced(key: string, val: unknown, delay = 400) {
  persistPending[key] = val;
  if (persistTimers[key]) clearTimeout(persistTimers[key]);
  persistTimers[key] = setTimeout(() => {
    persist(key, persistPending[key]);
    delete persistTimers[key];
    delete persistPending[key];
  }, delay);
}
// Flush any pending debounced writes immediately before the page unloads,
// so a quick navigation/refresh right after an edit doesn't lose data.
if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', () => {
    Object.entries(persistPending).forEach(([key, val]) => persist(key, val));
  });
}

// Convert RawMaterial → InventoryItem
export function materialToItem(m: RawMaterial): InventoryItem {
  return {
    id: m.id, name: m.name, code: m.code, unit: m.unit,
    stock_quantity: m.current_stock, reorder_level: m.min_stock,
    max_quantity: m.max_stock, current_price: m.unit_cost_usd,
    category: m.category, supplier: m.supplier, location: m.location,
    created_at: m.last_updated, updated_at: m.last_updated,
  };
}

// ── localStorage quota monitoring ─────────────────────────────────────────────
// localStorage stores strings as UTF-16 (2 bytes per char).
// Conservative limit: 5 MB (browsers range from 5–10 MB per origin).
const STORAGE_LIMIT_BYTES = 5 * 1024 * 1024;

export interface StorageUsage {
  usedBytes:  number;
  limitBytes: number;
  percent:    number;
  usedKB:     number;
  limitKB:    number;
  /** Breakdown per app key (app_* keys only) */
  breakdown:  { key: string; kb: number }[];
}

export function getStorageUsage(): StorageUsage {
  let total = 0;
  const breakdown: { key: string; kb: number }[] = [];

  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i) ?? '';
    const val = localStorage.getItem(key) ?? '';
    // Each UTF-16 char = 2 bytes
    const bytes = (key.length + val.length) * 2;
    total += bytes;
    if (key.startsWith('app_')) {
      breakdown.push({ key, kb: Math.round(bytes / 102) / 10 });
    }
  }

  breakdown.sort((a, b) => b.kb - a.kb);

  return {
    usedBytes:  total,
    limitBytes: STORAGE_LIMIT_BYTES,
    percent:    Math.min(100, (total / STORAGE_LIMIT_BYTES) * 100),
    usedKB:     Math.round(total / 1024),
    limitKB:    Math.round(STORAGE_LIMIT_BYTES / 1024),
    breakdown,
  };
}
