import { useCallback, useEffect, useState, useRef, type MutableRefObject } from 'react';
import type { ProductionPlan, ErrorLogEntry } from '../types';
import { genId, ts, load, persistDebounced } from './appData.helpers';

type LogAudit = (e: {
  action: string; entity_type: string; entity_id?: string;
  summary: string; amount_usd?: number; actor?: string; actor_role?: string;
}) => void;

/**
 * Operational state: production planning (P2) and the operational error log
 * (P3-partial). Both are self-contained — production plans only emit audit
 * entries, and the error log has no cross-domain dependencies at all.
 *
 * `logErrorRef` is returned so other domains (orders, production) can record
 * operational errors through a stable ref without taking `logError` as a
 * dependency. Extracted from AppDataContext to keep that file focused.
 */
export function useOpsData(logAuditRef: MutableRefObject<LogAudit>) {
  // ─── Production planning (P2) ───────────────────────────────────────────
  const [productionPlans, setProductionPlans] = useState<ProductionPlan[]>(() => load('app_production_plans', []));
  useEffect(() => { persistDebounced('app_production_plans', productionPlans); }, [productionPlans]);

  const addProductionPlan = useCallback((data: Omit<ProductionPlan, 'id' | 'created_at' | 'status'>): ProductionPlan => {
    const plan: ProductionPlan = { ...data, id: genId('plan'), status: 'active', created_at: ts() };
    setProductionPlans(prev => [plan, ...prev]);
    logAuditRef.current({ action: 'plan.create', entity_type: 'production', entity_id: plan.id, summary: `خطة إنتاج: ${plan.title}` });
    return plan;
  }, [logAuditRef]);

  const updateProductionPlan = useCallback((id: string, patch: Partial<ProductionPlan>) => {
    setProductionPlans(prev => prev.map(p => p.id === id ? { ...p, ...patch } : p));
  }, []);

  const deleteProductionPlan = useCallback((id: string) => {
    setProductionPlans(prev => prev.filter(p => p.id !== id));
  }, []);

  // ─── Operational error log (P3-partial) ─────────────────────────────────
  const [errorLog, setErrorLog] = useState<ErrorLogEntry[]>(() => load('app_error_log', []));
  useEffect(() => { persistDebounced('app_error_log', errorLog); }, [errorLog]);

  const logError = useCallback((source: string, message: string, level: 'error' | 'warning' = 'error', context?: string) => {
    setErrorLog(prev => [{ id: genId('err'), timestamp: ts(), level, source, message, context }, ...prev].slice(0, 300));
  }, []);
  const logErrorRef = useRef(logError);
  useEffect(() => { logErrorRef.current = logError; }, [logError]);

  const clearErrorLog = useCallback(() => setErrorLog([]), []);

  return {
    productionPlans, setProductionPlans, addProductionPlan, updateProductionPlan, deleteProductionPlan,
    errorLog, setErrorLog, logError, logErrorRef, clearErrorLog,
  };
}
