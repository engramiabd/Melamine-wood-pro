import {
  useCallback, useEffect,
  type Dispatch, type MutableRefObject, type SetStateAction,
} from 'react';
import type { Product } from '../types';
import type {
  InventoryItem, Notification, SystemSettings, ProductionBatch,
} from './appData.types';
import {
  resolveConsumption, deductStock, STANDARD_BOM_BY_CODE,
  resolveFactoryConsumption, hasFactoryBom,
} from '../utils/bom';
import { type ProductionLineExtended } from '../lib/demoData';
import { genId, ts, today, load, persist } from './appData.helpers';

type LogAudit = (e: {
  action: string; entity_type: string; entity_id?: string; summary: string;
}) => void;
type LogError = (source: string, msg: string, level?: 'error' | 'warning') => void;
type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;

/**
 * Production domain: production-line CRUD, batch recording, BOM-based material
 * deduction, and the daily counter reset effect.
 *
 * consumeMaterialsForProduction is kept internal (not returned) — it's an
 * implementation detail of addProductionBatch and not exposed on the context.
 *
 * Cross-domain setters injected:
 * - setInventoryItems: consumeMaterials deducts raw-material stock
 * - setManagedProducts: addProductionBatch credits good boards to finished stock
 */
export function useProductionData(deps: {
  managedProducts: Product[];
  inventoryItems: InventoryItem[];
  systemSettings: Pick<SystemSettings, 'notifyLowStock'>;
  setProductionLines: Dispatch<SetStateAction<ProductionLineExtended[]>>;
  setProductionBatches: Dispatch<SetStateAction<ProductionBatch[]>>;
  setInventoryItems: Dispatch<SetStateAction<InventoryItem[]>>;
  setManagedProducts: Dispatch<SetStateAction<Product[]>>;
  logAuditRef: MutableRefObject<LogAudit>;
  logErrorRef: MutableRefObject<LogError>;
  addNotification: AddNotification;
}) {
  const {
    managedProducts, inventoryItems, systemSettings,
    setProductionLines, setProductionBatches, setInventoryItems, setManagedProducts,
    logAuditRef, logErrorRef, addNotification,
  } = deps;

  // ─── Production-line CRUD ─────────────────────────────────────────────────
  const startProductionLine = useCallback((id: string) => {
    setProductionLines(prev => prev.map(l =>
      l.id === id ? { ...l, status: 'active' as const, stop_reason: undefined } : l,
    ));
    addNotification({ title: 'خط إنتاج نشط', message: 'تم تشغيل خط الإنتاج بنجاح', type: 'success', role_target: 'production_supervisor' });
  }, [setProductionLines, addNotification]);

  const stopProductionLine = useCallback((id: string, reason: string) => {
    setProductionLines(prev => prev.map(l =>
      l.id === id ? { ...l, status: 'stopped' as const, stop_reason: reason, stop_started_at: ts() } : l,
    ));
    addNotification({ title: 'خط إنتاج متوقف', message: `السبب: ${reason}`, type: 'warning', role_target: 'production_supervisor' });
  }, [setProductionLines, addNotification]);

  const addProductionLine = useCallback((line: Partial<ProductionLineExtended>) => {
    const newLine: ProductionLineExtended = {
      id: genId('line'), name: line.name || 'خط جديد', code: line.code || 'NEW',
      status: 'idle' as const, capacity_per_day: line.capacity_per_day || 200,
      efficiency_percentage: 0, operating_cost_usd: line.operating_cost_usd || 500,
      total_produced_today: 0, total_defective_today: 0, production_speed: 0,
      created_at: ts(), ...(line.notes ? { notes: line.notes } : {}),
    };
    setProductionLines(prev => [...prev, newLine]);
    addNotification({ title: 'خط إنتاج جديد', message: `تمت إضافة ${newLine.name}`, type: 'success', role_target: 'admin' });
  }, [setProductionLines, addNotification]);

  const updateProductionLine = useCallback((id: string, data: Partial<ProductionLineExtended>) => {
    setProductionLines(prev => prev.map(l => l.id === id ? { ...l, ...data } : l));
  }, [setProductionLines]);

  const deleteProductionLine = useCallback((id: string) => {
    setProductionLines(prev => prev.filter(l => l.id !== id));
  }, [setProductionLines]);

  // ─── consumeMaterialsForProduction (internal) ─────────────────────────────
  // Deducts raw materials consumed by a production run using the product's BOM
  // (or the standard recipe). Logs warnings when items are missing or low.
  const consumeMaterialsForProduction = useCallback((
    producedQty: number, productId?: string, productName?: string,
  ) => {
    if (!producedQty || producedQty <= 0) return;
    const product = managedProducts.find(p =>
      (productId && p.id === productId) || (productName && p.name === productName),
    );
    const consumption = hasFactoryBom(product)
      ? resolveFactoryConsumption(product, inventoryItems)
      : resolveConsumption(product, inventoryItems, STANDARD_BOM_BY_CODE);

    if (product && hasFactoryBom(product)) {
      const thKey = String(product.thickness_mm).replace(/\.0$/, '');
      const mdf = inventoryItems.find(i => i.code === `MDF-${thKey}`);
      const paper = inventoryItems.find(i => i.code === `PAPER-${product.color_number}`);
      const facesQty = product.faces === 'وجهين' ? 2 : 1;
      if (!mdf)
        logErrorRef.current('processProduction', `لا يوجد MDF لسماكة ${thKey} (المنتج ${product.code})`, 'error');
      else if (mdf.stock_quantity < producedQty)
        logErrorRef.current('processProduction', `رصيد MDF غير كافٍ لسماكة ${thKey}: المطلوب ${producedQty} المتاح ${mdf.stock_quantity}`, 'warning');
      if (!paper || paper.stock_quantity <= 0)
        logErrorRef.current('processProduction', `ميلامين بدون ورق (لون ${product.color_number}) للمنتج ${product.code}`, 'warning');
      else if (paper.stock_quantity < producedQty * facesQty)
        logErrorRef.current('processProduction', `رصيد الورق غير كافٍ (لون ${product.color_number}): المطلوب ${producedQty * facesQty} المتاح ${paper.stock_quantity}`, 'warning');
    }
    if (!consumption.length) return;

    const lowAlerts: { name: string; unit: string; newQty: number; reorder: number }[] = [];
    setInventoryItems(prev => prev.map(item => {
      const c = consumption.find(x => x.id === item.id);
      if (!c) return item;
      const newQty = deductStock(item.stock_quantity, c.qty, producedQty);
      if (newQty <= item.reorder_level)
        lowAlerts.push({ name: item.name, unit: item.unit, newQty, reorder: item.reorder_level });
      return { ...item, stock_quantity: newQty, updated_at: ts() };
    }));
    lowAlerts.forEach(a => systemSettings.notifyLowStock && addNotification({
      title: 'مخزون منخفض',
      message: `${a.name}: ${Math.round(a.newQty)} ${a.unit} (الحد الأدنى: ${a.reorder})`,
      type: 'warning', role_target: 'manager',
    }));
  }, [managedProducts, inventoryItems, systemSettings.notifyLowStock, setInventoryItems, logErrorRef, addNotification]);

  // ─── addProductionBatch ───────────────────────────────────────────────────
  const addProductionBatch = useCallback((batch: Omit<ProductionBatch, 'id'>) => {
    const newBatch: ProductionBatch = { ...batch, id: genId('batch') };
    setProductionBatches(prev => [newBatch, ...prev]);
    setProductionLines(prev => prev.map(l => l.id === batch.line_id ? {
      ...l,
      total_produced_today: (l.total_produced_today || 0) + batch.produced_quantity,
      total_defective_today: (l.total_defective_today || 0) + (batch.defective_quantity || 0),
      efficiency_percentage: Math.min(100, Math.round(
        (((l.total_produced_today || 0) + batch.produced_quantity) / l.capacity_per_day) * 100,
      )),
    } : l));
    consumeMaterialsForProduction(batch.produced_quantity, batch.product_id, batch.product_name);
    const goodBoards = Math.max(0, batch.produced_quantity - (batch.defective_quantity || 0));
    if (goodBoards > 0 && batch.product_id) {
      setManagedProducts(prev => prev.map(p =>
        p.id === batch.product_id ? { ...p, stock_quantity: (p.stock_quantity || 0) + goodBoards } : p,
      ));
    }
    logAuditRef.current({
      action: 'production.batch', entity_type: 'production', entity_id: batch.line_id,
      summary: `تسجيل إنتاج ${batch.produced_quantity} وحدة (${batch.product_name})`,
    });
  }, [consumeMaterialsForProduction, setProductionBatches, setProductionLines, setManagedProducts, logAuditRef]);

  // ─── Daily production counter reset ──────────────────────────────────────
  // total_produced_today / total_defective_today accumulate per calendar day.
  // Without this, they grew forever and efficiency climbed past any real value.
  // We zero them when the day rolls over — on app open, tab refocus, or a
  // midnight crossed while the app stays open (hourly safety check).
  useEffect(() => {
    const RESET_KEY = 'app_prod_reset_date';
    const maybeReset = () => {
      const last = load<string>(RESET_KEY, '');
      const t = today();
      if (last === t) return;
      if (last) {
        setProductionLines(prev => prev.map(l => ({
          ...l, total_produced_today: 0, total_defective_today: 0,
          efficiency_percentage: 0, production_speed: 0,
        })));
      }
      persist(RESET_KEY, t);
    };
    maybeReset();
    window.addEventListener('focus', maybeReset);
    document.addEventListener('visibilitychange', maybeReset);
    const interval = setInterval(maybeReset, 60 * 60 * 1000);
    return () => {
      window.removeEventListener('focus', maybeReset);
      document.removeEventListener('visibilitychange', maybeReset);
      clearInterval(interval);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return {
    startProductionLine, stopProductionLine,
    addProductionLine, updateProductionLine, deleteProductionLine,
    addProductionBatch,
  };
}
