import { describe, it, expect } from 'vitest';
import { genId, today, ts, materialToItem } from './appData.helpers';
import type { RawMaterial } from '../types';

describe('genId', () => {
  it('prefixes the id and stays unique across calls', () => {
    const a = genId('ord');
    const b = genId('ord');
    expect(a.startsWith('ord-')).toBe(true);
    expect(a).not.toBe(b);
  });
});

describe('today / ts', () => {
  it('today returns an ISO date (YYYY-MM-DD)', () => {
    expect(today()).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });
  it('ts returns a full ISO timestamp', () => {
    expect(ts()).toMatch(/^\d{4}-\d{2}-\d{2}T/);
  });
});

describe('materialToItem', () => {
  it('maps a raw material onto an inventory item shape', () => {
    const m: RawMaterial = {
      id: 'm1', name: 'ورق', code: 'RAW-MPW', category: 'raw_material', unit: 'كغ',
      current_stock: 5000, min_stock: 1000, max_stock: 10000,
      unit_cost_usd: 2.5, unit_cost_syp: 32500, supplier: 'مورّد', location: 'A-1',
      last_updated: '2026-01-01T00:00:00.000Z',
    };
    const it = materialToItem(m);
    expect(it.stock_quantity).toBe(5000);
    expect(it.reorder_level).toBe(1000);
    expect(it.max_quantity).toBe(10000);
    expect(it.current_price).toBe(2.5);
    expect(it.code).toBe('RAW-MPW');
    expect(it.created_at).toBe('2026-01-01T00:00:00.000Z');
  });
});
