import React, { createContext, useContext, useState, useCallback, useEffect, useRef, useMemo } from 'react';
import { useAuth } from './AuthContext';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { DEFAULT_ROLE_PERMISSIONS } from '../lib/permissions';
import { loadArchiveData } from '../lib/archiveLoader';
import {
  demoOrders, demoProductionLinesExtended, demoJournalEntries,
  demoEmployees, demoLeaveRequests, demoAttendance,
  demoProducts, demoProductionBatches, demoHourlyProduction,
  demoMaterials, demoCustomers, ProductionLineExtended, ProductionBatch,
} from '../lib/demoData';
import type {
  Order, JournalEntry, Employee, LeaveRequest,
  AttendanceRecord, Product, WorkerWallet,
  Customer, Invoice, InvoicePayment, OrderPayment,
  BOMComponent, InvoiceItem,
  AuditEntry, Supplier, PurchaseOrder, PurchaseOrderItem, PayrollBreakdown,
  ProductionPlan,
  ErrorLogEntry,
} from '../types';
import { genId, ts, today, load, persist, persistDebounced, materialToItem } from './appData.helpers';
import {
  initSync, setHydrateCallback, scheduleFlush, syncNow as runSync,
  subscribeSync, getSyncStatus, type SyncStatus,
} from '../lib/syncEngine';
import { useNotifications } from './useNotifications';
import { useOpsData } from './useOpsData';
import { useSuppliersData } from './useSuppliersData';
import { useCustomersData } from './useCustomersData';
import { useManagedProductsData } from './useManagedProductsData';
import { useLeavesData } from './useLeavesData';
import { useAttendanceData } from './useAttendanceData';
import { useEmployeesData } from './useEmployeesData';
import { useWalletData } from './useWalletData';
import { usePermissionsData } from './usePermissionsData';
import { useInventoryData } from './useInventoryData';
import { useProductionData } from './useProductionData';
import { useInvoicesData } from './useInvoicesData';
import { useOrdersData } from './useOrdersData';
import { useSettingsData } from './useSettingsData';
import type {
  InventoryItem, Notification, WalletTransaction,
  AdvanceRequest, Wallet, SystemSettings,
} from './appData.types';

// Re-export shared types so existing imports of `from '../contexts/AppDataContext'`
// continue to work unchanged.
export type {
  InventoryItem, Notification, WalletTransaction,
  AdvanceRequest, Wallet, SystemSettings,
};

// ─── Context Type ──────────────────────────────────────────────────────────
interface AppDataContextType {
  orders: Order[];
  productionLines: ProductionLineExtended[];
  inventoryItems: InventoryItem[];
  journalEntries: JournalEntry[];
  employees: Employee[];
  leaveRequests: LeaveRequest[];
  advanceRequests: AdvanceRequest[];
  attendanceRecords: AttendanceRecord[];
  notifications: Notification[];
  /** Notifications visible to the currently logged-in user (role/target filtered). */
  visibleNotifications: Notification[];
  wallets: Wallet[];
  walletTransactions: WalletTransaction[];
  products: Product[];
  productionBatches: ProductionBatch[];
  hourlyProduction: typeof demoHourlyProduction;
  systemSettings: SystemSettings;
  unreadCount: number;
  // Orders
  addOrder: (o: Omit<Order, 'id' | 'created_at'>) => Order;
  updateOrderStatus: (id: string, status: Order['status'], note?: string) => void;
  updateOrderFields: (id: string, data: Partial<Order>) => void;
  deleteOrder: (id: string) => void;
  getOrder: (id: string) => Order | undefined;
  // Production
  startProductionLine: (id: string) => void;
  stopProductionLine: (id: string, reason: string) => void;
  addProductionLine: (l: Partial<ProductionLineExtended>) => void;
  updateProductionLine: (id: string, d: Partial<ProductionLineExtended>) => void;
  deleteProductionLine: (id: string) => void;
  addProductionBatch: (b: Omit<ProductionBatch, 'id'>) => void;
  // Inventory
  addInventoryTransaction: (itemId: string, type: 'in' | 'out', qty: number, price?: number, note?: string) => void;
  addInventoryItem: (item: Omit<InventoryItem, 'id' | 'created_at' | 'updated_at'>) => void;
  updateInventoryItem: (id: string, data: Partial<InventoryItem>) => void;
  deleteInventoryItem: (id: string) => void;
  // Journal
  addJournalEntry: (e: Omit<JournalEntry, 'id' | 'created_at'>) => void;
  deleteJournalEntry: (id: string) => void;
  // Employees
  addEmployee: (e: Omit<Employee, 'id'>) => void;
  updateEmployee: (id: string, d: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;
  // Leaves
  addLeaveRequest: (r: Omit<LeaveRequest, 'id' | 'created_at'>) => void;
  approveLeave: (id: string) => void;
  rejectLeave: (id: string, reason: string) => void;
  // Wallet
  requestAdvance: (workerId: string, amount: number, reason: string) => boolean;
  approveAdvance: (id: string) => void;
  rejectAdvance: (id: string, reason: string) => void;
  addWalletTransaction: (tx: Omit<WalletTransaction, 'id' | 'created_at'>) => { success: boolean; error?: string };
  addBonus: (workerId: string, amount: number, reason: string) => void;
  repayAdvance: (workerId: string, amount: number) => void;
  getWallet: (workerId: string) => Wallet;
  processPayroll: () => void;
  // Attendance
  checkIn: (workerId: string, lat: number, lng: number) => AttendanceRecord;
  checkOut: (workerId: string, lat: number, lng: number) => void;
  getTodayRecord: (workerId: string) => AttendanceRecord | undefined;
  // Notifications
  addNotification: (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  deleteNotification: (id: string) => void;
  clearNotifications: () => void;
  // Settings
  updateSystemSettings: (s: Partial<SystemSettings>) => void;
  // Profile
  saveUserProfile: (d: { full_name: string; phone?: string; email: string }) => void;
  changePassword: (current: string, next: string) => Promise<{ success: boolean; error?: string }>;
  // Admin
  exportData: () => void;
  importData: (file: File, onComplete?: () => void) => void;
  clearAllData: () => void;
  resetToDemo: () => Promise<void>;
  // ── Customers ────────────────────────────────────────────────────────────
  customers: Customer[];
  addCustomer: (c: Omit<Customer, 'id' | 'created_at' | 'updated_at'>) => Customer;
  updateCustomer: (id: string, data: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  getCustomer: (id: string) => Customer | undefined;
  // ── Invoices ─────────────────────────────────────────────────────────────
  invoices: Invoice[];
  invoicePayments: InvoicePayment[];
  addInvoice: (inv: Omit<Invoice, 'id' | 'created_at' | 'updated_at'>) => Invoice;
  updateInvoice: (id: string, data: Partial<Invoice>) => void;
  deleteInvoice: (id: string) => void;
  addInvoicePayment: (payment: Omit<InvoicePayment, 'id' | 'created_at'>) => void;
  generateInvoiceFromOrder: (order: Order) => Invoice | undefined;
  // ── Order Payments ───────────────────────────────────────────────────────
  orderPayments: OrderPayment[];
  addOrderPayment: (payment: Omit<OrderPayment, 'id' | 'created_at'>) => void;
  // ── Product management ────────────────────────────────────────────────────
  managedProducts: Product[];
  addProduct: (p: Omit<Product, 'id' | 'created_at'>) => Product;
  updateProduct: (id: string, data: Partial<Product>) => void;
  setProductBOM: (productId: string, bom: BOMComponent[]) => void;
  deleteProduct: (id: string) => void;
  // ── Phase 3: audit log, suppliers, purchasing, payroll ────────────────────
  auditLog: AuditEntry[];
  logAudit: (e: { action: string; entity_type: string; entity_id?: string; summary: string; amount_usd?: number; actor?: string; actor_role?: string }) => void;
  syncStatus: SyncStatus;
  syncNow: () => Promise<void>;
  suppliers: Supplier[];
  addSupplier: (s: Omit<Supplier, 'id' | 'created_at'>) => Supplier;
  updateSupplier: (id: string, data: Partial<Supplier>) => void;
  deleteSupplier: (id: string) => void;
  purchaseOrders: PurchaseOrder[];
  addPurchaseOrder: (po: Omit<PurchaseOrder, 'id' | 'po_number' | 'created_at' | 'status'> & { status?: PurchaseOrder['status'] }) => PurchaseOrder;
  receivePurchaseOrder: (poId: string) => void;
  cancelPurchaseOrder: (poId: string) => void;
  computePayrollFromAttendance: (employeeId: string, year: number, month: number) => PayrollBreakdown | undefined;
  // ── Phase 4: granular permissions ─────────────────────────────────────────
  rolePermissions: Record<string, string[]>;
  can: (key: string) => boolean;
  toggleRolePermission: (role: string, key: string, enabled: boolean) => void;
  resetRolePermissions: () => void;
  adminSetUserPassword: (userId: string, pwd: string) => void;
  // ── P2: production planning ───────────────────────────────────────────────
  productionPlans: ProductionPlan[];
  addProductionPlan: (data: Omit<ProductionPlan, 'id' | 'created_at' | 'status'>) => ProductionPlan;
  updateProductionPlan: (id: string, patch: Partial<ProductionPlan>) => void;
  deleteProductionPlan: (id: string) => void;
  // ── Operational error log ─────────────────────────────────────────────────
  errorLog: ErrorLogEntry[];
  logError: (source: string, message: string, level?: 'error' | 'warning', context?: string) => void;
  clearErrorLog: () => void;
}

// ─── Helpers ───────────────────────────────────────────────────────────────
// genId, ts, today, load, persistDebounced, materialToItem now live in
// ./appData.helpers (shared with useNotifications and future extracted hooks).

const DEFAULT_SETTINGS: SystemSettings = {
  factoryName: 'شركة عبد الهادي للصناعة',
  factoryLat: 33.5138, factoryLng: 36.2765,
  attendanceRadius: 200, currency: 'USD',
  // Single global exchange rate (USD→SYP). All currency conversions across the
  // app read this value via CurrencyContext.exchangeRate — never hardcode a rate.
  exchangeRate: 14500,
  workStartTime: '07:00', workEndTime: '17:00', lateThresholdMinutes: 15,
  maxAdvanceAmount: 500, payrollDay: 25, taxRate: 0,
  autoInvoiceOnComplete: false,
  notifyNewOrder: true, notifyLowStock: true, notifyAttendance: true,
  // Factory production constants (from factoryConfig.ts defaults)
  mdfBundleSize: 50, paperSheetsPerDozen: 180, paperDozensPerBox: 9,
  dieselMinLiters: 500, dieselAvgLiters: 2000,
};

// ─── Context ───────────────────────────────────────────────────────────────
const AppDataContext = createContext<AppDataContextType | null>(null);

export function useAppData() {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error('useAppData must be used within AppDataProvider');
  return ctx;
}

// ─── Provider ──────────────────────────────────────────────────────────────
export function AppDataProvider({ children }: { children: React.ReactNode }) {
  const [productionLines, setProductionLines] = useState<ProductionLineExtended[]>(() => load('app_lines', demoProductionLinesExtended));
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>(() => load('app_inventory', []));
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(() => load('app_journal', demoJournalEntries));
  const [advanceRequests, setAdvanceRequests] = useState<AdvanceRequest[]>(() => load('app_advances', []));
  const [wallets, setWallets] = useState<Wallet[]>(() => load('app_wallets', []));
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(() => load('app_wallet_txs', []));
  const [productionBatches, setProductionBatches] = useState<ProductionBatch[]>(() => load('app_batches', demoProductionBatches));
  const [systemSettings, setSystemSettings] = useState<SystemSettings>(() => load('app_settings', DEFAULT_SETTINGS));

  const products: Product[] = demoProducts;
  const hourlyProduction = demoHourlyProduction;

  // ── New domain state ──────────────────────────────────────────────────────

  // ── Phase 3 state: audit log, suppliers, purchasing ──────────────────────
  const [auditLog, setAuditLog] = useState<AuditEntry[]>(() => load('app_audit', []));
  const [rolePermissions, setRolePermissions] = useState<Record<string, string[]>>(() => load('app_role_permissions', DEFAULT_ROLE_PERMISSIONS));

  // Persist
  useEffect(() => { persistDebounced('app_lines', productionLines); }, [productionLines]);
  useEffect(() => { persistDebounced('app_inventory', inventoryItems); }, [inventoryItems]);
  useEffect(() => { persistDebounced('app_journal', journalEntries); }, [journalEntries]);
  useEffect(() => { persistDebounced('app_advances', advanceRequests); }, [advanceRequests]);
  useEffect(() => { persistDebounced('app_wallets', wallets); }, [wallets]);
  useEffect(() => { persistDebounced('app_wallet_txs', walletTransactions); }, [walletTransactions]);
  useEffect(() => { persistDebounced('app_settings', systemSettings); }, [systemSettings]);
  useEffect(() => { persistDebounced('app_batches', productionBatches); }, [productionBatches]);
  useEffect(() => { persistDebounced('app_audit', auditLog); }, [auditLog]);
  useEffect(() => { persistDebounced('app_role_permissions', rolePermissions); }, [rolePermissions]);

  // ─── Lazy-load archive data for inventory + audit on first run ─────────────
  // These two arrays live here (not in extracted hooks) so they share one fetch.
  // Fires once. If localStorage already has data the setters are no-ops.
  useEffect(() => {
    const needsInventory = inventoryItems.length === 0;
    const needsAudit     = auditLog.length     === 0;
    if (!needsInventory && !needsAudit) return;
    loadArchiveData().then(d => {
      if (needsInventory && d.inventory.length) setInventoryItems(d.inventory);
      if (needsAudit     && d.audit.length)     setAuditLog(d.audit);
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [syncStatus, setSyncStatus] = useState<SyncStatus>(() => getSyncStatus());
  const syncNow = useCallback(async () => { await runSync(); }, []);

  // ─── Notifications (extracted domain hook — storage, visibility, CRUD) ────
  const { user, updateUser, isDemoMode } = useAuth();
  const {
    notifications, visibleNotifications, unreadCount,
    addNotification, markNotificationRead, markAllNotificationsRead,
    deleteNotification, clearNotifications, resetNotifications,
  } = useNotifications(user);

  // ─── Audit log (Phase 3) ──────────────────────────────────────────────────
  // Records significant actions. Exposed via a stable ref so existing callbacks
  // can log without churning their dependency arrays.
  const logAudit = useCallback((e: {
    action: string; entity_type: string; entity_id?: string; summary: string; amount_usd?: number;
    actor?: string; actor_role?: string;
  }) => {
    const entry: AuditEntry = {
      id: genId('audit'), timestamp: ts(),
      actor: e.actor || user?.full_name || 'النظام',
      actor_role: e.actor_role || user?.role,
      action: e.action, entity_type: e.entity_type, entity_id: e.entity_id,
      summary: e.summary, amount_usd: e.amount_usd,
    };
    setAuditLog(prev => [entry, ...prev].slice(0, 1000)); // keep the last 1000
  }, [user]);
  const logAuditRef = useRef(logAudit);
  useEffect(() => { logAuditRef.current = logAudit; }, [logAudit]);

  // ─── Granular permissions (Phase 4 — extracted) ──────────────────────────
  const { can, toggleRolePermission, resetRolePermissions, adminSetUserPassword } =
    usePermissionsData(user, rolePermissions, setRolePermissions, logAuditRef, addNotification);

  // ─── Operational state (production planning + error log) ──────────────────
  // Extracted to useOpsData. logErrorRef is a stable ref other domains use to
  // record operational errors without re-subscribing.
  const {
    productionPlans, setProductionPlans, addProductionPlan, updateProductionPlan, deleteProductionPlan,
    errorLog, setErrorLog, logError, logErrorRef, clearErrorLog,
  } = useOpsData(logAuditRef);

  // ─── Settings & profile (extracted) ───────────────────────────────────────
  const { updateSystemSettings, saveUserProfile, changePassword } =
    useSettingsData(user, isDemoMode, setSystemSettings, updateUser);

  // ─── Customers (extracted) ─────────────────────────────────────────────────
  // setCustomers is used by the invoices domain to update customer balances.
  const {
    customers, setCustomers, addCustomer, updateCustomer, deleteCustomer, getCustomer,
  } = useCustomersData(addNotification);

  // ─── Invoices (extracted) ──────────────────────────────────────────────────
  // setInvoices exported so useOrdersData can create invoices via generateInvoiceFromOrder.
  const {
    invoices, setInvoices, invoicePayments, setInvoicePayments,
    addInvoice, updateInvoice, deleteInvoice, addInvoicePayment,
  } = useInvoicesData({ user, setCustomers, setJournalEntries, logAuditRef, addNotification });

  // ─── Managed products (extracted) ──────────────────────────────────────────
  const {
    managedProducts, setManagedProducts, addProduct, updateProduct, setProductBOM, deleteProduct,
  } = useManagedProductsData(addNotification);

  // ─── Orders (extracted) ────────────────────────────────────────────────────
  // addOrderPayment lives here since it writes to setOrders (own state).
  const {
    orders, setOrders, orderPayments, setOrderPayments,
    addOrder, generateInvoiceFromOrder, updateOrderStatus,
    deleteOrder, updateOrderFields, getOrder, addOrderPayment,
  } = useOrdersData({
    user, invoices, systemSettings,
    setInvoices, setCustomers, setManagedProducts, setJournalEntries,
    logAuditRef, logErrorRef, addNotification,
  });

  // ─── Inventory (extracted) ─────────────────────────────────────────────────
  // addInventoryTransaction is exported so useSuppliersData can call it when
  // receiving a PO (adds stock + books expense + runs low-stock checks).
  // inventoryItems (filtered — no deleted_at) comes from the hook; the raw setter stays here
  const { addInventoryTransaction, addInventoryItem, updateInventoryItem, deleteInventoryItem } =
    useInventoryData({ inventoryItems, systemSettings, setInventoryItems, setJournalEntries, logAuditRef, addNotification });

  // ─── Production (extracted) ────────────────────────────────────────────────
  // Daily counter reset effect lives inside this hook alongside the methods
  // that need setProductionLines.
  const {
    startProductionLine, stopProductionLine,
    addProductionLine, updateProductionLine, deleteProductionLine,
    addProductionBatch,
  } = useProductionData({
    managedProducts, inventoryItems, systemSettings,
    setProductionLines, setProductionBatches, setInventoryItems, setManagedProducts,
    logAuditRef, logErrorRef, addNotification,
  });

  // ─── Employees (extracted) ─────────────────────────────────────────────────
  // setWallets injected so addEmployee/deleteEmployee can manage the wallet entry.
  const {
    employees, setEmployees, addEmployee, updateEmployee, deleteEmployee,
  } = useEmployeesData(addNotification, setWallets);

  // ─── Leaves (extracted) ────────────────────────────────────────────────────
  const {
    leaveRequests, setLeaveRequests, addLeaveRequest, approveLeave, rejectLeave,
  } = useLeavesData(logAuditRef, addNotification);

  // ─── Attendance (extracted) ────────────────────────────────────────────────
  // systemSettings passed so checkIn can compute lateness thresholds.
  const {
    attendanceRecords, setAttendanceRecords, getTodayRecord, checkIn, checkOut,
  } = useAttendanceData(systemSettings, addNotification);

  // ─── Wallet / advances / payroll operations (extracted) ───────────────────
  // State (wallets, walletTransactions, advanceRequests) stays inline because
  // setWallets must be available for useEmployeesData above. Methods live here.
  const {
    computePayrollFromAttendance,
    getWallet, addWalletTransaction,
    requestAdvance, approveAdvance, rejectAdvance,
    addBonus, repayAdvance, processPayroll,
  } = useWalletData({
    wallets, advanceRequests, employees, attendanceRecords, systemSettings,
    setWallets, setWalletTransactions, setAdvanceRequests,
    setJournalEntries, setSystemSettings,
    logAuditRef, addNotification,
  });


  // ─── Suppliers & Purchasing (Phase 3) ─────────────────────────────────────
  // Extracted to useSuppliersData. Receiving a PO feeds inventory via the live
  // addInventoryTransaction handler defined above.
  const {
    suppliers, setSuppliers, addSupplier, updateSupplier, deleteSupplier,
    purchaseOrders, setPurchaseOrders, addPurchaseOrder, receivePurchaseOrder, cancelPurchaseOrder,
  } = useSuppliersData(logAuditRef, addNotification, addInventoryTransaction);

  // ─── Journal ─────────────────────────────────────────────────────────────
  const addJournalEntry = useCallback((entry: Omit<JournalEntry, 'id' | 'created_at'>) => {
    setJournalEntries(prev => [{ ...entry, id: genId('je'), created_at: ts() }, ...prev]);
    logAuditRef.current({ action: 'journal.create', entity_type: 'finance', summary: `قيد ${entry.type === 'income' ? 'إيراد' : 'مصروف'}: ${entry.description ?? entry.category ?? ''}`, amount_usd: entry.amount_usd });
  }, []);

  const deleteJournalEntry = useCallback((id: string) => {
    setJournalEntries(prev => prev.filter(e => e.id !== id));
    logAuditRef.current({ action: 'journal.delete', entity_type: 'finance', entity_id: id, summary: 'حذف قيد محاسبي' });
  }, []);

  // Low stock alerts on mount
  const alertedRef = useRef(false);
  useEffect(() => {
    if (alertedRef.current) return;
    alertedRef.current = true;
    inventoryItems.filter(i => i.stock_quantity <= i.reorder_level * 0.5).forEach(item => {
      if (systemSettings.notifyLowStock) addNotification({ title: 'مخزون حرج', message: `${item.name}: ${item.stock_quantity} ${item.unit}`, type: 'error', role_target: 'manager' });
    });
  }, []); // eslint-disable-line




  // ─── Admin ────────────────────────────────────────────────────────────────
  const exportData = useCallback(() => {
    const data = { orders, productionLines, inventoryItems, journalEntries, employees, leaveRequests, advanceRequests, attendanceRecords, wallets, walletTransactions, systemSettings, customers, invoices, invoicePayments, managedProducts, orderPayments, productionBatches, suppliers, purchaseOrders, auditLog, rolePermissions, productionPlans, errorLog, exportedAt: ts(), version: '1.6.0' };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement('a'), { href: url, download: `melamine-${today()}.json` });
    a.click(); URL.revokeObjectURL(url);
    addNotification({ title: 'تصدير البيانات', message: 'تم تصدير البيانات بنجاح', type: 'success', role_target: 'admin' });
  }, [orders, productionLines, inventoryItems, journalEntries, employees, leaveRequests, advanceRequests, attendanceRecords, wallets, walletTransactions, systemSettings, customers, invoices, invoicePayments, managedProducts, orderPayments, productionBatches, suppliers, purchaseOrders, auditLog, rolePermissions, productionPlans, errorLog, addNotification]);

  const importData = useCallback((file: File, onComplete?: () => void) => {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const data = JSON.parse(e.target?.result as string);
        // Structural validation — ensure each field is the expected array/object type
        // before writing to state. Silently skip fields that don't pass.
        if (Array.isArray(data.orders)) setOrders(data.orders);
        if (Array.isArray(data.productionLines)) setProductionLines(data.productionLines);
        if (Array.isArray(data.advanceRequests)) setAdvanceRequests(data.advanceRequests);
        if (Array.isArray(data.attendanceRecords)) setAttendanceRecords(data.attendanceRecords);
        if (Array.isArray(data.productionBatches)) setProductionBatches(data.productionBatches);
        if (Array.isArray(data.suppliers)) setSuppliers(data.suppliers);
        if (Array.isArray(data.purchaseOrders)) setPurchaseOrders(data.purchaseOrders);
        if (Array.isArray(data.auditLog)) setAuditLog(data.auditLog);
        if (data.rolePermissions && typeof data.rolePermissions === 'object') setRolePermissions(data.rolePermissions);        if (Array.isArray(data.productionPlans)) setProductionPlans(data.productionPlans);
        if (Array.isArray(data.errorLog)) setErrorLog(data.errorLog);
        if (Array.isArray(data.inventoryItems)) setInventoryItems(data.inventoryItems);
        if (Array.isArray(data.journalEntries)) setJournalEntries(data.journalEntries);
        if (Array.isArray(data.employees)) setEmployees(data.employees);
        if (data.systemSettings && typeof data.systemSettings === 'object') {
          // Guard against a 0 or negative exchange rate which would cause
          // division-by-zero or negative currency conversions throughout the app.
          const safeSettings = { ...data.systemSettings };
          if (!safeSettings.exchangeRate || safeSettings.exchangeRate <= 0) {
            safeSettings.exchangeRate = systemSettings.exchangeRate;
          }
          setSystemSettings(safeSettings);
        }
        if (Array.isArray(data.leaveRequests)) setLeaveRequests(data.leaveRequests);
        if (Array.isArray(data.wallets)) setWallets(data.wallets);
        if (Array.isArray(data.walletTransactions)) setWalletTransactions(data.walletTransactions);
        if (Array.isArray(data.customers)) setCustomers(data.customers);
        if (Array.isArray(data.invoices)) setInvoices(data.invoices);
        if (Array.isArray(data.invoicePayments)) setInvoicePayments(data.invoicePayments);
        if (Array.isArray(data.managedProducts)) setManagedProducts(data.managedProducts);
        if (Array.isArray(data.orderPayments)) setOrderPayments(data.orderPayments);
        addNotification({ title: 'استيراد البيانات', message: 'تم استيراد البيانات بنجاح', type: 'success', role_target: 'admin' });
      } catch {
        addNotification({ title: 'خطأ في الاستيراد', message: 'الملف غير صالح أو تالف — لم يتم تغيير أي بيانات', type: 'error', role_target: 'admin' });
      } finally {
        onComplete?.();
      }
    };
    reader.readAsText(file);
  }, [addNotification, systemSettings.exchangeRate]);

  const clearAllData = useCallback(() => {
    // A true full wipe — the previous version silently left employees,
    // production lines, attendance, wallets and products in place despite the
    // "تم مسح جميع البيانات" message. System settings are configuration, not
    // data, so they are intentionally preserved.
    setOrders([]); setProductionLines([]); setInventoryItems([]); setJournalEntries([]);
    setEmployees([]); setLeaveRequests([]); setAdvanceRequests([]); setAttendanceRecords([]);
    setWallets([]); setWalletTransactions([]); setProductionBatches([]);
    setCustomers([]); setInvoices([]); setInvoicePayments([]); setOrderPayments([]);
    setManagedProducts([]);
    setSuppliers([]); setPurchaseOrders([]); setAuditLog([]);
    setRolePermissions({ ...DEFAULT_ROLE_PERMISSIONS });
    setProductionPlans([]); setErrorLog([]);
    resetNotifications([]);
    addNotification({ title: 'مسح البيانات', message: 'تم مسح جميع البيانات', type: 'warning', role_target: 'admin' });
  }, [addNotification, resetNotifications]);

  const resetToDemo = useCallback(async () => {
    // Load factory archive data (cached after first fetch — near-instant on repeat calls)
    const archive = await loadArchiveData();
    setOrders(demoOrders);
    setProductionLines(demoProductionLinesExtended);
    setInventoryItems(archive.inventory.length ? archive.inventory : []);
    setJournalEntries(demoJournalEntries);
    setEmployees(archive.employees.length ? archive.employees : []);
    setLeaveRequests([]);
    setAdvanceRequests([]);
    setAttendanceRecords([]);
    setProductionBatches(demoProductionBatches);
    setWallets([]);
    setWalletTransactions([]);
    resetNotifications([]);
    setCustomers(archive.customers.length ? archive.customers : []);
    setInvoices([]);
    setInvoicePayments([]);
    setManagedProducts(archive.products.length ? archive.products : []);
    setOrderPayments([]);
    setAuditLog(archive.audit.length ? archive.audit : []);
    addNotification({ title: 'إعادة تعيين', message: 'تمت إعادة التعيين إلى بيانات المصنع', type: 'info', role_target: 'admin' });
  }, [addNotification, resetNotifications]);

  // ─── Cloud sync (Supabase) ────────────────────────────────────────────────
  // No-op unless real Supabase credentials are configured. Re-reads every slice
  // from localStorage after a successful pull/merge. Placed here, after all
  // domain state/setters (including those from extracted hooks) are in scope.
  const hydrateFromStorage = useCallback(() => {
    setOrders(prev => load('app_orders', prev));
    setProductionLines(prev => load('app_lines', prev));
    setProductionBatches(prev => load('app_batches', prev));
    setProductionPlans(prev => load('app_production_plans', prev));
    setInventoryItems(prev => load('app_inventory', prev));
    setManagedProducts(prev => load('app_products', prev));
    setSuppliers(prev => load('app_suppliers', prev));
    setPurchaseOrders(prev => load('app_purchase_orders', prev));
    setCustomers(prev => load('app_customers', prev));
    setInvoices(prev => load('app_invoices', prev));
    setInvoicePayments(prev => load('app_invoice_payments', prev));
    setOrderPayments(prev => load('app_order_payments', prev));
    setJournalEntries(prev => load('app_journal', prev));
    setWallets(prev => load('app_wallets', prev));
    setWalletTransactions(prev => load('app_wallet_txs', prev));
    setEmployees(prev => load('app_employees', prev));
    setAttendanceRecords(prev => load('app_attendance', prev));
    setLeaveRequests(prev => load('app_leaves', prev));
    setAdvanceRequests(prev => load('app_advances', prev));
    setAuditLog(prev => load('app_audit', prev));
    setSystemSettings(prev => load('app_settings', prev));
    setRolePermissions(prev => load('app_role_permissions', prev));
  }, [setProductionPlans, setSuppliers, setPurchaseOrders]);

  useEffect(() => {
    setHydrateCallback(hydrateFromStorage);
    const unsub = subscribeSync(setSyncStatus);
    initSync();
    return unsub;
  }, [hydrateFromStorage]);

  // Push local changes up (debounced) whenever any synced slice changes.
  useEffect(() => {
    scheduleFlush();
  }, [
    orders, productionLines, productionBatches, productionPlans, inventoryItems,
    managedProducts, suppliers, purchaseOrders, customers, invoices, invoicePayments,
    orderPayments, journalEntries, wallets, walletTransactions, employees,
    attendanceRecords, leaveRequests, advanceRequests, auditLog, systemSettings, rolePermissions,
  ]);

  // ─── Value ────────────────────────────────────────────────────────────────
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const value: AppDataContextType = useMemo((): AppDataContextType => ({
    orders, productionLines, inventoryItems, journalEntries,
    employees, leaveRequests, advanceRequests, attendanceRecords,
    notifications, visibleNotifications, wallets, walletTransactions, products,
    productionBatches, hourlyProduction, systemSettings, unreadCount,
    addOrder, updateOrderStatus, updateOrderFields, deleteOrder, getOrder,
    startProductionLine, stopProductionLine, addProductionLine,
    updateProductionLine, deleteProductionLine, addProductionBatch,
    addInventoryTransaction, addInventoryItem, updateInventoryItem, deleteInventoryItem,
    addJournalEntry, deleteJournalEntry,
    addEmployee, updateEmployee, deleteEmployee,
    addLeaveRequest, approveLeave, rejectLeave,
    requestAdvance, approveAdvance, rejectAdvance,
    addWalletTransaction, addBonus, repayAdvance, getWallet, processPayroll,
    checkIn, checkOut, getTodayRecord,
    addNotification, markNotificationRead, markAllNotificationsRead,
    deleteNotification, clearNotifications,
    // New entities
    customers, addCustomer, updateCustomer, deleteCustomer, getCustomer,
    invoices, invoicePayments, addInvoice, updateInvoice, deleteInvoice, addInvoicePayment, generateInvoiceFromOrder,
    orderPayments, addOrderPayment,
    managedProducts, addProduct, updateProduct, setProductBOM, deleteProduct,
    auditLog, logAudit,
    syncStatus, syncNow,
    suppliers, addSupplier, updateSupplier, deleteSupplier,
    purchaseOrders, addPurchaseOrder, receivePurchaseOrder, cancelPurchaseOrder,
    computePayrollFromAttendance,
    rolePermissions, can, toggleRolePermission, resetRolePermissions, adminSetUserPassword,
    productionPlans, addProductionPlan, updateProductionPlan, deleteProductionPlan,
    errorLog, logError, clearErrorLog,
    updateSystemSettings, saveUserProfile, changePassword,
    exportData, importData, clearAllData, resetToDemo,
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [
    orders, productionLines, inventoryItems, journalEntries,
    employees, leaveRequests, advanceRequests, attendanceRecords,
    notifications, visibleNotifications, wallets, walletTransactions,
    productionBatches, systemSettings, unreadCount,
    customers, invoices, invoicePayments, orderPayments, managedProducts,
    auditLog, suppliers, purchaseOrders, rolePermissions, productionPlans, errorLog,
    syncStatus,
    addOrder, updateOrderStatus, updateOrderFields, deleteOrder, getOrder,
    startProductionLine, stopProductionLine, addProductionLine, updateProductionLine,
    deleteProductionLine, addProductionBatch,
    addInventoryTransaction, addInventoryItem, updateInventoryItem, deleteInventoryItem,
    addJournalEntry, deleteJournalEntry,
    addEmployee, updateEmployee, deleteEmployee,
    addLeaveRequest, approveLeave, rejectLeave,
    requestAdvance, approveAdvance, rejectAdvance,
    addWalletTransaction, addBonus, repayAdvance, getWallet, processPayroll,
    checkIn, checkOut, getTodayRecord,
    addNotification, markNotificationRead, markAllNotificationsRead,
    deleteNotification, clearNotifications,
    addCustomer, updateCustomer, deleteCustomer, getCustomer,
    addInvoice, updateInvoice, deleteInvoice, addInvoicePayment, generateInvoiceFromOrder,
    addOrderPayment, addProduct, updateProduct, setProductBOM, deleteProduct,
    logAudit, syncNow,
    addSupplier, updateSupplier, deleteSupplier,
    addPurchaseOrder, receivePurchaseOrder, cancelPurchaseOrder,
    computePayrollFromAttendance, can, toggleRolePermission, resetRolePermissions, adminSetUserPassword,
    addProductionPlan, updateProductionPlan, deleteProductionPlan,
    logError, clearErrorLog,
    updateSystemSettings, saveUserProfile, changePassword,
    exportData, importData, clearAllData, resetToDemo,
  ]);

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
}
