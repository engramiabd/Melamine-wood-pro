import { useCallback, useEffect, useState, type Dispatch, type MutableRefObject, type SetStateAction } from 'react';
import type { User, Invoice, InvoicePayment, JournalEntry } from '../types';
import type { Customer, Notification } from './appData.types';
import { genId, ts, today, load, persistDebounced } from './appData.helpers';

type LogAudit = (e: {
  action: string; entity_type: string; entity_id?: string;
  summary: string; amount_usd?: number;
}) => void;
type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;

/**
 * Invoices domain: state (invoices, invoicePayments), persistence, and CRUD.
 *
 * Cross-domain setters injected:
 * - setCustomers: addInvoice credits customer balance; deleteInvoice/addInvoicePayment reverse it
 * - setJournalEntries: addInvoicePayment books the received payment as income
 *
 * setInvoices is exported so useOrdersData can add invoices via
 * generateInvoiceFromOrder without this hook knowing about orders.
 */
export function useInvoicesData(deps: {
  user: User | null;
  setCustomers: Dispatch<SetStateAction<Customer[]>>;
  setJournalEntries: Dispatch<SetStateAction<JournalEntry[]>>;
  logAuditRef: MutableRefObject<LogAudit>;
  addNotification: AddNotification;
}) {
  const { user, setCustomers, setJournalEntries, logAuditRef, addNotification } = deps;

  const [invoices, setInvoices] = useState<Invoice[]>(() => load('app_invoices', []));
  const [invoicePayments, setInvoicePayments] = useState<InvoicePayment[]>(() => load('app_invoice_payments', []));
  useEffect(() => { persistDebounced('app_invoices', invoices); }, [invoices]);
  useEffect(() => { persistDebounced('app_invoice_payments', invoicePayments); }, [invoicePayments]);

  const addInvoice = useCallback((inv: Omit<Invoice, 'id' | 'created_at' | 'updated_at'>): Invoice => {
    const invoice: Invoice = { ...inv, id: genId('inv'), created_at: ts(), updated_at: ts() };
    setInvoices(prev => [invoice, ...prev]);
    if (invoice.type === 'sale') {
      setCustomers(prev => prev.map(c => c.id === invoice.customer_id
        ? { ...c, balance_usd: c.balance_usd + invoice.total_usd, updated_at: ts() } : c));
    }
    addNotification({
      title: invoice.type === 'quotation' ? 'عرض سعر جديد' : 'فاتورة جديدة',
      message: `${invoice.invoice_number} - ${invoice.customer_name}`,
      type: 'success', role_target: 'accountant',
    });
    logAuditRef.current({
      action: 'invoice.create', entity_type: 'invoice', entity_id: invoice.id,
      summary: `${invoice.type === 'quotation' ? 'إصدار عرض سعر' : 'إصدار فاتورة'} ${invoice.invoice_number} - ${invoice.customer_name}`,
      amount_usd: invoice.total_usd,
    });
    return invoice;
  }, [setCustomers, addNotification, logAuditRef]);

  const updateInvoice = useCallback((id: string, data: Partial<Invoice>) => {
    setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, ...data, updated_at: ts() } : inv));
  }, []);

  const deleteInvoice = useCallback((id: string) => {
    // Capture before removal so we can reverse the customer balance
    setInvoices(prev => {
      const inv = prev.find(i => i.id === id);
      if (inv?.type === 'sale') {
        setCustomers(prev2 => prev2.map(c => c.id === inv.customer_id
          ? { ...c, balance_usd: Math.max(0, c.balance_usd - inv.remaining_usd), updated_at: ts() } : c));
      }
      return prev.filter(i => i.id !== id);
    });
  }, [setCustomers]);

  const addInvoicePayment = useCallback((payment: Omit<InvoicePayment, 'id' | 'created_at'>) => {
    const p: InvoicePayment = { ...payment, id: genId('pay'), created_at: ts() };
    setInvoicePayments(prev => [p, ...prev]);
    // Update invoice paid/remaining/status
    setInvoices(prev => prev.map(inv => {
      if (inv.id !== payment.invoice_id) return inv;
      const newPaid = inv.paid_usd + payment.amount_usd;
      const newRemaining = Math.max(0, inv.total_usd - newPaid);
      const status: Invoice['status'] = newRemaining <= 0 ? 'paid' : 'partial';
      return { ...inv, paid_usd: newPaid, remaining_usd: newRemaining, status, updated_at: ts() };
    }));
    // Reduce customer balance by payment received
    setCustomers(prev => prev.map(c => {
      const inv = invoices.find(i => i.id === payment.invoice_id);
      return c.id === inv?.customer_id
        ? { ...c, balance_usd: Math.max(0, c.balance_usd - payment.amount_usd), updated_at: ts() }
        : c;
    }));
    // Book income journal entry
    setJournalEntries(prev => [{
      id: genId('je'), entry_number: `JE-${Date.now().toString().slice(-6)}`,
      type: 'income' as const, category: 'مدفوعات عملاء',
      description: `تسديد فاتورة ${payment.invoice_id}`,
      amount_usd: payment.amount_usd, amount_syp: payment.amount_syp,
      currency: 'USD' as const, payment_method: payment.method,
      created_by: 'النظام', entry_date: today(), created_at: ts(),
    } as JournalEntry, ...prev]);
    addNotification({
      title: 'دفعة مستلمة', message: `$${payment.amount_usd} - ${p.id}`,
      type: 'success', role_target: 'accountant',
    });
    logAuditRef.current({
      action: 'invoice.payment', entity_type: 'invoice', entity_id: payment.invoice_id,
      summary: `تسديد دفعة على فاتورة بقيمة $${payment.amount_usd}`, amount_usd: payment.amount_usd,
    });
  }, [invoices, setCustomers, setJournalEntries, addNotification, logAuditRef]);

  return {
    invoices, setInvoices,
    invoicePayments, setInvoicePayments,
    addInvoice, updateInvoice, deleteInvoice, addInvoicePayment,
  };
}
