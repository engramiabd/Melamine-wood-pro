import { useCallback, useEffect, useState, type Dispatch, type MutableRefObject, type SetStateAction } from 'react';
import type { User, Order, OrderPayment, Invoice, InvoiceItem, JournalEntry, Product } from '../types';
import type { Notification, SystemSettings } from './appData.types';
import { computeInvoiceFromOrder } from '../utils/invoicing';
import { demoOrders } from '../lib/demoData';
import { genId, ts, today, load, persistDebounced } from './appData.helpers';

type LogAudit = (e: {
  action: string; entity_type: string; entity_id?: string;
  summary: string; amount_usd?: number;
}) => void;
type LogError = (source: string, msg: string, level?: 'error' | 'warning') => void;
type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;
type SetCustomers = Dispatch<SetStateAction<{ id: string; balance_usd: number; updated_at: string; [k: string]: unknown }[]>>;

/**
 * Orders & order-payments domain.
 *
 * generateInvoiceFromOrder lives here (not in useInvoicesData) because it is
 * triggered from the order screen. It needs invoices (to guard idempotency)
 * and setInvoices (to persist the created invoice), both injected.
 *
 * Cross-domain setters injected:
 * - setInvoices / invoices: generateInvoiceFromOrder creates the invoice
 * - setCustomers: generateInvoiceFromOrder books the remaining receivable
 * - setManagedProducts: updateOrderStatus deducts sold boards on completion
 * - setJournalEntries: addOrderPayment books the received payment as income
 *
 * setOrders and setOrderPayments are exported for importData / clearAllData /
 * resetToDemo / hydrateFromStorage in AppDataContext.
 */
export function useOrdersData(deps: {
  user: User | null;
  invoices: Invoice[];
  systemSettings: Pick<SystemSettings, 'notifyNewOrder'>;
  setInvoices: Dispatch<SetStateAction<Invoice[]>>;
  setCustomers: SetCustomers;
  setManagedProducts: Dispatch<SetStateAction<Product[]>>;
  setJournalEntries: Dispatch<SetStateAction<JournalEntry[]>>;
  logAuditRef: MutableRefObject<LogAudit>;
  logErrorRef: MutableRefObject<LogError>;
  addNotification: AddNotification;
}) {
  const {
    user, invoices, systemSettings,
    setInvoices, setCustomers, setManagedProducts, setJournalEntries,
    logAuditRef, logErrorRef, addNotification,
  } = deps;

  const [orders, setOrders] = useState<Order[]>(() => load('app_orders', demoOrders));
  const [orderPayments, setOrderPayments] = useState<OrderPayment[]>(() => load('app_order_payments', []));
  useEffect(() => { persistDebounced('app_orders', orders); }, [orders]);
  useEffect(() => { persistDebounced('app_order_payments', orderPayments); }, [orderPayments]);

  // ─── addOrder ─────────────────────────────────────────────────────────────
  const addOrder = useCallback((orderData: Omit<Order, 'id' | 'created_at'>): Order => {
    const order: Order = { ...orderData, id: genId('ord'), created_at: ts() };
    setOrders(prev => [order, ...prev]);
    logAuditRef.current({
      action: 'order.create', entity_type: 'order', entity_id: order.id,
      summary: `إنشاء طلب ${order.order_number} للعميل ${order.customer_name}`,
      amount_usd: order.total_usd,
    });
    if (systemSettings.notifyNewOrder) {
      addNotification({
        title: 'طلب جديد',
        message: `طلب جديد من ${order.customer_name} بقيمة $${order.total_usd}`,
        type: 'info', role_target: 'manager',
      });
    }
    return order;
  }, [systemSettings.notifyNewOrder, logAuditRef, addNotification]);

  // ─── generateInvoiceFromOrder ─────────────────────────────────────────────
  // Auto-generates a sale invoice from a completed order. Idempotent —
  // skips silently if this order already has an invoice.
  const generateInvoiceFromOrder = useCallback((order: Order): Invoice | undefined => {
    if (invoices.some(inv => inv.order_id === order.id)) return undefined;
    const invId = genId('inv');
    const fin = computeInvoiceFromOrder(order);
    const items: InvoiceItem[] = fin.items.map(it => ({ ...it, id: genId('iitem'), invoice_id: invId }));
    const invoice: Invoice = {
      id: invId, invoice_number: `INV-${Date.now().toString().slice(-6)}`,
      type: 'sale', order_id: order.id,
      customer_id: order.customer_id || '', customer_name: order.customer_name,
      customer_phone: order.customer_phone, customer_address: order.customer_address,
      items,
      subtotal_usd: fin.subtotal_usd, subtotal_syp: fin.subtotal_syp,
      tax_rate: fin.tax_rate, tax_usd: 0, tax_syp: 0, discount_usd: 0, discount_syp: 0,
      total_usd: fin.total_usd, total_syp: fin.total_syp,
      paid_usd: fin.paid_usd, remaining_usd: fin.remaining_usd, status: fin.status,
      notes: `فاتورة تلقائية من الطلب ${order.order_number}`,
      created_by: user?.id || 'system', issued_date: today(),
      created_at: ts(), updated_at: ts(),
    };
    setInvoices(prev => [invoice, ...prev]);
    // Book only the UNPAID remainder to the customer receivable — paid portion
    // was already collected when the order payment was recorded.
    if (order.customer_id && fin.remaining_usd > 0) {
      setCustomers((prev: { id: string; balance_usd: number; updated_at: string; [k: string]: unknown }[]) =>
        prev.map(c => c.id === order.customer_id
          ? { ...c, balance_usd: (c.balance_usd as number) + fin.remaining_usd, updated_at: ts() }
          : c));
    }
    addNotification({
      title: 'فاتورة تلقائية',
      message: `أُنشئت فاتورة ${invoice.invoice_number} للطلب ${order.order_number}`,
      type: 'success', role_target: 'accountant',
    });
    logAuditRef.current({
      action: 'invoice.create', entity_type: 'invoice', entity_id: invoice.id,
      summary: `إصدار فاتورة ${invoice.invoice_number} للطلب ${order.order_number}`,
      amount_usd: invoice.total_usd,
    });
    return invoice;
  }, [invoices, user, setInvoices, setCustomers, addNotification, logAuditRef]);

  // ─── updateOrderStatus ────────────────────────────────────────────────────
  const updateOrderStatus = useCallback((id: string, status: Order['status'], note?: string) => {
    const order = orders.find(o => o.id === id);
    const alreadyCompleted = order?.status === 'completed';
    const accepting = status === 'in_production' && order?.status !== 'in_production' && !order?.accepted_by;
    setOrders(prev => prev.map(o => o.id === id ? {
      ...o, status, updated_at: ts(),
      ...(note ? { notes: note } : {}),
      ...(status === 'completed' ? { completed_at: ts() } : {}),
      ...(accepting ? { accepted_by: user?.id || 'system', accepted_at: ts() } : {}),
    } : o));
    if (status === 'completed' && order && !alreadyCompleted) {
      addNotification({ title: 'طلب مكتمل', message: `الطلب ${order.order_number} مكتمل`, type: 'success', role_target: 'manager' });
      // Deduct sold boards from finished-melamine stock (inventory loop close).
      setManagedProducts(prev => prev.map(p => {
        const sold = order.items.filter(it => it.product_id === p.id)
          .reduce((s, it) => s + (it.quantity || 0), 0);
        if (!sold) return p;
        if ((p.stock_quantity || 0) < sold) {
          logErrorRef.current('processOutputInvoice', `رصيد الميلامين التام غير كافٍ للمنتج ${p.code}: المطلوب ${sold} المتاح ${p.stock_quantity || 0}`, 'warning');
        }
        return { ...p, stock_quantity: Math.max(0, (p.stock_quantity || 0) - sold) };
      }));
      // NOTE: completing a production order does NOT create an invoice.
      // Invoicing is now a deliberate manual step from the order screen.
    }
    if (order) {
      logAuditRef.current({
        action: 'order.status', entity_type: 'order', entity_id: order.id,
        summary: `تغيير حالة الطلب ${order.order_number} إلى «${status}»`,
      });
    }
  }, [orders, user, setManagedProducts, addNotification, logAuditRef, logErrorRef]);

  // ─── deleteOrder / updateOrderFields / getOrder ───────────────────────────
  const deleteOrder = useCallback((id: string) => {
    // Soft-delete: set deleted_at instead of removing, so the sync engine
    // can propagate the deletion to other devices via the UNION merge.
    setOrders(prev => prev.map(o => o.id === id ? { ...o, deleted_at: ts(), updated_at: ts() } : o));
    logAuditRef.current({ action: 'order.delete', entity_type: 'order', entity_id: id, summary: 'حذف طلب (soft)' });
  }, [logAuditRef]);

  const updateOrderFields = useCallback((id: string, data: Partial<Order>) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, ...data, updated_at: ts() } : o));
  }, []);

  const getOrder = useCallback((id: string) => orders.find(o => o.id === id), [orders]);

  // ─── addOrderPayment ──────────────────────────────────────────────────────
  const addOrderPayment = useCallback((payment: Omit<OrderPayment, 'id' | 'created_at'>) => {
    const order = orders.find(o => o.id === payment.order_id);
    if (!order) return;
    const remaining = order.total_usd - order.paid_usd;
    // Cap at remaining balance to prevent overpayment
    const amountUsd = Math.min(payment.amount_usd, remaining);
    if (amountUsd <= 0) return;
    const amountSyp = amountUsd * (payment.amount_usd > 0 ? payment.amount_syp / payment.amount_usd : 1);

    const p: OrderPayment = { ...payment, amount_usd: amountUsd, amount_syp: amountSyp, id: genId('opay'), created_at: ts() };
    setOrderPayments(prev => [p, ...prev]);
    setOrders(prev => prev.map(o => {
      if (o.id !== payment.order_id) return o;
      const newPaid = o.paid_usd + amountUsd;
      const newRemaining = Math.max(0, o.total_usd - newPaid);
      const status: Order['payment_status'] = newRemaining <= 0 ? 'paid' : newPaid > 0 ? 'partial' : 'unpaid';
      return { ...o, paid_usd: newPaid, payment_status: status, updated_at: ts() };
    }));
    // Note: customer.balance_usd is adjusted only by addInvoicePayment (formal
    // billing). Orders track their own paid_usd without double-counting.
    setJournalEntries(prev => [{
      id: genId('je'), entry_number: `JE-${Date.now().toString().slice(-6)}`,
      type: 'income' as const, category: 'مدفوعات طلبات',
      description: `دفعة على الطلب ${order.order_number} - ${order.customer_name}`,
      amount_usd: amountUsd, amount_syp: amountSyp,
      currency: 'USD' as const, payment_method: payment.method,
      created_by: 'النظام', entry_date: today(), created_at: ts(),
    } as JournalEntry, ...prev]);
    addNotification({
      title: 'دفعة مستلمة', message: `$${amountUsd} على الطلب ${order.order_number}`,
      type: 'success', role_target: 'accountant',
    });
    logAuditRef.current({
      action: 'order.payment', entity_type: 'order', entity_id: order.id,
      summary: `دفعة $${amountUsd} على الطلب ${order.order_number}`, amount_usd: amountUsd,
    });
  }, [orders, setJournalEntries, addNotification, logAuditRef]);

  // Expose only non-deleted orders to consumers.
  // The raw `setOrders` is still exported for importData / hydrateFromStorage.
  const activeOrders = orders.filter(o => !o.deleted_at);

  return {
    orders: activeOrders, setOrders,
    orderPayments, setOrderPayments,
    addOrder, generateInvoiceFromOrder, updateOrderStatus,
    deleteOrder, updateOrderFields, getOrder,
    addOrderPayment,
  };
}
