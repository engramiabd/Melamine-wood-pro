import { useCallback, useEffect, useState } from 'react';
import type { Product, BOMComponent } from '../types';
import type { Notification } from './appData.types';
import { loadArchiveData } from '../lib/archiveLoader';
import { genId, ts, load, persistDebounced } from './appData.helpers';

type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;

/**
 * Managed products domain: state, persistence, and CRUD operations.
 *
 * NOTE: `setManagedProducts` is intentionally exported so the orders domain
 * (updateOrderStatus — deducts sold boards on completion) and the production
 * domain (addProductionBatch — credits good boards to stock) can write to
 * product stock quantities without this hook needing to know about orders or
 * batches. The same pattern used by useCustomersData for cross-domain writes.
 */
export function useManagedProductsData(addNotification: AddNotification) {
  const [managedProducts, setManagedProducts] = useState<Product[]>(() => load('app_products', []));
  useEffect(() => {
    setManagedProducts(prev => {
      if (prev.length > 0) return prev;
      loadArchiveData().then(d => { if (d.products.length) setManagedProducts(d.products); });
      return prev;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => { persistDebounced('app_products', managedProducts); }, [managedProducts]);

  const addProduct = useCallback((p: Omit<Product, 'id' | 'created_at'>): Product => {
    const product: Product = { ...p, id: genId('prod'), created_at: ts() };
    setManagedProducts(prev => [product, ...prev]);
    addNotification({ title: 'منتج جديد', message: `تمت إضافة ${product.name}`, type: 'success', role_target: 'manager' });
    return product;
  }, [addNotification]);

  const updateProduct = useCallback((id: string, data: Partial<Product>) => {
    setManagedProducts(prev => prev.map(p => p.id === id ? { ...p, ...data } : p));
  }, []);

  const setProductBOM = useCallback((productId: string, bom: BOMComponent[]) => {
    setManagedProducts(prev => prev.map(p => p.id === productId ? { ...p, bom } : p));
  }, []);

  const deleteProduct = useCallback((id: string) => {
    setManagedProducts(prev => prev.filter(p => p.id !== id));
  }, []);

  return { managedProducts, setManagedProducts, addProduct, updateProduct, setProductBOM, deleteProduct };
}
