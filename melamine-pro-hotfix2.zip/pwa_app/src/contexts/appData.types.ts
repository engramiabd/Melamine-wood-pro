import type { UserRole } from '../types';

// ─── Shared domain types for the AppData layer ─────────────────────────────
// Extracted so that helper modules (appData.helpers.ts, useNotifications.ts,
// etc.) can reference these types without creating a circular import with
// AppDataContext.tsx itself.

export interface InventoryItem {
  id: string; name: string; code: string; unit: string;
  stock_quantity: number; reorder_level: number; max_quantity: number;
  current_price: number; category: string; supplier?: string; location?: string;
  created_at: string; updated_at: string;
  deleted_at?: string | null;
}

export interface Notification {
  id: string; title: string; message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  is_read: boolean;
  /** Broadcast target: a role name, or 'all' for everyone. */
  role_target: UserRole | 'all';
  /** Optional: when set, this notification is for one specific user (e.g. wallet/advance updates). */
  target_user_id?: string;
  created_at: string;
}

export interface WalletTransaction {
  id: string; worker_id: string; type: 'salary' | 'advance' | 'bonus' | 'deduction' | 'overtime';
  amount_usd: number; amount_syp: number; description: string;
  reference_id?: string; created_at: string;
}

export interface AdvanceRequest {
  id: string; worker_id: string; worker_name: string;
  amount_usd: number; amount_syp: number; reason: string;
  status: 'pending' | 'approved' | 'rejected';
  payment_method: string; rejection_reason?: string;
  approved_at?: string; created_at: string;
}

export interface Wallet {
  workerId: string; balanceUSD: number; balanceSYP: number;
}

export interface SystemSettings {
  factoryName: string; factoryLat: number; factoryLng: number;
  attendanceRadius: number; currency: string; exchangeRate: number;
  workStartTime: string; workEndTime: string; lateThresholdMinutes: number;
  maxAdvanceAmount: number; payrollDay: number;
  lastPayrollPeriod?: string; // e.g. "2026-06" — guards against double payroll runs
  taxRate: number; // default VAT/tax percentage applied to invoices, e.g. 0 or 5
  autoInvoiceOnComplete: boolean; // auto-generate a sale invoice when an order is completed
  notifyNewOrder: boolean; notifyLowStock: boolean; notifyAttendance: boolean;
  // ── Factory production constants (moved from hardcoded factoryConfig.ts) ──
  // Defaults match عبد الهادي للصناعة; admin can override in Settings.
  mdfBundleSize: number;         // boards per bundle (default 50)
  paperSheetsPerDozen: number;   // sheets per dozen (default 180)
  paperDozensPerBox: number;     // dozens per box (default 9)
  dieselMinLiters: number;       // low-stock warning threshold (default 500)
  dieselAvgLiters: number;       // normal level (default 2000)
}
