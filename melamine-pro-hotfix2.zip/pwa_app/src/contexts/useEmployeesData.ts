import { useCallback, useEffect, useState } from 'react';
import type { Employee } from '../types';
import type { Notification, Wallet } from './appData.types';
import { loadArchiveData } from '../lib/archiveLoader';
import { genId, load, persistDebounced } from './appData.helpers';

type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;
type SetWallets = React.Dispatch<React.SetStateAction<Wallet[]>>;

/**
 * Employees domain: state, persistence, and CRUD.
 *
 * `setWallets` is injected because adding an employee creates a zero-balance
 * wallet entry, and deleting an employee removes theirs. The wallet state
 * itself stays in AppDataContext (alongside the rest of the wallet/payroll
 * cluster), so we inject the setter to keep the cross-domain write explicit
 * rather than hiding it behind a callback prop.
 *
 * setEmployees is exported for importData / clearAllData / resetToDemo.
 * employees is read by requestAdvance, processPayroll, computePayroll in
 * AppDataContext via the destructured return value.
 */
export function useEmployeesData(
  addNotification: AddNotification,
  setWallets: SetWallets,
) {
  const [employees, setEmployees] = useState<Employee[]>(() => load('app_employees', []));

  // Lazy-load archive data on first run (no localStorage data yet)
  useEffect(() => {
    setEmployees(prev => {
      if (prev.length > 0) return prev;
      loadArchiveData().then(d => { if (d.employees.length) setEmployees(d.employees); });
      return prev;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { persistDebounced('app_employees', employees); }, [employees]);

  const addEmployee = useCallback((emp: Omit<Employee, 'id'>) => {
    const newEmp: Employee = { ...emp, id: genId('emp') };
    setEmployees(prev => [...prev, newEmp]);
    setWallets(prev => [...prev, { workerId: newEmp.user_id, balanceUSD: 0, balanceSYP: 0 }]);
    addNotification({ title: 'موظف جديد', message: 'تمت إضافة موظف جديد', type: 'success', role_target: 'hr' });
  }, [addNotification, setWallets]);

  const updateEmployee = useCallback((id: string, data: Partial<Employee>) => {
    setEmployees(prev => prev.map(e => e.id === id ? { ...e, ...data } : e));
  }, []);

  // Soft-delete: set deleted_at + is_active=false instead of removing,
  // so the sync engine propagates the deletion to other devices.
  const deleteEmployee = useCallback((id: string) => {
    setEmployees(prev => prev.map(e =>
      e.id === id ? { ...e, is_active: false, deleted_at: new Date().toISOString() } : e
    ));
  }, []);

  // Expose only non-deleted employees to consumers.
  const activeEmployees = employees.filter(e => !e.deleted_at);

  return { employees: activeEmployees, setEmployees, addEmployee, updateEmployee, deleteEmployee };
}
