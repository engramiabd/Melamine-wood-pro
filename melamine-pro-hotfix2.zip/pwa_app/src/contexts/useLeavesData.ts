import { useCallback, useEffect, useState, type MutableRefObject } from 'react';
import type { LeaveRequest } from '../types';
import type { Notification } from './appData.types';
import { genId, ts, load, persistDebounced } from './appData.helpers';

type LogAudit = (e: {
  action: string; entity_type: string; entity_id?: string;
  summary: string; amount_usd?: number;
}) => void;
type AddNotification = (n: Omit<Notification, 'id' | 'created_at' | 'is_read'>) => void;

/**
 * Leaves domain: state, persistence, and CRUD.
 * No cross-domain writes — fully self-contained.
 * setLeaveRequests is exported for importData / clearAllData / resetToDemo.
 */
export function useLeavesData(
  logAuditRef: MutableRefObject<LogAudit>,
  addNotification: AddNotification,
) {
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>(() => load('app_leaves', []));
  useEffect(() => { persistDebounced('app_leaves', leaveRequests); }, [leaveRequests]);

  const addLeaveRequest = useCallback((req: Omit<LeaveRequest, 'id' | 'created_at'>) => {
    setLeaveRequests(prev => [{ ...req, id: genId('leave'), created_at: ts() }, ...prev]);
    addNotification({ title: 'طلب إجازة جديد', message: 'طلب إجازة جديد في انتظار الموافقة', type: 'info', role_target: 'hr' });
  }, [addNotification]);

  const approveLeave = useCallback((id: string) => {
    setLeaveRequests(prev => prev.map(l => l.id === id ? { ...l, status: 'approved' as const } : l));
    logAuditRef.current({ action: 'leave.approve', entity_type: 'hr', entity_id: id, summary: 'اعتماد طلب إجازة' });
  }, [logAuditRef]);

  const rejectLeave = useCallback((id: string, reason: string) => {
    setLeaveRequests(prev => prev.map(l => l.id === id ? { ...l, status: 'rejected' as const, rejection_reason: reason } : l));
    logAuditRef.current({ action: 'leave.reject', entity_type: 'hr', entity_id: id, summary: `رفض طلب إجازة: ${reason}` });
  }, [logAuditRef]);

  return { leaveRequests, setLeaveRequests, addLeaveRequest, approveLeave, rejectLeave };
}
