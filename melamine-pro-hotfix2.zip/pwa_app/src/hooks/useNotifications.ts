import { useState, useCallback } from 'react';

export type NotificationType = 'info' | 'success' | 'warning' | 'error';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  link?: string;
}

// Demo notifications
const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'n1',
    type: 'warning',
    title: 'مخزون منخفض',
    message: 'صمغ يوريا فورمالديهايد وصل لأقل من الحد الأدنى (150/200 كغ)',
    timestamp: new Date(Date.now() - 15 * 60000),
    read: false,
    link: '/inventory',
  },
  {
    id: 'n2',
    type: 'info',
    title: 'طلب إنتاج جديد',
    message: 'طلب ORD-2024-002 من مكتبة النجوم - 30 لوح ميلامين',
    timestamp: new Date(Date.now() - 45 * 60000),
    read: false,
    link: '/orders/o2',
  },
  {
    id: 'n3',
    type: 'error',
    title: 'خط الإنتاج B متوقف',
    message: 'توقف خط الإنتاج B بسبب نقص في الكهرباء منذ 02:15 ساعة',
    timestamp: new Date(Date.now() - 135 * 60000),
    read: false,
    link: '/production-lines',
  },
  {
    id: 'n4',
    type: 'success',
    title: 'طلب مكتمل',
    message: 'تم اكتمال طلب ORD-2024-003 لمؤسسة البناء الذهبي بنجاح',
    timestamp: new Date(Date.now() - 3 * 3600000),
    read: true,
    link: '/orders/o3',
  },
  {
    id: 'n5',
    type: 'info',
    title: 'طلب سلفة',
    message: 'علي العامل يطلب سلفة بمبلغ $200 - بانتظار موافقتك',
    timestamp: new Date(Date.now() - 6 * 3600000),
    read: true,
    link: '/wallet',
  },
  {
    id: 'n6',
    type: 'warning',
    title: 'موعد صيانة',
    message: 'خط الإنتاج C يحتاج صيانة دورية منذ 7 أيام',
    timestamp: new Date(Date.now() - 24 * 3600000),
    read: true,
    link: '/production-lines',
  },
];

export function useNotifications() {
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = useCallback((id: string) => {
    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const addNotification = useCallback((notification: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: AppNotification = {
      ...notification,
      id: `n-${Date.now()}`,
      timestamp: new Date(),
      read: false,
    };
    setNotifications(prev => [newNotification, ...prev]);
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  // Format relative time in Arabic
  const formatRelativeTime = useCallback((date: Date): string => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1)  return 'الآن';
    if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
    if (diffHours < 24) return `منذ ${diffHours} ساعة`;
    if (diffDays < 7)  return `منذ ${diffDays} أيام`;
    return date.toLocaleDateString('ar-SY');
  }, []);

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    removeNotification,
    addNotification,
    clearAll,
    formatRelativeTime,
  };
}
