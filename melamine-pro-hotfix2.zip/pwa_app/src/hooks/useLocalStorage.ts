import { useState, useCallback } from 'react';

/**
 * Persist state in localStorage with JSON serialization.
 * Falls back to initialValue on parse errors or SSR.
 */
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = localStorage.getItem(key);
      return item !== null ? (JSON.parse(item) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  const setValue = useCallback((value: T | ((prev: T) => T)) => {
    try {
      const next = value instanceof Function ? value(storedValue) : value;
      setStoredValue(next);
      localStorage.setItem(key, JSON.stringify(next));
    } catch (err) {
      console.warn(`useLocalStorage[${key}]:`, err);
    }
  }, [key, storedValue]);

  const removeValue = useCallback(() => {
    try {
      localStorage.removeItem(key);
      setStoredValue(initialValue);
    } catch (err) {
      console.warn(`useLocalStorage[${key}]:`, err);
    }
  }, [key, initialValue]);

  return [storedValue, setValue, removeValue] as const;
}
