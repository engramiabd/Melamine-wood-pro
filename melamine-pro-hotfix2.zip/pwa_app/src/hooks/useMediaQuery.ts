import { useState, useEffect } from 'react';

/** Generic media query hook */
export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return window.matchMedia(query).matches;
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia(query);
    setMatches(mq.matches);
    const handler = (e: MediaQueryListEvent) => setMatches(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, [query]);

  return matches;
}

/** True when viewport width ≥ 768px */
export const useIsDesktop = () => useMediaQuery('(min-width: 768px)');

/** True when viewport width < 768px */
export const useIsMobile = () => useMediaQuery('(max-width: 767px)');
