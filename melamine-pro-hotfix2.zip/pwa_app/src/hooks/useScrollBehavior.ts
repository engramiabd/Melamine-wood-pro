import { useRef, useCallback } from 'react';

interface Options {
  threshold?: number;   // min px scrolled before toggling (default 60)
  downDelta?: number;   // px downward movement to hide (default 6)
  upDelta?: number;     // px upward movement to show (default 4)
  onVisibilityChange?: (visible: boolean) => void;
}

/**
 * Returns a scroll event handler and a ref to attach to the scroll container.
 * Calls onVisibilityChange(false) when scrolling down, (true) when scrolling up.
 */
export function useScrollBehavior({
  threshold = 60,
  downDelta = 6,
  upDelta = 4,
  onVisibilityChange,
}: Options = {}) {
  const scrollRef    = useRef<HTMLDivElement>(null);
  const lastY        = useRef(0);
  const visibleRef   = useRef(true);
  const ticking      = useRef(false);

  const onScroll = useCallback(() => {
    if (ticking.current) return;
    ticking.current = true;

    requestAnimationFrame(() => {
      ticking.current = false;
      const el = scrollRef.current;
      if (!el) return;

      const y = el.scrollTop;
      const delta = y - lastY.current;
      lastY.current = y;

      if (delta > downDelta && y > threshold && visibleRef.current) {
        visibleRef.current = false;
        onVisibilityChange?.(false);
      } else if (delta < -upDelta && !visibleRef.current) {
        visibleRef.current = true;
        onVisibilityChange?.(true);
      }
    });
  }, [threshold, downDelta, upDelta, onVisibilityChange]);

  const reset = useCallback(() => {
    lastY.current = 0;
    if (!visibleRef.current) {
      visibleRef.current = true;
      onVisibilityChange?.(true);
    }
  }, [onVisibilityChange]);

  return { scrollRef, onScroll, reset };
}
