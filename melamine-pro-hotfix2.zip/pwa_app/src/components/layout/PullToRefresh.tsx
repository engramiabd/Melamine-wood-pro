/**
 * PullToRefresh — Native touch implementation without react-swipeable.
 *
 * KEY DESIGN:
 * ─ Uses native touchstart/touchmove/touchend on the scroll container.
 * ─ Only activates when scrollTop === 0 AND first-touch swipe is downward.
 * ─ touch-action: pan-y on the container → browser handles normal scroll.
 *   We call preventDefault() only when pull-to-refresh is actually active
 *   (scrollTop === 0 and moving down), so normal scroll is never blocked.
 * ─ Renders a CSS-driven indicator (no framer-motion) for max performance.
 */

import React, { useRef, useState, useCallback, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';

interface PullToRefreshProps {
  onRefresh: () => Promise<void> | void;
  children: React.ReactNode;
  disabled?: boolean;
}

const PULL_THRESHOLD = 65;  // px before "release to refresh" state
const MAX_PULL       = 100; // rubber-band ceiling
const RESISTANCE     = 0.45; // how much pull translates to movement

export const PullToRefresh: React.FC<PullToRefreshProps> = ({
  onRefresh,
  children,
  disabled = false,
}) => {
  const containerRef   = useRef<HTMLDivElement>(null);
  const startYRef      = useRef(0);
  const pullDistRef    = useRef(0);
  const isPullingRef   = useRef(false);
  const isRefreshingRef = useRef(false);

  const [pullDist, setPullDist]       = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [triggered, setTriggered]     = useState(false);

  // Reset all state
  const resetPull = useCallback((animate = false) => {
    isPullingRef.current  = false;
    pullDistRef.current   = 0;
    if (!animate) {
      setPullDist(0);
      setTriggered(false);
    }
  }, []);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const onTouchStart = (e: TouchEvent) => {
      if (disabled || isRefreshingRef.current) return;
      if (el.scrollTop > 1) return;            // not at top — normal scroll
      startYRef.current   = e.touches[0].clientY;
      isPullingRef.current = false;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (disabled || isRefreshingRef.current) return;
      const dy = e.touches[0].clientY - startYRef.current;
      if (dy <= 0) { resetPull(); return; }     // swiping up — not pull-to-refresh
      if (el.scrollTop > 1) { resetPull(); return; } // drifted from top

      // We're pulling down from the top — take over from browser scroll
      isPullingRef.current = true;
      e.preventDefault();                        // stop native scroll rubber-band

      const clamped = Math.min(dy * RESISTANCE, MAX_PULL);
      pullDistRef.current = clamped;
      setPullDist(clamped);
      setTriggered(clamped >= PULL_THRESHOLD);
    };

    const onTouchEnd = async () => {
      if (!isPullingRef.current) return;
      const dist = pullDistRef.current;
      isPullingRef.current = false;

      if (dist < PULL_THRESHOLD) {
        // Not enough pull — animate back to 0
        setPullDist(0);
        setTriggered(false);
        pullDistRef.current = 0;
        return;
      }

      // Commit refresh
      try { navigator.vibrate?.([15, 8, 15]); } catch { /**/ }
      isRefreshingRef.current = true;
      setIsRefreshing(true);
      setPullDist(55);   // hold indicator in place while refreshing
      setTriggered(true);

      try { await onRefresh(); } finally {
        isRefreshingRef.current = false;
        setIsRefreshing(false);
        setPullDist(0);
        setTriggered(false);
        pullDistRef.current = 0;
      }
    };

    // { passive: false } only on touchmove so we can call preventDefault
    el.addEventListener('touchstart', onTouchStart, { passive: true });
    el.addEventListener('touchmove',  onTouchMove,  { passive: false });
    el.addEventListener('touchend',   onTouchEnd,   { passive: true });
    el.addEventListener('touchcancel', () => resetPull(), { passive: true });

    return () => {
      el.removeEventListener('touchstart',  onTouchStart);
      el.removeEventListener('touchmove',   onTouchMove);
      el.removeEventListener('touchend',    onTouchEnd);
    };
  }, [disabled, onRefresh, resetPull]);

  const show      = pullDist > 5 || isRefreshing;
  const progress  = Math.min(pullDist / PULL_THRESHOLD, 1);
  const spinDeg   = isRefreshing ? undefined : `${Math.round(progress * 270)}deg`;

  return (
    <div
      style={{
        position:   'relative',
        flex:       1,
        display:    'flex',
        flexDirection: 'column',
        minHeight:  0,
        overflow:   'hidden',
      }}
    >
      {/* Pull indicator */}
      {show && (
        <div
          style={{
            position:        'absolute',
            top:             Math.max(pullDist * 0.4 - 4, 6),
            left:            0,
            right:           0,
            zIndex:          30,
            display:         'flex',
            justifyContent:  'center',
            pointerEvents:   'none',
            transition:      isRefreshing ? 'top 0.3s ease' : 'none',
          }}
        >
          <div
            style={{
              display:       'flex',
              alignItems:    'center',
              gap:           7,
              padding:       '6px 14px',
              borderRadius:  999,
              fontSize:      12,
              fontWeight:    700,
              boxShadow:     '0 2px 12px rgba(0,0,0,0.12)',
              background:    triggered || isRefreshing ? '#2563eb' : '#fff',
              color:         triggered || isRefreshing ? '#fff' : '#64748b',
              border:        triggered || isRefreshing ? 'none' : '1px solid #e2e8f0',
              transition:    'background 0.2s, color 0.2s',
            }}
          >
            <RefreshCw
              size={13}
              style={{
                transform:  isRefreshing ? undefined : `rotate(${spinDeg})`,
                animation:  isRefreshing ? 'spin 0.7s linear infinite' : 'none',
              }}
            />
            <span>
              {isRefreshing ? 'جاري التحديث...' : triggered ? 'اترك للتحديث' : 'اسحب للتحديث'}
            </span>
          </div>
        </div>
      )}

      {/* Scrollable content */}
      <div
        ref={containerRef}
        style={{
          flex:               1,
          overflowY:          'auto',
          overflowX:          'hidden',
          overscrollBehavior: 'contain',
          touchAction:        'pan-y',
          transform:          show && !isRefreshing ? `translateY(${Math.min(pullDist * 0.35, 26)}px)` : undefined,
          transition:         isRefreshing || pullDist === 0 ? 'transform 0.3s ease' : 'none',
        }}
      >
        {children}
      </div>
    </div>
  );
};
