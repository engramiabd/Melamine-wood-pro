import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Bell, LogOut, Settings, User, Check, X,
  Trash2, Search, Zap, AlertTriangle, Info, CheckCircle,
  Package, ClipboardList, Users, DollarSign, Clock, Sun, Moon,
} from 'lucide-react';
import { useAuth }      from '../../contexts/AuthContext';
import { useCurrency }  from '../../contexts/CurrencyContext';
import { useTheme }     from '../../contexts/ThemeContext';
import { useIsDesktop } from '../../hooks/useMediaQuery';
import { useAppData }   from '../../contexts/AppDataContext';
import { Avatar }       from '../ui/Avatar';
import { SyncIndicator } from '../ui/SyncIndicator';

/* ── Page titles ─────────────────────────────────────────────────── */
const TITLES: Record<string, string> = {
  '/':                     'لوحة التحكم',
  '/orders':               'طلبات الإنتاج',
  '/orders/new':           'طلب جديد',
  '/production-lines':     'خطوط الإنتاج',
  '/inventory':            'المخزون',
  '/journal':              'السجل المحاسبي',
  '/wallet':               'المحفظة المالية',
  '/attendance':           'الحضور',
  '/attendance/dashboard': 'لوحة الحضور',
  '/hr/employees':         'الموارد البشرية',
  '/hr/leaves':            'الإجازات',
  '/hr/payroll':           'الرواتب',
  '/admin':                'الإدارة',
  '/costs':                'حاسبة التكاليف',
  '/sales':                'المبيعات',
  '/finance':              'الإدارة المالية',
  '/settings':             'الإعدادات',
  '/demo':                 'الوضع التجريبي',
  '/profile':              'الملف الشخصي',
  '/notifications':        'الإشعارات',
  '/reports':              'التقارير',
};

const getTitle = (p: string) => {
  if (TITLES[p]) return TITLES[p];
  if (p.startsWith('/orders/'))           return 'تفاصيل الطلب';
  if (p.startsWith('/production-lines/')) return 'خط الإنتاج';
  if (p.startsWith('/hr/'))              return 'الموارد البشرية';
  return 'ميلامين برو';
};

const ROLE_LABELS: Record<string, string> = {
  admin: 'مدير النظام', manager: 'مدير تنفيذي',
  production_supervisor: 'مشرف إنتاج', worker: 'عامل إنتاج',
  accountant: 'محاسب', hr: 'موارد بشرية',
};

const ROLE_COLORS: Record<string, string> = {
  admin:                'linear-gradient(135deg,#dc2626,#b91c1c)',
  manager:              'linear-gradient(135deg,#2563eb,#1d4ed8)',
  production_supervisor:'linear-gradient(135deg,#d97706,#b45309)',
  worker:               'linear-gradient(135deg,#059669,#047857)',
  accountant:           'linear-gradient(135deg,#7c3aed,#6d28d9)',
  hr:                   'linear-gradient(135deg,#db2777,#be185d)',
};

/* ── Notif Icon ─────────────────────────────────────────────────── */
const NotifIcon: React.FC<{ type: string }> = ({ type }) => {
  const map: Record<string, { icon: React.FC<{ size?: number; color?: string }>, color: string, bg: string }> = {
    warning:    { icon: AlertTriangle, color: '#d97706', bg: '#fffbeb' },
    error:      { icon: Zap,           color: '#dc2626', bg: '#fef2f2' },
    success:    { icon: CheckCircle,   color: '#059669', bg: '#ecfdf5' },
    info:       { icon: Info,          color: '#2563eb', bg: '#eff6ff' },
    order:      { icon: ClipboardList, color: '#7c3aed', bg: '#f5f3ff' },
    inventory:  { icon: Package,       color: '#ea580c', bg: '#fff7ed' },
    attendance: { icon: Clock,         color: '#0891b2', bg: '#ecfeff' },
    hr:         { icon: Users,         color: '#db2777', bg: '#fdf2f8' },
    wallet:     { icon: DollarSign,    color: '#059669', bg: '#ecfdf5' },
  };
  const cfg = map[type] ?? map.info;
  const Icon = cfg.icon;
  return (
    <div style={{
      width: 34, height: 34, borderRadius: 9,
      background: cfg.bg, display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>
      <Icon size={15} color={cfg.color} />
    </div>
  );
};

/* ── App Logo ───────────────────────────────────────────────────── */
const AppLogo: React.FC = () => (
  <svg width="30" height="30" viewBox="0 0 32 32" fill="none">
    <defs>
      <linearGradient id="tb-lg1" x1="0" y1="0" x2="32" y2="32">
        <stop stopColor="#1d4ed8" />
        <stop offset="1" stopColor="#6d28d9" />
      </linearGradient>
      <linearGradient id="tb-lg2" x1="0" y1="0" x2="0" y2="1">
        <stop stopColor="white" stopOpacity="0.9" />
        <stop offset="1" stopColor="white" stopOpacity="0.5" />
      </linearGradient>
    </defs>
    <rect width="32" height="32" rx="9" fill="url(#tb-lg1)" />
    <rect x="4"  y="18" width="24" height="10" rx="1.5" fill="url(#tb-lg2)" fillOpacity="0.25" />
    <rect x="6"  y="14" width="6"  height="14" rx="1"   fill="url(#tb-lg2)" fillOpacity="0.35" />
    <rect x="13" y="12" width="6"  height="16" rx="1"   fill="url(#tb-lg2)" fillOpacity="0.35" />
    <rect x="20" y="15" width="5"  height="13" rx="1"   fill="url(#tb-lg2)" fillOpacity="0.35" />
    <rect x="7"    y="8"  width="2.5" height="7" rx="1" fill="white" fillOpacity="0.85" />
    <rect x="14.5" y="6"  width="2.5" height="7" rx="1" fill="white" fillOpacity="0.85" />
    <rect x="21"   y="9"  width="2"   height="6" rx="1" fill="white" fillOpacity="0.85" />
    <circle cx="27" cy="5" r="3.5" fill="#10b981" />
    <circle cx="27" cy="5" r="2"   fill="white" />
  </svg>
);

/* ── Currency Toggle (compact icon button) ──────────────────────── */
const CurrencyToggle: React.FC<{
  currency: 'USD' | 'SYP';
  onToggle: () => void;
}> = ({ currency, onToggle }) => {
  const isUSD = currency === 'USD';

  return (
    <button
      onClick={onToggle}
      title={isUSD ? 'التبديل إلى الليرة السورية' : 'Switch to USD'}
      style={{
        width: 36, height: 36,
        borderRadius: 10,
        border: 'none',
        cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexDirection: 'column',
        gap: 0,
        background: isUSD
          ? 'linear-gradient(135deg,#1d4ed8,#2563eb)'
          : 'linear-gradient(135deg,#15803d,#16a34a)',
        boxShadow: isUSD
          ? '0 2px 8px rgba(29,78,216,0.35)'
          : '0 2px 8px rgba(21,128,61,0.35)',
        touchAction: 'manipulation',
        WebkitTapHighlightColor: 'transparent',
        transition: 'all 0.22s cubic-bezier(0.34,1.56,0.64,1)',
        position: 'relative',
        overflow: 'hidden',
      } as React.CSSProperties}
    >
      {/* Shimmer overlay */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 60%)',
        borderRadius: 10,
      }} />

      <AnimatePresence mode="wait">
        <motion.div
          key={currency}
          initial={{ opacity: 0, scale: 0.6, rotateY: 90 }}
          animate={{ opacity: 1, scale: 1, rotateY: 0 }}
          exit={{ opacity: 0, scale: 0.6, rotateY: -90 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          style={{
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            lineHeight: 1, zIndex: 1,
          }}
        >
          <span style={{
            fontSize: isUSD ? 14 : 13,
            fontWeight: 900,
            color: '#fff',
            lineHeight: 1,
            letterSpacing: isUSD ? '-0.5px' : '0px',
          }}>
            {isUSD ? '$' : 'ل.س'}
          </span>
        </motion.div>
      </AnimatePresence>
    </button>
  );
};

/* ── Search Bar ─────────────────────────────────────────────────── */
interface SearchResult { label: string; path: string; icon: React.FC<{ size?: number }> }
const SEARCH_ITEMS: SearchResult[] = [
  { label: 'لوحة التحكم',       path: '/',                    icon: CheckCircle },
  { label: 'طلبات الإنتاج',    path: '/orders',               icon: ClipboardList },
  { label: 'طلب جديد',          path: '/orders/new',           icon: ClipboardList },
  { label: 'العملاء',           path: '/customers',            icon: Users },
  { label: 'الفواتير',          path: '/invoices',             icon: DollarSign },
  { label: 'المنتجات',          path: '/products',             icon: Package },
  { label: 'خطوط الإنتاج',      path: '/production-lines',     icon: Zap },
  { label: 'إدارة المخزون',     path: '/inventory',            icon: Package },
  { label: 'السجل المحاسبي',    path: '/journal',              icon: DollarSign },
  { label: 'المحفظة المالية',   path: '/wallet',               icon: DollarSign },
  { label: 'تسجيل الحضور',     path: '/attendance',           icon: Clock },
  { label: 'لوحة الحضور',      path: '/attendance/dashboard', icon: Clock },
  { label: 'الموارد البشرية',   path: '/hr/employees',         icon: Users },
  { label: 'الرواتب',           path: '/hr/payroll',           icon: DollarSign },
  { label: 'الإعدادات',         path: '/settings',             icon: Settings },
  { label: 'التقارير',          path: '/reports',              icon: CheckCircle },
  { label: 'المبيعات',          path: '/sales',                icon: DollarSign },
  { label: 'الإدارة المالية',   path: '/finance',              icon: DollarSign },
  { label: 'لوحة الإدارة',     path: '/admin',                icon: Settings },
];

const SearchBar: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [q, setQ]             = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const navigate               = useNavigate();
  const inputRef               = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  useEffect(() => {
    if (!q.trim()) { setResults([]); return; }
    setResults(SEARCH_ITEMS.filter(i => i.label.includes(q.trim())).slice(0, 6));
  }, [q]);

  const go = (path: string) => { navigate(path); onClose(); };

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.18 }}
      style={{
        position: 'absolute', top: 'calc(100% + 6px)', left: 0, right: 0,
        background: 'var(--surface)', borderRadius: 16,
        border: '1px solid rgba(15,23,42,0.08)',
        boxShadow: '0 24px 56px rgba(15,23,42,0.16), 0 4px 12px rgba(15,23,42,0.06)',
        zIndex: 65, overflow: 'hidden', minWidth: 280,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', borderBottom: '1px solid var(--g100)' }}>
        <Search size={15} color="var(--g400)" />
        <input
          ref={inputRef}
          value={q}
          onChange={e => setQ(e.target.value)}
          placeholder="ابحث في التطبيق..."
          style={{
            flex: 1, border: 'none', outline: 'none', fontSize: 13,
            color: 'var(--g800)', background: 'transparent', fontFamily: 'inherit',
          }}
          dir="rtl"
        />
        {q && (
          <button onClick={() => setQ('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--g400)', padding: 2 }}>
            <X size={13} />
          </button>
        )}
      </div>

      {results.length > 0 ? (
        <div style={{ maxHeight: 260, overflowY: 'auto' }}>
          {results.map(r => {
            const Icon = r.icon;
            return (
              <button
                key={r.path}
                onClick={() => go(r.path)}
                style={{
                  width: '100%', display: 'flex', alignItems: 'center', gap: 10,
                  padding: '9px 14px', background: 'none', border: 'none',
                  cursor: 'pointer', textAlign: 'right', borderBottom: '1px solid var(--g50)',
                  transition: 'background 0.12s',
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'var(--g50)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'none')}
              >
                <div style={{
                  width: 28, height: 28, borderRadius: 8,
                  background: 'var(--g100)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0, color: 'var(--g500)',
                }}>
                  <Icon size={13} />
                </div>
                <span style={{ fontSize: 13, color: 'var(--g700)', fontWeight: 600 }}>{r.label}</span>
              </button>
            );
          })}
        </div>
      ) : q.trim() ? (
        <div style={{ padding: '18px 14px', textAlign: 'center', color: 'var(--g400)', fontSize: 13 }}>
          لا توجد نتائج لـ "{q}"
        </div>
      ) : (
        <div style={{ padding: '10px 14px' }}>
          <p style={{ margin: '0 0 8px', fontSize: 10, color: 'var(--g400)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            روابط سريعة
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
            {SEARCH_ITEMS.slice(0, 6).map(r => (
              <button
                key={r.path}
                onClick={() => go(r.path)}
                style={{
                  padding: '4px 9px', borderRadius: 7, fontSize: 11, fontWeight: 600,
                  background: 'var(--g100)', border: 'none', cursor: 'pointer',
                  color: 'var(--g700)', transition: 'background 0.12s',
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'var(--g200)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'var(--g100)')}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
};

/* ── Notification Panel ──────────────────────────────────────────── */
const NotifPanel: React.FC<{
  notifications: ReturnType<typeof useAppData>['notifications'];
  onMarkAllRead: () => void;
  onDelete: (id: string) => void;
  onNavigate: (path: string) => void;
  onClear: () => void;
}> = ({ notifications, onMarkAllRead, onDelete, onNavigate, onClear }) => {
  const unread = notifications.filter(n => !n.is_read).length;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95, y: -8 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: -8 }}
      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
      style={{
        position: 'absolute', left: 0, top: 'calc(100% + 8px)',
        width: 320, background: 'var(--surface)', borderRadius: 18,
        border: '1px solid rgba(15,23,42,0.07)',
        boxShadow: '0 24px 60px rgba(15,23,42,0.16), 0 4px 12px rgba(15,23,42,0.06)',
        zIndex: 65, overflow: 'hidden', transformOrigin: 'top left',
      }}
    >
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 14px 10px',
        background: 'linear-gradient(135deg, rgba(37,99,235,0.05), rgba(124,58,237,0.05))',
        borderBottom: '1px solid var(--g100)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 30, height: 30, borderRadius: 9,
            background: 'linear-gradient(135deg, #2563eb, #7c3aed)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Bell size={14} color="white" />
          </div>
          <div>
            <p style={{ margin: 0, fontSize: 12, fontWeight: 800, color: 'var(--g800)' }}>الإشعارات</p>
            <p style={{ margin: 0, fontSize: 10, color: 'var(--g500)' }}>
              {unread > 0 ? `${unread} غير مقروء` : 'كل شيء مقروء'}
            </p>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 5 }}>
          {unread > 0 && (
            <button
              onClick={onMarkAllRead}
              style={{
                display: 'flex', alignItems: 'center', gap: 3, padding: '4px 8px',
                borderRadius: 7, fontSize: 10, fontWeight: 700, color: '#2563eb',
                background: 'rgba(37,99,235,0.08)', border: 'none', cursor: 'pointer',
              }}
            >
              <Check size={10} /> قراءة الكل
            </button>
          )}
          {notifications.length > 0 && (
            <button
              onClick={onClear}
              style={{
                display: 'flex', alignItems: 'center', gap: 3, padding: '4px 8px',
                borderRadius: 7, fontSize: 10, fontWeight: 700, color: '#dc2626',
                background: 'rgba(220,38,38,0.08)', border: 'none', cursor: 'pointer',
              }}
            >
              <Trash2 size={10} /> مسح
            </button>
          )}
        </div>
      </div>

      {/* List */}
      <div style={{ maxHeight: 340, overflowY: 'auto', touchAction: 'pan-y' }}>
        {notifications.length === 0 ? (
          <div style={{ padding: '28px 14px', textAlign: 'center' }}>
            <div style={{
              width: 48, height: 48, borderRadius: 13, background: 'var(--g100)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 10px',
            }}>
              <Bell size={20} color="var(--g300)" />
            </div>
            <p style={{ margin: 0, fontSize: 12, color: 'var(--g400)', fontWeight: 600 }}>لا توجد إشعارات</p>
          </div>
        ) : (
          <AnimatePresence>
            {notifications.slice(0, 8).map((n, i) => (
              <motion.div
                key={n.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10, height: 0 }}
                transition={{ delay: i * 0.03 }}
                style={{
                  display: 'flex', gap: 10, padding: '10px 14px',
                  borderBottom: '1px solid var(--g50)',
                  background: n.is_read ? 'var(--surface)' : 'rgba(37,99,235,0.025)',
                  cursor: 'pointer', position: 'relative',
                }}
                onClick={() => onNavigate('/notifications')}
              >
                {!n.is_read && (
                  <div style={{
                    position: 'absolute', right: 0, top: 0, bottom: 0,
                    width: 3, borderRadius: '0 99px 99px 0',
                    background: 'linear-gradient(180deg, #2563eb, #7c3aed)',
                  }} />
                )}

                <NotifIcon type={n.type} />

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 6 }}>
                    <p style={{
                      margin: 0, fontSize: 12, fontWeight: n.is_read ? 600 : 800,
                      color: 'var(--g800)', lineHeight: 1.3,
                      overflow: 'hidden', display: '-webkit-box',
                      WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
                    }}>
                      {n.message}
                    </p>
                    <button
                      onClick={e => { e.stopPropagation(); onDelete(n.id); }}
                      style={{
                        background: 'none', border: 'none', cursor: 'pointer',
                        color: 'var(--g300)', padding: 2, flexShrink: 0,
                        borderRadius: 4,
                      }}
                    >
                      <X size={11} />
                    </button>
                  </div>
                  <p style={{ margin: '3px 0 0', fontSize: 10, color: 'var(--g400)' }}>
                    {new Date(n.created_at).toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' })}
                    {' · '}
                    {new Date(n.created_at).toLocaleDateString('ar-SY', { month: 'short', day: 'numeric' })}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>

      {/* Footer */}
      {notifications.length > 0 && (
        <button
          onClick={() => onNavigate('/notifications')}
          style={{
            width: '100%', padding: '10px 14px', textAlign: 'center',
            fontSize: 12, fontWeight: 700, color: '#2563eb',
            background: 'var(--g50)', border: 'none', borderTop: '1px solid var(--g100)',
            cursor: 'pointer',
          }}
        >
          عرض جميع الإشعارات ({notifications.length})
        </button>
      )}
    </motion.div>
  );
};

/* ── User Menu ──────────────────────────────────────────────────── */
const UserMenu: React.FC<{
  user: ReturnType<typeof useAuth>['user'];
  onNavigate: (path: string) => void;
  onLogout: () => void;
}> = ({ user, onNavigate, onLogout }) => {
  const roleColor = ROLE_COLORS[user?.role ?? ''] ?? 'linear-gradient(135deg,#2563eb,#7c3aed)';
  const roleLabel = ROLE_LABELS[user?.role ?? ''] ?? user?.role ?? '';
  const initials  = (user?.full_name ?? 'م').split(' ').map(w => w[0]).slice(0, 2).join('');

  const items = [
    { icon: User,     label: 'الملف الشخصي', path: '/profile' },
    { icon: Settings, label: 'الإعدادات',     path: '/settings' },
    { icon: Bell,     label: 'الإشعارات',     path: '/notifications' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.94, y: -8 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.94, y: -8 }}
      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
      style={{
        position: 'absolute', left: 0, top: 'calc(100% + 8px)',
        width: 230, background: 'var(--surface)', borderRadius: 18,
        border: '1px solid rgba(15,23,42,0.07)',
        boxShadow: '0 24px 60px rgba(15,23,42,0.16), 0 4px 12px rgba(15,23,42,0.06)',
        zIndex: 65, overflow: 'hidden', transformOrigin: 'top left',
      }}
    >
      {/* User card */}
      <div style={{
        padding: '14px',
        background: 'linear-gradient(135deg, rgba(37,99,235,0.06), rgba(124,58,237,0.06))',
        borderBottom: '1px solid var(--g100)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Avatar
            userId={user?.id}
            name={user?.full_name}
            role={user?.role}
            size={40}
            radius={12}
            fallbackPhoto={user?.avatar_url}
            style={{ boxShadow: '0 3px 10px rgba(37,99,235,0.3)' }}
          />
          <div style={{ minWidth: 0, flex: 1 }}>
            <p style={{
              margin: 0, fontSize: 12, fontWeight: 800, color: 'var(--g800)',
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            }}>
              {user?.full_name}
            </p>
            <span style={{
              display: 'inline-block', padding: '1px 6px', borderRadius: 5, marginTop: 3,
              fontSize: 9, fontWeight: 800, color: '#fff',
              background: roleColor,
            }}>
              {roleLabel}
            </span>
          </div>
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 5, marginTop: 8,
          padding: '5px 8px', borderRadius: 7, background: 'rgba(16,185,129,0.1)',
        }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#10b981', boxShadow: '0 0 5px rgba(16,185,129,0.6)' }} />
          <span style={{ fontSize: 10, fontWeight: 600, color: '#065f46' }}>متصل الآن</span>
        </div>
      </div>

      {/* Menu items */}
      <div style={{ padding: '4px 0' }}>
        {items.map(item => (
          <button
            key={item.label}
            onClick={() => onNavigate(item.path)}
            style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 9,
              padding: '9px 14px', fontSize: 12, color: 'var(--g700)',
              background: 'none', border: 'none', cursor: 'pointer',
              textAlign: 'right', transition: 'background 0.12s',
            }}
            onMouseEnter={e => (e.currentTarget.style.background = 'var(--g50)')}
            onMouseLeave={e => (e.currentTarget.style.background = 'none')}
          >
            <div style={{
              width: 28, height: 28, borderRadius: 8, background: 'var(--g100)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--g500)', flexShrink: 0,
            }}>
              <item.icon size={13} />
            </div>
            <span style={{ fontWeight: 600 }}>{item.label}</span>
          </button>
        ))}
      </div>

      <div style={{ height: 1, background: 'var(--g100)', margin: '0 14px' }} />

      <div style={{ padding: '4px 0 4px' }}>
        <button
          onClick={onLogout}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 9,
            padding: '9px 14px', fontSize: 12, color: '#dc2626',
            background: 'none', border: 'none', cursor: 'pointer',
            textAlign: 'right', transition: 'background 0.12s',
          }}
          onMouseEnter={e => (e.currentTarget.style.background = '#fef2f2')}
          onMouseLeave={e => (e.currentTarget.style.background = 'none')}
        >
          <div style={{
            width: 28, height: 28, borderRadius: 8, background: '#fee2e2',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#dc2626', flexShrink: 0,
          }}>
            <LogOut size={13} />
          </div>
          <span style={{ fontWeight: 700 }}>تسجيل الخروج</span>
        </button>
      </div>
    </motion.div>
  );
};

/* ── Main TopBar ─────────────────────────────────────────────────── */
export const TopBar: React.FC = () => {
  const { user, logout }  = useAuth();
  const { resolvedTheme, toggleTheme } = useTheme();
  const {
    visibleNotifications: notifications, deleteNotification,
    clearNotifications, markAllNotificationsRead,
  } = useAppData();
  const location  = useLocation();
  const navigate  = useNavigate();
  const isDesktop = useIsDesktop();

  const [notifOpen,  setNotifOpen]  = useState(false);
  const [menuOpen,   setMenuOpen]   = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const notifRef  = useRef<HTMLDivElement>(null);
  const menuRef   = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  const title      = getTitle(location.pathname);
  const unread     = notifications.filter(n => !n.is_read).length;
  const isDemoMode = user?.id?.startsWith('demo-');
  const initials   = (user?.full_name ?? 'م').split(' ').map(w => w[0]).slice(0, 2).join('');
  const roleColor  = ROLE_COLORS[user?.role ?? ''] ?? 'linear-gradient(135deg,#2563eb,#7c3aed)';

  /* Close dropdowns on outside click */
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      // Skip handler entirely when all panels are already closed (most common case)
      if (!notifOpen && !menuOpen && !searchOpen) return;
      if (notifRef.current  && !notifRef.current.contains(e.target as Node))  setNotifOpen(false);
      if (menuRef.current   && !menuRef.current.contains(e.target as Node))   setMenuOpen(false);
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setSearchOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [notifOpen, menuOpen, searchOpen]);

  const handleNavigate = useCallback((path: string) => {
    navigate(path);
    setNotifOpen(false);
    setMenuOpen(false);
    setSearchOpen(false);
  }, [navigate]);

  const handleLogout = useCallback(() => {
    logout();
    setMenuOpen(false);
  }, [logout]);

  return (
    <header
      dir="rtl"
      role="banner"
      aria-label="شريط التطبيق"
      style={{
        display: 'flex', alignItems: 'center',
        width: '100%', height: '100%',
        paddingInline: isDesktop ? 20 : 14,
        gap: isDesktop ? 10 : 7,
        background: 'transparent',
      } as React.CSSProperties}
    >
      {/* ── Right side: Logo + Title ─────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: isDesktop ? 10 : 8, flex: 1, minWidth: 0 }}>

        {/* Logo — always visible */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
          <span style={{ display: 'flex', filter: 'drop-shadow(0 2px 5px rgba(79,70,229,0.28))' }}><AppLogo /></span>
          {isDesktop && (
            <div>
              <p style={{ margin: 0, fontSize: 14, fontWeight: 900, color: 'var(--g800)', lineHeight: 1 }}>ميلامين برو</p>
              <p style={{ margin: '2px 0 0', fontSize: 10, color: 'var(--g400)', lineHeight: 1 }}>نظام إدارة المصنع</p>
            </div>
          )}
        </div>

        {/* Divider on mobile */}
        {!isDesktop && (
          <div style={{ width: 1, height: 18, background: 'var(--border-color)', borderRadius: 1, flexShrink: 0 }} />
        )}

        {/* Page title */}
        <AnimatePresence mode="wait">
          <motion.h1
            key={title}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.14 }}
            style={{
              margin: 0, flex: 1, minWidth: 0,
              fontSize: isDesktop ? 17 : 15.5,
              fontWeight: 800,
              letterSpacing: '-0.3px',
              color: 'var(--text-primary)',
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            }}
          >
            {title}
          </motion.h1>
        </AnimatePresence>
      </div>

      {/* ── Left side: Actions ───────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: isDesktop ? 8 : 5, flexShrink: 0 }}>

        {/* Demo badge */}
        {isDemoMode && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 4, padding: '3px 8px',
            borderRadius: 8, background: '#fffbeb', border: '1px solid #fde68a',
            fontSize: 10, fontWeight: 800, color: '#92400e', flexShrink: 0,
          }}>
            <span style={{
              width: 5, height: 5, borderRadius: '50%', background: '#f59e0b',
              animation: 'ping 1.4s ease-out infinite', display: 'inline-block',
            }} />
            {isDesktop ? 'تجريبي' : ''}
          </div>
        )}

        {/* Search (desktop only) */}
        {isDesktop && (
          <div style={{ position: 'relative' }} ref={searchRef}>
            <button
              aria-label="البحث"
              onClick={() => { setSearchOpen(o => !o); setNotifOpen(false); setMenuOpen(false); }}
              style={{
                width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center',
                borderRadius: 12,
                background: searchOpen ? 'rgba(79,70,229,0.12)' : 'transparent',
                border: 'none',
                cursor: 'pointer', color: searchOpen ? '#4f46e5' : 'var(--text-secondary)',
                touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent',
                transition: 'background 0.15s, color 0.15s',
              } as React.CSSProperties}
            >
              <Search size={15} />
            </button>
            <AnimatePresence>
              {searchOpen && <SearchBar onClose={() => setSearchOpen(false)} />}
            </AnimatePresence>
          </div>
        )}

        {/* Sync indicator */}
        <SyncIndicator />

        {/* Theme toggle — light / dark */}
        <button
          onClick={toggleTheme}
          data-fm
          aria-label={resolvedTheme === 'dark' ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن'}
          title={resolvedTheme === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}
          style={{
            width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center',
            borderRadius: 12, border: 'none', background: 'transparent',
            color: 'var(--text-secondary)', cursor: 'pointer', flexShrink: 0,
            touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent',
          } as React.CSSProperties}>
          <AnimatePresence mode="wait" initial={false}>
            <motion.span
              key={resolvedTheme}
              initial={{ rotate: -90, opacity: 0, scale: 0.6 }}
              animate={{ rotate: 0, opacity: 1, scale: 1 }}
              exit={{ rotate: 90, opacity: 0, scale: 0.6 }}
              transition={{ duration: 0.18 }}
              style={{ display: 'flex' }}>
              {resolvedTheme === 'dark'
                ? <Sun size={17} color="#f59e0b" />
                : <Moon size={17} />}
            </motion.span>
          </AnimatePresence>
        </button>

        {/* Notifications */}
        <div style={{ position: 'relative' }} ref={notifRef}>
          <button
            aria-label="الإشعارات"
            onClick={() => { setNotifOpen(o => !o); setMenuOpen(false); setSearchOpen(false); }}
            style={{
              width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center',
              borderRadius: 12,
              background: notifOpen ? 'rgba(79,70,229,0.12)' : 'transparent',
              border: 'none',
              cursor: 'pointer', position: 'relative',
              color: notifOpen ? '#4f46e5' : 'var(--text-secondary)',
              touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent',
              transition: 'background 0.15s, color 0.15s',
            } as React.CSSProperties}
          >
            <Bell size={16} />
            {unread > 0 && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                style={{
                  position: 'absolute', top: -3, left: -3,
                  minWidth: 16, height: 16, borderRadius: 99,
                  background: '#ef4444', color: '#fff',
                  fontSize: 9, fontWeight: 900,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  border: '2px solid var(--surface-secondary)',
                  boxShadow: '0 2px 5px rgba(239,68,68,0.4)',
                  padding: '0 3px',
                }}
              >
                {unread > 9 ? '9+' : unread}
              </motion.span>
            )}
          </button>

          <AnimatePresence>
            {notifOpen && (
              <NotifPanel
                notifications={notifications}
                onMarkAllRead={markAllNotificationsRead}
                onDelete={deleteNotification}
                onNavigate={handleNavigate}
                onClear={clearNotifications}
              />
            )}
          </AnimatePresence>
        </div>

        {/* User avatar + menu */}
        <div style={{ position: 'relative' }} ref={menuRef}>
          <button
            aria-label="القائمة"
            onClick={() => { setMenuOpen(o => !o); setNotifOpen(false); setSearchOpen(false); }}
            aria-label="حساب المستخدم"
            style={{
              width: 38, height: 38, borderRadius: 12,
              background: 'transparent', border: 'none', padding: 0,
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: menuOpen ? '0 4px 14px rgba(79,70,229,0.4)' : '0 2px 6px rgba(15,23,42,0.12)',
              outline: menuOpen ? '2px solid rgba(79,70,229,0.35)' : '2px solid transparent',
              outlineOffset: 1.5,
              touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent',
              transition: 'box-shadow 0.18s, outline-color 0.18s',
            } as React.CSSProperties}
          >
            <Avatar
              userId={user?.id}
              name={user?.full_name}
              role={user?.role}
              size={38}
              radius={12}
              fallbackPhoto={user?.avatar_url}
            />
          </button>

          <AnimatePresence>
            {menuOpen && (
              <UserMenu
                user={user}
                onNavigate={handleNavigate}
                onLogout={handleLogout}
              />
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
};
