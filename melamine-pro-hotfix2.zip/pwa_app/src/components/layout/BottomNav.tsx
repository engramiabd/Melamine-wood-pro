import React, { useState, useCallback, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { MoreHorizontal, Trophy } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { vibrate } from '../../utils/haptics';
import { BottomSheet } from './BottomSheet';
import {
  DashboardIcon, OrderIcon, ProductionLineIcon,
  InventoryIcon, AttendanceIcon, WalletIcon,
} from '../ui/AppIcon';

interface NavItem {
  path:  string;
  label: string;
  icon:  React.ComponentType<{ size?: number; className?: string }>;
}

const MAIN_NAV: NavItem[] = [
  { path: '/',                 label: 'الرئيسية', icon: DashboardIcon       },
  { path: '/orders',           label: 'الطلبات',  icon: OrderIcon           },
  { path: '/production-lines', label: 'الإنتاج',  icon: ProductionLineIcon  },
  { path: '/inventory',        label: 'المخزون',  icon: InventoryIcon       },
];

const WORKER_NAV: NavItem[] = [
  { path: '/',                 label: 'الرئيسية', icon: DashboardIcon       },
  { path: '/production-lines', label: 'الإنتاج',  icon: ProductionLineIcon  },
  { path: '/loyalty',          label: 'نقاطي',    icon: Trophy              },
  { path: '/attendance',       label: 'حضوري',    icon: AttendanceIcon      },
  { path: '/wallet',           label: 'محفظتي',   icon: WalletIcon          },
];

function haptic(pattern: number | number[] = 10) {
  vibrate(pattern);
}

export const BottomNav: React.FC = () => {
  const { user }          = useAuth();
  const location          = useLocation();
  const navigate          = useNavigate();
  const [sheet, setSheet] = useState(false);
  const indicatorRef      = useRef<HTMLDivElement>(null);
  const containerRef      = useRef<HTMLDivElement>(null);

  const openSheet  = useCallback(() => { haptic([8, 4, 8]); setSheet(true);  }, []);
  const closeSheet = useCallback(() => { setSheet(false); }, []);

  const navTo = useCallback((path: string) => {
    haptic(8);
    navigate(path);
  }, [navigate]);

  if (!user) return null;

  const isWorker = user.role === 'worker';
  const items    = isWorker ? WORKER_NAV : MAIN_NAV;
  const total    = items.length + (isWorker ? 0 : 1); // +1 for More btn

  const isActive = (path: string) =>
    path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);

  const activeIndex  = items.findIndex(i => isActive(i.path));
  const moreActive   = !isWorker && activeIndex === -1;
  // pill index: RTL so index 0 is rightmost → we invert
  const pillIndex    = moreActive ? items.length : activeIndex;

  return (
    <>
      {/* ── Nav bar ─────────────────────────────────────────────── */}
      <div
        ref={containerRef}
        style={{
          display:  'flex',
          height:   '100%',
          position: 'relative',
          width:    '100%',
        }}
      >
        {/* ── Active indicator pill ─────────────────────────────── */}
        {/*
          RTL layout: items render right→left.
          Item 0 (rightmost) → translateX = 0
          Item 1             → translateX = -100%
          Item N             → translateX = -N * 100%

          We use translateX to avoid left/right % confusion in RTL.
          The pill starts at the rightmost slot (index=0) and
          slides left as index increases.
        */}
        <div
          ref={indicatorRef}
          aria-hidden="true"
          className="nav-pill"
          style={{
            position:     'absolute',
            top:          10,
            right:        `calc(${pillIndex} * (100% / ${total}) + (100% / ${total}) / 2 - 29px)`,
            width:        58,
            height:       44,
            transition:   'right 0.42s cubic-bezier(0.34,1.4,0.5,1)',
            pointerEvents: 'none',
            zIndex:       0,
          }}
        />

        {/* ── Nav items ───────────────────────────────────────────── */}
        {items.map((item) => {
          const active = isActive(item.path);
          const Icon   = item.icon;
          return (
            <NavButton
              key={item.path}
              label={item.label}
              active={active}
              onClick={() => navTo(item.path)}
            >
              <Icon
                size={25}
                color={active ? 'var(--text-primary)' : 'var(--text-secondary)'}
                strokeWidth={active ? 2.5 : 1.9}
              />
            </NavButton>
          );
        })}

        {/* ── More button ─────────────────────────────────────────── */}
        {!isWorker && (
          <NavButton
            label="المزيد"
            active={sheet || moreActive}
            onClick={openSheet}
          >
            <MoreHorizontal
              size={25}
              strokeWidth={sheet || moreActive ? 2.5 : 1.9}
              style={{
                color:      sheet || moreActive ? 'var(--text-primary)' : 'var(--text-secondary)',
                transform:  sheet ? 'rotate(90deg)' : 'none',
                transition: 'transform 0.3s cubic-bezier(0.34,1.4,0.5,1), color 0.2s',
              }}
            />
          </NavButton>
        )}
      </div>

      {/* ── Bottom Sheet ─────────────────────────────────────────── */}
      <BottomSheet isOpen={sheet} onClose={closeSheet} />
    </>
  );
};

/* ── Single button ────────────────────────────────────────────── */
const NavButton: React.FC<{
  label:    string;
  active:   boolean;
  onClick:  () => void;
  children: React.ReactNode;
}> = ({ label, active, onClick, children }) => {
  const btnRef = useRef<HTMLButtonElement>(null);

  /* CSS-only press effect via data attribute */
  const handleDown = () => { if (btnRef.current) btnRef.current.setAttribute('data-pressed','1'); };
  const handleUp   = () => { if (btnRef.current) btnRef.current.removeAttribute('data-pressed'); };

  return (
    <button
      ref={btnRef}
      onClick={onClick}
      onPointerDown={handleDown}
      onPointerUp={handleUp}
      onPointerLeave={handleUp}
      onPointerCancel={handleUp}
      aria-label={label}
      aria-current={active ? 'page' : undefined}
      data-nav-btn
      style={{
        flex:                    1,
        display:                 'flex',
        flexDirection:           'column',
        alignItems:              'center',
        justifyContent:          'center',
        background:              'transparent',
        border:                  'none',
        cursor:                  'pointer',
        position:                'relative',
        zIndex:                  1,
        height:                  '100%',
        minHeight:               'unset',
        touchAction:             'manipulation',
        WebkitTapHighlightColor: 'transparent',
        outline:                 'none',
        userSelect:              'none',
        WebkitUserSelect:        'none' as React.CSSProperties['WebkitUserSelect'],
      } as React.CSSProperties}
    >
      {/* Icon — centered inside the active lozenge */}
      <div style={{
        display:    'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transform:  active ? 'scale(1.04)' : 'scale(1)',
        transition: 'transform 0.3s cubic-bezier(0.34,1.5,0.5,1)',
      }}>
        {children}
      </div>
    </button>
  );
};
