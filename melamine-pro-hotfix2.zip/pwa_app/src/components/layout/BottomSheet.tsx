import React, { useRef, useCallback, useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { X, Sparkles, Trophy } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import {
  JournalIcon, WalletIcon, AttendanceIcon, HRIcon,
  AdminShieldIcon, GearIcon, CostCalcIcon, SalesChartIcon,
  FinanceIcon, DemoModeIcon, CustomerIcon, InvoiceIcon, ProductIcon, InventoryIcon,
} from '../ui/AppIcon';

/* ─── Sheet items ────────────────────────────────────────────── */
interface SheetItem {
  path:   string;
  label:  string;
  icon:   React.ComponentType<{ size?: number; className?: string }>;
  grad:   string;
  roles?: string[];
}

const ITEMS: SheetItem[] = [
  {
    path: '/assistant', label: 'المساعد الذكي',
    icon: Sparkles,
    grad: 'linear-gradient(135deg,#6366f1,#8b5cf6)',
    roles: ['admin','manager','production_supervisor','accountant','worker','hr'],
  },
  {
    path: '/loyalty', label: 'نقاط الولاء',
    icon: Trophy,
    grad: 'linear-gradient(135deg,#f59e0b,#d97706)',
    roles: ['admin','manager','production_supervisor','accountant','worker','hr'],
  },
  {
    path: '/search', label: 'البحث الشامل',
    icon: CustomerIcon,
    grad: 'linear-gradient(135deg,#2563eb,#4f46e5)',
    roles: ['admin','manager','production_supervisor','accountant','worker','hr'],
  },
  {
    path: '/customers', label: 'العملاء',
    icon: CustomerIcon,
    grad: 'linear-gradient(135deg,#06b6d4,#0891b2)',
    roles: ['admin','manager','production_supervisor','accountant'],
  },
  {
    path: '/invoices', label: 'الفواتير',
    icon: InvoiceIcon,
    grad: 'linear-gradient(135deg,#6366f1,#4f46e5)',
    roles: ['admin','manager','accountant'],
  },
  {
    path: '/products', label: 'المنتجات',
    icon: ProductIcon,
    grad: 'linear-gradient(135deg,#ec4899,#db2777)',
    roles: ['admin','manager'],
  },
  {
    path: '/suppliers', label: 'الموردون والمشتريات',
    icon: InvoiceIcon,
    grad: 'linear-gradient(135deg,#8b5cf6,#6366f1)',
    roles: ['admin','manager','accountant'],
  },
  {
    path: '/production-plan', label: 'تخطيط الإنتاج',
    icon: ProductIcon,
    grad: 'linear-gradient(135deg,#c026d3,#9333ea)',
    roles: ['admin','manager','production_supervisor'],
  },
  {
    path: '/journal', label: 'السجل المحاسبي',
    icon: JournalIcon,
    grad: 'linear-gradient(135deg,#f59e0b,#ea580c)',
    roles: ['admin','manager','accountant'],
  },
  {
    path: '/wallet', label: 'محافظ العمال',
    icon: WalletIcon,
    grad: 'linear-gradient(135deg,#10b981,#0d9488)',
  },
  {
    path: '/finance', label: 'المالية والمبيعات',
    icon: FinanceIcon,
    grad: 'linear-gradient(135deg,#3b82f6,#4f46e5)',
    roles: ['admin','manager','accountant'],
  },
  {
    path: '/costs', label: 'حاسبة التكاليف',
    icon: CostCalcIcon,
    grad: 'linear-gradient(135deg,#0ea5e9,#06b6d4)',
    roles: ['admin','manager','accountant'],
  },
  {
    path: '/attendance', label: 'تسجيل الحضور',
    icon: AttendanceIcon,
    grad: 'linear-gradient(135deg,#10b981,#16a34a)',
  },
  {
    path: '/attendance/dashboard', label: 'لوحة الحضور',
    icon: AttendanceIcon,
    grad: 'linear-gradient(135deg,#06b6d4,#0284c7)',
    roles: ['admin','manager','production_supervisor','hr'],
  },
  {
    path: '/hr/employees', label: 'الموارد البشرية',
    icon: HRIcon,
    grad: 'linear-gradient(135deg,#f43f5e,#ec4899)',
    roles: ['admin','manager','hr'],
  },
  {
    path: '/admin', label: 'لوحة الإدارة',
    icon: AdminShieldIcon,
    grad: 'linear-gradient(135deg,#ef4444,#dc2626)',
    roles: ['admin'],
  },
  {
    path: '/audit', label: 'سجل التدقيق',
    icon: AdminShieldIcon,
    grad: 'linear-gradient(135deg,var(--text-secondary),#1e293b)',
    roles: ['admin'],
  },
  {
    path: '/admin/permissions', label: 'الصلاحيات',
    icon: AdminShieldIcon,
    grad: 'linear-gradient(135deg,#f43f5e,#e11d48)',
    roles: ['admin'],
  },
  {
    path: '/errors', label: 'سجل الأخطاء',
    icon: AdminShieldIcon,
    grad: 'linear-gradient(135deg,#334155,#0f172a)',
    roles: ['admin'],
  },
  {
    path: '/settings', label: 'الإعدادات',
    icon: GearIcon,
    grad: 'linear-gradient(135deg,var(--text-tertiary),var(--text-secondary))',
  },
  {
    path: '/reports', label: 'التقارير',
    icon: SalesChartIcon,
    grad: 'linear-gradient(135deg,#f59e0b,#d97706)',
    roles: ['admin','manager','accountant'],
  },
  {
    path: '/notifications', label: 'الإشعارات',
    icon: DemoModeIcon,
    grad: 'linear-gradient(135deg,#6366f1,#8b5cf6)',
  },
  {
    path: '/profile', label: 'الملف الشخصي',
    icon: HRIcon,
    grad: 'linear-gradient(135deg,#0ea5e9,#06b6d4)',
  },
  {
    path: '/demo', label: 'الوضع التجريبي',
    icon: DemoModeIcon,
    grad: 'linear-gradient(135deg,#d946ef,#7c3aed)',
  },
];

/* ─── Constants ──────────────────────────────────────────────── */
const SHEET_MAX_H  = typeof window !== 'undefined'
  ? Math.round(window.innerHeight * 0.86)
  : 600;
const CLOSE_THRESH = 90;   // px to drag down before auto-close
const SNAP_THRESH  = 40;   // px — snaps back if dragged less

/* ─── Component ──────────────────────────────────────────────── */
interface Props {
  isOpen:  boolean;
  onClose: () => void;
}

export const BottomSheet: React.FC<Props> = ({ isOpen, onClose }) => {
  const { user }    = useAuth();
  const navigate    = useNavigate();
  const location    = useLocation();
  const sheetRef    = useRef<HTMLDivElement>(null);
  const backdropRef = useRef<HTMLDivElement>(null);

  /* Translation Y state — managed via DOM ref for performance */
  const dragStartY    = useRef(0);
  const dragCurrentY  = useRef(0);
  const isDragging    = useRef(false);
  const animFrameRef  = useRef(0);

  /* Visibility state — for mount/unmount */
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setMounted(true);
      /* Animate in on next frame so transition runs */
      requestAnimationFrame(() => {
        requestAnimationFrame(() => applyTranslate(0, true));
      });
    } else if (mounted) {
      animateOut();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  /* Prevent page scroll when sheet is open */
  useEffect(() => {
    if (!mounted) return;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, [mounted]);

  /* Android back button */
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: PopStateEvent) => { e.preventDefault(); onClose(); };
    window.addEventListener('popstate', handler);
    return () => window.removeEventListener('popstate', handler);
  }, [isOpen, onClose]);

  /* ── DOM manipulation helpers ──────────────────────────────── */
  const applyTranslate = (y: number, withTransition = false) => {
    const el = sheetRef.current;
    const bd = backdropRef.current;
    if (!el) return;

    el.style.transition = withTransition
      ? 'transform 0.38s cubic-bezier(0.32,0.72,0,1)'
      : 'none';
    el.style.transform  = `translateY(${y}px)`;

    if (bd) {
      const progress = Math.max(0, 1 - y / SHEET_MAX_H);
      bd.style.opacity = String(progress);
    }
  };

  const animateOut = () => {
    const el = sheetRef.current;
    if (!el) { setMounted(false); return; }
    el.style.transition = 'transform 0.26s cubic-bezier(0.55,0,1,0.45)';
    el.style.transform  = `translateY(${SHEET_MAX_H + 100}px)`;
    if (backdropRef.current) {
      backdropRef.current.style.transition = 'opacity 0.26s ease';
      backdropRef.current.style.opacity    = '0';
    }
    setTimeout(() => setMounted(false), 280);
  };

  /* ── Touch / pointer drag handlers ────────────────────────── */
  const onDragStart = useCallback((e: React.PointerEvent) => {
    // Capture the pointer so we receive all subsequent pointer events
    // even if the pointer leaves the handle element during drag.
    e.currentTarget.setPointerCapture(e.pointerId);
    dragStartY.current   = e.clientY;
    dragCurrentY.current = 0;
    isDragging.current   = true;
  }, []);

  const onDragMove = useCallback((e: PointerEvent) => {
    if (!isDragging.current) return;
    const clientY = e.clientY;

    const delta = clientY - dragStartY.current;
    dragCurrentY.current = delta;

    /* Only allow dragging DOWN */
    if (delta < 0) {
      applyTranslate(0);
      return;
    }

    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    animFrameRef.current = requestAnimationFrame(() => {
      /* Rubber-band when dragging very far */
      const rubberband = delta > 0
        ? Math.min(delta, SHEET_MAX_H)
        : 0;
      applyTranslate(rubberband);
    });
  }, []);

  const onDragEnd = useCallback((_e?: PointerEvent) => {
    if (!isDragging.current) return;
    isDragging.current = false;
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);

    const delta = dragCurrentY.current;
    if (delta > CLOSE_THRESH) {
      /* Close the sheet */
      try { navigator.vibrate?.(8); } catch { /* noop */ }
      onClose();
    } else {
      /* Snap back to open position */
      applyTranslate(0, true);
    }
  }, [onClose]);

  /* Attach global move/end listeners when dragging */
  useEffect(() => {
    if (!mounted) return;
    const opts = { passive: true } as AddEventListenerOptions;
    window.addEventListener('pointermove', onDragMove, opts);
    window.addEventListener('pointerup',   onDragEnd,  opts);
    window.addEventListener('pointercancel', onDragEnd, opts);
    return () => {
      window.removeEventListener('pointermove', onDragMove);
      window.removeEventListener('pointerup',   onDragEnd);
      window.removeEventListener('pointercancel', onDragEnd);
    };
  }, [mounted, onDragMove, onDragEnd]);

  /* ── Navigation ─────────────────────────────────────────────── */
  const handleNav = useCallback((path: string) => {
    navigate(path);
    onClose();
    try { navigator.vibrate?.(8); } catch { /* noop */ }
  }, [navigate, onClose]);

  /* ── Filtered items ─────────────────────────────────────────── */
  const items = ITEMS.filter(
    item => !item.roles || (user?.role && item.roles.includes(user.role))
  );

  if (!mounted) return null;

  return (
    <>
      {/* ── Backdrop ──────────────────────────────────────────── */}
      <div
        ref={backdropRef}
        onClick={onClose}
        style={{
          position:             'fixed',
          inset:                0,
          zIndex:               50,
          background:           'rgba(15,23,42,0.6)',
          backdropFilter:       'blur(4px)',
          WebkitBackdropFilter: 'blur(4px)',
          touchAction:          'none',
          opacity:              0,
          transition:           'opacity 0.32s ease',
        }}
      />

      {/* ── Sheet panel ────────────────────────────────────────── */}
      <div
        ref={sheetRef}
        dir="rtl"
        onClick={e => e.stopPropagation()}
        style={{
          position:      'fixed',
          left:          0,
          right:         0,
          bottom:        0,
          zIndex:        51,
          maxHeight:     SHEET_MAX_H,
          background: 'var(--surface)',
          borderRadius:  '24px 24px 0 0',
          boxShadow:     '0 -4px 40px rgba(0,0,0,0.2)',
          display:       'flex',
          flexDirection: 'column',
          overflow:      'hidden',
          transform:     `translateY(${SHEET_MAX_H + 100}px)`, // start off-screen
          willChange:    'transform', // OK here — isolated from scroll container
        }}
      >
        {/* ── Drag handle ───────────────────────────────────────── */}
        <div
          onPointerDown={onDragStart}
          style={{
            display:        'flex',
            flexDirection:  'column',
            alignItems:     'center',
            padding:        '12px 0 4px',
            cursor:         'grab',
            flexShrink:     0,
            userSelect:     'none',
            touchAction:    'none', // handle captures all touch
          }}
        >
          {/* Handle bar */}
          <div style={{
            width:        44,
            height:       5,
            borderRadius: 999,
            background:   'rgba(148,163,184,0.45)',
          }} />
        </div>

        {/* ── Header ────────────────────────────────────────────── */}
        <div style={{
          display:        'flex',
          alignItems:     'center',
          justifyContent: 'space-between',
          padding:        '6px 18px 10px',
          flexShrink:     0,
        }}>
          {/* Logo + title */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width:          40,
              height:         40,
              borderRadius:   13,
              background:     'linear-gradient(135deg,#1d4ed8,#4f46e5)',
              display:        'flex',
              alignItems:     'center',
              justifyContent: 'center',
              boxShadow:      '0 3px 12px rgba(37,99,235,0.35)',
              flexShrink:     0,
            }}>
              <svg width="22" height="22" viewBox="0 0 32 32" fill="none">
                <rect x="3" y="17" width="26" height="12" rx="2" fill="white" fillOpacity="0.3"/>
                <rect x="5" y="12" width="6"  height="17" rx="1.5" fill="white" fillOpacity="0.55"/>
                <rect x="13" y="9"  width="6" height="20" rx="1.5" fill="white" fillOpacity="0.55"/>
                <rect x="21" y="13" width="5" height="16" rx="1.5" fill="white" fillOpacity="0.55"/>
                <rect x="6"  y="5"  width="3" height="8"  rx="1"   fill="white" fillOpacity="0.9"/>
                <rect x="14" y="3"  width="3" height="7"  rx="1"   fill="white" fillOpacity="0.9"/>
                <rect x="22" y="6"  width="3" height="8"  rx="1"   fill="white" fillOpacity="0.9"/>
                <circle cx="26" cy="7" r="3" fill="#4ade80"/>
              </svg>
            </div>
            <div>
              <p style={{ margin: 0, fontWeight: 800, fontSize: 15, color: 'var(--text-primary)', lineHeight: 1.2 }}>
                ميلامين برو
              </p>
              <p style={{ margin: 0, fontSize: 11, color: 'var(--text-tertiary)', marginTop: 2, fontWeight: 500 }}>
                القائمة الكاملة
              </p>
            </div>
          </div>

          {/* Close button */}
          <button
            onClick={onClose}
            style={{
              width:                   36,
              height:                  36,
              borderRadius:            '50%',
              background:              'var(--border-color)',
              border:                  'none',
              cursor:                  'pointer',
              display:                 'flex',
              alignItems:              'center',
              justifyContent:          'center',
              flexShrink:              0,
              touchAction:             'manipulation',
              WebkitTapHighlightColor: 'transparent',
              minHeight:               'unset',
            } as React.CSSProperties}
          >
            <X size={15} color="var(--text-tertiary)" strokeWidth={2.5} />
          </button>
        </div>

        {/* Divider */}
        <div style={{
          height:     1,
          background: 'rgba(226,232,240,0.7)',
          margin:     '0 16px 4px',
          flexShrink: 0,
        }} />

        {/* ── Scrollable grid content ───────────────────────────── */}
        {/*
          CRITICAL: touch-action: pan-y so inner scroll works.
          The drag handle has touch-action:none so it captures
          the drag gesture only when the user starts on the handle.
          The content area allows vertical scroll naturally.
        */}
        <div
          style={{
            flex:               1,
            overflowY:          'auto',
            overflowX:          'hidden',
            overscrollBehavior: 'contain',
            touchAction:        'pan-y',
            scrollbarWidth:     'none',
            paddingBottom:      `max(16px, env(safe-area-inset-bottom))`,
          }}
        >
          <div style={{
            display:             'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap:                 10,
            padding:             '12px 14px 8px',
          }}>
            {items.map((item, idx) => {
              const Icon     = item.icon;
              const isActive = location.pathname === item.path ||
                               location.pathname.startsWith(item.path + '/');
              return (
                <SheetCell
                  key={item.path}
                  item={item}
                  Icon={Icon}
                  isActive={isActive}
                  index={idx}
                  onPress={() => handleNav(item.path)}
                />
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
};

/* ── Grid cell ────────────────────────────────────────────────── */
const SheetCell: React.FC<{
  item:     SheetItem;
  Icon:     React.ComponentType<{ size?: number; className?: string }>;
  isActive: boolean;
  index:    number;
  onPress:  () => void;
}> = ({ item, Icon, isActive, index, onPress }) => {
  const [pressed, setPressed] = useState(false);

  return (
    <button
      onClick={onPress}
      onPointerDown={() => setPressed(true)}
      onPointerUp={() => setPressed(false)}
      onPointerLeave={() => setPressed(false)}
      onPointerCancel={() => setPressed(false)}
      style={{
        display:                 'flex',
        flexDirection:           'column',
        alignItems:              'center',
        gap:                     9,
        padding:                 '14px 8px 12px',
        borderRadius:            18,
        background:              isActive
          ? 'linear-gradient(135deg,rgba(37,99,235,0.08),rgba(79,70,229,0.06))'
          : 'var(--surface-secondary)',
        border:                  `1.5px solid ${isActive ? 'rgba(37,99,235,0.2)' : 'rgba(226,232,240,0.9)'}`,
        boxShadow:               isActive
          ? '0 2px 10px rgba(37,99,235,0.10)'
          : '0 1px 2px rgba(0,0,0,0.03)',
        cursor:                  'pointer',
        outline:                 'none',
        WebkitTapHighlightColor: 'transparent',
        touchAction:             'manipulation',
        minHeight:               'unset',
        position:                'relative',
        transform:               pressed ? 'scale(0.90)' : 'scale(1)',
        transition:              'transform 0.12s cubic-bezier(0.34,1.56,0.64,1), background 0.15s, border-color 0.15s',
        /* Stagger animation via delay */
        animation:               `fadeUp 0.3s cubic-bezier(0.22,1,0.36,1) ${index * 0.030}s both`,
      } as React.CSSProperties}
    >
      {/* Active dot */}
      {isActive && (
        <div style={{
          position:     'absolute',
          top:          8,
          left:         8,
          width:        6,
          height:       6,
          borderRadius: '50%',
          background:   '#2563eb',
        }} />
      )}

      {/* Icon box */}
      <div style={{
        width:          50,
        height:         50,
        borderRadius:   15,
        background:     item.grad,
        display:        'flex',
        alignItems:     'center',
        justifyContent: 'center',
        boxShadow:      `0 4px 14px rgba(0,0,0,0.18)`,
        transform:      pressed ? 'scale(0.93)' : 'scale(1)',
        transition:     'transform 0.12s ease',
        flexShrink:     0,
      }}>
        <Icon size={23} className="text-white" />
      </div>

      {/* Label */}
      <p style={{
        margin:     0,
        fontSize:   11,
        fontWeight: 700,
        lineHeight: 1.3,
        textAlign:  'center',
        color:      isActive ? '#1d4ed8' : '#334155',
      }}>
        {item.label}
      </p>
    </button>
  );
};
