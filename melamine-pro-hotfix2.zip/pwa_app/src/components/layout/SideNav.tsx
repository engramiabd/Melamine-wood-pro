import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, LogOut } from 'lucide-react';
import { useAuth }     from '../../contexts/AuthContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import {
  DashboardIcon, OrderIcon, ProductionLineIcon, InventoryIcon,
  JournalIcon, WalletIcon, AttendanceIcon, HRIcon, AdminShieldIcon,
  GearIcon, CostCalcIcon, SalesChartIcon, FinanceIcon, DemoModeIcon,
  CustomerIcon, InvoiceIcon, ProductIcon,
} from '../ui/AppIcon';

interface NavItemDef {
  path:   string;
  label:  string;
  icon:   React.ComponentType<{ size?: number; className?: string }>;
  roles?: string[];
}

interface Section {
  title:  string;
  items:  NavItemDef[];
  roles?: string[];
}

const SECTIONS: Section[] = [
  {
    title: 'الرئيسية',
    items: [
      { path: '/', label: 'لوحة التحكم', icon: DashboardIcon },
    ],
  },
  {
    title: 'الإنتاج',
    items: [
      { path: '/orders',           label: 'الطلبات',       icon: OrderIcon,          roles: ['admin','manager','production_supervisor','accountant'] },
      { path: '/customers',        label: 'العملاء',       icon: CustomerIcon,       roles: ['admin','manager','production_supervisor','accountant'] },
      { path: '/production-lines', label: 'خطوط الإنتاج',  icon: ProductionLineIcon, roles: ['admin','manager','production_supervisor','worker'] },
      { path: '/inventory',        label: 'المخزون',        icon: InventoryIcon,      roles: ['admin','manager','production_supervisor'] },
      { path: '/products',         label: 'المنتجات',       icon: ProductIcon,        roles: ['admin','manager'] },
    ],
  },
  {
    title: 'المالية',
    items: [
      { path: '/journal',  label: 'السجل المحاسبي',  icon: JournalIcon,   roles: ['admin','manager','accountant'] },
      { path: '/invoices', label: 'الفواتير',          icon: InvoiceIcon,   roles: ['admin','manager','accountant'] },
      { path: '/wallet',   label: 'المحفظة',          icon: WalletIcon,    roles: ['admin','manager','production_supervisor','worker','accountant'] },
      { path: '/finance',  label: 'الإدارة المالية',  icon: FinanceIcon,   roles: ['admin','manager','accountant'] },
      { path: '/sales',    label: 'المبيعات',          icon: SalesChartIcon,roles: ['admin','manager','accountant'] },
      { path: '/costs',    label: 'حاسبة التكاليف',   icon: CostCalcIcon,  roles: ['admin','manager','accountant'] },
    ],
  },
  {
    title: 'الموارد البشرية',
    items: [
      { path: '/attendance',          label: 'الحضور',         icon: AttendanceIcon, roles: ['admin','manager','production_supervisor','worker'] },
      { path: '/attendance/dashboard',label: 'لوحة الحضور',    icon: AttendanceIcon, roles: ['admin','manager','production_supervisor'] },
      { path: '/hr/employees',        label: 'الموظفون',        icon: HRIcon,         roles: ['admin','manager','hr'] },
      { path: '/hr/leaves',           label: 'الإجازات',        icon: HRIcon,         roles: ['admin','manager','hr'] },
      { path: '/hr/payroll',          label: 'الرواتب',         icon: HRIcon,         roles: ['admin','manager','accountant','hr'] },
    ],
  },
  {
    title: 'النظام',
    items: [
      { path: '/admin',         label: 'لوحة الإدارة',   icon: AdminShieldIcon, roles: ['admin'] },
      { path: '/reports',       label: 'التقارير',        icon: SalesChartIcon,  roles: ['admin','manager','accountant'] },
      { path: '/notifications', label: 'الإشعارات',       icon: DemoModeIcon   },
      { path: '/profile',       label: 'الملف الشخصي',   icon: HRIcon         },
      { path: '/demo',          label: 'الوضع التجريبي',  icon: DemoModeIcon   },
      { path: '/settings',      label: 'الإعدادات',       icon: GearIcon       },
    ],
  },
];

/* ── Logo ───────────────────────────────────────────────────────────────── */
const Logo: React.FC = () => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '18px 16px 14px', borderBottom: '1px solid var(--g100)' }}>
    <svg width="34" height="34" viewBox="0 0 32 32" fill="none">
      <rect width="32" height="32" rx="9" fill="url(#sn-g)" />
      <defs>
        <linearGradient id="sn-g" x1="0" y1="0" x2="32" y2="32">
          <stop stopColor="#2563eb" />
          <stop offset="1" stopColor="#7c3aed" />
        </linearGradient>
      </defs>
      <rect x="5"  y="16" width="22" height="11" rx="1" fill="white" fillOpacity="0.2" />
      <rect x="8"  y="13" width="5"  height="14" rx="1" fill="white" fillOpacity="0.3" />
      <rect x="14" y="11" width="5"  height="16" rx="1" fill="white" fillOpacity="0.3" />
      <rect x="20" y="14" width="4"  height="13" rx="1" fill="white" fillOpacity="0.3" />
      <rect x="9"  y="8"  width="2"  height="6"  rx="1" fill="white" fillOpacity="0.8" />
      <rect x="15" y="6"  width="2"  height="6"  rx="1" fill="white" fillOpacity="0.8" />
      <rect x="21" y="9"  width="2"  height="5"  rx="1" fill="white" fillOpacity="0.8" />
      <circle cx="26" cy="6" r="3"   fill="#10b981" />
      <circle cx="26" cy="6" r="1.5" fill="white" />
    </svg>
    <div>
      <p style={{ margin: 0, fontSize: 14, fontWeight: 900, color: 'var(--g800)', lineHeight: 1 }}>ميلامين برو</p>
      <p style={{ margin: '3px 0 0', fontSize: 10, color: 'var(--g400)', lineHeight: 1 }}>إدارة المصنع</p>
    </div>
  </div>
);

/* ── Nav item ───────────────────────────────────────────────────────────── */
const SideNavItem: React.FC<{ item: NavItemDef }> = ({ item }) => {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.path}
      end={item.path === '/'}
      style={({ isActive }) => ({
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '9px 12px',
        borderRadius: 10,
        marginBottom: 2,
        textDecoration: 'none',
        fontSize: 13,
        fontWeight: isActive ? 700 : 500,
        color: isActive ? 'var(--brand)' : 'var(--g600)',
        background: isActive ? 'rgba(37,99,235,0.08)' : 'transparent',
        transition: 'all 0.15s',
        position: 'relative',
      })}
    >
      {({ isActive }) => (
        <>
          {isActive && (
            <motion.div
              layoutId="sidenav-active"
              style={{
                position: 'absolute',
                right: 0, top: 4, bottom: 4,
                width: 3,
                background: 'var(--brand)',
                borderRadius: '3px 0 0 3px',
              }}
              transition={{ type: 'spring', stiffness: 500, damping: 35 }}
            />
          )}
          <div style={{
            width: 28, height: 28,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            borderRadius: 7,
            background: isActive ? 'rgba(37,99,235,0.12)' : 'var(--g100)',
            flexShrink: 0,
            transition: 'all 0.15s',
          }}>
            <Icon
              size={15}
              className={isActive ? 'text-blue-600' : 'text-slate-500'}
            />
          </div>
          <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {item.label}
          </span>
        </>
      )}
    </NavLink>
  );
};

/* ── Section ────────────────────────────────────────────────────────────── */
const SideNavSection: React.FC<{ section: Section; userRole: string }> = ({ section, userRole }) => {
  const [open, setOpen] = useState(true);

  const visible = section.items.filter(i => !i.roles || i.roles.includes(userRole));
  if (visible.length === 0) return null;

  return (
    <div style={{ marginBottom: 4 }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          width: '100%', padding: '6px 12px 4px',
          fontSize: 10, fontWeight: 800, color: 'var(--g400)',
          letterSpacing: '0.08em', textTransform: 'uppercase',
          background: 'none', border: 'none', cursor: 'pointer',
          textAlign: 'right',
        }}
      >
        {section.title}
        <motion.div
          animate={{ rotate: open ? 0 : -90 }}
          transition={{ duration: 0.2 }}
        >
          <ChevronDown size={11} />
        </motion.div>
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            style={{ overflow: 'hidden', paddingInline: 4 }}
          >
            {visible.map(item => (
              <SideNavItem key={item.path} item={item} />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

/* ── Main component ─────────────────────────────────────────────────────── */
export const SideNav: React.FC = () => {
  const { user, logout } = useAuth();
  const { currency, setCurrency } = useCurrency();
  const navigate = useNavigate();

  const ROLE_LABELS: Record<string, string> = {
    admin: 'مدير النظام', manager: 'مدير', production_supervisor: 'مشرف إنتاج',
    worker: 'عامل', accountant: 'محاسب', hr: 'موارد بشرية',
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      background: 'var(--surface)',
      borderInlineStart: '1px solid var(--g100)',
    }}>
      {/* Logo */}
      <Logo />

      {/* Navigation */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 8px 0', scrollbarWidth: 'none' }}>
        {SECTIONS.map(section => (
          <SideNavSection
            key={section.title}
            section={section}
            userRole={user?.role ?? ''}
          />
        ))}
      </div>

      {/* Footer */}
      <div style={{ borderTop: '1px solid var(--g100)', padding: '12px 12px 16px' }}>
        {/* Currency toggle */}
        <div style={{ marginBottom: 12 }}>
          <p style={{ margin: '0 0 6px', fontSize: 10, fontWeight: 700, color: 'var(--g400)', letterSpacing: '0.06em' }}>
            العملة
          </p>
          <div className="currency-toggle" style={{ width: '100%' }}>
            <button
              className={`currency-btn ${currency === 'USD' ? 'active-usd' : ''}`}
              onClick={() => setCurrency('USD')}
              style={{ flex: 1, justifyContent: 'center' }}
            >
              <span>$</span>
              <span>دولار</span>
            </button>
            <button
              className={`currency-btn ${currency === 'SYP' ? 'active-syp' : ''}`}
              onClick={() => setCurrency('SYP')}
              style={{ flex: 1, justifyContent: 'center' }}
            >
              <span>ل.س</span>
              <span>ليرة</span>
            </button>
          </div>
        </div>

        {/* User card */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '10px 12px',
          background: 'var(--g50)',
          borderRadius: 12,
          border: '1px solid var(--g100)',
        }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10, flexShrink: 0,
            background: 'linear-gradient(135deg, #2563eb, #7c3aed)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff', fontWeight: 900, fontSize: 14,
          }}>
            {user?.full_name?.charAt(0) ?? 'م'}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ margin: 0, fontSize: 12, fontWeight: 700, color: 'var(--g800)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {user?.full_name}
            </p>
            <p style={{ margin: '2px 0 0', fontSize: 10, color: 'var(--g500)' }}>
              {ROLE_LABELS[user?.role ?? ''] ?? user?.role}
            </p>
          </div>
          <button
            onClick={() => navigate('/settings')}
            style={{
              width: 28, height: 28, borderRadius: 8,
              background: 'none', border: '1px solid var(--g200)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', color: 'var(--g500)',
              flexShrink: 0,
            }}
            title="الإعدادات"
          >
            <GearIcon size={13} />
          </button>
          <button
            onClick={logout}
            style={{
              width: 28, height: 28, borderRadius: 8,
              background: 'none', border: '1px solid #fecaca',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', color: '#ef4444',
              flexShrink: 0,
            }}
            title="تسجيل الخروج"
          >
            <LogOut size={13} />
          </button>
        </div>
      </div>
    </div>
  );
};
