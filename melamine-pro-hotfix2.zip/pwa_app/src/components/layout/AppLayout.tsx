import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { TopBar }    from './TopBar';
import { BottomNav } from './BottomNav';
import { SideNav }   from './SideNav';
import { useIsDesktop } from '../../hooks/useMediaQuery';
import { AlertTriangle } from 'lucide-react';
import { ErrorBoundary } from '../ui/ErrorBoundary';

const TOPBAR_H    = 56;
const BOTTOMNAV_H = 64;

/* Read CSS env(safe-area-inset-bottom) after fonts/layout are ready */
function getSAB(): number {
  try {
    const raw = getComputedStyle(document.documentElement)
      .getPropertyValue('--sab').trim();
    const n = parseFloat(raw);
    return isNaN(n) ? 0 : n;
  } catch {
    return 0;
  }
}

export const AppLayout: React.FC = () => {
  const location   = useLocation();
  const isDesktop  = useIsDesktop();
  const contentRef = useRef<HTMLDivElement>(null);
  const topbarRef  = useRef<HTMLDivElement>(null);

  /* ── Safe area bottom ─────────────────────────────────── */
  const [sab, setSab] = useState(0);
  useEffect(() => {
    const read = () => setSab(getSAB());
    read();
    const t = setTimeout(read, 300);
    window.addEventListener('orientationchange', read);
    window.addEventListener('resize', read);
    return () => {
      clearTimeout(t);
      window.removeEventListener('orientationchange', read);
      window.removeEventListener('resize', read);
    };
  }, []);

  /* ── TopBar hide/show via direct DOM manipulation ────────
   *
   * We use REFS (not setState) for topbar visibility to avoid
   * React re-renders during scroll — re-renders cause jank.
   *
   * applyTopbarState() writes directly to:
   *   topbarRef.current.style.transform
   *   contentRef.current.style.top
   *
   * This bypasses React's reconciliation entirely, giving us
   * silky-smooth topbar hide/show without any scroll jank.
   *
   * On desktop: topbar is always visible (no hide/show).
   ──────────────────────────────────────────────────────── */
  const topbarHidden = useRef(false);
  const lastScrollY  = useRef(0);
  const rafId        = useRef<number>(0);

  const applyTopbarState = useCallback((hidden: boolean) => {
    const tb = topbarRef.current;
    const ct = contentRef.current;
    if (!tb || !ct) return;
    tb.style.transform = hidden ? `translateY(-${TOPBAR_H}px)` : 'translateY(0px)';
    ct.style.top       = hidden ? '0px' : `${TOPBAR_H}px`;
  }, []);

  const handleScroll = useCallback(() => {
    if (isDesktop) return;
    if (rafId.current) return;

    rafId.current = requestAnimationFrame(() => {
      rafId.current = 0;
      const el = contentRef.current;
      if (!el) return;

      const y     = el.scrollTop;
      const delta = y - lastScrollY.current;
      lastScrollY.current = y;

      if (delta > 8 && y > 60 && !topbarHidden.current) {
        topbarHidden.current = true;
        applyTopbarState(true);
      } else if (delta < -6 && topbarHidden.current) {
        topbarHidden.current = false;
        applyTopbarState(false);
      }
    });
  }, [isDesktop, applyTopbarState]);

  useEffect(() => {
    const el = contentRef.current;
    if (!el) return;
    el.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      el.removeEventListener('scroll', handleScroll);
      if (rafId.current) cancelAnimationFrame(rafId.current);
    };
  }, [handleScroll]);

  /* Reset scroll + show topbar on route change */
  useEffect(() => {
    const el = contentRef.current;
    if (el) el.scrollTop = 0;
    lastScrollY.current = 0;
    if (topbarHidden.current) {
      topbarHidden.current = false;
      applyTopbarState(false);
    }
  }, [location.pathname, applyTopbarState]);

  /* Set initial positions */
  useEffect(() => {
    applyTopbarState(false);
  }, [applyTopbarState]);

  /* ── Online status ──────────────────────────────────────── */
  const [isOnline, setIsOnline] = useState(() => navigator.onLine);
  useEffect(() => {
    const on  = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online',  on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online',  on);
      window.removeEventListener('offline', off);
    };
  }, []);

  /* ── Geometry ───────────────────────────────────────────── */
  const mainBottom = isDesktop ? 0 : sab;

  return (
    <div className="app-shell" dir="rtl">

      {/* ── TopBar wrapper ──────────────────────────────────────
          The WRAPPER has no background — only the inner div does.
          This way translateY(-56px) hides EVERYTHING including
          the background. If background was on .topbar CSS class,
          it would remain visible even after translateY.
          
          NO will-change here — creates compositing conflict.
      ─────────────────────────────────────────────────────── */}
      <div
        ref={topbarRef}
        className="topbar"
        style={{
          transform:  'translateY(0px)',
          transition: isDesktop ? 'none' : 'transform 0.28s cubic-bezier(0.22,1,0.36,1)',
          pointerEvents: 'auto',
        }}
      >
        <div style={{
          height:               TOPBAR_H,
          background:           'var(--glass-bg)',
          backdropFilter:       'blur(20px) saturate(180%)',
          WebkitBackdropFilter: 'blur(20px) saturate(180%)',
          borderBottom:         '1px solid var(--border-color, rgba(0,0,0,0.06))',
          boxShadow:            '0 1px 12px rgba(0,0,0,0.05)',
          display:              'flex',
          alignItems:           'center',
          width:                '100%',
        }}>
          <TopBar />
        </div>
      </div>

      {/* ── SideNav (desktop only) ──────────────────────────── */}
      {isDesktop && (
        <div className="sidenav">
          <SideNav />
        </div>
      )}

      {/* ── Main content ────────────────────────────────────────
          THE ONLY scroll container in the entire app.
          top/bottom set by direct DOM ref (applyTopbarState).
          
          CRITICAL: No CSS transition on top/bottom during scroll.
          No will-change. No -webkit-overflow-scrolling.
      ─────────────────────────────────────────────────────── */}
      <main
        ref={contentRef}
        id="main-content"
        className="main-content"
        aria-label="المحتوى الرئيسي"
        style={{
          top:    TOPBAR_H,
          bottom: mainBottom,
          contain: 'layout',
        }}
      >
        {/* Offline banner */}
        <AnimatePresence initial={false}>
          {!isOnline && (
            <motion.div
              key="offline-banner"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 36, opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.22, ease: 'easeInOut' }}
              style={{ overflow: 'hidden', flexShrink: 0 }}
            >
              <div style={{
                height:         36,
                background:     'linear-gradient(90deg,#f59e0b,#d97706)',
                color:          '#fff',
                display:        'flex',
                alignItems:     'center',
                justifyContent: 'center',
                gap:            8,
                fontSize:       12,
                fontWeight:     700,
              }}>
                <span style={{
                  width: 6, height: 6, borderRadius: '50%',
                  background: '#fff', display: 'inline-block',
                  animation: 'pulse 1.6s ease-in-out infinite',
                }} />
                لا يوجد اتصال بالإنترنت
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Page content with native-style transition */}
        <AnimatePresence mode="sync" initial={false}>
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15, ease: 'easeOut' }}
            style={{ minHeight: '100%', willChange: 'opacity' }}
          >
            <ErrorBoundary
              key={location.pathname}
              fallback={
                <div dir="rtl" style={{ padding: '48px 22px', textAlign: 'center' }}>
                  <div style={{
                    maxWidth: 380, margin: '0 auto', background: 'var(--surface)',
                    border: '1px solid var(--border-color)', borderRadius: 20, padding: 28,
                  }}>
                    <div style={{
                      width: 56, height: 56, borderRadius: 16, margin: '0 auto 14px',
                      background: 'rgba(239,68,68,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      <AlertTriangle size={26} style={{ color: '#ef4444' }} />
                    </div>
                    <h2 style={{ fontSize: 16, fontWeight: 800, color: 'var(--text-primary)', marginBottom: 6 }}>
                      تعذّر عرض هذه الصفحة
                    </h2>
                    <p style={{ fontSize: 13, color: 'var(--text-tertiary)', lineHeight: 1.7, marginBottom: 18 }}>
                      حدث خطأ غير متوقّع أثناء تحميل هذه الصفحة. يمكنك إعادة المحاولة أو التنقّل إلى صفحة أخرى من القائمة.
                    </p>
                    <button
                      onClick={() => window.location.reload()}
                      style={{
                        padding: '11px 22px', borderRadius: 12, border: 'none', cursor: 'pointer',
                        background: 'linear-gradient(135deg,#3b82f6,#6366f1)', color: '#fff', fontSize: 13, fontWeight: 700,
                      }}>
                      إعادة المحاولة
                    </button>
                  </div>
                </div>
              }
            >
              <Outlet />
            </ErrorBoundary>
          </motion.div>
        </AnimatePresence>

        {/* Bottom spacer — last card never hidden under BottomNav */}
        {!isDesktop && (
          <div
            aria-hidden="true"
            style={{
              height:        BOTTOMNAV_H + sab + 24,
              flexShrink:    0,
              pointerEvents: 'none',
            }}
          />
        )}
      </main>

      {/* ── BottomNav — fixed, never animated ───────────────── */}
      {!isDesktop && (
        <nav className="bottomnav" aria-label="التنقل الرئيسي">
          <BottomNav />
        </nav>
      )}
    </div>
  );
};
