import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { UserRole } from '../../types';

interface ProtectedRouteProps {
  allowedRoles?: UserRole[];
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ allowedRoles }) => {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  // Show loading indicator while restoring session
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="flex flex-col items-center gap-4">
          {/* Logo */}
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-xl">
            <svg width="32" height="32" viewBox="0 0 64 64" fill="none">
              <rect x="6"  y="34" width="52" height="24" rx="3" fill="white" fillOpacity="0.3"/>
              <rect x="12" y="26" width="12" height="32" rx="2" fill="white" fillOpacity="0.6"/>
              <rect x="26" y="22" width="12" height="36" rx="2" fill="white" fillOpacity="0.6"/>
              <rect x="40" y="28" width="10" height="30" rx="2" fill="white" fillOpacity="0.6"/>
              <rect x="14" y="12" width="5" height="16" rx="2" fill="white" fillOpacity="0.9"/>
              <rect x="28" y="8"  width="5" height="16" rx="2" fill="white" fillOpacity="0.9"/>
              <rect x="42" y="14" width="5" height="16" rx="2" fill="white" fillOpacity="0.9"/>
              <circle cx="16" cy="10" r="4" fill="#34d399"/>
              <circle cx="30" cy="6"  r="4" fill="#34d399"/>
              <circle cx="44" cy="12" r="4" fill="#fbbf24"/>
            </svg>
          </div>

          {/* Bouncing dots */}
          <div className="flex gap-1.5">
            {[0, 1, 2].map(i => (
              <div
                key={i}
                className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.15}s` }}
              />
            ))}
          </div>
          <p className="text-sm text-slate-500 font-medium">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  // Not authenticated → redirect to login, saving the intended path
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Authenticated but wrong role → redirect to unauthorized
  if (allowedRoles && allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  // All checks passed → render the child routes via Outlet
  return <Outlet />;
};
