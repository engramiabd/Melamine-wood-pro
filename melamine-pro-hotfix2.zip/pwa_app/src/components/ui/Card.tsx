import React from 'react';
import { clsx } from 'clsx';

/* ── Card ────────────────────────────────────────────────────────────────── */
interface CardProps {
  children:  React.ReactNode;
  className?: string;
  onClick?:   () => void;
  variant?:  'default' | 'elevated' | 'glass' | 'flat';
  padding?:  'none' | 'sm' | 'md' | 'lg';
  noBorder?: boolean;
}

const PADDING = {
  none: '',
  sm:   'p-3',
  md:   'p-4',
  lg:   'p-5',
};

export const Card: React.FC<CardProps> = ({
  children,
  className,
  onClick,
  variant = 'default',
  padding = 'none',
  noBorder = false,
}) => {
  const base = clsx(
    'rounded-2xl overflow-hidden',
    variant === 'default'  && ['bg-white', !noBorder && 'border border-slate-100', 'shadow-[0_1px_3px_rgba(15,23,42,0.07)]'],
    variant === 'elevated' && 'bg-white shadow-[0_4px_16px_rgba(15,23,42,0.09)]',
    variant === 'glass'    && 'bg-white/85 backdrop-blur-xl border border-white/60 shadow-[0_4px_16px_rgba(15,23,42,0.08)]',
    variant === 'flat'     && ['bg-slate-50', !noBorder && 'border border-slate-100'],
    PADDING[padding],
    onClick && 'cursor-pointer active:scale-[0.985] transition-transform',
    className,
  );

  if (onClick) {
    return (
      <div className={base} onClick={onClick} role="button" tabIndex={0}
        onKeyDown={e => e.key === 'Enter' && onClick()}>
        {children}
      </div>
    );
  }

  return <div className={base}>{children}</div>;
};

/* ── Card Sub-components ─────────────────────────────────────────────────── */
interface SubProps {
  children:   React.ReactNode;
  className?: string;
}

export const CardHeader: React.FC<SubProps> = ({ children, className }) => (
  <div className={clsx('px-4 py-3.5 border-b border-slate-100/80', className)}>
    {children}
  </div>
);

export const CardBody: React.FC<SubProps> = ({ children, className }) => (
  <div className={clsx('px-4 py-4', className)}>
    {children}
  </div>
);

export const CardFooter: React.FC<SubProps> = ({ children, className }) => (
  <div className={clsx('px-4 py-3 border-t border-slate-100/80 bg-slate-50/40', className)}>
    {children}
  </div>
);

/* ── Section Header ──────────────────────────────────────────────────────── */
interface SectionHeaderProps {
  title:        string;
  subtitle?:    string;
  icon?:        React.ReactNode;
  iconBg?:      string;
  action?:      React.ReactNode;
  className?:   string;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({
  title, subtitle, icon, iconBg = 'bg-blue-100', action, className,
}) => (
  <div className={clsx('flex items-center justify-between', className)}>
    <div className="flex items-center gap-2.5 min-w-0">
      {icon && (
        <div className={clsx('w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0', iconBg)}>
          {icon}
        </div>
      )}
      <div className="min-w-0">
        <h3 className="text-sm font-black text-slate-800 leading-tight truncate">{title}</h3>
        {subtitle && <p className="text-[11px] text-slate-400 mt-0.5 leading-none">{subtitle}</p>}
      </div>
    </div>
    {action && <div className="flex-shrink-0 mr-2">{action}</div>}
  </div>
);

/* ── Info Row ────────────────────────────────────────────────────────────── */
interface InfoRowProps {
  label:       string;
  value:       React.ReactNode;
  icon?:       React.ReactNode;
  className?:  string;
}

export const InfoRow: React.FC<InfoRowProps> = ({ label, value, icon, className }) => (
  <div className={clsx('flex items-center justify-between py-2.5 border-b border-slate-100 last:border-0', className)}>
    <div className="flex items-center gap-2 text-slate-500">
      {icon && <span className="flex-shrink-0">{icon}</span>}
      <span className="text-[13px]">{label}</span>
    </div>
    <span className="text-[13px] font-bold text-slate-800">{value}</span>
  </div>
);
