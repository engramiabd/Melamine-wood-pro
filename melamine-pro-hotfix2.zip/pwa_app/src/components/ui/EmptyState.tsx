import React from 'react';
import { motion } from 'framer-motion';
import { Inbox } from 'lucide-react';

interface EmptyStateProps {
  /** Lucide icon component (defaults to Inbox). */
  icon?: React.ComponentType<{ size?: number; style?: React.CSSProperties; className?: string }>;
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void };
  /** Optional compact mode for in-card empties. */
  compact?: boolean;
}

/**
 * Unified, theme-aware empty state used across the app.
 * Uses CSS variable tokens so it adapts to light/dark automatically.
 */
export const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon = Inbox,
  title,
  description,
  action,
  compact = false,
}) => (
  <motion.div
    initial={{ opacity: 0, y: 8 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
    dir="rtl"
    style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      padding: compact ? '28px 20px' : '48px 24px',
    }}
  >
    <div
      style={{
        width: compact ? 56 : 72,
        height: compact ? 56 : 72,
        borderRadius: compact ? 16 : 20,
        background: 'var(--surface-tertiary)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 16,
      }}
    >
      <Icon size={compact ? 26 : 32} style={{ color: 'var(--text-tertiary)' }} />
    </div>
    <h3 style={{ fontSize: compact ? 14 : 15, fontWeight: 800, color: 'var(--text-primary)', marginBottom: 6 }}>
      {title}
    </h3>
    {description && (
      <p
        style={{
          fontSize: 13,
          color: 'var(--text-tertiary)',
          lineHeight: 1.7,
          maxWidth: 300,
          marginBottom: action ? 18 : 0,
        }}
      >
        {description}
      </p>
    )}
    {action && (
      <motion.button
        whileTap={{ scale: 0.96 }}
        onClick={action.onClick}
        style={{
          padding: '10px 22px',
          borderRadius: 12,
          border: 'none',
          cursor: 'pointer',
          background: 'linear-gradient(135deg,#3b82f6,#6366f1)',
          color: '#fff',
          fontSize: 13,
          fontWeight: 700,
        }}
      >
        {action.label}
      </motion.button>
    )}
  </motion.div>
);

export default EmptyState;
