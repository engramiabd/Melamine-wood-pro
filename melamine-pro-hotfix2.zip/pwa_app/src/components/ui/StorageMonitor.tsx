/**
 * StorageMonitor — localStorage quota widget for the Admin panel.
 *
 * Shows a usage bar (green → amber → red) and a detailed breakdown
 * of the biggest app_* keys. Warns at 70%, alerts at 90%.
 */
import React, { useMemo, useState } from 'react';
import { HardDrive, ChevronDown, ChevronUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { getStorageUsage } from '../../contexts/appData.helpers';

const KEY_LABELS: Record<string, string> = {
  app_orders:           'الطلبات',
  app_inventory:        'المخزون',
  app_products:         'المنتجات',
  app_customers:        'العملاء',
  app_employees:        'الموظفون',
  app_audit:            'سجل التدقيق',
  app_journal:          'القيود المحاسبية',
  app_wallet_txs:       'معاملات المحفظة',
  app_wallets:          'المحافظ',
  app_batches:          'دفعات الإنتاج',
  app_invoice_payments: 'مدفوعات الفواتير',
  app_order_payments:   'مدفوعات الطلبات',
  app_invoices:         'الفواتير',
  app_lines:            'خطوط الإنتاج',
  app_suppliers:        'الموردون',
  app_purchase_orders:  'أوامر الشراء',
};

function label(key: string) {
  return KEY_LABELS[key] ?? key.replace('app_', '');
}

function barColor(pct: number) {
  if (pct >= 90) return '#ef4444'; // red
  if (pct >= 70) return '#f59e0b'; // amber
  return '#10b981';                 // green
}

export const StorageMonitor: React.FC = () => {
  const [expanded, setExpanded] = useState(false);
  const usage = useMemo(() => getStorageUsage(), [expanded]); // recalc on expand

  const color  = barColor(usage.percent);
  const isWarn = usage.percent >= 70;
  const isCrit = usage.percent >= 90;

  return (
    <div className="rounded-2xl border border-gray-100 bg-white dark:bg-gray-800 dark:border-gray-700 p-4 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: `${color}18` }}
          >
            {isCrit
              ? <AlertTriangle size={16} style={{ color }} />
              : isWarn
              ? <AlertTriangle size={16} style={{ color }} />
              : <HardDrive    size={16} style={{ color }} />}
          </div>
          <div>
            <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
              مساحة التخزين المحلي
            </p>
            <p className="text-xs text-gray-400">
              {usage.usedKB} KB من {usage.limitKB} KB
            </p>
          </div>
        </div>
        <button
          onClick={() => setExpanded(v => !v)}
          className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
          aria-label={expanded ? 'إخفاء التفاصيل' : 'عرض التفاصيل'}
        >
          {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
      </div>

      {/* Progress bar */}
      <div className="h-2 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${usage.percent}%`, background: color }}
        />
      </div>

      {/* Status message */}
      {isCrit && (
        <p className="text-xs text-red-600 dark:text-red-400 font-medium flex items-center gap-1.5">
          <AlertTriangle size={12} />
          التخزين ممتلئ بنسبة {Math.round(usage.percent)}٪ — يُنصح بتصدير البيانات الآن
        </p>
      )}
      {isWarn && !isCrit && (
        <p className="text-xs text-amber-600 dark:text-amber-400 font-medium flex items-center gap-1.5">
          <AlertTriangle size={12} />
          التخزين ممتلئ بنسبة {Math.round(usage.percent)}٪ — راقب النمو
        </p>
      )}
      {!isWarn && (
        <p className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
          <CheckCircle size={12} />
          {Math.round(usage.percent)}٪ مستخدم — الوضع طبيعي
        </p>
      )}

      {/* Breakdown */}
      {expanded && usage.breakdown.length > 0 && (
        <div className="pt-1 space-y-1.5 border-t border-gray-100 dark:border-gray-700">
          <p className="text-xs text-gray-400 pb-0.5">التفاصيل (أكبر المفاتيح):</p>
          {usage.breakdown.slice(0, 10).map(({ key, kb }) => (
            <div key={key} className="flex items-center justify-between gap-2">
              <span className="text-xs text-gray-600 dark:text-gray-300 truncate flex-1">
                {label(key)}
              </span>
              <div className="flex items-center gap-2 shrink-0">
                {/* Mini bar relative to biggest item */}
                <div className="w-16 h-1 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-blue-400"
                    style={{
                      width: `${Math.min(100, (kb / (usage.breakdown[0]?.kb || 1)) * 100)}%`
                    }}
                  />
                </div>
                <span className="text-xs text-gray-400 w-12 text-left">{kb} KB</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
