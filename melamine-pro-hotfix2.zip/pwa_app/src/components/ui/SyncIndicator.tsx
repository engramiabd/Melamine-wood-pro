import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Cloud, CloudOff, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { useAppData } from '../../contexts/AppDataContext';

/**
 * Small cloud icon in the top bar that mirrors the sync engine state. Tapping it
 * triggers a manual sync (or opens Settings when sync isn't configured yet).
 */
export const SyncIndicator: React.FC = () => {
  const { syncStatus, syncNow } = useAppData();
  const navigate = useNavigate();
  const { configured, online, syncing, pending, error } = syncStatus;

  let Icon = Cloud, color = 'var(--text-tertiary)', label = 'مزامنة', spin = false;
  if (!configured)      { Icon = CloudOff;   color = 'var(--text-tertiary)'; label = 'المزامنة غير مفعّلة'; }
  else if (!online)     { Icon = CloudOff;   color = '#d97706'; label = 'دون اتصال'; }
  else if (syncing)     { Icon = RefreshCw;  color = '#2563eb'; label = 'جارٍ المزامنة'; spin = true; }
  else if (error)       { Icon = CloudOff;   color = '#dc2626'; label = 'خطأ في المزامنة'; }
  else if (pending > 0) { Icon = Cloud;      color = '#d97706'; label = `${pending} بانتظار المزامنة`; }
  else                  { Icon = Cloud;      color = '#059669'; label = 'متزامن'; }

  const onClick = () => {
    if (!configured) { navigate('/settings'); return; }
    if (syncing || !online) return;
    void syncNow();
    toast.message('جارٍ المزامنة…');
  };

  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      style={{
        width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 12, border: 'none', background: 'transparent',
        cursor: syncing ? 'default' : 'pointer', flexShrink: 0, position: 'relative',
        touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent',
      } as React.CSSProperties}
    >
      <Icon size={18} color={color} className={spin ? 'animate-spin' : ''} />
      {configured && !syncing && (pending > 0 || error) && (
        <span style={{
          position: 'absolute', top: 7, left: 8, width: 7, height: 7, borderRadius: '50%',
          background: error ? '#dc2626' : '#d97706',
          border: '1.5px solid var(--glass-bg, #fff)',
        }} />
      )}
    </button>
  );
};

export default SyncIndicator;
