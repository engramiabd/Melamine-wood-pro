import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error:    Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;

      return (
        <div
          dir="rtl"
          style={{
            minHeight:      '100dvh',
            display:        'flex',
            flexDirection:  'column',
            alignItems:     'center',
            justifyContent: 'center',
            background:     'linear-gradient(135deg,#1e3a8a,#1d4ed8)',
            padding:        24,
            fontFamily:     "'IBM Plex Sans Arabic', system-ui, sans-serif",
          }}
        >
          {/* Icon */}
          <div style={{
            width: 80, height: 80, borderRadius: 24,
            background: 'rgba(255,255,255,0.15)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 24,
          }}>
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none"
              stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
              <line x1="12" y1="9" x2="12" y2="13"/>
              <line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
          </div>

          <h1 style={{
            color: '#fff', fontSize: 22, fontWeight: 900,
            margin: '0 0 8px', textAlign: 'center',
          }}>
            حدث خطأ غير متوقع
          </h1>

          <p style={{
            color: 'rgba(255,255,255,0.65)', fontSize: 14,
            margin: '0 0 8px', textAlign: 'center', maxWidth: 300,
          }}>
            واجه التطبيق مشكلة تقنية. يمكنك العودة للصفحة الرئيسية.
          </p>

          {this.state.error && (
            <details style={{ marginBottom: 24, maxWidth: 340, width: '100%' }}>
              <summary style={{
                color: 'rgba(255,255,255,0.5)', fontSize: 11,
                cursor: 'pointer', textAlign: 'center', userSelect: 'none',
              }}>
                تفاصيل الخطأ
              </summary>
              <pre style={{
                marginTop: 8, padding: 12, borderRadius: 12,
                background: 'rgba(0,0,0,0.3)', color: '#fca5a5',
                fontSize: 10, overflowX: 'auto', direction: 'ltr',
                fontFamily: 'monospace', whiteSpace: 'pre-wrap',
                wordBreak: 'break-all',
              }}>
                {this.state.error.message}
              </pre>
            </details>
          )}

          <button
            onClick={this.handleReset}
            style={{
              padding:      '13px 32px',
              borderRadius: 14,
              background: 'var(--surface)',
              color:        '#1d4ed8',
              fontWeight:   800,
              fontSize:     15,
              border:       'none',
              cursor:       'pointer',
              boxShadow:    '0 4px 20px rgba(0,0,0,0.2)',
              fontFamily:   'inherit',
            }}
          >
            العودة للرئيسية
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
