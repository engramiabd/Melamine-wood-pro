import React from 'react';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { clsx } from 'clsx';

interface PaginationProps {
  page: number;          // 1-indexed current page
  totalItems: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  className?: string;
}

export const Pagination: React.FC<PaginationProps> = ({ page, totalItems, pageSize, onPageChange, className }) => {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  if (totalPages <= 1) return null;

  const startItem = (page - 1) * pageSize + 1;
  const endItem = Math.min(page * pageSize, totalItems);

  // Build a compact page list: 1 ... p-1 p p+1 ... totalPages
  const pages: (number | 'ellipsis')[] = [];
  const add = (n: number) => { if (!pages.includes(n)) pages.push(n); };
  add(1);
  if (page > 3) pages.push('ellipsis');
  for (let p = Math.max(2, page - 1); p <= Math.min(totalPages - 1, page + 1); p++) add(p);
  if (page < totalPages - 2) pages.push('ellipsis');
  if (totalPages > 1) add(totalPages);

  return (
    <div className={clsx('flex flex-col items-center gap-2 py-4', className)} dir="rtl">
      <div className="flex items-center gap-1.5">
        <button
          onClick={() => onPageChange(Math.max(1, page - 1))}
          disabled={page === 1}
          aria-label="الصفحة السابقة"
          className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-500 disabled:opacity-30 hover:bg-slate-100 active:bg-slate-200 transition-colors"
        >
          <ChevronRight size={18} />
        </button>

        {pages.map((p, i) =>
          p === 'ellipsis' ? (
            <span key={`e${i}`} className="w-9 h-9 flex items-center justify-center text-slate-400 text-sm">⋯</span>
          ) : (
            <button
              key={p}
              onClick={() => onPageChange(p)}
              aria-current={p === page ? 'page' : undefined}
              className={clsx(
                'w-9 h-9 rounded-xl text-sm font-bold transition-colors',
                p === page ? 'bg-blue-600 text-white shadow-[0_2px_8px_rgba(37,99,235,0.35)]' : 'text-slate-600 hover:bg-slate-100 active:bg-slate-200'
              )}
            >
              {p}
            </button>
          )
        )}

        <button
          onClick={() => onPageChange(Math.min(totalPages, page + 1))}
          disabled={page === totalPages}
          aria-label="الصفحة التالية"
          className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-500 disabled:opacity-30 hover:bg-slate-100 active:bg-slate-200 transition-colors"
        >
          <ChevronLeft size={18} />
        </button>
      </div>
      <p className="text-[11px] text-slate-400">
        عرض {startItem}–{endItem} من أصل {totalItems}
      </p>
    </div>
  );
};

/** Hook: slice an array for the current page, clamping page to valid range. */
export function usePagination<T>(items: T[], pageSize: number, page: number) {
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const start = (safePage - 1) * pageSize;
  const pageItems = items.slice(start, start + pageSize);
  return { pageItems, totalPages, safePage };
}
