import React, { useId } from 'react';
import { motion } from 'framer-motion';

// ── Types ──────────────────────────────────────────────────────────────────────
export type SwitchSize  = 'sm' | 'md' | 'lg';
export type SwitchColor = 'blue' | 'green' | 'emerald' | 'violet' | 'amber' | 'red' | 'indigo' | 'teal' | 'rose';

// ── Color maps ─────────────────────────────────────────────────────────────────
const TRACK_ON: Record<SwitchColor, string> = {
  blue:    'hsl(217,91%,60%)',
  green:   'hsl(142,76%,45%)',
  emerald: 'hsl(160,84%,39%)',
  violet:  'hsl(258,90%,66%)',
  amber:   'hsl(38,92%,50%)',
  red:     'hsl(0,84%,60%)',
  indigo:  'hsl(239,84%,67%)',
  teal:    'hsl(174,84%,40%)',
  rose:    'hsl(330,81%,60%)',
};

const TRACK_GLOW: Record<SwitchColor, string> = {
  blue:    'rgba(59,130,246,0.30)',
  green:   'rgba(34,197,94,0.30)',
  emerald: 'rgba(16,185,129,0.30)',
  violet:  'rgba(139,92,246,0.30)',
  amber:   'rgba(245,158,11,0.30)',
  red:     'rgba(239,68,68,0.30)',
  indigo:  'rgba(99,102,241,0.30)',
  teal:    'rgba(20,184,166,0.30)',
  rose:    'rgba(244,63,94,0.30)',
};

// ── Size config ────────────────────────────────────────────────────────────────
const SIZES: Record<SwitchSize, {
  trackW: number; trackH: number;
  thumbSz: number; pad: number;
}> = {
  sm: { trackW: 38, trackH: 22, thumbSz: 16, pad: 3 },
  md: { trackW: 51, trackH: 31, thumbSz: 25, pad: 3 },
  lg: { trackW: 62, trackH: 37, thumbSz: 31, pad: 3 },
};

// ── Core Switch ────────────────────────────────────────────────────────────────
interface SwitchProps {
  checked:      boolean;
  onChange:     (checked: boolean) => void;
  size?:        SwitchSize;
  color?:       SwitchColor;
  disabled?:    boolean;
  label?:       string;
  description?: string;
  icon?:        React.ReactNode;
  iconBg?:      string;
  id?:          string;
  className?:   string;
}

export const Switch: React.FC<SwitchProps> = ({
  checked, onChange,
  size    = 'md',
  color   = 'blue',
  disabled = false,
  label, description, icon, iconBg,
  id: externalId,
  className = '',
}) => {
  const autoId  = useId();
  const switchId = externalId ?? autoId;
  const sz       = SIZES[size];

  // Thumb travel distance (track − thumb − both paddings)
  const travelX = sz.trackW - sz.thumbSz - sz.pad * 2;

  const vars = {
    '--sw-w':      `${sz.trackW}px`,
    '--sw-h':      `${sz.trackH}px`,
    '--sw-thumb':  `${sz.thumbSz}px`,
    '--sw-pad':    `${sz.pad}px`,
    '--sw-travel': `${travelX}px`,
    '--sw-on':     TRACK_ON[color],
    '--sw-glow':   TRACK_GLOW[color],
  } as React.CSSProperties;

  // Pure-CSS iOS switch: a checkbox drives the track + thumb via CSS only.
  const switchEl = (
    <label className={`ios-switch ${className}`} style={vars}>
      <input
        id={switchId}
        type="checkbox"
        role="switch"
        aria-checked={checked}
        checked={checked}
        disabled={disabled}
        onChange={(e) => {
          try { navigator.vibrate?.(8); } catch { /* noop */ }
          onChange(e.target.checked);
        }}
      />
      <span className="ios-track" />
      <span className="ios-thumb" />
    </label>
  );

  if (!label) return switchEl;

  return (
    <div className="flex items-center justify-between gap-3 w-full">
      <div className="flex items-center gap-3 min-w-0 flex-1">
        {icon && iconBg && (
          <div className={`icon-box-sm ${iconBg} shrink-0`} style={{ borderRadius: 10 }}>
            {icon}
          </div>
        )}
        <div className="min-w-0">
          <p className="text-sm font-semibold text-gray-800 leading-tight">{label}</p>
          {description && (
            <p className="text-xs text-gray-400 mt-0.5 leading-snug">{description}</p>
          )}
        </div>
      </div>
      {switchEl}
    </div>
  );
};

// ── SwitchRow — full settings row ─────────────────────────────────────────────
interface SwitchRowProps {
  checked:      boolean;
  onChange:     (v: boolean) => void;
  label:        string;
  description?: string;
  icon:         React.ReactNode;
  iconBg:       string;
  color?:       SwitchColor;
  disabled?:    boolean;
  last?:        boolean;
}

export const SwitchRow: React.FC<SwitchRowProps> = ({
  checked, onChange, label, description, icon, iconBg,
  color = 'blue', disabled, last,
}) => (
  <div
    className={`flex items-center justify-between px-4 bg-white transition-colors active:bg-gray-50/80 ${
      !last ? 'border-b border-gray-100/80' : ''
    }`}
    style={{ paddingTop: 13, paddingBottom: 13, minHeight: 60 }}
  >
    {/* Left: icon + text */}
    <div className="flex items-center gap-3 flex-1 min-w-0">
      <div className={`icon-box-sm ${iconBg} shrink-0`} style={{ borderRadius: 10 }}>
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-[14.5px] font-semibold text-gray-800 leading-tight truncate">{label}</p>
        {description && (
          <p className="text-[12px] text-gray-400 mt-0.5 leading-snug">{description}</p>
        )}
      </div>
    </div>

    {/* Right: switch */}
    <div className="mr-3 shrink-0">
      <Switch
        checked={checked}
        onChange={onChange}
        color={color}
        size="md"
        disabled={disabled}
      />
    </div>
  </div>
);

// ── ToggleGroup — segmented control ───────────────────────────────────────────
interface ToggleOption<T extends string> {
  value: T;
  label: string;
  icon?:  React.ReactNode;
}

export function ToggleGroup<T extends string>({
  value, onChange, options, className = '',
}: {
  value:     T;
  onChange:  (v: T) => void;
  options:   ToggleOption<T>[];
  className?: string;
}) {
  return (
    <div
      role="group"
      className={`flex rounded-2xl p-1 gap-1 ${className}`}
      style={{ background: 'hsl(220,14%,91%)' }}
    >
      {options.map(opt => {
        const active = opt.value === value;
        return (
          <motion.button
            key={opt.value}
            onClick={() => {
              try { navigator.vibrate?.(8); } catch {}
              onChange(opt.value);
            }}
            whileTap={{ scale: 0.96 }}
            className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2
              rounded-xl text-xs font-bold border-0 outline-none cursor-pointer
              transition-colors duration-150
              ${active ? 'text-blue-700' : 'bg-transparent text-gray-500'}`}
            style={active
              ? {
                  background: '#fff',
                  boxShadow: '0 1px 4px rgba(0,0,0,0.13), 0 0 0 0.5px rgba(0,0,0,0.06)',
                  minHeight: 36,
                }
              : { minHeight: 36 }
            }
          >
            {opt.icon}
            <span>{opt.label}</span>
          </motion.button>
        );
      })}
    </div>
  );
}

// ── Checkbox ───────────────────────────────────────────────────────────────────
interface CheckboxProps {
  checked:   boolean;
  onChange:  (v: boolean) => void;
  label?:    string;
  color?:    SwitchColor;
  size?:     'sm' | 'md';
  disabled?: boolean;
}

export const Checkbox: React.FC<CheckboxProps> = ({
  checked, onChange,
  label, color = 'blue',
  size = 'md', disabled,
}) => {
  const boxSz  = size === 'sm' ? 18 : 22;
  const iconSz = size === 'sm' ? 10 : 12;

  return (
    <label
      className={`flex items-center gap-2.5 cursor-pointer ${disabled ? 'opacity-40' : ''}`}
      style={{ WebkitUserSelect: 'none', userSelect: 'none' }}
    >
      <motion.button
        role="checkbox"
        aria-checked={checked}
        onClick={() => !disabled && onChange(!checked)}
        whileTap={disabled ? {} : { scale: 0.84 }}
        transition={{ type: 'spring', stiffness: 700, damping: 30 }}
        className="rounded-md flex items-center justify-center shrink-0 border-0 outline-none p-0 transition-all"
        style={{
          width:      boxSz,
          height:     boxSz,
          background: checked ? TRACK_ON[color]  : '#fff',
          boxShadow:  checked
            ? `0 0 0 2px ${TRACK_ON[color]}`
            : '0 0 0 2px hsl(220,14%,75%)',
          minHeight:  'unset',
          minWidth:   'unset',
        }}
      >
        {checked && (
          <motion.svg
            initial={{ scale: 0.3, opacity: 0 }}
            animate={{ scale: 1,   opacity: 1 }}
            transition={{ type: 'spring', stiffness: 700, damping: 22 }}
            viewBox="0 0 12 10"
            fill="none"
            style={{ width: iconSz, height: iconSz * 0.85 }}
          >
            <path
              d="M1 5l3 3.5L11 1"
              stroke="white"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </motion.svg>
        )}
      </motion.button>

      {label && (
        <span className="text-sm font-medium text-gray-700">{label}</span>
      )}
    </label>
  );
};

export default Switch;
