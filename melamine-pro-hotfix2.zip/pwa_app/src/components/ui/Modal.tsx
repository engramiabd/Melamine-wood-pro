import React, { useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';

/* ─── Portal Root ─────────────────────────────────────────────────────────── */
function getPortalRoot(): HTMLElement {
  let el = document.getElementById('modal-root');
  if (!el) {
    el = document.createElement('div');
    el.id = 'modal-root';
    el.setAttribute('dir', 'rtl');
    document.body.appendChild(el);
  }
  return el;
}

/* ─── Types ───────────────────────────────────────────────────────────────── */
export interface BottomSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  maxHeight?: string;
  disableBackdropClose?: boolean;
  disableSwipe?: boolean;
}

export interface CenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
  maxWidth?: string;
}

/* ─── BottomSheetModal ────────────────────────────────────────────────────── */
/*
 * Rendered via createPortal into #modal-root (child of document.body),
 * OUTSIDE .app-shell — so it is NEVER clipped by overflow:hidden,
 * and the footer/buttons are ALWAYS visible above the BottomNav.
 *
 * Swipe-down-to-close: touch/pointer events on the drag handle.
 */
export const BottomSheetModal: React.FC<BottomSheetModalProps> = ({
  isOpen,
  onClose,
  children,
  maxHeight = '88dvh',
  disableBackdropClose = false,
  disableSwipe = false,
}) => {
  const sheetRef   = useRef<HTMLDivElement>(null);
  const backdropRef = useRef<HTMLDivElement>(null);
  const startY     = useRef(0);
  const currentY   = useRef(0);
  const isDragging = useRef(false);
  const mounted    = useRef(false);

  /* ── mount / unmount animation ── */
  useEffect(() => {
    const sheet    = sheetRef.current;
    const backdrop = backdropRef.current;
    if (!sheet || !backdrop) return;

    if (isOpen) {
      mounted.current = true;
      // force initial state
      sheet.style.transition = 'none';
      sheet.style.transform   = 'translateY(100%)';
      backdrop.style.opacity  = '0';
      // animate in on next frame
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          sheet.style.transition    = 'transform 0.38s cubic-bezier(0.32,0.72,0,1)';
          sheet.style.transform     = 'translateY(0%)';
          backdrop.style.transition = 'opacity 0.28s ease';
          backdrop.style.opacity    = '1';
        });
      });
    } else if (mounted.current) {
      sheet.style.transition    = 'transform 0.32s cubic-bezier(0.32,0.72,0,1)';
      sheet.style.transform     = 'translateY(105%)';
      backdrop.style.transition = 'opacity 0.28s ease';
      backdrop.style.opacity    = '0';
    }
  }, [isOpen]);

  /* ── body scroll lock ── */
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  /* ── swipe-down-to-close on drag handle ── */
  const onPointerDown = useCallback((e: React.PointerEvent) => {
    if (disableSwipe) return;
    isDragging.current = true;
    startY.current     = e.clientY;
    currentY.current   = 0;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  }, [disableSwipe]);

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    if (!isDragging.current) return;
    const delta = e.clientY - startY.current;
    if (delta < 0) return; // don't allow swiping up
    currentY.current = delta;
    const sheet = sheetRef.current;
    if (sheet) {
      sheet.style.transition = 'none';
      sheet.style.transform  = `translateY(${delta}px)`;
      // fade backdrop
      const backdrop = backdropRef.current;
      if (backdrop) {
        const pct = Math.min(delta / 300, 1);
        backdrop.style.opacity = String(1 - pct * 0.7);
      }
    }
  }, []);

  const onPointerUp = useCallback(() => {
    if (!isDragging.current) return;
    isDragging.current = false;
    const sheet = sheetRef.current;
    if (!sheet) return;

    if (currentY.current > 100) {
      // close
      sheet.style.transition = 'transform 0.3s cubic-bezier(0.32,0.72,0,1)';
      sheet.style.transform  = 'translateY(105%)';
      const backdrop = backdropRef.current;
      if (backdrop) {
        backdrop.style.transition = 'opacity 0.25s ease';
        backdrop.style.opacity    = '0';
      }
      setTimeout(onClose, 300);
    } else {
      // snap back
      sheet.style.transition = 'transform 0.38s cubic-bezier(0.34,1.56,0.64,1)';
      sheet.style.transform  = 'translateY(0%)';
      const backdrop = backdropRef.current;
      if (backdrop) {
        backdrop.style.transition = 'opacity 0.2s ease';
        backdrop.style.opacity    = '1';
      }
    }
  }, [onClose]);

  if (!isOpen && !mounted.current) return null;

  return createPortal(
    <div
      style={{
        position:       'fixed',
        inset:          0,
        zIndex:         300,
        display:        'flex',
        alignItems:     'flex-end',
        justifyContent: 'center',
        pointerEvents:  isOpen ? 'auto' : 'none',
      }}
    >
      {/* Backdrop */}
      <div
        ref={backdropRef}
        onClick={disableBackdropClose ? undefined : onClose}
        style={{
          position:           'fixed',
          inset:              0,
          background:         'rgba(0,0,0,0.54)',
          backdropFilter:     'blur(4px)',
          WebkitBackdropFilter: 'blur(4px)',
          opacity:            0,
        }}
      />

      {/* Sheet */}
      <div
        ref={sheetRef}
        dir="rtl"
        style={{
          position:       'relative',
          width:          '100%',
          maxWidth:       540,
          maxHeight,
          background: 'var(--surface)',
          borderRadius:   '24px 24px 0 0',
          display:        'flex',
          flexDirection:  'column',
          overflow:       'hidden',
          boxShadow:      '0 -8px 48px rgba(0,0,0,0.22)',
          transform:      'translateY(100%)',
          willChange:     'transform',
          paddingBottom:  'env(safe-area-inset-bottom, 0px)',
        }}
      >
        {/* Drag Handle — touch/pointer events only on this strip */}
        <div
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
          style={{
            flexShrink:  0,
            padding:     '14px 0 6px',
            cursor:      disableSwipe ? 'default' : 'grab',
            touchAction: 'none',
            userSelect:  'none',
          }}
        >
          <div style={{
            width: 44, height: 5,
            background:   '#CBD5E1',
            borderRadius: 999,
            margin:       '0 auto',
          }} />
        </div>

        {/* Children */}
        {children}
      </div>
    </div>,
    getPortalRoot(),
  );
};

/* ─── CenterModal ─────────────────────────────────────────────────────────── */
export const CenterModal: React.FC<CenterModalProps> = ({
  isOpen,
  onClose,
  children,
  title,
  maxWidth = '420px',
}) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  if (!isOpen) return null;

  return createPortal(
    <div
      onClick={onClose}
      style={{
        position:           'fixed',
        inset:              0,
        zIndex:             300,
        background:         'rgba(0,0,0,0.54)',
        backdropFilter:     'blur(4px)',
        WebkitBackdropFilter: 'blur(4px)',
        display:            'flex',
        alignItems:         'center',
        justifyContent:     'center',
        padding:            '16px',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        dir="rtl"
        style={{
          width:        '100%',
          maxWidth,
          background: 'var(--surface)',
          borderRadius: 20,
          overflow:     'hidden',
          boxShadow:    '0 20px 60px rgba(0,0,0,0.24)',
          animation:    'scaleIn 0.22s cubic-bezier(0.34,1.56,0.64,1)',
        }}
      >
        {title && (
          <div style={{
            padding:        '16px 20px',
            borderBottom:   '1px solid #F1F5F9',
            display:        'flex',
            alignItems:     'center',
            justifyContent: 'space-between',
          }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: '#0F172A', margin: 0 }}>{title}</h3>
            <button onClick={onClose} style={{
              width: 32, height: 32, minHeight: 'unset',
              background: '#F8FAFC', border: 'none',
              borderRadius: '50%', display: 'flex',
              alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer',
            }}>
              <X size={16} color="#64748B" />
            </button>
          </div>
        )}
        {children}
      </div>
    </div>,
    getPortalRoot(),
  );
};

/* ─── Sub-components ──────────────────────────────────────────────────────── */

/** Fixed header — never scrolls, stays at top of sheet */
export const SheetHeader: React.FC<{
  children?: React.ReactNode;
  title?: string;
  onClose?: () => void;
  noPadding?: boolean;
  className?: string;
}> = ({ children, title, onClose, noPadding, className }) => (
  <div className={className} style={{ flexShrink: 0, position: 'relative', padding: noPadding ? 0 : '4px 16px 12px' }}>
    {(title || onClose) && (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: noPadding ? 0 : '4px 0 8px' }}>
        {title && <h3 style={{ fontSize: 16, fontWeight: 700, color: '#0F172A', margin: 0, flex: 1, textAlign: 'right' }}>{title}</h3>}
        {onClose && (
          <button
            onClick={onClose}
            style={{
              width: 30, height: 30, minHeight: 'unset',
              background: 'rgba(0,0,0,0.08)',
              border: 'none', borderRadius: '50%',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', flexShrink: 0, marginRight: title ? 8 : 0,
            }}
          >
            <X size={15} color="var(--text-secondary)" />
          </button>
        )}
      </div>
    )}
    {children}
  </div>
);

/** Scrollable body — takes all remaining space */
export const SheetBody: React.FC<{
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  noPadding?: boolean;
}> = ({ children, className, style, noPadding }) => (
  <div
    className={className}
    style={{
      flex:               1,
      overflowY:          'auto',
      overscrollBehavior: 'contain',
      touchAction:        'pan-y',
      WebkitOverflowScrolling: 'touch' as any,
      padding:            noPadding ? 0 : '0 16px',
      display:            'flex',
      flexDirection:      'column',
      gap:                12,
      ...style,
    }}
  >
    {children}
  </div>
);

/** Fixed footer — always visible above BottomNav */
export const SheetFooter: React.FC<{
  children: React.ReactNode;
  noBorder?: boolean;
}> = ({ children, noBorder }) => (
  <div
    style={{
      flexShrink:  0,
      padding:     '12px 16px 16px',
      borderTop:   noBorder ? 'none' : '1px solid #F1F5F9',
      background: 'var(--surface)',
    }}
  >
    {children}
  </div>
);

export default BottomSheetModal;
