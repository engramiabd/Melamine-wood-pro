import React from 'react';
import { clsx } from 'clsx';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?:   'primary' | 'secondary' | 'danger' | 'ghost' | 'outline' | 'success' | 'warning';
  size?:      'xs' | 'sm' | 'md' | 'lg' | 'xl';
  isLoading?: boolean;
  fullWidth?: boolean;
  leftIcon?:  React.ReactNode;
  rightIcon?: React.ReactNode;
  rounded?:   boolean;
}

const VARIANTS = {
  primary:   'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white shadow-[0_2px_8px_rgba(37,99,235,0.35)] disabled:bg-blue-300',
  secondary: 'bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 disabled:bg-slate-50 disabled:text-slate-400',
  danger:    'bg-red-600 hover:bg-red-700 active:bg-red-800 text-white shadow-[0_2px_8px_rgba(220,38,38,0.3)] disabled:bg-red-300',
  ghost:     'bg-transparent hover:bg-slate-100 active:bg-slate-200 text-slate-600 disabled:text-slate-300',
  outline:   'bg-white border-2 border-slate-200 hover:border-slate-300 hover:bg-slate-50 active:bg-slate-100 text-slate-700 disabled:border-slate-100 disabled:text-slate-400',
  success:   'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white shadow-[0_2px_8px_rgba(5,150,105,0.35)] disabled:bg-emerald-300',
  warning:   'bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-white shadow-[0_2px_8px_rgba(217,119,6,0.3)] disabled:bg-amber-300',
};

const SIZES = {
  xs: 'h-7  px-2.5 text-[11px] gap-1   rounded-lg',
  sm: 'h-8  px-3   text-xs     gap-1.5 rounded-xl',
  md: 'h-10 px-4   text-sm     gap-2   rounded-xl',
  lg: 'h-12 px-5   text-[15px] gap-2   rounded-2xl',
  xl: 'h-14 px-6   text-base   gap-2.5 rounded-2xl',
};

const Spinner: React.FC<{ size?: number }> = ({ size = 14 }) => (
  <svg
    className="animate-spin flex-shrink-0"
    width={size} height={size}
    viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2.5"
  >
    <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"
      strokeLinecap="round" strokeOpacity="0.3" />
    <path d="M12 2v4" strokeLinecap="round" />
  </svg>
);

export const Button: React.FC<ButtonProps> = ({
  variant   = 'primary',
  size      = 'md',
  isLoading = false,
  fullWidth = false,
  leftIcon,
  rightIcon,
  rounded   = false,
  children,
  className,
  disabled,
  ...props
}) => {
  const isDisabled = disabled || isLoading;

  return (
    <button
      disabled={isDisabled}
      className={clsx(
        'inline-flex items-center justify-center font-bold',
        'transition-all duration-150 active:scale-95',
        'touch-manipulation select-none',
        'disabled:opacity-60 disabled:cursor-not-allowed disabled:shadow-none disabled:scale-100',
        VARIANTS[variant],
        SIZES[size],
        fullWidth && 'w-full',
        rounded && '!rounded-full',
        className,
      )}
      {...props}
    >
      {isLoading ? (
        <>
          <Spinner size={size === 'xs' ? 12 : size === 'sm' ? 13 : 15} />
          {children && <span className="opacity-75">{children}</span>}
        </>
      ) : (
        <>
          {leftIcon && <span className="flex-shrink-0">{leftIcon}</span>}
          {children}
          {rightIcon && <span className="flex-shrink-0">{rightIcon}</span>}
        </>
      )}
    </button>
  );
};

/* ── Icon Button ─────────────────────────────────────────────────────────── */
interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  size?:    'sm' | 'md' | 'lg';
  variant?: 'ghost' | 'secondary' | 'danger' | 'primary';
  label?:   string;
}

const ICON_SIZES    = { sm: 'w-7 h-7 rounded-lg',  md: 'w-9 h-9 rounded-xl', lg: 'w-11 h-11 rounded-xl' };
const ICON_VARIANTS = {
  ghost:     'hover:bg-slate-100 active:bg-slate-200 text-slate-500',
  secondary: 'bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-600',
  danger:    'hover:bg-red-50 active:bg-red-100 text-red-500',
  primary:   'bg-blue-50 hover:bg-blue-100 active:bg-blue-200 text-blue-600',
};

export const IconButton: React.FC<IconButtonProps> = ({
  size    = 'md',
  variant = 'ghost',
  label,
  children,
  className,
  ...props
}) => (
  <button
    aria-label={label}
    className={clsx(
      'flex items-center justify-center flex-shrink-0',
      'transition-colors duration-150 touch-manipulation active:scale-90',
      ICON_SIZES[size],
      ICON_VARIANTS[variant],
      className,
    )}
    {...props}
  >
    {children}
  </button>
);
