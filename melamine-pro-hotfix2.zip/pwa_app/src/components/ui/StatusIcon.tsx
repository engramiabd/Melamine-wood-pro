import React from 'react';

// ─── Unified Professional Icon System ─────────────────────────────────────────
// All icons are SVG-based, consistent 24px viewBox, no emojis

interface IconProps {
  size?: number;
  className?: string;
  strokeWidth?: number;
}

// ── Finance & Money ───────────────────────────────────────────────────────────
export const MoneyBagIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M12 2C10.5 2 9.5 3 9.5 3L7 6h10l-2.5-3S13.5 2 12 2z" fill="currentColor" opacity="0.3"/>
    <path d="M7 6C4.5 7.5 3 10 3 13c0 4.4 4 8 9 8s9-3.6 9-8c0-3-1.5-5.5-4-7H7z" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M12 10v1m0 0c-1.5 0-2.5.8-2.5 2s1 2 2.5 2 2.5.8 2.5 2-1 2-2.5 2m0-8c1.5 0 2.5.8 2.5 2m-2.5 6v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

export const RevenueUpIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="3" fill="currentColor" opacity="0.1"/>
    <path d="M7 14l3.5-4 3 3 3.5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M14.5 8H17v2.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const ExpenseDownIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="3" fill="currentColor" opacity="0.1"/>
    <path d="M7 10l3.5 4 3-3 3.5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M14.5 16H17v-2.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const NetProfitIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M12 7v1m0 8v1m4-5c0 2.2-1.8 4-4 4s-4-1.8-4-4 1.8-4 4-4c1 0 2 .4 2.7 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M14 10l2-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

// ── Production & Factory ──────────────────────────────────────────────────────
export const ActiveLineIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="8" width="20" height="8" rx="2" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5"/>
    <circle cx="6" cy="12" r="2" fill="currentColor"/>
    <circle cx="12" cy="12" r="2" fill="currentColor" opacity="0.6"/>
    <circle cx="18" cy="12" r="2" fill="currentColor" opacity="0.3"/>
    <path d="M2 12h2m16 0h2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M8 12h2m4 0h2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

export const StoppedLineIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="8" width="20" height="8" rx="2" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <rect x="8" y="10" width="2" height="4" rx="1" fill="currentColor"/>
    <rect x="14" y="10" width="2" height="4" rx="1" fill="currentColor"/>
    <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity="0.3"/>
  </svg>
);

export const EfficiencyIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M12 3C7 3 3 7 3 12s4 9 9 9 9-4 9-9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M12 3c2.5 0 4.7 1 6.3 2.7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.4"/>
    <path d="M12 7v5l3 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="19" cy="6" r="2.5" fill="currentColor" opacity="0.2" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M18 6l1 1 1.5-1.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// ── HR & People ───────────────────────────────────────────────────────────────
export const PayrollIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="4" y="3" width="16" height="18" rx="2" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M8 8h8M8 12h8M8 16h5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    <circle cx="17" cy="16" r="3.5" fill="white" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M17 14.5v1.5l1 1" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const BonusIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6L12 2z" fill="currentColor" opacity="0.2" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
  </svg>
);

export const DeductionIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M8 12h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);

export const OvertimeIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M12 7v5l3.5 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M18 3l2 2-2 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M20 5h-3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

// ── Status & Alerts ───────────────────────────────────────────────────────────
export const SuccessIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.15"/>
    <path d="M7.5 12l3 3 6-6" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const WarningTriangleIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
    <path d="M12 9v4M12 17h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);

export const InfoCircleIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M12 11v6M12 8h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);

export const ErrorIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M15 9l-6 6M9 9l6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
  </svg>
);

// ── Results & Calculations ────────────────────────────────────────────────────
export const TotalCostIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="3" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M7 12h10M7 8h6M7 16h8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M16 15l1.5 1.5L20 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const BreakEvenIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M7 12h10M7 12l3-3m-3 3l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M17 12l-3-3m3 3l-3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// ── Inventory & Materials ─────────────────────────────────────────────────────
export const WoodIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="8" width="20" height="8" rx="2" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M6 8v8M10 8v8M14 8v8M18 8v8" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity="0.4"/>
    <path d="M2 12h20" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity="0.3"/>
  </svg>
);

export const ChemicalIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M9 3h6v5l4 6c1 2 0 4-2 5H7c-2-1-3-3-2-5l4-6V3z" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
    <path d="M9 3h6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    <circle cx="10" cy="15" r="1" fill="currentColor"/>
    <circle cx="14" cy="13" r="1" fill="currentColor"/>
    <circle cx="12" cy="17" r="1" fill="currentColor" opacity="0.5"/>
  </svg>
);

export const PackagingBoxIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M21 10V20a1 1 0 01-1 1H4a1 1 0 01-1-1V10" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M23 7H1l2 3h18l2-3z" fill="currentColor" opacity="0.2" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M9 21V11h6v10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

export const SparePartIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3-3a6 6 0 01-7.4 7.4l-6.3 6.3a2 2 0 01-2.8-2.8L10.5 10a6 6 0 017.4-7.4l-3 3z" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
  </svg>
);

// ── System & Admin ────────────────────────────────────────────────────────────
export const ServerIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="3" width="20" height="8" rx="2" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <rect x="2" y="13" width="20" height="8" rx="2" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <circle cx="7" cy="7" r="1.5" fill="currentColor"/>
    <circle cx="7" cy="17" r="1.5" fill="currentColor"/>
    <path d="M11 7h6M11 17h6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

export const DatabaseIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <ellipse cx="12" cy="6" rx="8" ry="3" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" stroke="currentColor" strokeWidth="1.5"/>
  </svg>
);

export const BackupIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-10 6 6 0 10-11.8 2.3A4 4 0 003 15z" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
    <path d="M12 11v6M9 14l3 3 3-3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const NotificationBellSolidIcon: React.FC<IconProps> = ({ size = 20, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M12 2a7 7 0 00-7 7v3l-2 2v1h18v-1l-2-2V9a7 7 0 00-7-7z" fill="currentColor" opacity="0.2" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
    <path d="M10 17c0 1.1.9 2 2 2s2-.9 2-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

// ── Compound Status Components ─────────────────────────────────────────────────
interface StatusBadgeProps {
  type: 'success' | 'warning' | 'error' | 'info';
  size?: number;
}

export const StatusBadgeIcon: React.FC<StatusBadgeProps> = ({ type, size = 16 }) => {
  const configs = {
    success: { Icon: SuccessIcon,        color: 'text-emerald-600' },
    warning: { Icon: WarningTriangleIcon, color: 'text-amber-600'  },
    error:   { Icon: ErrorIcon,           color: 'text-red-600'    },
    info:    { Icon: InfoCircleIcon,      color: 'text-blue-600'   },
  };
  const { Icon, color } = configs[type];
  return <Icon size={size} className={color} />;
};

// ── Category Icon Selector ─────────────────────────────────────────────────────
interface CategoryIconProps extends IconProps {
  category: string;
}

export const MaterialCategoryIcon: React.FC<CategoryIconProps> = ({ category, size = 18, className = '' }) => {
  switch (category) {
    case 'raw_material': return <WoodIcon size={size} className={className || 'text-blue-600'} />;
    case 'chemical':     return <ChemicalIcon size={size} className={className || 'text-purple-600'} />;
    case 'packaging':    return <PackagingBoxIcon size={size} className={className || 'text-emerald-600'} />;
    case 'spare_part':   return <SparePartIcon size={size} className={className || 'text-orange-600'} />;
    default:             return <InfoCircleIcon size={size} className={className || 'text-gray-500'} />;
  }
};

// ── Role Icon ──────────────────────────────────────────────────────────────────
export const RoleIconSVG: React.FC<{ role: string; size?: number; className?: string }> = ({ role, size = 20, className = '' }) => {
  switch (role) {
    case 'admin':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
          <path d="M12 2L3 7v5c0 5.25 3.75 10.15 9 11.35C17.25 22.15 21 17.25 21 12V7l-9-5z" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
          <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      );
    case 'manager':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
          <rect x="2" y="7" width="20" height="14" rx="2" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2" stroke="currentColor" strokeWidth="1.5"/>
          <circle cx="12" cy="14" r="2" fill="currentColor" opacity="0.3" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M9 21v-1a3 3 0 016 0v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      );
    case 'production_supervisor':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
          <path d="M2 20h20M4 20V8l8-5 8 5v12" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/>
          <rect x="9" y="12" width="6" height="8" rx="1" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5"/>
        </svg>
      );
    case 'worker':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
          <path d="M2 20h20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M12 3a3 3 0 100 6 3 3 0 000-6z" fill="currentColor" opacity="0.2" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M6 20v-2a6 6 0 0112 0v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M4 7h16v2H4z" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1"/>
        </svg>
      );
    case 'accountant':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
          <rect x="4" y="2" width="16" height="20" rx="2" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M8 7h8M8 11h8M8 15h5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M16 14l1.5 1.5L20 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      );
    case 'hr':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
          <circle cx="9" cy="7" r="3" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5"/>
          <circle cx="16" cy="8" r="2" fill="currentColor" opacity="0.1" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M3 20v-1a6 6 0 0112 0v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M16 14a4 4 0 015 0v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M18 10v4M16 12h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      );
    default:
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
          <circle cx="12" cy="8" r="4" fill="currentColor" opacity="0.15" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M4 20v-1a8 8 0 0116 0v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      );
  }
};
