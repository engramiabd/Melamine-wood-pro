import React from 'react';
import { LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  iconColor?: string;
  iconBg?: string;
  trend?: { value: number; label: string; positive?: boolean };
  onClick?: () => void;
  gradient?: string;
  badge?: { text: string; color: string };
}

export const StatsCard: React.FC<StatsCardProps> = ({
  title, value, subtitle, icon: Icon, iconColor = 'text-blue-600',
  iconBg = 'bg-blue-100', trend, onClick, gradient, badge,
}) => {
  if (gradient) {
    return (
      <motion.div
        whileTap={{ scale: 0.97 }}
        onClick={onClick}
        className={`${gradient} rounded-2xl p-4 text-white shadow-lg cursor-pointer select-none`}
      >
        <div className="flex items-center justify-between mb-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <Icon size={20} className="text-white" />
          </div>
          {badge && (
            <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-medium">
              {badge.text}
            </span>
          )}
        </div>
        <p className="text-white/80 text-xs mb-1">{title}</p>
        <p className="text-2xl font-black">{value}</p>
        {subtitle && <p className="text-white/70 text-xs mt-1">{subtitle}</p>}
        {trend && (
          <div className="flex items-center gap-1 mt-2">
            <span className="text-white/80 text-xs">
              {trend.value > 0 ? '↑' : '↓'} {Math.abs(trend.value)}% {trend.label}
            </span>
          </div>
        )}
      </motion.div>
    );
  }

  return (
    <motion.div
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className={`bg-white rounded-2xl p-4 shadow-sm border border-gray-100 ${onClick ? 'cursor-pointer active:shadow-md' : ''}`}
    >
      <div className="flex items-center justify-between mb-3">
        <div className={`w-10 h-10 ${iconBg} rounded-xl flex items-center justify-center`}>
          <Icon size={20} className={iconColor} />
        </div>
        {badge && (
          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${badge.color}`}>
            {badge.text}
          </span>
        )}
      </div>
      <p className="text-xs text-gray-500 mb-1">{title}</p>
      <p className="text-xl font-black text-gray-900 leading-tight">{value}</p>
      {subtitle && <p className="text-xs text-gray-500 mt-1">{subtitle}</p>}
      {trend && (
        <div className="flex items-center gap-1 mt-2">
          <span className={`text-xs font-medium flex items-center gap-0.5 ${trend.positive !== false ? 'text-emerald-600' : 'text-red-500'}`}>
            {trend.positive !== false ? '↑' : '↓'} {Math.abs(trend.value)}%
          </span>
          <span className="text-xs text-gray-400">{trend.label}</span>
        </div>
      )}
    </motion.div>
  );
};
