/**
 * AppIcon — Modern SVG icon system for Melamine Factory PWA
 * Replaces all emoji and generic icons with custom, professional SVG icons
 */
import React from 'react';
import { clsx } from 'clsx';

interface IconProps {
  size?: number;
  className?: string;
  strokeWidth?: number;
}

/* ── Factory / Production ─────────────────────────────────────────────────── */

export const FactoryIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="13" width="20" height="9" rx="1.5" stroke="currentColor" strokeWidth="1.8" />
    <path d="M2 13L7 9V13" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M7 13L12 9V13" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M12 13L17 9V13" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <rect x="17" y="9" width="5" height="4" rx="0.5" stroke="currentColor" strokeWidth="1.8" />
    <line x1="6" y1="16" x2="6" y2="19" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="10" y1="16" x2="10" y2="19" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="14" y1="16" x2="14" y2="19" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="18" y1="16" x2="18" y2="19" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M8 9V5M8 5L6 3M8 5L10 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M14 9V4M14 4L12 2M14 4L16 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const ProductionLineIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="1" y="10" width="22" height="4" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <circle cx="5" cy="12" r="1.5" fill="currentColor" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" />
    <circle cx="19" cy="12" r="1.5" fill="currentColor" />
    <rect x="3" y="6" width="5" height="3" rx="1" stroke="currentColor" strokeWidth="1.5" />
    <rect x="10" y="5" width="4" height="4" rx="1" stroke="currentColor" strokeWidth="1.5" />
    <rect x="16" y="6" width="5" height="3" rx="1" stroke="currentColor" strokeWidth="1.5" />
    <path d="M5 15v3M12 15v3M19 15v3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const MelamineBoard: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="6" width="20" height="12" rx="1.5" stroke="currentColor" strokeWidth="1.8" />
    <line x1="2" y1="9" x2="22" y2="9" stroke="currentColor" strokeWidth="1" strokeDasharray="2 2" />
    <line x1="2" y1="15" x2="22" y2="15" stroke="currentColor" strokeWidth="1" strokeDasharray="2 2" />
    <line x1="8" y1="6" x2="8" y2="18" stroke="currentColor" strokeWidth="1" strokeDasharray="2 2" />
    <line x1="16" y1="6" x2="16" y2="18" stroke="currentColor" strokeWidth="1" strokeDasharray="2 2" />
    <circle cx="5" cy="4" r="1" fill="currentColor" opacity="0.4" />
    <circle cx="12" cy="4" r="1" fill="currentColor" opacity="0.4" />
    <circle cx="19" cy="4" r="1" fill="currentColor" opacity="0.4" />
    <circle cx="5" cy="20" r="1" fill="currentColor" opacity="0.4" />
    <circle cx="12" cy="20" r="1" fill="currentColor" opacity="0.4" />
    <circle cx="19" cy="20" r="1" fill="currentColor" opacity="0.4" />
  </svg>
);

/* ── Orders / Sales ───────────────────────────────────────────────────────── */

export const OrderIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="2.5" stroke="currentColor" strokeWidth="1.8" />
    <line x1="7" y1="8" x2="17" y2="8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="7" y1="12" x2="15" y2="12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="7" y1="16" x2="12" y2="16" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <circle cx="18" cy="17" r="3.5" fill="currentColor" className="opacity-20" stroke="currentColor" strokeWidth="1.5" />
    <path d="M16.5 17l1 1 1.5-1.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const NewOrderIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="3" y="3" width="14" height="18" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <line x1="6" y1="8" x2="14" y2="8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="6" y1="11.5" x2="11" y2="11.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <circle cx="19" cy="19" r="4" fill="currentColor" className="opacity-15" stroke="currentColor" strokeWidth="1.8" />
    <line x1="19" y1="17" x2="19" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="17" y1="19" x2="21" y2="19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

/* ── Inventory / Materials ────────────────────────────────────────────────── */

export const InventoryIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="14" width="6" height="7" rx="1" stroke="currentColor" strokeWidth="1.8" />
    <rect x="9" y="11" width="6" height="10" rx="1" stroke="currentColor" strokeWidth="1.8" />
    <rect x="16" y="8" width="6" height="13" rx="1" stroke="currentColor" strokeWidth="1.8" />
    <path d="M2 14L5 8l3 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    <line x1="1" y1="21" x2="23" y2="21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const WarehouseIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M3 21V11L12 4L21 11V21" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <rect x="8" y="14" width="8" height="7" rx="0.5" stroke="currentColor" strokeWidth="1.8" />
    <line x1="12" y1="14" x2="12" y2="21" stroke="currentColor" strokeWidth="1.5" />
    <rect x="5" y="12" width="3.5" height="4" rx="0.5" stroke="currentColor" strokeWidth="1.5" />
    <rect x="15.5" y="12" width="3.5" height="4" rx="0.5" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

/* ── Finance / Money ──────────────────────────────────────────────────────── */

export const WalletIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="7" width="20" height="14" rx="2.5" stroke="currentColor" strokeWidth="1.8" />
    <path d="M2 11h20" stroke="currentColor" strokeWidth="1.5" />
    <path d="M2 8.5L6 5h12l4 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
    <rect x="14" y="14" width="5" height="3" rx="1.5" fill="currentColor" className="opacity-30" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

export const CashIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="1" y="6" width="22" height="13" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <circle cx="12" cy="12.5" r="3" stroke="currentColor" strokeWidth="1.8" />
    <circle cx="12" cy="12.5" r="1" fill="currentColor" />
    <rect x="4" y="9" width="2" height="7" rx="1" fill="currentColor" className="opacity-20" />
    <rect x="18" y="9" width="2" height="7" rx="1" fill="currentColor" className="opacity-20" />
  </svg>
);

export const RevenueIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M3 17L8 12L12 15L16 9L21 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M17 7h4v4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <line x1="3" y1="21" x2="21" y2="21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const ExchangeIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9.5" stroke="currentColor" strokeWidth="1.8" />
    <path d="M12 7v2.5M12 14.5V17" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M9.5 10.5h4a1 1 0 010 2H10a1 1 0 000 2h4.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

/* ── HR / People ──────────────────────────────────────────────────────────── */

export const WorkerIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="8" r="3.5" stroke="currentColor" strokeWidth="1.8" />
    <path d="M5 20c0-3.866 3.134-7 7-7s7 3.134 7 7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M9 5.5A3 3 0 0115 5.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <rect x="8" y="3" width="8" height="1.5" rx="0.75" fill="currentColor" className="opacity-30" />
  </svg>
);

export const TeamIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="9" cy="8" r="3" stroke="currentColor" strokeWidth="1.8" />
    <circle cx="17" cy="9" r="2.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="M2 19c0-3.314 3.134-6 7-6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M16 19c0-2.761 2.239-5 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M8 13c1.06-.636 2.277-1 3.5-1 1.223 0 2.44.364 3.5 1" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export const CustomerIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="8" r="3.2" stroke="currentColor" strokeWidth="1.8" />
    <path d="M5 20c0-3.866 3.134-7 7-7s7 3.134 7 7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <circle cx="18.5" cy="6.5" r="1.6" stroke="currentColor" strokeWidth="1.4" />
  </svg>
);

export const InvoiceIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M6 3h9l4 4v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M15 3v4h4" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <line x1="8" y1="11" x2="16" y2="11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="8" y1="14.5" x2="16" y2="14.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="8" y1="18" x2="12.5" y2="18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const ProductIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M21 8l-9-5-9 5 9 5 9-5z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M3 8v8l9 5 9-5V8" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <line x1="12" y1="13" x2="12" y2="21" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

export const HRIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="3" y="4" width="18" height="16" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <circle cx="9" cy="10" r="2.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="M5 18c0-2.21 1.79-4 4-4s4 1.79 4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="15" y1="9" x2="20" y2="9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="15" y1="13" x2="19" y2="13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="15" y1="17" x2="18" y2="17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const PayrollIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="5" width="20" height="14" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <path d="M2 9h20" stroke="currentColor" strokeWidth="1.5" />
    <circle cx="7" cy="14" r="1.5" fill="currentColor" className="opacity-40" />
    <line x1="10" y1="14" x2="18" y2="14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <circle cx="7" cy="17" r="1.5" fill="currentColor" className="opacity-40" />
    <line x1="10" y1="17" x2="16" y2="17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const LeaveIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="3" y="4" width="18" height="17" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <line x1="3" y1="9" x2="21" y2="9" stroke="currentColor" strokeWidth="1.5" />
    <line x1="8" y1="2" x2="8" y2="6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <line x1="16" y1="2" x2="16" y2="6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <path d="M9 14l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/* ── Attendance / Time ────────────────────────────────────────────────────── */

export const AttendanceIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.8" />
    <path d="M12 7v5l3.5 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="12" cy="12" r="1" fill="currentColor" />
    <path d="M6.5 20l1.5-2.5M17.5 20L16 17.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />
  </svg>
);

export const CheckInIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9.5" stroke="currentColor" strokeWidth="1.8" />
    <path d="M8 12l3 3 5-5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M3 12h2M19 12h2M12 3v2M12 19v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />
  </svg>
);

export const LocationPinIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M12 22C12 22 5 15.5 5 9.5C5 6.462 8.134 4 12 4C15.866 4 19 6.462 19 9.5C19 15.5 12 22 12 22Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <circle cx="12" cy="9.5" r="2.5" stroke="currentColor" strokeWidth="1.8" />
    <ellipse cx="12" cy="21" rx="3" ry="1" fill="currentColor" className="opacity-15" />
  </svg>
);

/* ── Dashboard / Analytics ────────────────────────────────────────────────── */

export const DashboardIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="2" y="2" width="9" height="9" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <rect x="13" y="2" width="9" height="9" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <rect x="2" y="13" width="9" height="9" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <rect x="13" y="13" width="9" height="9" rx="2" stroke="currentColor" strokeWidth="1.8" />
  </svg>
);

export const AnalyticsIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <polyline points="22,12 18,12 15,21 9,3 6,12 2,12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const KPIIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M3 20L8 14L12 17L17 10L21 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="21" cy="7" r="3" stroke="currentColor" strokeWidth="1.8" />
    <line x1="19.5" y1="7" x2="22.5" y2="7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="21" y1="5.5" x2="21" y2="8.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

/* ── Journal / Accounting ─────────────────────────────────────────────────── */

export const JournalIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="4" y="2" width="16" height="20" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <rect x="2" y="4" width="3" height="16" rx="1.5" fill="currentColor" className="opacity-20" stroke="currentColor" strokeWidth="1.5" />
    <line x1="8" y1="7" x2="17" y2="7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="8" y1="10.5" x2="17" y2="10.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="8" y1="14" x2="14" y2="14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="8" y1="17.5" x2="12" y2="17.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const LedgerIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.8" />
    <line x1="12" y1="3" x2="12" y2="21" stroke="currentColor" strokeWidth="1.5" />
    <line x1="3" y1="9" x2="21" y2="9" stroke="currentColor" strokeWidth="1" opacity="0.4" />
    <line x1="3" y1="15" x2="21" y2="15" stroke="currentColor" strokeWidth="1" opacity="0.4" />
    <line x1="6" y1="6" x2="9" y2="6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="15" y1="6" x2="18" y2="6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

/* ── Settings / Admin ─────────────────────────────────────────────────────── */

export const AdminShieldIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M12 2L4 5.5V11C4 16.15 7.5 20.75 12 22C16.5 20.75 20 16.15 20 11V5.5L12 2Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M8.5 12l2.5 2.5 4.5-4.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const GearIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.8" />
    <path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.93 4.93l1.77 1.77M17.3 17.3l1.77 1.77M4.93 19.07l1.77-1.77M17.3 6.7l1.77-1.77" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const CostCalcIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="3" y="3" width="18" height="18" rx="2.5" stroke="currentColor" strokeWidth="1.8" />
    <line x1="3" y1="9" x2="21" y2="9" stroke="currentColor" strokeWidth="1.5" />
    <line x1="3" y1="15" x2="21" y2="15" stroke="currentColor" strokeWidth="1.5" />
    <line x1="9" y1="9" x2="9" y2="21" stroke="currentColor" strokeWidth="1.5" />
    <line x1="15" y1="9" x2="15" y2="21" stroke="currentColor" strokeWidth="1.5" />
    <circle cx="6" cy="6" r="1.5" fill="currentColor" className="opacity-40" />
    <line x1="12" y1="5" x2="19" y2="5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <path d="M11 18l2-2-2-2M14 18l-2-2 2-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" opacity="0.6" />
  </svg>
);

export const SalesChartIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="4" y="14" width="3" height="6" rx="1" fill="currentColor" className="opacity-30" stroke="currentColor" strokeWidth="1.5" />
    <rect x="9" y="10" width="3" height="10" rx="1" fill="currentColor" className="opacity-50" stroke="currentColor" strokeWidth="1.5" />
    <rect x="14" y="6" width="3" height="14" rx="1" fill="currentColor" className="opacity-70" stroke="currentColor" strokeWidth="1.5" />
    <rect x="19" y="3" width="3" height="17" rx="1" fill="currentColor" className="opacity-90" stroke="currentColor" strokeWidth="1.5" />
    <line x1="2" y1="21" x2="22" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <path d="M4 12L8 9L12 11L16 7L22 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" opacity="0.4" />
  </svg>
);

export const FinanceIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9.5" stroke="currentColor" strokeWidth="1.8" />
    <path d="M12 7v1.5M12 15.5V17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <path d="M9 10.5c0-1.1.9-2 2-2h2a2 2 0 010 4h-2a2 2 0 000 4h2a2 2 0 002-2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export const NotificationBellIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M6 10.5C6 7.46 8.686 5 12 5C15.314 5 18 7.46 18 10.5V15L20 17H4L6 15V10.5Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M10 17C10 18.105 10.895 19 12 19C13.105 19 14 18.105 14 17" stroke="currentColor" strokeWidth="1.8" />
    <path d="M12 2C12 2 12 3.5 12 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const DemoModeIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9.5" stroke="currentColor" strokeWidth="1.8" />
    <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="1.5" strokeDasharray="2 1.5" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" />
    <path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.05 5.05l1.41 1.41M17.54 17.54l1.41 1.41M5.05 18.95l1.41-1.41M17.54 6.46l1.41-1.41" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />
  </svg>
);

/* ── Status Icons ─────────────────────────────────────────────────────────── */

export const StatusActiveIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9.5" stroke="currentColor" strokeWidth="1.8" />
    <path d="M8 12l3 3 5-5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const StatusStoppedIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="12" cy="12" r="9.5" stroke="currentColor" strokeWidth="1.8" />
    <rect x="9" y="9" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="2" />
  </svg>
);

export const StatusWarningIcon: React.FC<IconProps> = ({ size = 24, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
    <line x1="12" y1="9" x2="12" y2="13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <circle cx="12" cy="17" r="1" fill="currentColor" />
  </svg>
);

/* ── Quick Action Custom Icons ────────────────────────────────────────────── */

export const QuickAddOrderIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg width={size} height={size} viewBox="0 0 28 28" fill="none" className={className}>
    <rect x="4" y="4" width="16" height="20" rx="2.5" fill="white" fillOpacity="0.25" />
    <rect x="4" y="4" width="16" height="20" rx="2.5" stroke="white" strokeWidth="1.8" />
    <line x1="8" y1="10" x2="16" y2="10" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="8" y1="14" x2="13" y2="14" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    <circle cx="21" cy="21" r="5" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.8" />
    <line x1="21" y1="18.5" x2="21" y2="23.5" stroke="white" strokeWidth="2" strokeLinecap="round" />
    <line x1="18.5" y1="21" x2="23.5" y2="21" stroke="white" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const QuickProductionIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg width={size} height={size} viewBox="0 0 28 28" fill="none" className={className}>
    <rect x="2" y="16" width="24" height="10" rx="1.5" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.8" />
    <path d="M2 16L7 11V16" stroke="white" strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M7 16L12 11V16" stroke="white" strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M12 16L17 11V16" stroke="white" strokeWidth="1.8" strokeLinejoin="round" />
    <rect x="17" y="11" width="7" height="5" rx="0.5" stroke="white" strokeWidth="1.8" />
    <line x1="7" y1="19" x2="7" y2="22" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="14" y1="19" x2="14" y2="22" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="21" y1="19" x2="21" y2="22" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M10 11V7M10 7L8 5M10 7L12 5" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M17 11V6M17 6L15 4M17 6L19 4" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const QuickInventoryIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg width={size} height={size} viewBox="0 0 28 28" fill="none" className={className}>
    <rect x="3" y="17" width="7" height="8" rx="1" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.8" />
    <rect x="11" y="13" width="7" height="12" rx="1" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.8" />
    <rect x="19" y="9" width="7" height="16" rx="1" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.8" />
    <line x1="1" y1="25" x2="27" y2="25" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const QuickJournalIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg width={size} height={size} viewBox="0 0 28 28" fill="none" className={className}>
    <rect x="5" y="3" width="18" height="22" rx="2" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.8" />
    <rect x="2" y="5" width="4" height="18" rx="2" fill="white" fillOpacity="0.15" stroke="white" strokeWidth="1.5" />
    <line x1="9" y1="9" x2="19" y2="9" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="9" y1="13" x2="19" y2="13" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="9" y1="17" x2="15" y2="17" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    <line x1="9" y1="21" x2="13" y2="21" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export const QuickAttendanceIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg width={size} height={size} viewBox="0 0 28 28" fill="none" className={className}>
    <circle cx="14" cy="14" r="11" fill="white" fillOpacity="0.15" stroke="white" strokeWidth="1.8" />
    <path d="M14 8v6l4 2.5" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="14" cy="14" r="1.5" fill="white" />
    <path d="M8 23.5l1.5-2.5M20 23.5L18.5 21" stroke="white" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />
  </svg>
);

export const QuickHRIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg width={size} height={size} viewBox="0 0 28 28" fill="none" className={className}>
    <circle cx="10" cy="10" r="4" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.8" />
    <circle cx="20" cy="11" r="3" fill="white" fillOpacity="0.15" stroke="white" strokeWidth="1.5" />
    <path d="M2 23c0-4.418 3.582-8 8-8" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
    <path d="M18 23c0-3.314 2.686-6 6-6" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M10 15c1.245-.762 2.678-1.2 4-1.2 1.322 0 2.755.438 4 1.2" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

/* ── Compound Icon with Badge ─────────────────────────────────────────────── */

export const IconWithBadge: React.FC<{
  icon: React.ReactNode;
  badge?: number;
  badgeColor?: string;
  className?: string;
}> = ({ icon, badge, badgeColor = 'bg-red-500', className }) => (
  <div className={clsx('relative inline-flex', className)}>
    {icon}
    {badge !== undefined && badge > 0 && (
      <span className={clsx(
        'absolute -top-1 -left-1 min-w-[16px] h-4 rounded-full flex items-center justify-center',
        'text-white text-[9px] font-black px-1 shadow-sm',
        badgeColor
      )}>
        {badge > 99 ? '99+' : badge}
      </span>
    )}
  </div>
);

/* ── App Logo Icon ────────────────────────────────────────────────────────── */

export const AppLogoIcon: React.FC<{ size?: number; className?: string }> = ({ size = 40, className }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" fill="none" className={className}>
    <rect width="40" height="40" rx="10" fill="url(#logo-grad)" />
    <defs>
      <linearGradient id="logo-grad" x1="0" y1="0" x2="40" y2="40">
        <stop offset="0%" stopColor="#2563eb" />
        <stop offset="100%" stopColor="#4f46e5" />
      </linearGradient>
    </defs>
    {/* Factory building */}
    <rect x="6" y="22" width="28" height="12" rx="1.5" fill="white" fillOpacity="0.9" />
    {/* Production chevrons */}
    <path d="M6 22L11 17V22" fill="white" fillOpacity="0.7" />
    <path d="M11 22L16 17V22" fill="white" fillOpacity="0.7" />
    <path d="M16 22L21 17V22" fill="white" fillOpacity="0.7" />
    {/* Right section */}
    <rect x="21" y="17" width="7" height="5" rx="0.5" fill="white" fillOpacity="0.7" />
    {/* Chimneys */}
    <rect x="9" y="10" width="3" height="7" rx="1" fill="white" fillOpacity="0.6" />
    <rect x="16" y="8" width="3" height="9" rx="1" fill="white" fillOpacity="0.6" />
    {/* Smoke */}
    <circle cx="10.5" cy="8.5" r="1.5" fill="white" fillOpacity="0.3" />
    <circle cx="17.5" cy="6.5" r="1.5" fill="white" fillOpacity="0.3" />
    {/* Active dot */}
    <circle cx="29" cy="9" r="4" fill="#10b981" />
    <circle cx="29" cy="9" r="2" fill="white" />
    {/* Board lines */}
    <line x1="10" y1="26" x2="10" y2="31" stroke="#2563eb" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="16" y1="26" x2="16" y2="31" stroke="#2563eb" strokeWidth="1.5" strokeLinecap="round" />
    <line x1="22" y1="26" x2="22" y2="31" stroke="#2563eb" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);
