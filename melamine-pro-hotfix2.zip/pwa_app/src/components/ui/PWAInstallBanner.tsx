import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, X, Smartphone, Share } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const PWAInstallBanner: React.FC = () => {
  const { canInstall, isInstalled, isIOS, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(() =>
    localStorage.getItem('pwa_banner_dismissed') === 'true'
  );
  const [installing, setInstalling] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // Don't show if installed, dismissed, or can't install (and not iOS)
  if (isInstalled || dismissed) return null;
  if (!canInstall && !isIOS) return null;

  const handleDismiss = () => {
    setDismissed(true);
    localStorage.setItem('pwa_banner_dismissed', 'true');
  };

  const handleInstall = async () => {
    if (isIOS) {
      setShowIOSGuide(true);
      return;
    }
    setInstalling(true);
    await install();
    setInstalling(false);
  };

  return (
    <>
      <AnimatePresence>
        {!showIOSGuide && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-20 left-4 right-4 z-40 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-4 shadow-2xl shadow-blue-500/30"
            dir="rtl"
          >
            <div className="flex items-center gap-3">
              {/* Icon */}
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <Smartphone size={22} className="text-white" />
              </div>

              {/* Text */}
              <div className="flex-1 min-w-0">
                <p className="font-bold text-white text-sm">ثبّت التطبيق</p>
                <p className="text-blue-200 text-xs leading-relaxed">
                  {isIOS
                    ? 'أضف للشاشة الرئيسية للوصول السريع'
                    : 'احصل على تجربة أفضل بتثبيت التطبيق'}
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleInstall}
                  disabled={installing}
                  className="flex items-center gap-1.5 bg-white text-blue-700 font-bold text-xs px-3 py-2 rounded-xl hover:bg-blue-50 transition-colors disabled:opacity-70"
                >
                  {installing ? (
                    <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                  ) : isIOS ? (
                    <Share size={12} />
                  ) : (
                    <Download size={12} />
                  )}
                  {isIOS ? 'إضافة' : 'تثبيت'}
                </motion.button>

                <button
                  onClick={handleDismiss}
                  className="w-7 h-7 flex items-center justify-center rounded-xl bg-white/20 hover:bg-white/30 transition-colors"
                >
                  <X size={14} className="text-white" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* iOS Guide Modal */}
      <AnimatePresence>
        {showIOSGuide && (
          <motion.div
            className="fixed inset-0 z-50 flex items-end"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Backdrop */}
            <div
              className="absolute inset-0 bg-black/50"
              onClick={() => setShowIOSGuide(false)}
            />

            {/* Sheet */}
            <motion.div
              className="relative w-full bg-white rounded-t-3xl p-6 pb-10 shadow-2xl"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30 }}
              dir="rtl"
            >
              <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-5" />

              <h3 className="text-lg font-black text-gray-900 mb-4 text-center">
                كيفية تثبيت التطبيق على iPhone
              </h3>

              <div className="space-y-4">
                {[
                  {
                    step: 1,
                    icon: <Share size={20} className="text-blue-600" />,
                    text: 'اضغط على زر المشاركة',
                    desc: 'في شريط الأدوات أسفل Safari',
                  },
                  {
                    step: 2,
                    icon: <span className="text-lg">➕</span>,
                    text: 'اختر "إضافة إلى الشاشة الرئيسية"',
                    desc: 'قد تحتاج للتمرير لأسفل القائمة',
                  },
                  {
                    step: 3,
                    icon: <span className="text-lg">✅</span>,
                    text: 'اضغط "إضافة"',
                    desc: 'سيظهر أيقونة التطبيق على شاشتك',
                  },
                ].map(item => (
                  <div key={item.step} className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5">
                      {item.icon}
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-sm text-gray-900">{item.text}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{item.desc}</p>
                    </div>
                    <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-black flex-shrink-0">
                      {item.step}
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => { setShowIOSGuide(false); handleDismiss(); }}
                className="mt-6 w-full py-3.5 bg-blue-600 text-white font-bold rounded-2xl text-sm"
              >
                فهمت، شكراً!
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
