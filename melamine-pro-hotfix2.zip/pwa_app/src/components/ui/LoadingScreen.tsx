import React from 'react';
import { motion } from 'framer-motion';
import { Factory } from 'lucide-react';

interface LoadingScreenProps {
  message?: string;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ message = 'جاري التحميل...' }) => {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900 flex flex-col items-center justify-center z-50" dir="rtl">
      {/* Background circles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-white/5"
            style={{
              width: `${[120, 200, 80, 160, 100, 240][i]}px`,
              height: `${[120, 200, 80, 160, 100, 240][i]}px`,
              top: `${[10, 60, 30, 80, 5, 45][i]}%`,
              left: `${[10, 70, 50, 20, 80, 40][i]}%`,
            }}
            animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 3 + i * 0.5, repeat: Infinity, delay: i * 0.3 }}
          />
        ))}
      </div>

      {/* Logo */}
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        className="relative z-10 flex flex-col items-center gap-6"
      >
        {/* Icon */}
        <div className="relative">
          <motion.div
            className="w-24 h-24 bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl flex items-center justify-center shadow-2xl"
            animate={{ rotate: [0, 3, -3, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          >
            <Factory size={44} className="text-white" />
          </motion.div>

          {/* Ping effect */}
          <motion.div
            className="absolute inset-0 rounded-3xl bg-blue-400/20 border border-blue-400/30"
            animate={{ scale: [1, 1.3, 1], opacity: [0.8, 0, 0.8] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </div>

        {/* Title */}
        <div className="text-center">
          <motion.h1
            className="text-3xl font-black text-white mb-1"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            ميلامين برو
          </motion.h1>
          <motion.p
            className="text-blue-200 text-sm"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            نظام إدارة مصنع الميلامين
          </motion.p>
        </div>

        {/* Loading bar */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex flex-col items-center gap-3"
        >
          <div className="w-48 h-1.5 bg-white/20 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-white rounded-full"
              animate={{ x: ['-100%', '100%'] }}
              transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
            />
          </div>
          <p className="text-blue-200 text-xs font-medium">{message}</p>
        </motion.div>

        {/* 3 dots */}
        <div className="flex items-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="w-1.5 h-1.5 bg-white/60 rounded-full"
              animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
};

// Skeleton loader for cards
export const CardSkeleton: React.FC<{ count?: number }> = ({ count = 4 }) => (
  <div className="grid grid-cols-2 gap-3 px-4">
    {[...Array(count)].map((_, i) => (
      <div key={i} className="bg-white rounded-2xl p-4 border border-gray-100">
        <div className="shimmer h-3 w-16 rounded-full mb-3" />
        <div className="shimmer h-6 w-20 rounded-full mb-2" />
        <div className="shimmer h-2 w-12 rounded-full" />
      </div>
    ))}
  </div>
);

// Inline spinner
export const Spinner: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className = 'text-blue-600',
}) => (
  <motion.div
    animate={{ rotate: 360 }}
    transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
    className={`border-2 border-current border-t-transparent rounded-full ${className}`}
    style={{ width: size, height: size }}
  />
);
