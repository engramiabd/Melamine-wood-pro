/**
 * Modern SVG Icon System — replaces all emojis across the app
 * All icons are pure SVG, consistent 24×24 viewBox, stroke-based design
 */

import React from 'react';

interface IconProps {
  size?: number;
  className?: string;
  color?: string;
}

const icon = (paths: React.ReactNode, viewBox = '0 0 24 24') =>
  ({ size = 20, className = '', color = 'currentColor' }: IconProps) => (
    <svg
      width={size}
      height={size}
      viewBox={viewBox}
      fill="none"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      {paths}
    </svg>
  );

// ── Status Icons ──────────────────────────────────────────────────────────────
export const IconSuccess = icon(<>
  <circle cx="12" cy="12" r="9" strokeWidth="1.5" />
  <path d="M8.5 12.5l2.5 2.5 4.5-5" />
</>);

export const IconWarning = icon(<>
  <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
  <line x1="12" y1="9" x2="12" y2="13" />
  <line x1="12" y1="17" x2="12.01" y2="17" />
</>);

export const IconError = icon(<>
  <circle cx="12" cy="12" r="9" strokeWidth="1.5" />
  <line x1="15" y1="9" x2="9" y2="15" />
  <line x1="9" y1="9" x2="15" y2="15" />
</>);

export const IconInfo = icon(<>
  <circle cx="12" cy="12" r="9" strokeWidth="1.5" />
  <line x1="12" y1="8" x2="12" y2="12" />
  <line x1="12" y1="16" x2="12.01" y2="16" strokeWidth="2.5" />
</>);

// ── Navigation Icons ──────────────────────────────────────────────────────────
export const IconDashboard = icon(<>
  <rect x="3" y="3" width="7" height="7" rx="1.5" />
  <rect x="14" y="3" width="7" height="7" rx="1.5" />
  <rect x="3" y="14" width="7" height="7" rx="1.5" />
  <rect x="14" y="14" width="7" height="7" rx="1.5" />
</>);

export const IconFactory = icon(<>
  <rect x="2" y="10" width="20" height="11" rx="1.5" strokeWidth="1.5" />
  <path d="M6 10V6l5 4V6l5 4V6l4 4" />
  <line x1="6" y1="14" x2="6" y2="18" />
  <line x1="10" y1="14" x2="10" y2="18" />
  <line x1="14" y1="14" x2="14" y2="18" />
  <path d="M2 21h20" strokeWidth="1.5" />
</>);

export const IconOrders = icon(<>
  <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
  <polyline points="14 2 14 8 20 8" />
  <line x1="9" y1="13" x2="15" y2="13" />
  <line x1="9" y1="17" x2="13" y2="17" />
</>);

export const IconInventory = icon(<>
  <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 002 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z" />
  <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
  <line x1="12" y1="22.08" x2="12" y2="12" />
</>);

export const IconWallet = icon(<>
  <rect x="2" y="5" width="20" height="14" rx="2" />
  <path d="M16 12a1 1 0 100 2 1 1 0 000-2z" fill="currentColor" stroke="none" />
  <path d="M2 10h20" />
</>);

export const IconAttendance = icon(<>
  <circle cx="12" cy="12" r="9" strokeWidth="1.5" />
  <polyline points="12 7 12 12 15 15" />
</>);

export const IconHR = icon(<>
  <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
  <circle cx="9" cy="7" r="4" />
  <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />
</>);

export const IconAnalytics = icon(<>
  <line x1="18" y1="20" x2="18" y2="10" />
  <line x1="12" y1="20" x2="12" y2="4" />
  <line x1="6" y1="20" x2="6" y2="14" />
  <path d="M2 20h20" />
</>);

export const IconJournal = icon(<>
  <path d="M4 19.5A2.5 2.5 0 016.5 17H20" />
  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" />
  <line x1="9" y1="9" x2="15" y2="9" />
  <line x1="9" y1="13" x2="13" y2="13" />
</>);

export const IconFinance = icon(<>
  <line x1="12" y1="1" x2="12" y2="23" />
  <path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" />
</>);

export const IconSales = icon(<>
  <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
  <polyline points="17 6 23 6 23 12" />
</>);

export const IconCosts = icon(<>
  <rect x="4" y="2" width="16" height="20" rx="2" />
  <path d="M9 7h6M9 11h6M9 15h4" />
  <circle cx="16" cy="16" r="3" fill="none" />
  <path d="M16 14v4M14 16h4" strokeWidth="1.5" />
</>);

export const IconAdmin = icon(<>
  <path d="M12 2L3 7l9 5 9-5-9-5z" />
  <path d="M3 17l9 5 9-5" />
  <path d="M3 12l9 5 9-5" />
</>);

export const IconSettings = icon(<>
  <circle cx="12" cy="12" r="3" />
  <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" />
</>);

export const IconDemo = icon(<>
  <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
</>);

// ── Action Icons ──────────────────────────────────────────────────────────────
export const IconPlus = icon(<>
  <line x1="12" y1="5" x2="12" y2="19" />
  <line x1="5" y1="12" x2="19" y2="12" />
</>);

export const IconSearch = icon(<>
  <circle cx="11" cy="11" r="7" />
  <line x1="21" y1="21" x2="16.65" y2="16.65" />
</>);

export const IconFilter = icon(<>
  <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
</>);

export const IconSort = icon(<>
  <line x1="3" y1="6" x2="21" y2="6" />
  <line x1="3" y1="12" x2="15" y2="12" />
  <line x1="3" y1="18" x2="9" y2="18" />
</>);

export const IconEdit = icon(<>
  <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" />
  <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" />
</>);

export const IconDelete = icon(<>
  <polyline points="3 6 5 6 21 6" />
  <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6" />
  <path d="M10 11v6M14 11v6" />
  <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2" />
</>);

export const IconSave = icon(<>
  <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" />
  <polyline points="17 21 17 13 7 13 7 21" />
  <polyline points="7 3 7 8 15 8" />
</>);

export const IconDownload = icon(<>
  <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
  <polyline points="7 10 12 15 17 10" />
  <line x1="12" y1="15" x2="12" y2="3" />
</>);

export const IconUpload = icon(<>
  <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
  <polyline points="17 8 12 3 7 8" />
  <line x1="12" y1="3" x2="12" y2="15" />
</>);

export const IconRefresh = icon(<>
  <polyline points="23 4 23 10 17 10" />
  <polyline points="1 20 1 14 7 14" />
  <path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15" />
</>);

export const IconPrint = icon(<>
  <polyline points="6 9 6 2 18 2 18 9" />
  <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2" />
  <rect x="6" y="14" width="12" height="8" />
</>);

export const IconSend = icon(<>
  <line x1="22" y1="2" x2="11" y2="13" />
  <polygon points="22 2 15 22 11 13 2 9 22 2" />
</>);

export const IconCamera = icon(<>
  <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z" />
  <circle cx="12" cy="13" r="4" />
</>);

// ── Finance Icons ─────────────────────────────────────────────────────────────
export const IconDollar = icon(<>
  <line x1="12" y1="1" x2="12" y2="23" />
  <path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" />
</>);

export const IconTrendUp = icon(<>
  <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
  <polyline points="17 6 23 6 23 12" />
</>);

export const IconTrendDown = icon(<>
  <polyline points="23 18 13.5 8.5 8.5 13.5 1 6" />
  <polyline points="17 18 23 18 23 12" />
</>);

export const IconArrowIncome = icon(<>
  <circle cx="12" cy="12" r="9" strokeWidth="1.5" />
  <polyline points="8 12 12 8 16 12" />
  <line x1="12" y1="16" x2="12" y2="8" />
</>);

export const IconArrowExpense = icon(<>
  <circle cx="12" cy="12" r="9" strokeWidth="1.5" />
  <polyline points="16 12 12 16 8 12" />
  <line x1="12" y1="8" x2="12" y2="16" />
</>);

export const IconBanknote = icon(<>
  <rect x="2" y="6" width="20" height="12" rx="2" />
  <circle cx="12" cy="12" r="3" />
  <path d="M6 12h.01M18 12h.01" strokeWidth="2.5" />
</>);

export const IconCreditCard = icon(<>
  <rect x="1" y="4" width="22" height="16" rx="2" />
  <line x1="1" y1="10" x2="23" y2="10" />
  <path d="M5 15h2M9 15h4" strokeWidth="2" />
</>);

export const IconCoin = icon(<>
  <circle cx="12" cy="12" r="9" strokeWidth="1.5" />
  <path d="M15 9.5a3 3 0 10-6 0 3 3 0 006 0z" />
  <path d="M12 14v2" />
</>);

export const IconGift = icon(<>
  <polyline points="20 12 20 22 4 22 4 12" />
  <rect x="2" y="7" width="20" height="5" />
  <path d="M12 22V7" />
  <path d="M12 7H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7z" />
  <path d="M12 7h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z" />
</>);

export const IconRepeat = icon(<>
  <polyline points="17 1 21 5 17 9" />
  <path d="M3 11V9a4 4 0 014-4h14" />
  <polyline points="7 23 3 19 7 15" />
  <path d="M21 13v2a4 4 0 01-4 4H3" />
</>);

export const IconExchange = icon(<>
  <path d="M7 16V4m0 0L3 8m4-4l4 4" />
  <path d="M17 8v12m0 0l4-4m-4 4l-4-4" />
</>);

// ── HR Icons ──────────────────────────────────────────────────────────────────
export const IconUser = icon(<>
  <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
  <circle cx="12" cy="7" r="4" />
</>);

export const IconUserPlus = icon(<>
  <path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2" />
  <circle cx="9" cy="7" r="4" />
  <line x1="19" y1="8" x2="19" y2="14" />
  <line x1="16" y1="11" x2="22" y2="11" />
</>);

export const IconShield = icon(<>
  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
</>);

export const IconBriefcase = icon(<>
  <rect x="2" y="7" width="20" height="14" rx="2" />
  <path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" />
</>);

export const IconHardHat = icon(<>
  <path d="M2 18a1 1 0 001 1h18a1 1 0 001-1v-2a1 1 0 00-1-1H3a1 1 0 00-1 1v2z" />
  <path d="M10 10V7a2 2 0 114 0v3" />
  <path d="M4 15a8 8 0 1116 0" />
</>);

export const IconHammer = icon(<>
  <path d="M15 5l7 7-7 7" />
  <path d="M2 12h13" />
  <path d="M13 7l5 5-5 5" />
</>);

export const IconBookOpen = icon(<>
  <path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z" />
  <path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z" />
</>);

export const IconCalendar = icon(<>
  <rect x="3" y="4" width="18" height="18" rx="2" />
  <line x1="16" y1="2" x2="16" y2="6" />
  <line x1="8" y1="2" x2="8" y2="6" />
  <line x1="3" y1="10" x2="21" y2="10" />
</>);

export const IconClock = icon(<>
  <circle cx="12" cy="12" r="9" strokeWidth="1.5" />
  <polyline points="12 7 12 12 15 15" />
</>);

export const IconAward = icon(<>
  <circle cx="12" cy="8" r="6" />
  <path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11" />
</>);

export const IconStar = icon(<>
  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
</>);

// ── Production Icons ──────────────────────────────────────────────────────────
export const IconZap = icon(<>
  <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
</>);

export const IconAlertTriangle = icon(<>
  <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
  <line x1="12" y1="9" x2="12" y2="13" />
  <line x1="12" y1="17" x2="12.01" y2="17" strokeWidth="2.5" />
</>);

export const IconActivity = icon(<>
  <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
</>);

export const IconCpu = icon(<>
  <rect x="4" y="4" width="16" height="16" rx="2" />
  <rect x="9" y="9" width="6" height="6" />
  <line x1="9" y1="1" x2="9" y2="4" />
  <line x1="15" y1="1" x2="15" y2="4" />
  <line x1="9" y1="20" x2="9" y2="23" />
  <line x1="15" y1="20" x2="15" y2="23" />
  <line x1="20" y1="9" x2="23" y2="9" />
  <line x1="20" y1="14" x2="23" y2="14" />
  <line x1="1" y1="9" x2="4" y2="9" />
  <line x1="1" y1="14" x2="4" y2="14" />
</>);

export const IconServer = icon(<>
  <rect x="2" y="2" width="20" height="8" rx="2" />
  <rect x="2" y="14" width="20" height="8" rx="2" />
  <line x1="6" y1="6" x2="6.01" y2="6" strokeWidth="3" />
  <line x1="6" y1="18" x2="6.01" y2="18" strokeWidth="3" />
</>);

export const IconDatabase = icon(<>
  <ellipse cx="12" cy="5" rx="9" ry="3" />
  <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
  <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
</>);

// ── Location Icons ────────────────────────────────────────────────────────────
export const IconMapPin = icon(<>
  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
  <circle cx="12" cy="10" r="3" />
</>);

export const IconNavigation = icon(<>
  <polygon points="3 11 22 2 13 21 11 13 3 11" />
</>);

// ── Misc Icons ────────────────────────────────────────────────────────────────
export const IconBell = icon(<>
  <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" />
  <path d="M13.73 21a2 2 0 01-3.46 0" />
</>);

export const IconLock = icon(<>
  <rect x="3" y="11" width="18" height="11" rx="2" />
  <path d="M7 11V7a5 5 0 0110 0v4" />
</>);

export const IconEye = icon(<>
  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
  <circle cx="12" cy="12" r="3" />
</>);

export const IconEyeOff = icon(<>
  <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" />
  <line x1="1" y1="1" x2="23" y2="23" />
</>);

export const IconChevronRight = icon(<>
  <polyline points="9 18 15 12 9 6" />
</>);

export const IconChevronDown = icon(<>
  <polyline points="6 9 12 15 18 9" />
</>);

export const IconChevronLeft = icon(<>
  <polyline points="15 18 9 12 15 6" />
</>);

export const IconX = icon(<>
  <line x1="18" y1="6" x2="6" y2="18" />
  <line x1="6" y1="6" x2="18" y2="18" />
</>);

export const IconCheck = icon(<>
  <polyline points="20 6 9 17 4 12" />
</>);

export const IconTag = icon(<>
  <path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" />
  <line x1="7" y1="7" x2="7.01" y2="7" strokeWidth="2.5" />
</>);

export const IconHash = icon(<>
  <line x1="4" y1="9" x2="20" y2="9" />
  <line x1="4" y1="15" x2="20" y2="15" />
  <line x1="10" y1="3" x2="8" y2="21" />
  <line x1="16" y1="3" x2="14" y2="21" />
</>);

export const IconGlobe = icon(<>
  <circle cx="12" cy="12" r="9" strokeWidth="1.5" />
  <line x1="2" y1="12" x2="22" y2="12" />
  <path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z" />
</>);

export const IconLogIn = icon(<>
  <path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4" />
  <polyline points="10 17 15 12 10 7" />
  <line x1="15" y1="12" x2="3" y2="12" />
</>);

export const IconLogOut = icon(<>
  <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4" />
  <polyline points="16 17 21 12 16 7" />
  <line x1="21" y1="12" x2="9" y2="12" />
</>);

export const IconPhone = icon(<>
  <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z" />
</>);

export const IconMail = icon(<>
  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
  <polyline points="22 6 12 13 2 6" />
</>);

export const IconBuilding = icon(<>
  <rect x="4" y="2" width="16" height="20" rx="1" />
  <path d="M9 22V12h6v10" />
  <path d="M8 6h.01M12 6h.01M16 6h.01M8 10h.01M12 10h.01M16 10h.01" strokeWidth="2" />
</>);

export const IconThumbUp = icon(<>
  <path d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 002-1.7l1.38-9a2 2 0 00-2-2.3H14z" />
  <path d="M7 22H4a2 2 0 01-2-2v-7a2 2 0 012-2h3" />
</>);

export const IconThumbDown = icon(<>
  <path d="M10 15v4a3 3 0 003 3l4-9V2H5.72a2 2 0 00-2 1.7l-1.38 9a2 2 0 002 2.3H10z" />
  <path d="M17 2h2.67A2.31 2.31 0 0122 4v7a2.31 2.31 0 01-2.33 2H17" />
</>);

export const IconHistory = icon(<>
  <polyline points="1 4 1 10 7 10" />
  <path d="M3.51 15a9 9 0 102.13-9.36L1 10" />
  <polyline points="12 7 12 12 15 15" />
</>);

// ── Status Dot Component ──────────────────────────────────────────────────────
export const StatusDot: React.FC<{
  status: 'active' | 'stopped' | 'warning' | 'idle';
  pulse?: boolean;
  size?: number;
}> = ({ status, pulse = false, size = 8 }) => {
  const colors = {
    active: 'bg-emerald-500',
    stopped: 'bg-red-500',
    warning: 'bg-amber-500',
    idle: 'bg-gray-400',
  };
  return (
    <span className="relative inline-flex" style={{ width: size, height: size }}>
      {pulse && (
        <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${colors[status]} opacity-60`} />
      )}
      <span className={`relative inline-flex rounded-full ${colors[status]}`} style={{ width: size, height: size }} />
    </span>
  );
};

// ── Role Icon Map ─────────────────────────────────────────────────────────────
export const RoleIcon: React.FC<{ role: string; size?: number; className?: string }> = ({ role, size = 18, className }) => {
  const props = { size, className };
  switch (role) {
    case 'admin': return <IconShield {...props} />;
    case 'manager': return <IconBriefcase {...props} />;
    case 'production_supervisor': return <IconFactory {...props} />;
    case 'worker': return <IconHardHat {...props} />;
    case 'accountant': return <IconJournal {...props} />;
    case 'hr': return <IconHR {...props} />;
    default: return <IconUser {...props} />;
  }
};

// ── Log Level Icon ────────────────────────────────────────────────────────────
export const LogLevelIcon: React.FC<{ level: string; size?: number }> = ({ level, size = 16 }) => {
  switch (level) {
    case 'success': return <IconSuccess size={size} className="text-emerald-600" />;
    case 'warning': return <IconWarning size={size} className="text-amber-600" />;
    case 'error':   return <IconError size={size} className="text-red-600" />;
    case 'info':    return <IconInfo size={size} className="text-blue-600" />;
    default:        return <IconInfo size={size} className="text-gray-500" />;
  }
};
