import React, { useEffect, useState } from 'react';
import { getAvatar, roleGradient, roleRing, initials, AVATAR_EVENT } from '../../lib/avatar';

interface AvatarProps {
  userId?: string;
  name?: string;
  role?: string;
  /** px size of the square avatar. */
  size?: number;
  /** border radius; number => px, 'full' => circle. Default: squircle (size * 0.32). */
  radius?: number | 'full';
  /** show a role-coloured ring around the avatar. */
  ring?: boolean;
  /** explicit photo data-URL that overrides the stored one (e.g. live preview). */
  photo?: string | null;
  /** fallback photo (e.g. user.avatar_url) when nothing is stored. */
  fallbackPhoto?: string | null;
  style?: React.CSSProperties;
}

/**
 * Role-aware avatar: shows the user's personal photo when available, otherwise a
 * role-coloured gradient with their initials. Re-renders automatically when the
 * photo changes anywhere in the app.
 */
export const Avatar: React.FC<AvatarProps> = ({
  userId, name, role, size = 40, radius, ring = false, photo, fallbackPhoto, style,
}) => {
  const [stored, setStored] = useState<string | null>(() => getAvatar(userId));

  useEffect(() => {
    setStored(getAvatar(userId));
    const onChange = (e: Event) => {
      const id = (e as CustomEvent).detail?.userId;
      if (!id || id === userId) setStored(getAvatar(userId));
    };
    window.addEventListener(AVATAR_EVENT, onChange);
    window.addEventListener('storage', onChange);
    return () => {
      window.removeEventListener(AVATAR_EVENT, onChange);
      window.removeEventListener('storage', onChange);
    };
  }, [userId]);

  const src = photo ?? stored ?? fallbackPhoto ?? null;
  const br = radius === 'full' ? '50%' : (radius ?? Math.round(size * 0.32));
  const ringStyle: React.CSSProperties = ring
    ? { boxShadow: `0 0 0 2px var(--surface, #fff), 0 0 0 4px ${roleRing(role)}` }
    : {};

  const base: React.CSSProperties = {
    width: size, height: size, borderRadius: br, flexShrink: 0,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    overflow: 'hidden', ...ringStyle, ...style,
  };

  if (src) {
    return (
      <div style={base}>
        <img src={src} alt={name ?? 'avatar'} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
      </div>
    );
  }

  return (
    <div style={{
      ...base,
      background: roleGradient(role),
      color: '#fff', fontWeight: 900,
      fontSize: Math.max(11, Math.round(size * 0.36)),
      letterSpacing: '-0.5px',
    }}>
      {initials(name)}
    </div>
  );
};

export default Avatar;
