import React from 'react';
import { RefreshCw, Cloud, CloudOff, CheckCircle2, AlertCircle, WifiOff } from 'lucide-react';
import { useAppData } from '../../contexts/AppDataContext';

/** Relative "time ago" in Arabic. */
function timeAgo(iso: string | null): string {
  if (!iso) return 'لم تتم بعد';
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'الآن';
  if (m < 60) return `قبل ${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `قبل ${h} ساعة`;
  return `قبل ${Math.floor(h / 24)} يوم`;
}

export const SyncStatus: React.FC = () => {
  const { syncStatus, syncNow } = useAppData();
  const { configured, online, syncing, pending, lastSyncedAt, error } = syncStatus;

  // State → colour + label + icon
  let tone = '#64748b', label = 'غير مفعّلة', Icon = CloudOff, hint = 'لم تُضبط مزامنة السحابة بعد';
  if (configured) {
    if (!online)       { tone = '#d97706'; label = 'دون اتصال';   Icon = WifiOff;     hint = 'سيتم الرفع تلقائياً عند عودة الإنترنت'; }
    else if (syncing)  { tone = '#2563eb'; label = 'جارٍ المزامنة'; Icon = RefreshCw;  hint = 'يتم رفع وسحب البيانات الآن'; }
    else if (error)    { tone = '#dc2626'; label = 'خطأ في المزامنة'; Icon = AlertCircle; hint = error; }
    else if (pending)  { tone = '#d97706'; label = 'بانتظار الرفع'; Icon = Cloud;      hint = `${pending} جدول بانتظار المزامنة`; }
    else               { tone = '#059669'; label = 'متزامن';        Icon = CheckCircle2; hint = `آخر مزامنة: ${timeAgo(lastSyncedAt)}`; }
  }

  return (
    <div style={{
      background: 'var(--surface)', border: '1px solid var(--border-color)',
      borderRadius: 16, padding: 16, display: 'flex', flexDirection: 'column', gap: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 42, height: 42, borderRadius: 12, flexShrink: 0,
          background: `${tone}1a`, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon size={20} color={tone} className={syncing ? 'animate-spin' : ''} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 14, fontWeight: 800, color: 'var(--text-primary)' }}>مزامنة السحابة</span>
            <span style={{ fontSize: 10.5, fontWeight: 800, color: tone, background: `${tone}1a`, padding: '2px 8px', borderRadius: 999 }}>{label}</span>
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{hint}</div>
        </div>
      </div>

      {configured ? (
        <button
          onClick={() => { void syncNow(); }}
          disabled={syncing || !online}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            padding: '10px 0', borderRadius: 12, border: 'none', cursor: syncing || !online ? 'not-allowed' : 'pointer',
            background: syncing || !online ? 'var(--surface-secondary)' : 'linear-gradient(135deg,#2563eb,#4f46e5)',
            color: syncing || !online ? 'var(--text-tertiary)' : '#fff', fontSize: 13, fontWeight: 800,
          }}>
          <RefreshCw size={15} className={syncing ? 'animate-spin' : ''} />
          {syncing ? 'جارٍ المزامنة…' : 'مزامنة الآن'}
        </button>
      ) : (
        <div style={{ fontSize: 11, color: 'var(--text-tertiary)', lineHeight: 1.7 }}>
          لتفعيل المزامنة: أضِف مفاتيح Supabase في ملف <code style={{ background: 'var(--surface-secondary)', padding: '1px 5px', borderRadius: 5 }}>.env</code> ثم شغّل مخطّط <code style={{ background: 'var(--surface-secondary)', padding: '1px 5px', borderRadius: 5 }}>supabase/schema.sql</code>. يعمل التطبيق بكامل وظائفه دون اتصال، وتُحفظ كل البيانات محلياً.
        </div>
      )}
    </div>
  );
};

export default SyncStatus;
