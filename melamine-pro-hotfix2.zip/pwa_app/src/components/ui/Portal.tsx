import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';

/**
 * Renders children into document.body — completely outside .app-shell.
 * This means position:fixed children are relative to the VIEWPORT,
 * not clipped by .app-shell's overflow:hidden or stacking context.
 *
 * Use this for ALL modals, sheets, drawers, and overlays so they
 * always appear above the BottomNav and never get clipped.
 */
export const Portal: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const el = useRef<HTMLDivElement | null>(null);

  if (!el.current) {
    el.current = document.createElement('div');
    el.current.setAttribute('data-portal', 'true');
  }

  useEffect(() => {
    const node = el.current!;
    document.body.appendChild(node);
    return () => {
      document.body.removeChild(node);
    };
  }, []);

  return createPortal(children, el.current);
};
