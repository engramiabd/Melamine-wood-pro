import React from 'react';

const shimmerStyle: React.CSSProperties = {
  background: 'linear-gradient(90deg, var(--skeleton-base) 25%, var(--skeleton-hi) 50%, var(--skeleton-base) 75%)',
  backgroundSize: '200% 100%',
  animation: 'shimmer 1.4s ease-in-out infinite',
};

export const Skeleton: React.FC<{
  width?: number | string;
  height?: number | string;
  radius?: number;
  className?: string;
  style?: React.CSSProperties;
}> = ({ width = '100%', height = 14, radius = 8, className, style }) => (
  <div className={className} style={{ ...shimmerStyle, width, height, borderRadius: radius, ...style }} aria-hidden="true" />
);

// A card-shaped skeleton (used in lists / dashboards).
export const SkeletonCard: React.FC<{ lines?: number }> = ({ lines = 2 }) => (
  <div style={{ background: 'var(--surface)', borderRadius: 18, padding: 16, boxShadow: '0 2px 6px rgba(0,0,0,0.05)' }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
      <Skeleton width={40} height={40} radius={12} />
      <div style={{ flex: 1 }}>
        <Skeleton width="55%" height={13} />
        <div style={{ height: 6 }} />
        <Skeleton width="35%" height={10} />
      </div>
    </div>
    {Array.from({ length: lines }).map((_, i) => (
      <div key={i} style={{ marginTop: 8 }}><Skeleton width={`${90 - i * 15}%`} height={11} /></div>
    ))}
  </div>
);

// Full-page skeleton used as the lazy-route Suspense fallback. Mirrors the
// usual page shape (hero header + a few cards) so route loads feel instant.
export const PageSkeleton: React.FC = () => (
  <div style={{ minHeight: '100%', background: '#f4f6fb' }} dir="rtl">
    <div style={{ background: 'linear-gradient(135deg,#1e3a8a,#2563eb)', padding: '22px 18px 34px' }}>
      <Skeleton width="45%" height={20} radius={10} style={{ background: 'rgba(255,255,255,0.25)', backgroundImage: 'none' }} />
      <div style={{ height: 8 }} />
      <Skeleton width="30%" height={12} radius={8} style={{ background: 'rgba(255,255,255,0.18)', backgroundImage: 'none' }} />
    </div>
    <div style={{ padding: 16, marginTop: -18, display: 'grid', gap: 12 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <Skeleton height={72} radius={18} />
        <Skeleton height={72} radius={18} />
      </div>
      <SkeletonCard lines={2} />
      <SkeletonCard lines={3} />
      <SkeletonCard lines={2} />
    </div>
  </div>
);

export default Skeleton;
