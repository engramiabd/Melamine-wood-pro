/**
 * BottomModal — A bottom sheet modal that correctly clears the BottomNav.
 *
 * KEY DESIGN DECISIONS:
 * ─────────────────────
 * 1. z-index: 60 (above BottomNav z-40 and TopBar z-40)
 * 2. The modal sheet uses flexbox column with:
 *    - A FIXED header/handle (flexShrink: 0)
 *    - A SCROLLABLE middle section (flex: 1, overflowY: auto)
 *    - A FIXED action footer (flexShrink: 0)
 *    This ensures action buttons are ALWAYS visible above the keyboard/nav.
 * 3. paddingBottom: env(safe-area-inset-bottom) on the outer sheet
 *    so nothing is hidden behind iPhone home indicator.
 * 4. maxHeight: 92dvh uses dynamic viewport height (accounts for
 *    browser chrome on mobile, notches, etc.)
 */

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface BottomModalProps {
  /** Controls visibility */
  isOpen: boolean;
  /** Called when backdrop is tapped or close button pressed */
  onClose: () => void;
  /** Modal content — use BottomModalHeader, BottomModalBody, BottomModalFooter */
  children: React.ReactNode;
  /** Max height of the sheet. Default: '92dvh' */
  maxHeight?: string;
  /** Max width (for tablet/desktop centering). Default: '520px' */
  maxWidth?: string;
}

export const BottomModal: React.FC<BottomModalProps> = ({
  isOpen,
  onClose,
  children,
  maxHeight = '92dvh',
  maxWidth = '520px',
}) => (
  <AnimatePresence>
    {isOpen && (
      <motion.div
        key="bottom-modal-backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.14 }}
        style={{
          position: 'fixed',
          inset: 0,
          zIndex: 60,
          background: 'rgba(0,0,0,0.55)',
          backdropFilter: 'blur(4px)',
          WebkitBackdropFilter: 'blur(4px)',
          display: 'flex',
          alignItems: 'flex-end',
          justifyContent: 'center',
          touchAction: 'none',
          overscrollBehavior: 'none',
        }}
        onClick={onClose}
      >
        <motion.div
          key="bottom-modal-sheet"
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 32, stiffness: 400, mass: 0.75 }}
          style={{
            width: '100%',
            maxWidth,
            maxHeight,
            background: 'var(--surface)',
            borderRadius: '24px 24px 0 0',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            // Push content above iPhone home indicator
            paddingBottom: 'env(safe-area-inset-bottom, 0px)',
          }}
          onClick={e => e.stopPropagation()}
          dir="rtl"
        >
          {children}
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

// ── Sub-components ────────────────────────────────────────────────────────────

/** Drag handle bar at the top of the sheet */
export const BottomModalHandle: React.FC = () => (
  <div style={{
    padding: '12px 0 4px',
    flexShrink: 0,
    display: 'flex',
    justifyContent: 'center',
  }}>
    <div style={{
      width: 40, height: 5,
      background: '#CBD5E1',
      borderRadius: 999,
    }} />
  </div>
);

interface BottomModalHeaderProps {
  /** Background gradient class e.g. "from-blue-600 to-indigo-600" */
  gradient?: string;
  /** Solid background color (used when no gradient) */
  background?: string;
  children: React.ReactNode;
  /** Show close button */
  onClose?: () => void;
}

/** Colored header section — flexShrink: 0 so it never scrolls */
export const BottomModalHeader: React.FC<BottomModalHeaderProps> = ({
  gradient,
  background,
  children,
  onClose,
}) => (
  <div
    className={gradient ? `bg-gradient-to-r ${gradient}` : ''}
    style={{
      flexShrink: 0,
      padding: '8px 20px 20px',
      position: 'relative',
      background: !gradient ? background : undefined,
    }}
  >
    {onClose && (
      <button
        onClick={onClose}
        style={{
          position: 'absolute', top: 8, left: 16,
          width: 32, height: 32, minHeight: 'unset',
          background: 'rgba(255,255,255,0.22)',
          borderRadius: '50%', border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path d="M1 1l12 12M13 1L1 13" stroke="white" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </button>
    )}
    {children}
  </div>
);

/** Scrollable body section — flex: 1 so it fills remaining space */
export const BottomModalBody: React.FC<{
  children: React.ReactNode;
  padding?: string;
}> = ({ children, padding = '16px' }) => (
  <div style={{
    flex: 1,
    overflowY: 'auto',
    overscrollBehavior: 'contain',
    touchAction: 'pan-y',
    padding,
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
  }}>
    {children}
  </div>
);

/** Fixed footer with action buttons — flexShrink: 0, always visible */
export const BottomModalFooter: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => (
  <div style={{
    flexShrink: 0,
    padding: '12px 16px 16px',
    borderTop: '1px solid #F1F5F9',
    background: 'var(--surface)',
  }}>
    {children}
  </div>
);

/** Two-button action row */
export const BottomModalActions: React.FC<{
  cancelLabel?: string;
  confirmLabel?: string;
  onCancel: () => void;
  onConfirm: () => void;
  confirmDisabled?: boolean;
  confirmLoading?: boolean;
  confirmColor?: string;
  confirmIcon?: React.ReactNode;
}> = ({
  cancelLabel = 'إلغاء',
  confirmLabel = 'تأكيد',
  onCancel,
  onConfirm,
  confirmDisabled,
  confirmLoading,
  confirmColor = '#2563EB',
  confirmIcon,
}) => (
  <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 10 }}>
    <button
      onClick={onCancel}
      style={{
        padding: '13px 0', borderRadius: 14,
        border: '1.5px solid #E2E8F0',
        background: 'var(--surface)', color: '#64748B',
        fontSize: 13, fontWeight: 700,
        cursor: 'pointer', minHeight: 'unset',
      }}
    >
      {cancelLabel}
    </button>
    <button
      onClick={onConfirm}
      disabled={confirmDisabled || confirmLoading}
      style={{
        padding: '13px 0', borderRadius: 14, border: 'none',
        background: confirmDisabled || confirmLoading ? '#9CA3AF' : confirmColor,
        color: '#fff', fontSize: 13, fontWeight: 700,
        cursor: confirmDisabled || confirmLoading ? 'not-allowed' : 'pointer',
        minHeight: 'unset',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      }}
    >
      {confirmLoading ? (
        <>
          <div style={{
            width: 16, height: 16,
            border: '2px solid rgba(255,255,255,0.3)',
            borderTopColor: '#fff',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
          }} />
          جاري الحفظ...
        </>
      ) : (
        <>{confirmIcon}{confirmLabel}</>
      )}
    </button>
  </div>
);

/** Full-width single confirm button */
export const BottomModalConfirmBtn: React.FC<{
  label: string;
  onClick: () => void;
  loading?: boolean;
  disabled?: boolean;
  color?: string;
  icon?: React.ReactNode;
}> = ({ label, onClick, loading, disabled, color = '#2563EB', icon }) => (
  <button
    onClick={onClick}
    disabled={disabled || loading}
    style={{
      width: '100%', padding: '14px 0', borderRadius: 14, border: 'none',
      background: disabled || loading ? '#9CA3AF' : color,
      color: '#fff', fontSize: 14, fontWeight: 800,
      cursor: disabled || loading ? 'not-allowed' : 'pointer',
      minHeight: 'unset',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    }}
  >
    {loading ? (
      <>
        <div style={{
          width: 18, height: 18,
          border: '2px solid rgba(255,255,255,0.3)',
          borderTopColor: '#fff',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite',
        }} />
        جاري المعالجة...
      </>
    ) : (
      <>{icon}{label}</>
    )}
  </button>
);
