import React from 'react';
import {
  ShoppingCart, ArrowDownLeft, AlertTriangle,
} from 'lucide-react';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../ui/Modal';
import type { InventoryItem } from '../../contexts/AppDataContext';
import type { ModalMode } from './shared';

interface TxModalProps {
  modal: { mode: ModalMode; itemId: string };
  selectedItem: InventoryItem;
  txQty: string; setTxQty: (v: string) => void;
  txPrice: string; setTxPrice: (v: string) => void;
  txNote: string; setTxNote: (v: string) => void;
  isSaving: boolean;
  exchangeRate: number;
  formatUSD: (n: number) => string;
  formatSYP: (n: number) => string;
  onClose: () => void;
  onConfirm: () => void;
}

export function TxModal({
  modal, selectedItem, txQty, setTxQty, txPrice, setTxPrice, txNote, setTxNote,
  isSaving, exchangeRate, formatUSD, formatSYP, onClose, onConfirm,
}: TxModalProps) {
  if (modal.mode !== 'buy' && modal.mode !== 'use') return null;
  const isBuy = modal.mode === 'buy';
  const color = isBuy ? '#15803d' : '#c2410c';
  const bgColor = isBuy ? '#f0fdf4' : '#fef2f2';
  const totalCost = (parseFloat(txQty) || 0) * (parseFloat(txPrice) || selectedItem.current_price);
  const afterQty = isBuy
    ? selectedItem.stock_quantity + (parseFloat(txQty) || 0)
    : selectedItem.stock_quantity - (parseFloat(txQty) || 0);

  return (
    <BottomSheetModal isOpen onClose={onClose}>
      <SheetHeader onClose={onClose}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: bgColor, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {isBuy ? <ShoppingCart size={18} color={color} /> : <ArrowDownLeft size={18} color={color} />}
          </div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>
              {isBuy ? 'شراء مواد' : 'صرف للإنتاج'}
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{selectedItem.name}</div>
          </div>
        </div>
      </SheetHeader>
      <SheetBody>
        {/* Current stock */}
        <div style={{ background: 'var(--surface-secondary)', borderRadius: 12, padding: 12, marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 2 }}>الكمية الحالية</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--text-primary)' }}>
              {selectedItem.stock_quantity.toFixed(1)} <span style={{ fontSize: 13, fontWeight: 500 }}>{selectedItem.unit}</span>
            </div>
          </div>
          <div style={{ textAlign: 'left' }}>
            <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 2 }}>بعد العملية</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: afterQty < 0 ? '#ef4444' : color }}>
              {afterQty.toFixed(1)} <span style={{ fontSize: 13, fontWeight: 500 }}>{selectedItem.unit}</span>
            </div>
          </div>
        </div>

        {/* Qty */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>
            الكمية ({selectedItem.unit}) *
          </label>
          <input type="number" value={txQty} onChange={e => setTxQty(e.target.value)}
            placeholder="أدخل الكمية"
            style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 16, outline: 'none', boxSizing: 'border-box' }} />
          {/* Quick amounts */}
          <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
            {[10, 25, 50, 100, 200].map(q => (
              <button key={q} onClick={() => setTxQty(String(q))}
                style={{ padding: '4px 10px', borderRadius: 8, border: `1.5px solid ${txQty === String(q) ? color : 'var(--border-color)'}`, background: txQty === String(q) ? bgColor : '#fff', color: txQty === String(q) ? color : 'var(--text-tertiary)', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Price (buy only) */}
        {isBuy && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>
              سعر الوحدة ($)
            </label>
            <input type="number" value={txPrice} onChange={e => setTxPrice(e.target.value)}
              placeholder={`السعر الحالي: $${selectedItem.current_price}`}
              style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 16, outline: 'none', boxSizing: 'border-box' }} />
          </div>
        )}

        {/* Note */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>ملاحظات</label>
          <textarea value={txNote} onChange={e => setTxNote(e.target.value)}
            rows={2} placeholder={isBuy ? 'اسم المورد، رقم الفاتورة...' : 'لأي خط إنتاج، سبب الصرف...'}
            style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', resize: 'none', boxSizing: 'border-box' }} />
        </div>

        {/* Summary */}
        {parseFloat(txQty) > 0 && (
          <div style={{ background: bgColor, borderRadius: 12, padding: 12, border: `1px solid ${color}30` }}>
            <div style={{ fontSize: 11, fontWeight: 600, color, marginBottom: 8 }}>ملخص العملية</div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>الكمية</span>
              <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-primary)' }}>{txQty} {selectedItem.unit}</span>
            </div>
            {isBuy && (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>السعر للوحدة</span>
                  <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-primary)' }}>${parseFloat(txPrice) || selectedItem.current_price}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 6, borderTop: '1px solid var(--border-color)' }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>الإجمالي</span>
                  <div>
                    <span style={{ fontSize: 14, fontWeight: 800, color }}>{formatUSD(totalCost)}</span>
                    <div style={{ fontSize: 10, color: 'var(--text-tertiary)', textAlign: 'left' }}>{formatSYP(totalCost * exchangeRate)}</div>
                  </div>
                </div>
              </>
            )}
            {!isBuy && afterQty < selectedItem.reorder_level && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8, padding: '6px 10px', background: '#fffbeb', borderRadius: 8 }}>
                <AlertTriangle size={12} color="#f59e0b" />
                <span style={{ fontSize: 11, color: '#b45309' }}>سيكون المخزون أقل من حد إعادة الطلب</span>
              </div>
            )}
          </div>
        )}
      </SheetBody>
      <SheetFooter>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onClose}
            style={{ flex: 1, padding: '13px', borderRadius: 12, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
            إلغاء
          </button>
          <button onClick={onConfirm} disabled={!txQty || parseFloat(txQty) <= 0 || isSaving || (!isBuy && parseFloat(txQty) > selectedItem.stock_quantity)}
            style={{
              flex: 2, padding: '13px', borderRadius: 12, border: 'none',
              background: !txQty || isSaving ? 'var(--border-color)' : color,
              color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            }}>
            {isSaving ? <><span style={{ animation: 'spin 1s linear infinite', display: 'inline-block', borderTop: '2px solid #fff', borderRight: '2px solid transparent', width: 16, height: 16, borderRadius: '50%' }} /> جاري الحفظ...</> : isBuy ? <><ShoppingCart size={15} /> تأكيد الشراء</> : <><ArrowDownLeft size={15} /> تأكيد الصرف</>}
          </button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
}
