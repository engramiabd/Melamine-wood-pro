import React from 'react';
import type { Dispatch, SetStateAction } from 'react';
import { CheckCircle, Plus } from 'lucide-react';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../ui/Modal';
import { CATEGORIES, UNITS } from './shared';
import type { ModalMode } from './shared';

export interface InventoryFormState {
  name: string; unit: string; category: string;
  stock_quantity: string; reorder_level: string; max_quantity: string;
  current_price: string; supplier: string; storage_location: string; description: string;
}

interface AddEditModalProps {
  modal: { mode: ModalMode; itemId: string };
  form: InventoryFormState;
  setForm: Dispatch<SetStateAction<InventoryFormState>>;
  isSaving: boolean;
  onClose: () => void;
  onSubmit: () => void;
}

const NUMERIC_FIELDS: { label: string; key: keyof InventoryFormState; disabledOnEdit: boolean }[] = [
  { label: 'الكمية الحالية', key: 'stock_quantity', disabledOnEdit: true },
  { label: 'حد إعادة الطلب', key: 'reorder_level', disabledOnEdit: false },
  { label: 'الكمية القصوى', key: 'max_quantity', disabledOnEdit: false },
];

export function AddEditModal({ modal, form, setForm, isSaving, onClose, onSubmit }: AddEditModalProps) {
  if (modal.mode !== 'add' && modal.mode !== 'edit') return null;
  const isEdit = modal.mode === 'edit';

  return (
    <BottomSheetModal isOpen onClose={onClose}>
      <SheetHeader onClose={onClose}>
        <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>
          {isEdit ? 'تعديل المادة' : 'إضافة مادة جديدة'}
        </div>
      </SheetHeader>
      <SheetBody>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Name */}
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>اسم المادة *</label>
            <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              placeholder="مثال: صفيحة ميلامين بيضاء"
              style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 16, outline: 'none', boxSizing: 'border-box' }} />
          </div>

          {/* Category + Unit */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>الفئة</label>
              <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', background: 'var(--surface)', boxSizing: 'border-box' }}>
                {CATEGORIES.filter(c => c !== 'الكل').map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>وحدة القياس</label>
              <select value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))}
                style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', background: 'var(--surface)', boxSizing: 'border-box' }}>
                {UNITS.map(u => <option key={u}>{u}</option>)}
              </select>
            </div>
          </div>

          {/* Quantities */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
            {NUMERIC_FIELDS.map(f => {
              const disabled = f.disabledOnEdit && isEdit;
              return (
                <div key={f.key}>
                  <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>{f.label}</label>
                  <input type="number" value={form[f.key]} disabled={disabled}
                    onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                    style={{ width: '100%', padding: '10px 12px', borderRadius: 10, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box', background: disabled ? 'var(--surface-secondary)' : '#fff', color: disabled ? 'var(--text-tertiary)' : '#0f172a' }} />
                </div>
              );
            })}
          </div>

          {/* Price */}
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>السعر الحالي ($)</label>
            <input type="number" value={form.current_price} onChange={e => setForm(f => ({ ...f, current_price: e.target.value }))}
              placeholder="0.00"
              style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 16, outline: 'none', boxSizing: 'border-box' }} />
          </div>

          {/* Supplier + Location */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>المورد</label>
              <input value={form.supplier} onChange={e => setForm(f => ({ ...f, supplier: e.target.value }))}
                placeholder="اسم المورد"
                style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>موقع التخزين</label>
              <input value={form.storage_location} onChange={e => setForm(f => ({ ...f, storage_location: e.target.value }))}
                placeholder="مستودع A"
                style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
            </div>
          </div>

          {/* Description */}
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>وصف (اختياري)</label>
            <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              rows={2} placeholder="وصف المادة..."
              style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', resize: 'none', boxSizing: 'border-box' }} />
          </div>
        </div>
      </SheetBody>
      <SheetFooter>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onClose}
            style={{ flex: 1, padding: '13px', borderRadius: 12, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
            إلغاء
          </button>
          <button onClick={onSubmit}
            disabled={!form.name || isSaving}
            style={{
              flex: 2, padding: '13px', borderRadius: 12, border: 'none',
              background: !form.name || isSaving ? 'var(--border-color)' : '#3b82f6',
              color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            }}>
            {isSaving
              ? <><span style={{ animation: 'spin 1s linear infinite', display: 'inline-block', borderTop: '2px solid #fff', borderRight: '2px solid transparent', width: 16, height: 16, borderRadius: '50%' }} /> جاري الحفظ...</>
              : isEdit ? <><CheckCircle size={15} /> حفظ التعديلات</> : <><Plus size={15} /> إضافة المادة</>
            }
          </button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
}
