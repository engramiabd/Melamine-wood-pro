import React from 'react';
import { motion } from 'framer-motion';

// ── Types ──────────────────────────────────────────────────────────────────
export type ViewMode = 'cards' | 'table' | 'analytics' | 'warehouses';
export type FilterStatus = 'all' | 'good' | 'low' | 'critical';
export type ModalMode = 'buy' | 'use' | 'edit' | 'add' | 'detail';

export interface TransactionEntry {
  id: string;
  type: 'in' | 'out';
  qty: number;
  price?: number;
  date: string;
  note: string;
  by: string;
}

export const CATEGORIES = ['الكل', 'مواد أساسية', 'كيميائية', 'ورقية', 'معدنية', 'تعبئة وتغليف'];
export const UNITS = ['كغ', 'متر', 'لتر', 'قطعة', 'طن', 'رول', 'صفيحة'];
export const CATEGORY_COLORS: Record<string, string> = {
  'مواد أساسية': '#3b82f6',
  'كيميائية': '#8b5cf6',
  'ورقية': '#f59e0b',
  'معدنية': 'var(--text-tertiary)',
  'تعبئة وتغليف': '#06b6d4',
};

export function getStatus(qty: number, reorder: number): FilterStatus {
  if (qty <= 0) return 'critical';
  if (qty <= reorder * 0.5) return 'critical';
  if (qty <= reorder) return 'low';
  return 'good';
}

export const STATUS_CONFIG = {
  good:     { label: 'جيد',    color: '#22c55e', bg: '#f0fdf4', border: '#bbf7d0', text: '#15803d' },
  low:      { label: 'منخفض', color: '#f59e0b', bg: '#fffbeb', border: '#fde68a', text: '#b45309' },
  critical: { label: 'حرج',   color: '#ef4444', bg: '#fef2f2', border: '#fecaca', text: '#b91c1c' },
};

// ── AnimNum ────────────────────────────────────────────────────────────────
export function AnimNum({ value, decimals = 0 }: { value: number; decimals?: number }) {
  const [display, setDisplay] = React.useState(0);
  React.useEffect(() => {
    let raf = 0;
    const dur = 480; // ~30 frames at 60fps, matching the previous timing
    const start = performance.now();
    const tick = (now: number) => {
      const progress = Math.min((now - start) / dur, 1);
      setDisplay(value * progress);
      if (progress < 1) raf = requestAnimationFrame(tick);
      else setDisplay(value);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return <>{display.toFixed(decimals)}</>;
}

// ── CircleProgress ─────────────────────────────────────────────────────────
export function CircleProgress({ pct, color, size = 56 }: { pct: number; color: string; size?: number }) {
  const r = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (Math.min(pct, 100) / 100) * circ;
  return (
    <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--border-color)" strokeWidth={5} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={5}
        strokeDasharray={circ} strokeDashoffset={offset}
        strokeLinecap="round" style={{ transition: 'stroke-dashoffset 1s ease' }} />
    </svg>
  );
}

// ── StockBar ───────────────────────────────────────────────────────────────
export function StockBar({ qty, reorder, max }: { qty: number; reorder: number; max: number }) {
  const pct = max > 0 ? Math.min((qty / max) * 100, 100) : 0;
  const reorderPct = max > 0 ? Math.min((reorder / max) * 100, 100) : 0;
  const status = getStatus(qty, reorder);
  const color = STATUS_CONFIG[status].color;
  return (
    <div style={{ position: 'relative', height: 6, background: 'var(--border-color)', borderRadius: 99, overflow: 'visible' }}>
      <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: 'easeOut' }}
        style={{ height: '100%', background: color, borderRadius: 99, position: 'absolute', top: 0, right: 0 }} />
      <div style={{
        position: 'absolute', top: -3, width: 2, height: 12,
        background: 'var(--text-tertiary)', borderRadius: 1,
        right: `${100 - reorderPct}%`,
      }} />
    </div>
  );
}
