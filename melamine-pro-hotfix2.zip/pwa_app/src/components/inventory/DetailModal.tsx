import React from 'react';
import {
  ShoppingCart, ArrowDownLeft, Edit2,
  BarChart2, Building, MapPin, Tag, Hash, DollarSign,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell,
} from 'recharts';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../ui/Modal';
import type { InventoryItem } from '../../contexts/AppDataContext';
import { getStatus, STATUS_CONFIG, CircleProgress } from './shared';
import type { ModalMode } from './shared';

interface DetailModalProps {
  selectedItem: InventoryItem;
  isAdmin: boolean;
  formatUSD: (n: number) => string;
  onClose: () => void;
  onOpenModal: (m: { mode: ModalMode; itemId: string }) => void;
  onOpenEdit: (itemId: string) => void;
}

export function DetailModal({
  selectedItem, isAdmin, formatUSD, onClose, onOpenModal, onOpenEdit,
}: DetailModalProps) {
  const status = getStatus(selectedItem.stock_quantity, selectedItem.reorder_level);
  const cfg = STATUS_CONFIG[status];
  const pct = selectedItem.max_quantity > 0 ? Math.min((selectedItem.stock_quantity / selectedItem.max_quantity) * 100, 100) : 0;

  const chartData = [
    { label: 'الحالي', value: selectedItem.stock_quantity },
    { label: 'الحد الأدنى', value: selectedItem.reorder_level },
    { label: 'الأقصى', value: selectedItem.max_quantity },
  ];

  // Some optional fields (supplier, storage_location, category) are not part
  // of the strict InventoryItem type but may be present on demo/real records.
  const extra = selectedItem as InventoryItem & { supplier?: string; storage_location?: string; category?: string };

  return (
    <BottomSheetModal isOpen onClose={onClose}>
      <SheetHeader onClose={onClose}>
        <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>تفاصيل {selectedItem.name}</div>
      </SheetHeader>
      <SheetBody>
        {/* Stock gauge */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, background: 'var(--surface-secondary)', borderRadius: 14, padding: 14, marginBottom: 16 }}>
          <div style={{ position: 'relative' }}>
            <CircleProgress pct={pct} color={cfg.color} size={72} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontSize: 16, fontWeight: 800, color: cfg.color }}>{Math.round(pct)}%</span>
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--text-primary)' }}>
              {selectedItem.stock_quantity.toFixed(1)} <span style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-tertiary)' }}>{selectedItem.unit}</span>
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
              <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 99, background: cfg.bg, color: cfg.text, fontWeight: 600 }}>{cfg.label}</span>
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 4 }}>
              حد إعادة الطلب: {selectedItem.reorder_level} {selectedItem.unit}
            </div>
          </div>
        </div>

        {/* Bar chart */}
        <div style={{ background: 'var(--surface)', borderRadius: 14, padding: 12, marginBottom: 16, border: '1px solid var(--border-color)' }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-tertiary)', marginBottom: 10 }}>مقارنة مستويات المخزون</div>
          <ResponsiveContainer width="100%" height={140}>
            <BarChart data={chartData} barSize={36}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip />
              <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                {chartData.map((_, i) => (
                  <Cell key={i} fill={i === 0 ? cfg.color : i === 1 ? '#f59e0b' : '#3b82f6'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Info grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
          {[
            { icon: <DollarSign size={14} />, label: 'سعر الوحدة', value: formatUSD(selectedItem.current_price) },
            { icon: <BarChart2 size={14} />, label: 'القيمة الإجمالية', value: formatUSD(selectedItem.stock_quantity * selectedItem.current_price) },
            { icon: <Building size={14} />, label: 'المورد', value: extra.supplier || '—' },
            { icon: <MapPin size={14} />, label: 'موقع التخزين', value: extra.storage_location || '—' },
            { icon: <Tag size={14} />, label: 'الفئة', value: extra.category || '—' },
            { icon: <Hash size={14} />, label: 'وحدة القياس', value: selectedItem.unit },
          ].map(info => (
            <div key={info.label} style={{ background: 'var(--surface-secondary)', borderRadius: 10, padding: '10px 12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4, color: 'var(--text-tertiary)' }}>
                {info.icon}
                <span style={{ fontSize: 11 }}>{info.label}</span>
              </div>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>{info.value}</div>
            </div>
          ))}
        </div>

        {/* Quick actions */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <button onClick={() => { onClose(); setTimeout(() => onOpenModal({ mode: 'buy', itemId: selectedItem.id }), 100); }}
            style={{ padding: '12px', borderRadius: 12, border: 'none', background: '#f0fdf4', color: '#15803d', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <ShoppingCart size={14} /> شراء
          </button>
          <button onClick={() => { onClose(); setTimeout(() => onOpenModal({ mode: 'use', itemId: selectedItem.id }), 100); }}
            style={{ padding: '12px', borderRadius: 12, border: 'none', background: '#fff7ed', color: '#c2410c', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <ArrowDownLeft size={14} /> صرف للإنتاج
          </button>
        </div>
      </SheetBody>
      <SheetFooter>
        {isAdmin && (
          <button onClick={() => { onClose(); setTimeout(() => onOpenEdit(selectedItem.id), 100); }}
            style={{ width: '100%', padding: '13px', borderRadius: 12, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 14, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <Edit2 size={15} /> تعديل البيانات
          </button>
        )}
      </SheetFooter>
    </BottomSheetModal>
  );
}
