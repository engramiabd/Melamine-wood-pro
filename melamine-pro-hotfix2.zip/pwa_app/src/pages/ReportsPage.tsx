import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell,
  AreaChart, Area, Legend,
} from 'recharts';
import {
  FileText, Download, TrendingUp, TrendingDown, Factory,
  Package, Users, DollarSign, Filter, ChevronDown, Printer,
  RefreshCw, Calendar, Target, ArrowUpRight, ArrowDownRight,
  Award, ShoppingCart, CheckCircle, X, BarChart2, Clock,
  Wallet, AlertTriangle, Activity,
} from 'lucide-react';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAppData } from '../contexts/AppDataContext';
import {
  printOrder, printPayroll, printAttendance, printJournal,
  exportOrdersToCSV, exportJournalToCSV, exportAttendanceToCSV,
  exportEmployeesToCSV, exportToCSV,
} from '../utils/print';

const COLORS = ['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#ec4899','#84cc16'];
const MONTH_NAMES = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const DAY_NAMES   = ['السبت','الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'];

/* ── Custom Tooltip ─────────────────────────────────────────────────────── */
const ChartTooltip = ({ active, payload, label }: {
  active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string;
}) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-gray-900/95 backdrop-blur-md text-white text-xs rounded-xl px-3 py-2.5 shadow-xl border border-white/10" dir="rtl">
      {label && <p className="font-bold mb-1.5 text-gray-300">{label}</p>}
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2 mb-0.5">
          <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }} />
          <span className="text-gray-400">{p.name}:</span>
          <span className="font-bold text-white">
            {typeof p.value === 'number' && p.value > 999
              ? `$${p.value.toLocaleString()}`
              : p.value}
          </span>
        </div>
      ))}
    </div>
  );
};

type Period = 'week' | 'month' | 'quarter' | 'year';
type RType  = 'financial' | 'production' | 'hr' | 'inventory';

/* ══════════════════════════════════════════════════════════════════════════
   ReportsPage
═══════════════════════════════════════════════════════════════════════════ */
const ReportsPage: React.FC = () => {
  const { format, exchangeRate } = useCurrency();
  const {
    orders, journalEntries, employees, attendanceRecords,
    leaveRequests, inventoryItems, productionLines, wallets,
    walletTransactions,
  } = useAppData();

  const [period,      setPeriod]      = useState<Period>('month');
  const [reportType,  setReportType]  = useState<RType>('financial');
  const [showExport,  setShowExport]  = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportOk,    setExportOk]    = useState(false);

  /* ── Period filter helper ─────────────────────────────────────────── */
  const periodDays = period === 'week' ? 7 : period === 'month' ? 30 : period === 'quarter' ? 90 : 365;
  const cutoff = useMemo(() => {
    const d = new Date(); d.setDate(d.getDate() - periodDays); return d;
  }, [periodDays]);

  const inPeriod = (dateStr: string) => new Date(dateStr) >= cutoff;

  /* ── Financial ────────────────────────────────────────────────────── */
  const filteredEntries = useMemo(() => journalEntries.filter(e => inPeriod(e.created_at)), [journalEntries, cutoff]);
  const income  = useMemo(() => filteredEntries.filter(e => e.type === 'income').reduce((s,e) => s + e.amount_usd, 0), [filteredEntries]);
  const expense = useMemo(() => filteredEntries.filter(e => e.type === 'expense').reduce((s,e) => s + e.amount_usd, 0), [filteredEntries]);
  const net     = income - expense;
  const margin  = income > 0 ? Math.round((net / income) * 100) : 0;

  const filteredOrders     = useMemo(() => orders.filter(o => inPeriod(o.created_at)), [orders, cutoff]);
  const completedOrders    = useMemo(() => filteredOrders.filter(o => o.status === 'completed'), [filteredOrders]);
  const avgOrderValue      = useMemo(() =>
    completedOrders.length > 0 ? Math.round(completedOrders.reduce((s,o) => s+o.total_usd,0) / completedOrders.length) : 0,
  [completedOrders]);

  /* ── Monthly / weekly chart data ──────────────────────────────────── */
  const monthlyData = useMemo(() => {
    const buckets = period === 'week' ? 7 : period === 'month' ? 6 : period === 'quarter' ? 3 : 12;
    const now = new Date();
    const result: { label: string; revenue: number; expenses: number; orders: number; profit: number }[] = [];

    // Build the bucket keys + labels first, and an index from key -> bucket position
    const keys: string[] = [];
    const labels: string[] = [];
    if (period === 'week') {
      for (let i = 6; i >= 0; i--) {
        const d = new Date(now); d.setDate(d.getDate() - i);
        keys.push(d.toISOString().split('T')[0]); // dateStr
        labels.push(DAY_NAMES[d.getDay()]);
      }
    } else {
      for (let i = buckets - 1; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        keys.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`); // monthStr
        labels.push(MONTH_NAMES[d.getMonth()]);
      }
    }
    const keyIndex = new Map(keys.map((k, idx) => [k, idx]));
    const revenue = new Array(keys.length).fill(0);
    const expenses = new Array(keys.length).fill(0);
    const orderCounts = new Array(keys.length).fill(0);

    // Single pass over journalEntries
    const keyLen = period === 'week' ? 10 : 7; // 'YYYY-MM-DD'.length vs 'YYYY-MM'.length
    for (const e of journalEntries) {
      const idx = keyIndex.get(e.created_at.slice(0, keyLen));
      if (idx === undefined) continue;
      if (e.type === 'income') revenue[idx] += e.amount_usd;
      else if (e.type === 'expense') expenses[idx] += e.amount_usd;
    }
    // Single pass over orders
    for (const o of orders) {
      const idx = keyIndex.get(o.created_at.slice(0, keyLen));
      if (idx === undefined) continue;
      orderCounts[idx] += 1;
    }

    for (let i = 0; i < keys.length; i++) {
      result.push({
        label: labels[i],
        revenue: Math.round(revenue[i]),
        expenses: Math.round(expenses[i]),
        orders: orderCounts[i],
        profit: Math.round(revenue[i] - expenses[i]),
      });
    }
    return result;
  }, [journalEntries, orders, period]);

  const expenseByCategory = useMemo(() => {
    const cats: Record<string,number> = {};
    filteredEntries.filter(e => e.type === 'expense').forEach(e => {
      cats[e.category] = (cats[e.category]||0) + e.amount_usd;
    });
    return Object.entries(cats)
      .sort((a,b) => b[1]-a[1])
      .map(([name,value],i) => ({ name, value: Math.round(value), color: COLORS[i%COLORS.length] }));
  }, [filteredEntries]);

  const incomeByCategory = useMemo(() => {
    const cats: Record<string,number> = {};
    filteredEntries.filter(e => e.type === 'income').forEach(e => {
      cats[e.category] = (cats[e.category]||0) + e.amount_usd;
    });
    return Object.entries(cats)
      .sort((a,b) => b[1]-a[1])
      .map(([name,value],i) => ({ name, value: Math.round(value), color: COLORS[i%COLORS.length] }));
  }, [filteredEntries]);

  /* ── Production ───────────────────────────────────────────────────── */
  const productionChartData = useMemo(() =>
    productionLines.map(l => ({
      name: l.name.replace('خط الإنتاج ',''),
      فعلي: l.total_produced_today || 0,
      هدف: l.capacity_per_day || 200,
      كفاءة: l.efficiency_percentage || 0,
    })), [productionLines]);

  const productMix = useMemo(() => {
    const mix: Record<string,number> = {};
    orders.forEach(o => {
      o.items?.forEach(item => {
        const name = item.product?.name || item.product_id || 'غير محدد';
        mix[name] = (mix[name]||0) + (item.quantity||0);
      });
    });
    const total = Object.values(mix).reduce((s,v) => s+v, 0) || 1;
    return Object.entries(mix)
      .sort((a,b) => b[1]-a[1]).slice(0,5)
      .map(([name,val],i) => ({ name, value: Math.round((val/total)*100), raw: val, color: COLORS[i] }));
  }, [orders]);

  /* ── HR ───────────────────────────────────────────────────────────── */
  const hrStats = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const todayRec = attendanceRecords.filter(r => r.check_in?.startsWith(today) || r.date === today);
    const presentCount = todayRec.filter(r => r.status === 'present' || r.status === 'late').length;
    const lateCount    = todayRec.filter(r => r.status === 'late').length;
    const absentCount  = Math.max(0, employees.length - todayRec.length);
    const pendingLeaves= leaveRequests.filter(l => l.status === 'pending').length;
    const totalWages   = employees.reduce((s,e) => s+(e.salary_usd||0), 0);
    const deptMap: Record<string,number> = {};
    employees.forEach(e => { deptMap[e.department] = (deptMap[e.department]||0)+1; });
    const deptData = Object.entries(deptMap).map(([name,count]) => ({ name, count }));
    return { presentCount, lateCount, absentCount, pendingLeaves, totalWages, total: employees.length, deptData };
  }, [employees, attendanceRecords, leaveRequests]);

  const attendanceChartData = useMemo(() => {
    const now = new Date();
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(now); d.setDate(d.getDate() - (6 - i));
      const dateStr = d.toISOString().split('T')[0];
      const dayRec = attendanceRecords.filter(r => r.check_in?.startsWith(dateStr) || r.date === dateStr);
      return {
        day: DAY_NAMES[d.getDay()],
        حاضر: dayRec.filter(r => r.status === 'present').length,
        متأخر: dayRec.filter(r => r.status === 'late').length,
        غائب: Math.max(0, employees.length - dayRec.length),
      };
    });
  }, [attendanceRecords, employees]);

  /* ── Inventory ────────────────────────────────────────────────────── */
  const inventoryStats = useMemo(() => {
    const total    = inventoryItems.length;
    const low      = inventoryItems.filter(i => i.stock_quantity <= i.reorder_level).length;
    const critical = inventoryItems.filter(i => i.stock_quantity <= i.reorder_level * 0.5).length;
    const value    = inventoryItems.reduce((s,i) => s + i.stock_quantity * i.current_price, 0);
    const catMap: Record<string,number> = {};
    inventoryItems.forEach(i => { catMap[i.category] = (catMap[i.category]||0) + i.stock_quantity * i.current_price; });
    const catData = Object.entries(catMap).map(([name,value],idx) => ({ name, value: Math.round(value), color: COLORS[idx%COLORS.length] }));
    return { total, low, critical, value, catData };
  }, [inventoryItems]);

  const inventoryChartData = useMemo(() =>
    [...inventoryItems].sort((a,b) => b.stock_quantity*b.current_price - a.stock_quantity*a.current_price)
      .slice(0,8)
      .map(i => ({
        name: i.name.length > 10 ? i.name.slice(0,10)+'…' : i.name,
        الحالي: i.stock_quantity,
        الحد: i.reorder_level,
        الأقصى: i.max_quantity,
      })),
  [inventoryItems]);

  /* ── Wallet ───────────────────────────────────────────────────────── */
  const walletStats = useMemo(() => {
    const totalBalance = wallets.reduce((s,w) => s+w.balanceUSD, 0);
    const avgBalance   = wallets.length > 0 ? totalBalance / wallets.length : 0;
    const totalAdvances= walletTransactions?.filter(t => t.type === 'advance').reduce((s,t) => s+t.amount_usd, 0) || 0;
    const totalBonuses = walletTransactions?.filter(t => t.type === 'bonus').reduce((s,t) => s+t.amount_usd, 0) || 0;
    return { totalBalance, avgBalance, totalAdvances, totalBonuses };
  }, [wallets, walletTransactions]);

  /* ── Order summary table ──────────────────────────────────────────── */
  const orderSummary = useMemo(() => {
    const byMonth: Record<string, { month: string; total: number; completed: number; pending: number; cancelled: number; revenue: number }> = {};
    orders.forEach(o => {
      const d = new Date(o.created_at);
      const key = `${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}`;
      if (!byMonth[key]) byMonth[key] = { month: key, total: 0, completed: 0, pending: 0, cancelled: 0, revenue: 0 };
      byMonth[key].total++;
      if (o.status === 'completed')  { byMonth[key].completed++; byMonth[key].revenue += o.total_usd; }
      if (o.status === 'pending')      byMonth[key].pending++;
      if (o.status === 'cancelled')    byMonth[key].cancelled++;
    });
    return Object.values(byMonth).slice(-6).reverse();
  }, [orders]);

  /* ── KPI cards ────────────────────────────────────────────────────── */
  const kpiCards = useMemo(() => {
    const labelPeriod = period === 'week' ? 'الأسبوع' : period === 'month' ? 'الشهر' : period === 'quarter' ? 'الربع' : 'السنة';
    if (reportType === 'financial') return [
      { label: 'إجمالي الإيرادات', value: format(income), sub: `خلال ${labelPeriod}`, trend: net > 0, icon: <DollarSign size={16}/>, g: 'from-emerald-500 to-teal-500' },
      { label: 'إجمالي المصروفات', value: format(expense), sub: `${Math.round((expense/Math.max(income,1))*100)}% من الإيرادات`, trend: false, icon: <TrendingDown size={16}/>, g: 'from-red-500 to-rose-500' },
      { label: 'صافي الربح', value: format(net), sub: `هامش ${margin}%`, trend: net > 0, icon: <TrendingUp size={16}/>, g: net > 0 ? 'from-blue-500 to-indigo-500' : 'from-red-500 to-rose-600' },
      { label: 'متوسط قيمة الطلب', value: format(avgOrderValue), sub: `${filteredOrders.length} طلب`, trend: true, icon: <ShoppingCart size={16}/>, g: 'from-amber-500 to-orange-500' },
    ];
    if (reportType === 'production') return [
      { label: 'خطوط الإنتاج', value: `${productionLines.length}`, sub: `${productionLines.filter(l=>l.status==='active').length} نشطة`, trend: true, icon: <Factory size={16}/>, g: 'from-blue-500 to-indigo-500' },
      { label: 'إنتاج اليوم', value: `${productionLines.reduce((s,l)=>s+(l.total_produced_today||0),0)}`, sub: 'لوح إجمالي', trend: true, icon: <Target size={16}/>, g: 'from-emerald-500 to-green-500' },
      { label: 'كفاءة المصنع', value: `${Math.round(productionLines.reduce((s,l)=>s+(l.efficiency_percentage||0),0)/Math.max(productionLines.length,1))}%`, sub: 'متوسط الكفاءة', trend: true, icon: <Award size={16}/>, g: 'from-violet-500 to-purple-500' },
      { label: 'طلبات مكتملة', value: `${completedOrders.length}`, sub: `${filteredOrders.length} إجمالي`, trend: true, icon: <CheckCircle size={16}/>, g: 'from-amber-500 to-orange-500' },
    ];
    if (reportType === 'hr') return [
      { label: 'الموظفون', value: `${hrStats.total}`, sub: `${hrStats.presentCount} حاضر اليوم`, trend: true, icon: <Users size={16}/>, g: 'from-blue-500 to-indigo-500' },
      { label: 'إجمالي الرواتب', value: format(hrStats.totalWages), sub: 'شهرياً', trend: true, icon: <DollarSign size={16}/>, g: 'from-emerald-500 to-green-500' },
      { label: 'إجازات معلقة', value: `${hrStats.pendingLeaves}`, sub: 'بانتظار الموافقة', trend: false, icon: <Calendar size={16}/>, g: 'from-amber-500 to-orange-500' },
      { label: 'متأخرون اليوم', value: `${hrStats.lateCount}`, sub: 'تسجيل متأخر', trend: false, icon: <Clock size={16}/>, g: 'from-red-500 to-rose-500' },
    ];
    return [
      { label: 'إجمالي المواد', value: `${inventoryStats.total}`, sub: 'صنف مختلف', trend: true, icon: <Package size={16}/>, g: 'from-blue-500 to-indigo-500' },
      { label: 'قيمة المخزون', value: format(inventoryStats.value), sub: 'القيمة الكلية', trend: true, icon: <DollarSign size={16}/>, g: 'from-emerald-500 to-green-500' },
      { label: 'مواد منخفضة', value: `${inventoryStats.low}`, sub: 'تحت الحد الأدنى', trend: false, icon: <AlertTriangle size={16}/>, g: 'from-amber-500 to-orange-500' },
      { label: 'مواد حرجة', value: `${inventoryStats.critical}`, sub: 'تحتاج تجديداً فورياً', trend: false, icon: <AlertTriangle size={16}/>, g: 'from-red-500 to-rose-500' },
    ];
  }, [reportType, income, expense, net, margin, format, avgOrderValue, filteredOrders, completedOrders, productionLines, hrStats, inventoryStats, period]);

  /* ── Export handlers ──────────────────────────────────────────────── */
  const handleExport = async (fmt: string) => {
    setIsExporting(true);
    setShowExport(false);
    await new Promise(r => setTimeout(r, 400));

    try {
      if (fmt === 'CSV') {
        // Export based on current report type
        if (reportType === 'financial') {
          exportJournalToCSV(filteredEntries);
        } else if (reportType === 'production') {
          exportOrdersToCSV(filteredOrders);
        } else if (reportType === 'hr') {
          exportEmployeesToCSV(employees);
        } else {
          exportToCSV(
            inventoryItems.map(i => ({
              'المادة': i.name,
              'الفئة': i.category,
              'الوحدة': i.unit,
              'الكمية الحالية': i.stock_quantity,
              'حد إعادة الطلب': i.reorder_level,
              'الكمية القصوى': i.max_quantity,
              'السعر الحالي': i.current_price,
              'القيمة الإجمالية': (i.stock_quantity * i.current_price).toFixed(2),
              'المورد': i.supplier || '',
              'الحالة': i.stock_quantity <= i.reorder_level * 0.5 ? 'حرج' : i.stock_quantity <= i.reorder_level ? 'منخفض' : 'جيد',
            })),
            `مخزون_${new Date().toISOString().split('T')[0]}`
          );
        }
      } else if (fmt === 'JSON') {
        const data = {
          period,
          reportType,
          generated_at: new Date().toISOString(),
          financial: { income, expense, net, margin },
          orders: filteredOrders.map(o => ({
            order_number: o.order_number,
            customer: o.customer_name,
            status: o.status,
            total_usd: o.total_usd,
            created_at: o.created_at,
          })),
          production: productionLines.map(l => ({
            name: l.name,
            status: l.status,
            efficiency: l.efficiency_percentage,
            produced_today: l.total_produced_today,
          })),
          hr: { total: hrStats.total, present: hrStats.presentCount, late: hrStats.lateCount },
          inventory: { total: inventoryStats.total, low: inventoryStats.low, value: inventoryStats.value },
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `تقرير_${reportType}_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
      } else if (fmt === 'print') {
        if (reportType === 'financial') {
          printJournal(filteredEntries, period === 'week' ? 'الأسبوع' : period === 'month' ? 'الشهر' : period === 'quarter' ? 'الربع' : 'السنة');
        } else if (reportType === 'hr') {
          printAttendance(
            attendanceRecords.filter(r => {
              const d = new Date(r.check_in || r.date || '');
              return d >= cutoff;
            }),
            `خلال ${period === 'week' ? 'الأسبوع' : 'الفترة المحددة'}`
          );
        } else if (reportType === 'production') {
          // Print production report as custom HTML
          const w = window.open('', '_blank', 'width=900,height=700');
          if (w) {
            const rows = productionLines.map((l,i) => `
              <tr>
                <td>${i+1}</td>
                <td>${l.name}</td>
                <td>${l.status === 'active' ? 'نشط' : l.status === 'stopped' ? 'متوقف' : 'صيانة'}</td>
                <td>${l.efficiency_percentage || 0}%</td>
                <td>${l.total_produced_today || 0}</td>
                <td>${l.capacity_per_day || 200}</td>
                <td>${l.operating_cost_usd ? `$${l.operating_cost_usd}` : '-'}</td>
              </tr>`).join('');
            w.document.write(`<!DOCTYPE html><html lang="ar">
              <head><meta charset="UTF-8"><title>تقرير الإنتاج</title>
              <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
              <style>* { box-sizing:border-box; } body { font-family:'Cairo',sans-serif; direction:rtl; padding:32px; color:#1e293b; }
              h1 { color:#1e40af; font-size:22px; } table { width:100%; border-collapse:collapse; font-size:12px; margin-top:16px; }
              th { background:#1e40af; color:#fff; padding:8px; text-align:right; }
              td { padding:7px 8px; border-bottom:1px solid var(--border-color); }
              tr:nth-child(even) td { background:var(--surface-secondary); }
              @media print { body { -webkit-print-color-adjust:exact; } }</style>
              </head><body>
              <div style="display:flex;justify-content:space-between;margin-bottom:20px">
                <div><h1>ميلامين برو</h1><p style="color:var(--text-tertiary)">تقرير خطوط الإنتاج</p></div>
                <div style="text-align:left"><p>${new Date().toLocaleDateString('ar-SY')}</p></div>
              </div>
              <table><thead><tr><th>#</th><th>الخط</th><th>الحالة</th><th>الكفاءة</th><th>أنتج اليوم</th><th>الطاقة/يوم</th><th>التكلفة</th></tr></thead>
              <tbody>${rows}</tbody></table>
              </body></html>`);
            w.document.close();
            setTimeout(() => w.print(), 600);
          }
        } else {
          // Inventory print
          const w = window.open('', '_blank', 'width=900,height=700');
          if (w) {
            const rows = inventoryItems.map((i,idx) => `
              <tr>
                <td>${idx+1}</td><td>${i.name}</td><td>${i.category}</td>
                <td>${i.stock_quantity} ${i.unit}</td><td>${i.reorder_level}</td>
                <td>$${i.current_price}</td>
                <td>$${(i.stock_quantity*i.current_price).toFixed(2)}</td>
                <td style="color:${i.stock_quantity<=i.reorder_level*0.5?'#dc2626':i.stock_quantity<=i.reorder_level?'#d97706':'#16a34a'}">
                  ${i.stock_quantity<=i.reorder_level*0.5?'حرج':i.stock_quantity<=i.reorder_level?'منخفض':'جيد'}
                </td>
              </tr>`).join('');
            w.document.write(`<!DOCTYPE html><html lang="ar">
              <head><meta charset="UTF-8"><title>تقرير المخزون</title>
              <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
              <style>* { box-sizing:border-box; } body { font-family:'Cairo',sans-serif; direction:rtl; padding:32px; color:#1e293b; }
              h1 { color:#1e40af; } table { width:100%; border-collapse:collapse; font-size:12px; margin-top:16px; }
              th { background:#1e40af; color:#fff; padding:8px; text-align:right; }
              td { padding:7px 8px; border-bottom:1px solid var(--border-color); }
              tr:nth-child(even) td { background:var(--surface-secondary); }
              @media print { body { -webkit-print-color-adjust:exact; } }</style>
              </head><body>
              <h1>ميلامين برو — تقرير المخزون</h1>
              <p style="color:var(--text-tertiary)">${new Date().toLocaleDateString('ar-SY')}</p>
              <table><thead><tr><th>#</th><th>المادة</th><th>الفئة</th><th>الكمية</th><th>حد الطلب</th><th>السعر</th><th>القيمة</th><th>الحالة</th></tr></thead>
              <tbody>${rows}</tbody></table>
              </body></html>`);
            w.document.close();
            setTimeout(() => w.print(), 600);
          }
        }
      }
    } catch (err) {
      console.error('Export error:', err);
    }

    setIsExporting(false);
    setExportOk(true);
    setTimeout(() => setExportOk(false), 3000);
  };

  /* ── UI helpers ───────────────────────────────────────────────────── */
  const PERIODS: { key: Period; label: string }[] = [
    { key: 'week', label: 'أسبوع' }, { key: 'month', label: 'شهر' },
    { key: 'quarter', label: 'ربع سنة' }, { key: 'year', label: 'سنة' },
  ];
  const TYPES: { key: RType; label: string; icon: React.ReactNode }[] = [
    { key: 'financial',  label: 'المالية',         icon: <DollarSign size={13}/> },
    { key: 'production', label: 'الإنتاج',         icon: <Factory size={13}/> },
    { key: 'hr',         label: 'الموارد البشرية', icon: <Users size={13}/> },
    { key: 'inventory',  label: 'المخزون',         icon: <Package size={13}/> },
  ];

  const chartLabel = reportType === 'financial' ? 'الإيرادات والمصروفات'
    : reportType === 'production' ? 'إنتاج خطوط المصنع'
    : reportType === 'hr'        ? 'الحضور الأسبوعي'
    : 'أعلى مواد بالكمية';

  /* ── Render ───────────────────────────────────────────────────────── */
  return (
    <div className="min-h-full bg-gray-50" dir="rtl">

      {/* ── Hero Header ─────────────────────────────────────────────── */}
      <div className="bg-gradient-to-br from-slate-800 via-slate-900 to-gray-950 px-4 pt-5 pb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <div className="w-7 h-7 rounded-lg bg-blue-500/20 flex items-center justify-center">
                <BarChart2 size={15} className="text-blue-400" />
              </div>
              <h1 className="text-base font-black text-white">التقارير والتحليلات</h1>
            </div>
            <p className="text-xs text-slate-400 mr-9">بيانات شاملة لأداء المصنع</p>
          </div>

          <div className="flex items-center gap-2">
            <AnimatePresence>
              {exportOk && (
                <motion.div initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}
                  className="flex items-center gap-1 bg-emerald-500/20 text-emerald-400 text-xs px-2 py-1 rounded-lg border border-emerald-500/30">
                  <CheckCircle size={11} /> تم التصدير
                </motion.div>
              )}
            </AnimatePresence>

            <div className="relative">
              <button
                onClick={() => setShowExport(v => !v)}
                disabled={isExporting}
                className="flex items-center gap-1.5 bg-white/10 hover:bg-white/15 text-white text-xs font-bold px-3 py-2 rounded-xl border border-white/20 transition-colors"
              >
                {isExporting
                  ? <RefreshCw size={12} className="animate-spin" />
                  : <Download size={12} />}
                تصدير
                <ChevronDown size={10} className={`transition-transform duration-200 ${showExport ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {showExport && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setShowExport(false)} />
                    <motion.div
                      initial={{ opacity: 0, y: -6, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -6, scale: 0.95 }}
                      className="absolute left-0 top-full mt-1.5 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden z-20 w-44"
                    >
                      <div className="px-3 py-2 border-b border-gray-50">
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wide">تصدير التقرير</p>
                      </div>
                      {[
                        { fmt: 'CSV',   icon: <FileText size={14}/>,  label: 'ملف CSV',    desc: 'جدول بيانات' },
                        { fmt: 'JSON',  icon: <Download size={14}/>,  label: 'ملف JSON',   desc: 'بيانات خام' },
                        { fmt: 'print', icon: <Printer size={14}/>,   label: 'طباعة',      desc: 'نسخة مطبوعة' },
                      ].map(({ fmt, icon, label, desc }) => (
                        <button key={fmt} onClick={() => handleExport(fmt)}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-xs text-gray-700 hover:bg-gray-50 transition-colors text-right">
                          <div className="w-7 h-7 rounded-lg bg-gray-100 flex items-center justify-center text-gray-500 flex-shrink-0">
                            {icon}
                          </div>
                          <div>
                            <div className="font-bold text-gray-800">{label}</div>
                            <div className="text-[10px] text-gray-400">{desc}</div>
                          </div>
                        </button>
                      ))}
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Period Toggle */}
        <div className="flex bg-white/10 rounded-2xl p-1 gap-1 mb-3">
          {PERIODS.map(p => (
            <button key={p.key} onClick={() => setPeriod(p.key)}
              className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all duration-150 ${
                period === p.key ? 'bg-white text-gray-900 shadow-sm' : 'text-white/60 hover:text-white/80'
              }`}>
              {p.label}
            </button>
          ))}
        </div>

        {/* Report Type Filter */}
        <div className="flex gap-2 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
          {TYPES.map(t => (
            <button key={t.key} onClick={() => setReportType(t.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border flex-shrink-0 ${
                reportType === t.key
                  ? 'bg-white text-gray-900 border-white shadow-sm'
                  : 'bg-white/10 text-white/70 border-white/20 hover:bg-white/15'
              }`}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 py-4 space-y-4" style={{ paddingBottom: 'var(--page-pb)' }}>

        {/* ── KPI Grid ──────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 gap-3">
          {kpiCards.map((k, i) => (
            <motion.div key={`${reportType}-${i}`}
              initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="bg-white rounded-2xl p-3.5 shadow-sm border border-gray-100 overflow-hidden relative">
              <div className={`absolute inset-0 bg-gradient-to-br ${k.g} opacity-[0.04]`} />
              <div className="absolute -top-3 -left-3 w-16 h-16 rounded-full opacity-[0.06]"
                style={{ background: `linear-gradient(135deg, ${k.g.includes('emerald') ? '#10b981' : k.g.includes('red') ? '#ef4444' : k.g.includes('blue') ? '#3b82f6' : '#f59e0b'}, transparent)` }} />
              <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${k.g} flex items-center justify-center text-white mb-2.5 shadow-sm`}>
                {k.icon}
              </div>
              <div className="text-lg font-black text-gray-900 leading-none mb-0.5 font-numeric">{k.value}</div>
              <div className="text-[10px] text-gray-500 font-medium leading-tight">{k.label}</div>
              <div className={`flex items-center gap-0.5 text-[10px] font-bold mt-1 ${k.trend ? 'text-emerald-600' : 'text-red-500'}`}>
                {k.trend ? <ArrowUpRight size={9}/> : <ArrowDownRight size={9}/>}
                {k.sub}
              </div>
            </motion.div>
          ))}
        </div>

        {/* ── Main Chart ────────────────────────────────────────────── */}
        <AnimatePresence mode="wait">
          <motion.div key={`${reportType}-chart`}
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.22 }}
            className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-gray-900">{chartLabel}</h3>
                <p className="text-[10px] text-gray-400 mt-0.5">بيانات حقيقية من النظام</p>
              </div>
              <div className="text-xs text-blue-600 font-bold bg-blue-50 px-2 py-1 rounded-lg">
                {period === 'week' ? '7 أيام' : period === 'month' ? '30 يوم' : period === 'quarter' ? '90 يوم' : 'سنة كاملة'}
              </div>
            </div>

            <div style={{ height: 200 }}>
              <ResponsiveContainer width="100%" height="100%">
                {reportType === 'hr' ? (
                  <BarChart data={attendanceChartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                    <XAxis dataKey="day" tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} />
                    <YAxis tick={{ fontSize: 10, fill: 'var(--text-tertiary)' }} />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="حاضر" stackId="a" fill="#10b981" radius={[0,0,0,0]} maxBarSize={28} />
                    <Bar dataKey="متأخر" stackId="a" fill="#f59e0b" radius={[0,0,0,0]} maxBarSize={28} />
                    <Bar dataKey="غائب"  stackId="a" fill="#ef4444" radius={[4,4,0,0]} maxBarSize={28} />
                  </BarChart>
                ) : reportType === 'inventory' ? (
                  <BarChart data={inventoryChartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                    <XAxis dataKey="name" tick={{ fontSize: 8, fill: 'var(--text-tertiary)' }} />
                    <YAxis tick={{ fontSize: 10, fill: 'var(--text-tertiary)' }} />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="الحالي" fill="#3b82f6" radius={[4,4,0,0]} maxBarSize={20} />
                    <Bar dataKey="الحد"   fill="#f59e0b" radius={[4,4,0,0]} maxBarSize={20} />
                  </BarChart>
                ) : reportType === 'production' ? (
                  <BarChart data={productionChartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: 'var(--text-tertiary)' }} />
                    <YAxis tick={{ fontSize: 10, fill: 'var(--text-tertiary)' }} />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="فعلي" fill="#3b82f6" radius={[4,4,0,0]} maxBarSize={24} />
                    <Bar dataKey="هدف"  fill="var(--border-color)" radius={[4,4,0,0]} maxBarSize={24} />
                  </BarChart>
                ) : (
                  <AreaChart data={monthlyData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                    <defs>
                      <linearGradient id="rptRevGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%"  stopColor="#10b981" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="rptExpGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%"  stopColor="#ef4444" stopOpacity={0.15} />
                        <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                    <XAxis dataKey="label" tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} />
                    <YAxis tick={{ fontSize: 10, fill: 'var(--text-tertiary)' }} />
                    <Tooltip content={<ChartTooltip />} />
                    <Area type="monotone" dataKey="revenue"  name="إيرادات"  stroke="#10b981" strokeWidth={2} fill="url(#rptRevGrad)" />
                    <Area type="monotone" dataKey="expenses" name="مصروفات"  stroke="#ef4444" strokeWidth={2} fill="url(#rptExpGrad)" />
                  </AreaChart>
                )}
              </ResponsiveContainer>
            </div>

            {/* Legend */}
            <div className="flex flex-wrap gap-3 mt-3 justify-center">
              {reportType === 'financial' && (
                <>
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-600">
                    <div className="w-3 h-1.5 rounded-full bg-emerald-500" />إيرادات
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-600">
                    <div className="w-3 h-1.5 rounded-full bg-red-500" />مصروفات
                  </div>
                </>
              )}
              {reportType === 'production' && (
                <>
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-600">
                    <div className="w-3 h-1.5 rounded-full bg-blue-500" />فعلي
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-600">
                    <div className="w-3 h-1.5 rounded-full bg-gray-300" />هدف
                  </div>
                </>
              )}
              {reportType === 'hr' && (
                <>
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-600">
                    <div className="w-3 h-1.5 rounded-full bg-emerald-500" />حاضر
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-600">
                    <div className="w-3 h-1.5 rounded-full bg-amber-500" />متأخر
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-600">
                    <div className="w-3 h-1.5 rounded-full bg-red-500" />غائب
                  </div>
                </>
              )}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* ── Pie Charts Row ────────────────────────────────────────── */}
        {(reportType === 'financial' || reportType === 'production' || reportType === 'inventory') && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

            {/* Expense breakdown */}
            {reportType === 'financial' && expenseByCategory.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
                className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-gray-900">توزيع المصروفات</h3>
                  <span className="text-[10px] text-red-600 font-bold bg-red-50 px-2 py-0.5 rounded-lg">
                    {format(expense)}
                  </span>
                </div>
                <div style={{ height: 150 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={expenseByCategory} cx="50%" cy="50%" innerRadius={40} outerRadius={65}
                        dataKey="value" paddingAngle={3}>
                        {expenseByCategory.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie>
                      <Tooltip formatter={(v: number) => [`$${v.toLocaleString()}`, '']} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-1.5 mt-2">
                  {expenseByCategory.slice(0, 4).map((e, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: e.color }} />
                        <span className="text-[11px] text-gray-600 truncate max-w-[120px]">{e.name}</span>
                      </div>
                      <span className="text-[11px] font-bold text-gray-900">${e.value.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Income breakdown */}
            {reportType === 'financial' && incomeByCategory.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
                className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-gray-900">توزيع الإيرادات</h3>
                  <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-lg">
                    {format(income)}
                  </span>
                </div>
                <div style={{ height: 150 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={incomeByCategory} cx="50%" cy="50%" innerRadius={40} outerRadius={65}
                        dataKey="value" paddingAngle={3}>
                        {incomeByCategory.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie>
                      <Tooltip formatter={(v: number) => [`$${v.toLocaleString()}`, '']} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-1.5 mt-2">
                  {incomeByCategory.slice(0, 4).map((e, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: e.color }} />
                        <span className="text-[11px] text-gray-600 truncate max-w-[120px]">{e.name}</span>
                      </div>
                      <span className="text-[11px] font-bold text-gray-900">${e.value.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Product mix */}
            {reportType === 'production' && productMix.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
                className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                <h3 className="text-sm font-bold text-gray-900 mb-3">مزيج المنتجات</h3>
                <div style={{ height: 150 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={productMix} cx="50%" cy="50%" innerRadius={40} outerRadius={65}
                        dataKey="value" paddingAngle={3}>
                        {productMix.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie>
                      <Tooltip formatter={(v: number) => [`${v}%`, '']} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-1.5 mt-2">
                  {productMix.map((p, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: p.color }} />
                        <span className="text-[11px] text-gray-600 truncate max-w-[120px]">{p.name}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-gray-400">{p.raw} وحدة</span>
                        <span className="text-[11px] font-bold text-gray-900">{p.value}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Inventory category */}
            {reportType === 'inventory' && inventoryStats.catData.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
                className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                <h3 className="text-sm font-bold text-gray-900 mb-3">توزيع قيمة المخزون بالفئة</h3>
                <div style={{ height: 150 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={inventoryStats.catData} cx="50%" cy="50%" innerRadius={40} outerRadius={65}
                        dataKey="value" paddingAngle={3}>
                        {inventoryStats.catData.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie>
                      <Tooltip formatter={(v: number) => [`$${v.toLocaleString()}`, '']} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-1.5 mt-2">
                  {inventoryStats.catData.slice(0,4).map((e,i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: e.color }} />
                        <span className="text-[11px] text-gray-600 truncate max-w-[120px]">{e.name}</span>
                      </div>
                      <span className="text-[11px] font-bold text-gray-900">${e.value.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        )}

        {/* ── HR Department Breakdown ───────────────────────────────── */}
        {reportType === 'hr' && hrStats.deptData.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
            className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <h3 className="text-sm font-bold text-gray-900 mb-3">الموظفون حسب القسم</h3>
            <div style={{ height: 160 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={hrStats.deptData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                  <XAxis dataKey="name" tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} />
                  <YAxis tick={{ fontSize: 10, fill: 'var(--text-tertiary)' }} />
                  <Tooltip content={<ChartTooltip />} />
                  <Bar dataKey="count" name="عدد الموظفين" radius={[6,6,0,0]} maxBarSize={32}>
                    {hrStats.deptData.map((_, i) => <Cell key={i} fill={COLORS[i%COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        )}

        {/* ── Financial Profit Trend ────────────────────────────────── */}
        {reportType === 'financial' && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
            className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-gray-900">منحنى الربح</h3>
              <span className={`text-xs font-bold px-2 py-0.5 rounded-lg ${net > 0 ? 'text-emerald-600 bg-emerald-50' : 'text-red-600 bg-red-50'}`}>
                {net > 0 ? '+' : ''}{format(net)}
              </span>
            </div>
            <div style={{ height: 140 }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                  <defs>
                    <linearGradient id="profitLineGrad" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%"   stopColor="#3b82f6" />
                      <stop offset="100%" stopColor="#8b5cf6" />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                  <XAxis dataKey="label" tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} />
                  <YAxis tick={{ fontSize: 10, fill: 'var(--text-tertiary)' }} />
                  <Tooltip content={<ChartTooltip />} />
                  <Line type="monotone" dataKey="profit" name="الربح" stroke="url(#profitLineGrad)"
                    strokeWidth={2.5} dot={{ r: 4, fill: '#3b82f6', strokeWidth: 0 }}
                    activeDot={{ r: 6, fill: '#8b5cf6' }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        )}

        {/* ── Wallet Summary ────────────────────────────────────────── */}
        {reportType === 'financial' && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }}
            className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-4 text-white shadow-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-white/20 flex items-center justify-center">
                  <Wallet size={14} />
                </div>
                <h3 className="text-sm font-bold">محافظ العمال</h3>
              </div>
              <div className="text-[10px] bg-white/20 px-2 py-1 rounded-lg">{wallets.length} محفظة</div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'إجمالي الأرصدة', value: `$${Math.round(walletStats.totalBalance).toLocaleString()}` },
                { label: 'متوسط الرصيد',   value: `$${Math.round(walletStats.avgBalance).toLocaleString()}` },
                { label: 'إجمالي السلف',   value: `$${Math.round(walletStats.totalAdvances).toLocaleString()}` },
                { label: 'إجمالي المكافآت',value: `$${Math.round(walletStats.totalBonuses).toLocaleString()}` },
              ].map((item,i) => (
                <div key={i} className="bg-white/15 rounded-xl p-2.5">
                  <div className="text-[10px] text-white/70 mb-0.5">{item.label}</div>
                  <div className="text-sm font-black font-numeric">{item.value}</div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* ── Orders Summary Table ──────────────────────────────────── */}
        {reportType === 'production' && orderSummary.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
            className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-sm font-bold text-gray-900">ملخص الطلبات الشهري</h3>
              <button onClick={() => handleExport('CSV')}
                className="flex items-center gap-1 text-[10px] text-blue-600 font-bold bg-blue-50 px-2 py-1 rounded-lg">
                <Download size={9} /> تصدير
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-gray-50">
                  <tr>
                    {['الشهر','الإجمالي','مكتمل','معلق','ملغي','الإيراد'].map(h => (
                      <th key={h} className="px-3 py-2.5 text-right text-gray-500 font-bold whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {orderSummary.map((row, i) => (
                    <tr key={i} className="hover:bg-gray-50/60 transition-colors">
                      <td className="px-3 py-2.5 font-medium text-gray-900 whitespace-nowrap">{row.month}</td>
                      <td className="px-3 py-2.5 text-gray-600">{row.total}</td>
                      <td className="px-3 py-2.5"><span className="text-emerald-600 font-bold">{row.completed}</span></td>
                      <td className="px-3 py-2.5"><span className="text-amber-600 font-bold">{row.pending}</span></td>
                      <td className="px-3 py-2.5"><span className="text-red-500 font-bold">{row.cancelled}</span></td>
                      <td className="px-3 py-2.5 font-bold text-gray-900">${row.revenue.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-gray-50 border-t-2 border-gray-100">
                  <tr>
                    <td className="px-3 py-2.5 font-black text-gray-900">الإجمالي</td>
                    <td className="px-3 py-2.5 font-bold">{orderSummary.reduce((s,r)=>s+r.total,0)}</td>
                    <td className="px-3 py-2.5 font-bold text-emerald-600">{orderSummary.reduce((s,r)=>s+r.completed,0)}</td>
                    <td className="px-3 py-2.5 font-bold text-amber-600">{orderSummary.reduce((s,r)=>s+r.pending,0)}</td>
                    <td className="px-3 py-2.5 font-bold text-red-500">{orderSummary.reduce((s,r)=>s+r.cancelled,0)}</td>
                    <td className="px-3 py-2.5 font-black text-gray-900">${orderSummary.reduce((s,r)=>s+r.revenue,0).toLocaleString()}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </motion.div>
        )}

        {/* ── Inventory health ──────────────────────────────────────── */}
        {reportType === 'inventory' && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
            className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-gray-900">صحة المخزون</h3>
              <button onClick={() => handleExport('print')}
                className="flex items-center gap-1 text-[10px] text-blue-600 font-bold bg-blue-50 px-2 py-1 rounded-lg">
                <Printer size={9} /> طباعة
              </button>
            </div>
            <div className="space-y-2.5">
              {[
                { label: 'مخزون جيد', count: inventoryItems.filter(i => i.stock_quantity > i.reorder_level).length, color: '#10b981', bg: '#ecfdf5' },
                { label: 'مخزون منخفض', count: inventoryStats.low - inventoryStats.critical, color: '#f59e0b', bg: '#fffbeb' },
                { label: 'مخزون حرج', count: inventoryStats.critical, color: '#ef4444', bg: '#fef2f2' },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-24 text-xs font-medium text-gray-600 text-right flex-shrink-0">{item.label}</div>
                  <div className="flex-1 h-6 rounded-lg overflow-hidden" style={{ background: item.bg }}>
                    <div className="h-full rounded-lg transition-all duration-700 flex items-center justify-end pr-2"
                      style={{
                        width: `${Math.max(8, (item.count / Math.max(inventoryStats.total, 1)) * 100)}%`,
                        background: item.color,
                      }}>
                      <span className="text-white text-[10px] font-bold">{item.count}</span>
                    </div>
                  </div>
                  <div className="w-8 text-xs font-bold text-gray-700 text-left flex-shrink-0">
                    {Math.round((item.count / Math.max(inventoryStats.total, 1)) * 100)}%
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* ── Activity Summary ──────────────────────────────────────── */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65 }}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 rounded-xl bg-blue-50 flex items-center justify-center">
              <Activity size={14} className="text-blue-600" />
            </div>
            <h3 className="text-sm font-bold text-gray-900">ملخص تنفيذي</h3>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'الطلبات',   value: filteredOrders.length,  sub: `${completedOrders.length} مكتمل`, color: '#3b82f6' },
              { label: 'الإنتاج',  value: `${Math.round(productionLines.reduce((s,l)=>s+(l.efficiency_percentage||0),0)/Math.max(productionLines.length,1))}%`, sub: 'متوسط الكفاءة', color: '#10b981' },
              { label: 'الحضور',   value: `${hrStats.presentCount}/${hrStats.total}`, sub: 'اليوم', color: '#f59e0b' },
            ].map((item, i) => (
              <div key={i} className="text-center p-2.5 rounded-xl" style={{ background: `${item.color}10` }}>
                <div className="text-base font-black font-numeric" style={{ color: item.color }}>{item.value}</div>
                <div className="text-[10px] font-bold text-gray-700 mt-0.5">{item.label}</div>
                <div className="text-[9px] text-gray-400">{item.sub}</div>
              </div>
            ))}
          </div>
        </motion.div>

      </div>
    </div>
  );
};

export default React.memo(ReportsPage);
