import React, { useState, useMemo } from 'react';
import {
  TrendingUp, TrendingDown, DollarSign, ArrowUpRight, ArrowDownRight,
  Download, Filter, PieChartIcon, BarChart2, Wallet, CreditCard,
  RefreshCw, Plus, ChevronDown, ChevronUp, CheckCircle2, AlertCircle,
  FileText, Printer
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip,
  BarChart, Bar, CartesianGrid, PieChart, Pie, Cell, Legend
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAppData } from '../contexts/AppDataContext';
import { Card, CardBody, CardHeader } from '../components/ui/Card';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { SalesPanel } from './SalesPanel';

const COLORS = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4', '#ec4899'];

const CustomTooltip = ({ active, payload, label }: {
  active?: boolean;
  payload?: Array<{ value: number; name: string; color: string }>;
  label?: string;
}) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-gray-900 rounded-xl p-3 shadow-xl text-white text-xs min-w-[140px]" dir="rtl">
      <p className="text-gray-400 mb-1.5 font-medium">{label}</p>
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2 mb-0.5">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-gray-300">{p.name}:</span>
          <span className="font-bold">${typeof p.value === 'number' ? p.value.toLocaleString() : p.value}</span>
        </div>
      ))}
    </div>
  );
};

const FinanceContent: React.FC = () => {
  const { format, toggleCurrency, currency, exchangeRate } = useCurrency();
  const { journalEntries, wallets, walletTransactions, orders, addJournalEntry, can } = useAppData();
  const [period, setPeriod] = useState<'week' | 'month' | 'quarter' | 'year'>('month');
  const [activeTab, setActiveTab] = useState<'overview' | 'cashflow' | 'expenses' | 'wallets' | 'reports'>('overview');
  const [showAddEntry, setShowAddEntry] = useState(false);
  const [expandedEntry, setExpandedEntry] = useState<string | null>(null);
  const [addForm, setAddForm] = useState({ type: 'income' as 'income' | 'expense', amount: '', description: '', category: '' });
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Real computed financials from journal entries
  const totalIncome = useMemo(() =>
    journalEntries.filter(e => e.type === 'income').reduce((s, e) => s + e.amount_usd, 0),
    [journalEntries]);

  const totalExpenses = useMemo(() =>
    journalEntries.filter(e => e.type === 'expense').reduce((s, e) => s + e.amount_usd, 0),
    [journalEntries]);

  const netProfit = totalIncome - totalExpenses;
  const profitMargin = totalIncome > 0 ? (netProfit / totalIncome) * 100 : 0;

  // Category breakdown
  const expenseByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    journalEntries.filter(e => e.type === 'expense').forEach(e => {
      map[e.category] = (map[e.category] || 0) + e.amount_usd;
    });
    return Object.entries(map).map(([name, value], i) => ({ name, value, color: COLORS[i % COLORS.length] }))
      .sort((a, b) => b.value - a.value);
  }, [journalEntries]);

  const incomeByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    journalEntries.filter(e => e.type === 'income').forEach(e => {
      map[e.category] = (map[e.category] || 0) + e.amount_usd;
    });
    return Object.entries(map).map(([name, value], i) => ({ name, value, color: COLORS[i % COLORS.length] }))
      .sort((a, b) => b.value - a.value);
  }, [journalEntries]);

  // Monthly chart data
  const monthlyChartData = useMemo(() => {
    const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    const data: Record<number, { income: number; expenses: number; profit: number }> = {};
    journalEntries.forEach(e => {
      const m = new Date(e.created_at).getMonth();
      if (!data[m]) data[m] = { income: 0, expenses: 0, profit: 0 };
      if (e.type === 'income') data[m].income += e.amount_usd;
      if (e.type === 'expense') data[m].expenses += e.amount_usd;
    });
    return months.map((name, i) => ({
      name,
      income: data[i]?.income || 0,
      expenses: data[i]?.expenses || 0,
      profit: (data[i]?.income || 0) - (data[i]?.expenses || 0),
    }));
  }, [journalEntries]);

  // ── Trial Balance: group every journal entry by category, summing
  // debits (expenses) and credits (income) per category. Transfer entries
  // are excluded — they move funds between accounts rather than representing
  // income or expense, so including them would distort the P&L view. ───────
  const trialBalance = useMemo(() => {
    const map: Record<string, { category: string; type: 'income' | 'expense'; debit: number; credit: number }> = {};
    journalEntries.filter((e): e is typeof e & { type: 'income' | 'expense' } => e.type === 'income' || e.type === 'expense').forEach(e => {
      const key = `${e.type}:${e.category}`;
      if (!map[key]) map[key] = { category: e.category, type: e.type, debit: 0, credit: 0 };
      if (e.type === 'income') map[key].credit += e.amount_usd;
      else map[key].debit += e.amount_usd;
    });
    const rows = Object.values(map).sort((a, b) => (b.debit + b.credit) - (a.debit + a.credit));
    const totalDebit = rows.reduce((s, r) => s + r.debit, 0);
    const totalCredit = rows.reduce((s, r) => s + r.credit, 0);
    return { rows, totalDebit, totalCredit };
  }, [journalEntries]);

  // ── Profit & Loss statement: income categories, expense categories, net. ──
  const profitLoss = useMemo(() => {
    const totalRevenue = incomeByCategory.reduce((s, c) => s + c.value, 0);
    const totalCost = expenseByCategory.reduce((s, c) => s + c.value, 0);
    return {
      revenue: incomeByCategory,
      expenses: expenseByCategory,
      totalRevenue, totalCost,
      grossProfit: totalRevenue - totalCost,
      margin: totalRevenue > 0 ? ((totalRevenue - totalCost) / totalRevenue) * 100 : 0,
    };
  }, [incomeByCategory, expenseByCategory]);

  // Total wallet balance
  const totalWalletBalance = useMemo(() =>
    wallets.reduce((s, w) => s + w.balanceUSD, 0), [wallets]);

  const handleSaveEntry = () => {
    if (!addForm.amount || !addForm.description) return;
    setIsSaving(true);
    setTimeout(() => {
      addJournalEntry({
        entry_number: `JE-${Date.now().toString().slice(-6)}`,
        type: addForm.type,
        category: addForm.category || (addForm.type === 'income' ? 'إيرادات' : 'مصاريف'),
        amount_usd: parseFloat(addForm.amount),
        amount_syp: parseFloat(addForm.amount) * exchangeRate,
        currency: 'USD',
        payment_method: 'cash',
        description: addForm.description,
        created_by: 'current-user',
        entry_date: new Date().toISOString().split('T')[0],
      });
      setIsSaving(false);
      setSaveSuccess(true);
      setAddForm({ type: 'income', amount: '', description: '', category: '' });
      setTimeout(() => { setSaveSuccess(false); setShowAddEntry(false); }, 1500);
    }, 800);
  };

  const recentEntries = useMemo(() =>
    [...journalEntries].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).slice(0, 20),
    [journalEntries]);

  return (
    <div className="min-h-screen bg-gray-50 pb-28" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-br from-slate-800 via-blue-900 to-indigo-900 px-4 pt-4 pb-10">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-black text-white">الإدارة المالية</h1>
            <p className="text-blue-300 text-xs mt-0.5">{journalEntries.length} قيد محاسبي</p>
          </div>
          <div className="flex gap-2">
            <button onClick={toggleCurrency} className="w-9 h-9 bg-white/15 rounded-xl flex items-center justify-center">
              <span className="text-white text-xs font-bold">{currency}</span>
            </button>
            {can('finance.manage') && (
            <button onClick={() => setShowAddEntry(true)} className="w-9 h-9 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/30">
              <Plus size={16} className="text-white" />
            </button>
            )}
          </div>
        </div>

        {/* KPI Summary */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-emerald-500/20 border border-emerald-500/30 rounded-2xl p-3">
            <div className="flex items-center gap-1.5 mb-1"><ArrowUpRight size={13} className="text-emerald-400" /><span className="text-emerald-300 text-[10px]">الإيرادات</span></div>
            <p className="text-white font-black text-base">{format(totalIncome)}</p>
          </div>
          <div className="bg-red-500/20 border border-red-500/30 rounded-2xl p-3">
            <div className="flex items-center gap-1.5 mb-1"><ArrowDownRight size={13} className="text-red-400" /><span className="text-red-300 text-[10px]">المصروفات</span></div>
            <p className="text-white font-black text-base">{format(totalExpenses)}</p>
          </div>
          <div className={`${netProfit >= 0 ? 'bg-blue-500/20 border-blue-500/30' : 'bg-red-500/20 border-red-500/30'} border rounded-2xl p-3`}>
            <div className="flex items-center gap-1.5 mb-1">
              {netProfit >= 0 ? <TrendingUp size={13} className="text-blue-400" /> : <TrendingDown size={13} className="text-red-400" />}
              <span className="text-blue-300 text-[10px]">الصافي</span>
            </div>
            <p className={`font-black text-base ${netProfit >= 0 ? 'text-white' : 'text-red-300'}`}>{format(netProfit)}</p>
          </div>
        </div>

        {/* Profit margin */}
        <div className="mt-3 bg-white/10 rounded-2xl p-3">
          <div className="flex items-center justify-between text-xs text-white/70 mb-2">
            <span>هامش الربح</span>
            <span className="font-bold text-white">{profitMargin.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-white/20 rounded-full h-2">
            <motion.div className={`h-2 rounded-full ${profitMargin >= 30 ? 'bg-emerald-400' : profitMargin >= 15 ? 'bg-amber-400' : 'bg-red-400'}`}
              initial={{ width: 0 }} animate={{ width: `${Math.min(100, Math.max(0, profitMargin))}%` }} transition={{ duration: 1, ease: 'easeOut' }} />
          </div>
        </div>
      </div>

      <div className="px-4 -mt-4 space-y-4">
        {/* Tab Navigation */}
        <div className="flex gap-1 bg-gray-100 rounded-2xl p-1">
          {[
            { key: 'overview', label: 'نظرة عامة', icon: BarChart2 },
            { key: 'cashflow', label: 'التدفق', icon: TrendingUp },
            { key: 'expenses', label: 'المصاريف', icon: CreditCard },
            { key: 'wallets', label: 'المحافظ', icon: Wallet },
            { key: 'reports', label: 'التقارير', icon: FileText },
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button key={tab.key} onClick={() => setActiveTab(tab.key as typeof activeTab)}
                className={`flex-1 flex items-center justify-center gap-1 py-2 rounded-xl text-[10px] font-bold transition-all ${activeTab === tab.key ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500'}`}>
                <Icon size={11} />{tab.label}
              </button>
            );
          })}
        </div>

        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div key="overview" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
              {/* Monthly Chart */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2"><BarChart2 size={16} className="text-blue-600" /><h3 className="font-bold text-gray-800 text-sm">الإيرادات والمصاريف الشهرية</h3></div>
                </CardHeader>
                <CardBody className="pt-0 pb-3 px-2">
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={monthlyChartData.slice(-6)} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                      <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: 10 }} />
                      <Bar dataKey="income" name="الإيرادات" fill="#10b981" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="expenses" name="المصاريف" fill="#ef4444" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardBody>
              </Card>

              {/* Recent Entries */}
              <Card>
                <CardHeader>
                  <h3 className="font-bold text-gray-800 text-sm">آخر القيود المحاسبية</h3>
                </CardHeader>
                <CardBody className="p-0">
                  {recentEntries.slice(0, 8).map((entry, idx) => (
                    <motion.div key={entry.id} layout>
                      <button onClick={() => setExpandedEntry(expandedEntry === entry.id ? null : entry.id)}
                        className={`w-full flex items-center gap-3 px-4 py-3 text-right hover:bg-gray-50 transition-colors ${idx < recentEntries.length - 1 ? 'border-b border-gray-50' : ''}`}>
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${entry.type === 'income' ? 'bg-emerald-100' : 'bg-red-100'}`}>
                          {entry.type === 'income' ? <ArrowUpRight size={15} className="text-emerald-600" /> : <ArrowDownRight size={15} className="text-red-600" />}
                        </div>
                        <div className="flex-1 min-w-0 text-right">
                          <p className="text-sm font-semibold text-gray-800 truncate">{entry.description}</p>
                          <p className="text-[11px] text-gray-500">{entry.category} • {new Date(entry.created_at).toLocaleDateString('ar-SY')}</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <p className={`text-sm font-bold ${entry.type === 'income' ? 'text-emerald-600' : 'text-red-600'}`}>
                            {entry.type === 'income' ? '+' : '-'}{format(entry.amount_usd)}
                          </p>
                          {expandedEntry === entry.id ? <ChevronUp size={14} className="text-gray-400" /> : <ChevronDown size={14} className="text-gray-400" />}
                        </div>
                      </button>
                      <AnimatePresence>
                        {expandedEntry === entry.id && (
                          <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden">
                            <div className="px-4 pb-3 grid grid-cols-2 gap-2 bg-gray-50">
                              {[
                                { label: 'رقم القيد', val: entry.entry_number },
                                { label: 'طريقة الدفع', val: entry.payment_method || '—' },
                                { label: 'بالليرة السورية', val: `${(entry.amount_syp || entry.amount_usd * exchangeRate).toLocaleString()} ل.س` },
                                { label: 'بواسطة', val: entry.created_by || '—' },
                              ].map((row, i) => (
                                <div key={i} className="bg-white rounded-xl px-3 py-2">
                                  <p className="text-[10px] text-gray-400">{row.label}</p>
                                  <p className="text-xs font-semibold text-gray-700">{row.val}</p>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  ))}
                </CardBody>
              </Card>
            </motion.div>
          )}

          {activeTab === 'cashflow' && (
            <motion.div key="cashflow" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2"><TrendingUp size={16} className="text-blue-600" /><h3 className="font-bold text-gray-800 text-sm">التدفق النقدي</h3></div>
                </CardHeader>
                <CardBody className="pt-0 pb-3 px-2">
                  <ResponsiveContainer width="100%" height={220}>
                    <AreaChart data={monthlyChartData} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                      <defs>
                        <linearGradient id="incomeGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.25} />
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="expGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2} />
                          <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                      <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: 10 }} />
                      <Area type="monotone" dataKey="income" name="الإيرادات" stroke="#10b981" fill="url(#incomeGrad)" strokeWidth={2} dot={false} />
                      <Area type="monotone" dataKey="expenses" name="المصاريف" stroke="#ef4444" fill="url(#expGrad)" strokeWidth={2} dot={false} />
                      <Area type="monotone" dataKey="profit" name="الصافي" stroke="#3b82f6" fill="none" strokeWidth={2} strokeDasharray="4 4" dot={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardBody>
              </Card>

              {/* Monthly Summary Table */}
              <Card>
                <CardHeader><h3 className="font-bold text-gray-800 text-sm">الملخص الشهري</h3></CardHeader>
                <CardBody className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead><tr className="bg-gray-50">
                        <th className="text-right px-4 py-2.5 font-semibold text-gray-500">الشهر</th>
                        <th className="text-center px-3 py-2.5 font-semibold text-emerald-600">الإيرادات</th>
                        <th className="text-center px-3 py-2.5 font-semibold text-red-500">المصاريف</th>
                        <th className="text-center px-3 py-2.5 font-semibold text-blue-600">الصافي</th>
                      </tr></thead>
                      <tbody>
                        {monthlyChartData.slice(-6).map((row, i) => (
                          <tr key={i} className="border-t border-gray-50">
                            <td className="px-4 py-2.5 font-medium text-gray-700">{row.name}</td>
                            <td className="px-3 py-2.5 text-center text-emerald-600 font-bold">${row.income.toLocaleString()}</td>
                            <td className="px-3 py-2.5 text-center text-red-500 font-bold">${row.expenses.toLocaleString()}</td>
                            <td className={`px-3 py-2.5 text-center font-bold ${row.profit >= 0 ? 'text-blue-600' : 'text-red-600'}`}>${row.profit.toLocaleString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardBody>
              </Card>
            </motion.div>
          )}

          {activeTab === 'expenses' && (
            <motion.div key="expenses" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2"><PieChartIcon size={16} className="text-red-500" /><h3 className="font-bold text-gray-800 text-sm">توزيع المصاريف</h3></div>
                </CardHeader>
                <CardBody>
                  {expenseByCategory.length > 0 ? (
                    <div className="flex gap-4">
                      <PieChart width={110} height={110}>
                        <Pie data={expenseByCategory} cx={55} cy={55} innerRadius={32} outerRadius={50} dataKey="value" stroke="none" paddingAngle={3}>
                          {expenseByCategory.map((entry, index) => (<Cell key={index} fill={entry.color} />))}
                        </Pie>
                      </PieChart>
                      <div className="flex-1 space-y-2">
                        {expenseByCategory.map((cat, i) => (
                          <div key={i} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: cat.color }} />
                              <span className="text-xs text-gray-600">{cat.name}</span>
                            </div>
                            <span className="text-xs font-bold text-gray-800">{format(cat.value)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-400 text-sm">لا توجد مصاريف مسجلة</div>
                  )}
                </CardBody>
              </Card>

              {expenseByCategory.map((cat, i) => (
                <Card key={i}>
                  <CardBody className="py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-10 rounded-full shrink-0" style={{ backgroundColor: cat.color }} />
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-sm font-bold text-gray-800">{cat.name}</p>
                          <p className="text-sm font-bold" style={{ color: cat.color }}>{format(cat.value)}</p>
                        </div>
                        <div className="w-full bg-gray-100 rounded-full h-1.5">
                          <motion.div className="h-1.5 rounded-full" style={{ backgroundColor: cat.color }}
                            initial={{ width: 0 }}
                            animate={{ width: `${totalExpenses > 0 ? (cat.value / totalExpenses) * 100 : 0}%` }}
                            transition={{ duration: 0.8, delay: i * 0.1 }} />
                        </div>
                        <p className="text-[10px] text-gray-400 mt-0.5">
                          {totalExpenses > 0 ? ((cat.value / totalExpenses) * 100).toFixed(1) : 0}% من إجمالي المصاريف
                        </p>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              ))}
            </motion.div>
          )}

          {activeTab === 'wallets' && (
            <motion.div key="wallets" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
              <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl p-5 text-white">
                <p className="text-emerald-100 text-xs mb-1">إجمالي أرصدة المحافظ</p>
                <p className="text-3xl font-black">{format(totalWalletBalance)}</p>
                <p className="text-emerald-200 text-xs mt-1">{wallets.length} محفظة نشطة</p>
              </div>

              {wallets.map((wallet, i) => (
                <Card key={wallet.workerId}>
                  <CardBody className="py-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-emerald-100 rounded-2xl flex items-center justify-center">
                          <Wallet size={18} className="text-emerald-600" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-800">{wallet.workerId}</p>
                          <p className="text-xs text-gray-500">رصيد المحفظة</p>
                        </div>
                      </div>
                      <div className="text-left">
                        <p className="text-lg font-black text-emerald-600">{format(wallet.balanceUSD)}</p>
                        <p className="text-xs text-gray-400">الرصيد الحالي</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-emerald-50 rounded-xl p-2 text-center">
                        <p className="text-sm font-bold text-emerald-700">{format(wallet.balanceUSD)}</p>
                        <p className="text-[10px] text-gray-500">الرصيد بالدولار</p>
                      </div>
                      <div className="bg-blue-50 rounded-xl p-2 text-center">
                        <p className="text-sm font-bold text-blue-600">{(wallet.balanceSYP / 1000).toFixed(0)}K ل.س</p>
                        <p className="text-[10px] text-gray-500">الرصيد بالليرة</p>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              ))}

              {wallets.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-3"><Wallet size={36} className="text-gray-300" /></div>
                  <p className="text-gray-500 font-medium">لا توجد محافظ مسجلة</p>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'reports' && (
            <motion.div key="reports" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
              {/* ── Profit & Loss Statement ── */}
              <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                    <FileText size={15} className="text-blue-600" /> قائمة الدخل (الأرباح والخسائر)
                  </h3>
                  <button onClick={() => window.print()} className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center text-gray-500">
                    <Printer size={14} />
                  </button>
                </div>

                <div className="mb-4">
                  <p className="text-[11px] font-bold text-gray-400 mb-2">الإيرادات</p>
                  <div className="space-y-1.5">
                    {profitLoss.revenue.length === 0 ? (
                      <p className="text-xs text-gray-400 text-center py-3">لا توجد إيرادات مسجلة</p>
                    ) : profitLoss.revenue.map(r => (
                      <div key={r.name} className="flex justify-between items-center px-3 py-2 bg-emerald-50/50 rounded-lg">
                        <span className="text-xs text-gray-600">{r.name}</span>
                        <span className="text-xs font-bold text-emerald-600">{format(r.value)}</span>
                      </div>
                    ))}
                    <div className="flex justify-between items-center px-3 py-2 border-t border-gray-100 pt-2 mt-1">
                      <span className="text-xs font-bold text-gray-700">إجمالي الإيرادات</span>
                      <span className="text-sm font-black text-emerald-600">{format(profitLoss.totalRevenue)}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-[11px] font-bold text-gray-400 mb-2">المصروفات</p>
                  <div className="space-y-1.5">
                    {profitLoss.expenses.length === 0 ? (
                      <p className="text-xs text-gray-400 text-center py-3">لا توجد مصروفات مسجلة</p>
                    ) : profitLoss.expenses.map(r => (
                      <div key={r.name} className="flex justify-between items-center px-3 py-2 bg-red-50/50 rounded-lg">
                        <span className="text-xs text-gray-600">{r.name}</span>
                        <span className="text-xs font-bold text-red-600">{format(r.value)}</span>
                      </div>
                    ))}
                    <div className="flex justify-between items-center px-3 py-2 border-t border-gray-100 pt-2 mt-1">
                      <span className="text-xs font-bold text-gray-700">إجمالي المصروفات</span>
                      <span className="text-sm font-black text-red-600">{format(profitLoss.totalCost)}</span>
                    </div>
                  </div>
                </div>

                <div className={`rounded-2xl p-4 ${profitLoss.grossProfit >= 0 ? 'bg-emerald-600' : 'bg-red-600'}`}>
                  <div className="flex justify-between items-center">
                    <span className="text-white/80 text-xs font-bold">صافي الربح</span>
                    <span className="text-white text-xl font-black">{format(profitLoss.grossProfit)}</span>
                  </div>
                  <p className="text-white/70 text-[11px] mt-1">هامش الربح: {profitLoss.margin.toFixed(1)}%</p>
                </div>
              </div>

              {/* ── Trial Balance ── */}
              <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100">
                <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2 mb-4">
                  <BarChart2 size={15} className="text-indigo-600" /> ميزان المراجعة
                </h3>
                {trialBalance.rows.length === 0 ? (
                  <p className="text-xs text-gray-400 text-center py-6">لا توجد قيود محاسبية بعد</p>
                ) : (
                  <>
                    <div className="overflow-x-auto -mx-1">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="text-gray-400 border-b border-gray-100">
                            <th className="text-right py-2 px-1 font-semibold">الحساب</th>
                            <th className="text-left py-2 px-1 font-semibold">مدين</th>
                            <th className="text-left py-2 px-1 font-semibold">دائن</th>
                          </tr>
                        </thead>
                        <tbody>
                          {trialBalance.rows.map((r, i) => (
                            <tr key={i} className="border-b border-gray-50">
                              <td className="py-2 px-1 text-gray-700">{r.category}</td>
                              <td className="py-2 px-1 text-left text-red-600 font-medium">{r.debit > 0 ? `$${r.debit.toFixed(0)}` : '—'}</td>
                              <td className="py-2 px-1 text-left text-emerald-600 font-medium">{r.credit > 0 ? `$${r.credit.toFixed(0)}` : '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                        <tfoot>
                          <tr className="border-t-2 border-gray-200">
                            <td className="py-2.5 px-1 font-bold text-gray-800">الإجمالي</td>
                            <td className="py-2.5 px-1 text-left font-black text-red-600">${trialBalance.totalDebit.toFixed(0)}</td>
                            <td className="py-2.5 px-1 text-left font-black text-emerald-600">${trialBalance.totalCredit.toFixed(0)}</td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                    <div className="mt-3 px-3 py-2 bg-gray-50 rounded-lg flex items-center gap-2">
                      <CheckCircle2 size={13} className="text-emerald-500 shrink-0" />
                      <p className="text-[11px] text-gray-500">
                        صافي الفرق بين المدين والدائن: <span className="font-bold text-gray-700">${Math.abs(trialBalance.totalDebit - trialBalance.totalCredit).toFixed(0)}</span> — يمثل صافي الربح/الخسارة التراكمي
                      </p>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="h-4" />
      </div>

      {/* Add Entry Modal — Portal-based */}
      <BottomSheetModal isOpen={showAddEntry} onClose={() => setShowAddEntry(false)}>
        <SheetHeader onClose={() => setShowAddEntry(false)}>
          <h2 className="text-base font-bold text-gray-900">إضافة قيد محاسبي</h2>
        </SheetHeader>
        <SheetBody>
          <div className="flex gap-2">
            {[{ val: 'income', label: 'إيراد', color: 'bg-emerald-500' }, { val: 'expense', label: 'مصروف', color: 'bg-red-500' }].map(t => (
              <button key={t.val} onClick={() => setAddForm(f => ({ ...f, type: t.val as any }))}
                className={`flex-1 py-2.5 rounded-2xl text-sm font-bold transition-all ${addForm.type === t.val ? `${t.color} text-white shadow-lg` : 'bg-gray-100 text-gray-600'}`}>
                {t.label}
              </button>
            ))}
          </div>
          <input value={addForm.amount} onChange={e => setAddForm(f => ({ ...f, amount: e.target.value }))}
            type="number" inputMode="decimal" placeholder="المبلغ ($)"
            className="w-full px-4 py-3 border border-gray-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          <input value={addForm.category} onChange={e => setAddForm(f => ({ ...f, category: e.target.value }))}
            placeholder="الفئة (رواتب، مبيعات...)"
            className="w-full px-4 py-3 border border-gray-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          <textarea value={addForm.description} onChange={e => setAddForm(f => ({ ...f, description: e.target.value }))}
            placeholder="الوصف" rows={3}
            className="w-full px-4 py-3 border border-gray-200 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
        </SheetBody>
        <SheetFooter>
          <div className="flex gap-3">
            <button onClick={() => setShowAddEntry(false)} className="flex-1 py-3.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600">إلغاء</button>
            <button onClick={handleSaveEntry} disabled={!addForm.amount || !addForm.description || isSaving}
              className="flex-1 py-3.5 bg-blue-600 text-white rounded-xl text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2">
              {saveSuccess ? <><CheckCircle2 size={16} /> تم الحفظ</> : isSaving ? <><RefreshCw size={14} className="animate-spin" /> جاري الحفظ...</> : 'حفظ القيد'}
            </button>
          </div>
        </SheetFooter>
      </BottomSheetModal>
    </div>
  );
};

// ─── Unified financial hub: Finance management + Sales analytics ──────────────
export const FinancePage: React.FC = () => {
  const [tab, setTab] = useState<'finance' | 'sales'>('finance');
  return (
    <div className="min-h-screen" dir="rtl" style={{ background: 'var(--surface-secondary)' }}>
      <div className="px-4 pt-3 pb-2" style={{ background: 'var(--surface-secondary)' }}>
        <div className="rounded-2xl p-1 flex shadow-sm" style={{ background: 'var(--surface)' }}>
          {([['finance', 'الإدارة المالية'], ['sales', 'المبيعات والتحليلات']] as const).map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)}
              className="flex-1 py-2.5 rounded-xl text-sm font-bold transition"
              style={{
                background: tab === k ? 'linear-gradient(135deg,#3b82f6,#6366f1)' : 'transparent',
                color: tab === k ? '#fff' : 'var(--text-tertiary)',
              }}>
              {l}
            </button>
          ))}
        </div>
      </div>
      {tab === 'finance' ? <FinanceContent /> : <SalesPanel />}
    </div>
  );
};

export default FinancePage;
