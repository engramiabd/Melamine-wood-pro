import React, { useState, useMemo } from 'react';
import {
  Wallet, Plus, ArrowUpCircle, ArrowDownCircle,
  User, Clock, CheckCircle, AlertTriangle,
  Send, ThumbsUp, ThumbsDown,
  Banknote, Gift, CreditCard,
  ChevronDown, ChevronRight, DollarSign,
  TrendingUp, TrendingDown, X, AlertCircle,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Badge } from '../components/ui/Badge';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import { useAppData, AdvanceRequest, WalletTransaction } from '../contexts/AppDataContext';
import { EmptyState } from '../components/ui/EmptyState';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { WalletTransactionType, UserRole } from '../types';

// Employee name map (since Employee type has no full_name)
const EMP_NAMES: Record<string, string> = {
  'demo-admin-001': 'أحمد المدير',
  'demo-manager-002': 'محمد المشرف',
  'demo-supervisor-003': 'خالد المراقب',
  'demo-worker-004': 'علي العامل',
  'demo-accountant-005': 'سمر المحاسبة',
  'demo-hr-006': 'ريم الموارد البشرية',
};
function empName(userId: string, position: string) {
  return EMP_NAMES[userId] || position;
}

// ─── Config ───────────────────────────────────────────────────────────────────
const TX_CONFIG: Record<WalletTransactionType, {
  label: string; badge: 'success' | 'danger' | 'info' | 'warning' | 'purple';
  color: string; sign: '+' | '-'; bg: string; icon: React.ReactNode;
}> = {
  salary:    { label: 'راتب',     badge: 'success', color: 'text-emerald-600', sign: '+', bg: 'bg-emerald-50', icon: <Banknote size={16} /> },
  advance:   { label: 'سلفة',    badge: 'warning',  color: 'text-amber-600',  sign: '-', bg: 'bg-amber-50',   icon: <ArrowDownCircle size={16} /> },
  bonus:     { label: 'مكافأة', badge: 'purple',   color: 'text-purple-600', sign: '+', bg: 'bg-purple-50',  icon: <Gift size={16} /> },
  deduction: { label: 'خصم',     badge: 'danger',   color: 'text-red-600',    sign: '-', bg: 'bg-red-50',     icon: <ArrowDownCircle size={16} /> },
  overtime:  { label: 'إضافي',  badge: 'info',     color: 'text-blue-600',   sign: '+', bg: 'bg-blue-50',    icon: <Clock size={16} /> },
};

const QUICK_AMOUNTS = [50, 100, 200, 300, 400];
const REPAYMENT_OPTIONS = [
  'اقتطاع من الراتب - قسطان',
  'اقتطاع من الراتب - 3 أقساط',
  'اقتطاع من الراتب - 4 أقساط',
  'دفعة واحدة من الراتب القادم',
];
const QUICK_REASONS = ['نفقات طارئة', 'علاج طبي', 'مصاريف منزلية', 'شراء جهاز', 'تعليم'];

function relTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const h = Math.floor(diff / 3600000);
  if (h < 1) return `منذ ${Math.floor(diff / 60000)} دقيقة`;
  if (h < 24) return `منذ ${h} ساعة`;
  const d = Math.floor(h / 24);
  if (d < 7) return `منذ ${d} يوم`;
  return new Date(iso).toLocaleDateString('ar-SY');
}

// ─── Advance Request Modal ────────────────────────────────────────────────────
const AdvanceModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { formatUSD, formatSYP, exchangeRate } = useCurrency();
  const { user } = useAuth();
  const { requestAdvance, getWallet, systemSettings } = useAppData();
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [repayment, setRepayment] = useState(REPAYMENT_OPTIONS[0]);
  const [step, setStep] = useState<'form' | 'success'>('form');

  const maxAdvance = systemSettings.maxAdvanceAmount;
  const amountNum = parseFloat(amount || '0');
  const exceedsMax = amountNum > maxAdvance;
  const wallet = user ? getWallet(user.id) : null;

  const handleSubmit = () => {
    if (!user || !amountNum || exceedsMax || !reason) return;
    const ok = requestAdvance(user.id, amountNum, reason);
    if (ok) setStep('success');
  };

  return (
    <BottomSheetModal isOpen onClose={onClose}>
      <SheetHeader onClose={onClose}>
        <h3 className="font-bold text-gray-900 text-base">طلب سلفة</h3>
      </SheetHeader>

      {step === 'success' ? (
        <SheetBody style={{ alignItems: 'center', justifyContent: 'center', padding: '40px 16px' }}>
          <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Send size={36} className="text-emerald-500" />
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-1 text-center">تم إرسال الطلب!</h3>
          <p className="text-gray-500 text-sm text-center">طلب السلفة {formatUSD(amountNum)} بانتظار موافقة المشرف</p>
        </SheetBody>
      ) : (
        <>
          <SheetBody>
            {/* Limit info */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-start gap-2">
              <AlertTriangle size={16} className="text-amber-500 mt-0.5 shrink-0" />
              <div>
                <p className="text-amber-800 text-xs font-semibold">الحد الأقصى للسلفة: {formatUSD(maxAdvance)}</p>
                {wallet && <p className="text-amber-600 text-xs mt-0.5">رصيدك الحالي: {formatUSD(wallet.balanceUSD)}</p>}
              </div>
            </div>

            {/* Quick amounts */}
            <div>
              <p className="text-xs font-semibold text-gray-500 mb-2">مبالغ سريعة</p>
              <div className="flex gap-2 flex-wrap">
                {QUICK_AMOUNTS.map(v => (
                  <button key={v} onClick={() => setAmount(String(v))}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-all ${
                      amountNum === v ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-700 border-gray-200'
                    }`}>
                    ${v}
                  </button>
                ))}
              </div>
            </div>

            {/* Amount input */}
            <div>
              <label className="text-xs font-semibold text-gray-600 mb-1 block">المبلغ المطلوب *</label>
              <div className="relative">
                <DollarSign size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="number" value={amount} onChange={e => setAmount(e.target.value)}
                  placeholder="0.00" min="0" max={maxAdvance}
                  className={`w-full border rounded-xl pr-9 pl-4 py-3 text-base outline-none transition-all ${
                    exceedsMax ? 'border-red-400 bg-red-50' : 'border-gray-200 focus:border-blue-500'
                  }`}
                />
              </div>
              {amountNum > 0 && (
                <p className="text-xs text-gray-500 mt-1">= {formatSYP(amountNum * exchangeRate)}</p>
              )}
              {exceedsMax && (
                <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                  <AlertCircle size={12} /> يتجاوز الحد الأقصى المسموح به
                </p>
              )}
            </div>

            {/* Quick reasons */}
            <div>
              <p className="text-xs font-semibold text-gray-600 mb-2">سبب السلفة *</p>
              <div className="flex gap-2 flex-wrap mb-2">
                {QUICK_REASONS.map(r => (
                  <button key={r} onClick={() => setReason(r)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                      reason === r ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-600 border-gray-200'
                    }`}>
                    {r}
                  </button>
                ))}
              </div>
              <textarea
                value={reason} onChange={e => setReason(e.target.value)}
                placeholder="أو اكتب السبب هنا..."
                rows={2}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-blue-500 resize-none"
              />
            </div>

            {/* Repayment */}
            <div>
              <label className="text-xs font-semibold text-gray-600 mb-2 block">طريقة السداد</label>
              <div className="space-y-2">
                {REPAYMENT_OPTIONS.map(o => (
                  <button key={o} onClick={() => setRepayment(o)}
                    className={`w-full text-right px-3 py-2.5 rounded-xl border text-sm transition-all flex items-center justify-between ${
                      repayment === o ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 text-gray-700'
                    }`}>
                    <span>{o}</span>
                    {repayment === o && <CheckCircle size={16} className="text-blue-500 shrink-0" />}
                  </button>
                ))}
              </div>
            </div>
          </SheetBody>

          <SheetFooter>
            <button onClick={handleSubmit}
              disabled={!amountNum || exceedsMax || !reason}
              className="w-full bg-blue-600 text-white py-3.5 rounded-xl font-bold text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2">
              <Send size={16} />
              إرسال الطلب
            </button>
          </SheetFooter>
        </>
      )}
    </BottomSheetModal>
  );
};

// ─── Add Transaction Modal (for managers) ────────────────────────────────────
const AddTransactionModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { formatUSD, exchangeRate } = useCurrency();
  const { employees, addWalletTransaction, addJournalEntry } = useAppData();
  const [form, setForm] = useState({ workerId: '', type: 'bonus' as WalletTransactionType, amount: '', description: '' });
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const set = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const handleSave = () => {
    const amt = parseFloat(form.amount);
    if (!form.workerId || !amt || !form.description) return;
    setError(null);
    const result = addWalletTransaction({
      worker_id: form.workerId,
      type: form.type,
      amount_usd: amt,
      amount_syp: amt * exchangeRate,
      description: form.description,
    });
    if (!result.success) {
      setError(result.error || 'لا يمكن تنفيذ هذه العملية');
      return;
    }
    if (['bonus', 'deduction'].includes(form.type)) {
      addJournalEntry({
        entry_number: `JE-${Date.now().toString().slice(-6)}`,
        type: form.type === 'bonus' ? 'expense' : 'expense',
        category: form.type === 'bonus' ? 'مكافآت' : 'خصومات',
        description: form.description,
        amount_usd: amt,
        amount_syp: amt * exchangeRate,
        currency: 'USD',
        payment_method: 'cash',
        created_by: 'المشرف',
        entry_date: new Date().toISOString().split('T')[0],
      });
    }
    setSaved(true);
    setTimeout(onClose, 1500);
  };

  return (
    <BottomSheetModal isOpen onClose={onClose}>
      <SheetHeader onClose={onClose}>
        <h3 className="font-bold text-gray-900 text-base">إضافة معاملة مالية</h3>
      </SheetHeader>
      <SheetBody>
        {saved ? (
          <div className="flex flex-col items-center justify-center py-8 gap-3">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center">
              <CheckCircle size={32} className="text-emerald-500" />
            </div>
            <p className="text-gray-700 font-semibold">تمت الإضافة بنجاح</p>
            <p className="text-gray-500 text-sm">{formatUSD(parseFloat(form.amount || '0'))}</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-gray-600 mb-1 block">الموظف</label>
              <select value={form.workerId} onChange={e => set('workerId', e.target.value)}
                className="w-full border border-gray-200 rounded-xl px-3 py-3 text-sm outline-none focus:border-blue-500">
                <option value="">اختر الموظف</option>
                 {employees.map(e => <option key={e.id} value={e.user_id}>{empName(e.user_id, e.position)}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-600 mb-2 block">نوع المعاملة</label>
              <div className="grid grid-cols-3 gap-2">
                {(['bonus', 'deduction', 'overtime'] as WalletTransactionType[]).map(t => {
                  const cfg = TX_CONFIG[t];
                  return (
                    <button key={t} onClick={() => set('type', t)}
                      className={`py-2.5 rounded-xl border text-xs font-semibold transition-all ${
                        form.type === t ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-700 border-gray-200'
                      }`}>
                      {cfg.label}
                    </button>
                  );
                })}
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-600 mb-1 block">المبلغ (USD)</label>
              <div className="relative">
                <DollarSign size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input type="number" value={form.amount} onChange={e => set('amount', e.target.value)}
                  placeholder="0.00"
                  className="w-full border border-gray-200 rounded-xl pr-9 pl-4 py-3 text-base outline-none focus:border-blue-500" />
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-600 mb-1 block">الوصف</label>
              <input value={form.description} onChange={e => set('description', e.target.value)}
                placeholder="وصف المعاملة..."
                className="w-full border border-gray-200 rounded-xl px-3 py-3 text-sm outline-none focus:border-blue-500" />
            </div>
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 text-xs font-semibold rounded-xl px-3 py-2.5">
                {error}
              </div>
            )}
          </div>
        )}
      </SheetBody>
      {!saved && (
        <SheetFooter>
          <button onClick={handleSave}
            disabled={!form.workerId || !form.amount || !form.description}
            className="w-full bg-blue-600 text-white py-3.5 rounded-xl font-bold text-sm disabled:opacity-50 flex items-center justify-center gap-2">
            <CheckCircle size={16} />
            حفظ المعاملة
          </button>
        </SheetFooter>
      )}
    </BottomSheetModal>
  );
};

// ─── Reject Modal ─────────────────────────────────────────────────────────────
const RejectModal: React.FC<{ id: string; onClose: () => void }> = ({ id, onClose }) => {
  const { rejectAdvance } = useAppData();
  const [reason, setReason] = useState('');
  return (
    <BottomSheetModal isOpen onClose={onClose}>
      <SheetHeader onClose={onClose}>
        <h3 className="font-bold text-gray-900 text-base">سبب الرفض</h3>
      </SheetHeader>
      <SheetBody>
        <textarea value={reason} onChange={e => setReason(e.target.value)}
          placeholder="اكتب سبب رفض الطلب..."
          rows={4}
          className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-red-400 resize-none" />
      </SheetBody>
      <SheetFooter>
        <div className="flex gap-3">
          <button aria-label="إغلاق" onClick={onClose} className="flex-1 border border-gray-200 text-gray-600 py-3 rounded-xl font-semibold text-sm">
            إلغاء
          </button>
          <button onClick={() => { if (reason) { rejectAdvance(id, reason); onClose(); } }}
            disabled={!reason}
            className="flex-1 bg-red-600 text-white py-3 rounded-xl font-bold text-sm disabled:opacity-50">
            تأكيد الرفض
          </button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

// ─── Main Page ────────────────────────────────────────────────────────────────
function WalletPage() {
  const { format, formatUSD, formatSYP, currency } = useCurrency();
  const { user, hasRole } = useAuth();
  const {
    wallets, walletTransactions, advanceRequests,
    employees, getWallet, approveAdvance,
  } = useAppData();

  const [tab, setTab] = useState<'wallet' | 'advances' | 'all'>('wallet');
  const [showAdvanceModal, setShowAdvanceModal] = useState(false);
  const [showAddTxModal, setShowAddTxModal] = useState(false);
  const [rejectId, setRejectId] = useState<string | null>(null);
  const [expandedTx, setExpandedTx] = useState<string | null>(null);

  const isManager = hasRole(['admin', 'manager', 'production_supervisor', 'accountant'] as UserRole[]);
  const isWorker = hasRole(['worker'] as UserRole[]);

  // Current user's wallet
  const myWallet = user ? getWallet(user.id) : null;
  const myTransactions = useMemo(() =>
    walletTransactions.filter(t => t.worker_id === user?.id).slice(0, 30),
    [walletTransactions, user]
  );

  // Stats
  const totalIncome = myTransactions.filter(t => ['salary', 'bonus', 'overtime'].includes(t.type)).reduce((s, t) => s + t.amount_usd, 0);
  const totalDeductions = myTransactions.filter(t => ['advance', 'deduction'].includes(t.type)).reduce((s, t) => s + t.amount_usd, 0);

  // All wallets for managers
  const allWallets = useMemo(() => employees.map(e => ({
    employee: e,
    wallet: wallets.find(w => w.workerId === e.user_id) || { workerId: e.user_id, balanceUSD: 0, balanceSYP: 0 },
    txs: walletTransactions.filter(t => t.worker_id === e.user_id),
  })), [employees, wallets, walletTransactions]);

  const totalWalletUSD = wallets.reduce((s, w) => s + w.balanceUSD, 0);

  // Pending advances
  const pendingAdvances = advanceRequests.filter(r => r.status === 'pending');
  const myAdvances = advanceRequests.filter(r => r.worker_id === user?.id);

  return (
    <div style={{ paddingBottom: 'var(--page-pb)' }}>
      {/* Header */}
      <div className="bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-700 px-4 pt-5 pb-16 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-4 left-8 w-32 h-32 bg-white rounded-full" />
          <div className="absolute -bottom-8 right-4 w-48 h-48 bg-white rounded-full" />
        </div>
        <div className="relative">
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-emerald-100 text-sm">المحفظة المالية</p>
              <h1 className="text-white text-2xl font-bold">
                {myWallet ? format(myWallet.balanceUSD, myWallet.balanceSYP) : '$0'}
              </h1>
              {myWallet && currency === 'USD' && (
                <p className="text-emerald-200 text-xs mt-0.5">{formatSYP(myWallet.balanceSYP)}</p>
              )}
            </div>
            <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
              <Wallet size={28} className="text-white" />
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/15 rounded-2xl p-3 backdrop-blur-sm">
              <div className="flex items-center gap-1.5 mb-1">
                <TrendingUp size={14} className="text-emerald-200" />
                <p className="text-emerald-100 text-xs">إجمالي الدخل</p>
              </div>
              <p className="text-white font-bold text-lg">{formatUSD(totalIncome)}</p>
            </div>
            <div className="bg-white/15 rounded-2xl p-3 backdrop-blur-sm">
              <div className="flex items-center gap-1.5 mb-1">
                <TrendingDown size={14} className="text-rose-200" />
                <p className="text-emerald-100 text-xs">إجمالي الخصومات</p>
              </div>
              <p className="text-white font-bold text-lg">{formatUSD(totalDeductions)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="px-4 -mt-6 mb-4 relative z-10 flex gap-3">
        {isWorker && (
          <button onClick={() => setShowAdvanceModal(true)}
            className="flex-1 bg-white rounded-2xl py-3.5 shadow-lg border border-gray-100 flex flex-col items-center gap-1.5 active:scale-95 transition-transform">
            <div className="w-9 h-9 bg-amber-100 rounded-xl flex items-center justify-center">
              <CreditCard size={18} className="text-amber-600" />
            </div>
            <span className="text-xs font-semibold text-gray-700">طلب سلفة</span>
          </button>
        )}
        {isManager && (
          <>
            <button onClick={() => setShowAddTxModal(true)}
              className="flex-1 bg-white rounded-2xl py-3.5 shadow-lg border border-gray-100 flex flex-col items-center gap-1.5 active:scale-95 transition-transform">
              <div className="w-9 h-9 bg-blue-100 rounded-xl flex items-center justify-center">
                <Plus size={18} className="text-blue-600" />
              </div>
              <span className="text-xs font-semibold text-gray-700">معاملة جديدة</span>
            </button>
            <button onClick={() => setTab('advances')}
              className="flex-1 bg-white rounded-2xl py-3.5 shadow-lg border border-gray-100 flex flex-col items-center gap-1.5 active:scale-95 transition-transform relative">
              <div className="w-9 h-9 bg-purple-100 rounded-xl flex items-center justify-center">
                <ArrowUpCircle size={18} className="text-purple-600" />
              </div>
              <span className="text-xs font-semibold text-gray-700">السلف</span>
              {pendingAdvances.length > 0 && (
                <span className="absolute top-2 left-2 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                  {pendingAdvances.length}
                </span>
              )}
            </button>
          </>
        )}
      </div>

      {/* Tabs */}
      <div className="px-4 mb-4">
        <div className="flex bg-gray-100 rounded-2xl p-1 gap-1">
          {[
            { key: 'wallet', label: 'محفظتي' },
            { key: 'advances', label: isManager ? `السلف (${pendingAdvances.length})` : 'سلفي' },
            ...(isManager ? [{ key: 'all', label: 'كل المحافظ' }] : []),
          ].map(t => (
            <button key={t.key} onClick={() => setTab(t.key as typeof tab)}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                tab === t.key ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500'
              }`}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 space-y-4">
        {/* My Wallet Tab */}
        {tab === 'wallet' && (
          <>
            {/* Balance card */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-gray-800 text-sm">ملخص الحساب</h3>
                <Badge variant="success" size="sm">محدّث</Badge>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: 'الرصيد', value: formatUSD(myWallet?.balanceUSD || 0), color: 'text-emerald-600', bg: 'bg-emerald-50' },
                  { label: 'الدخل', value: formatUSD(totalIncome), color: 'text-blue-600', bg: 'bg-blue-50' },
                  { label: 'الخصومات', value: formatUSD(totalDeductions), color: 'text-red-600', bg: 'bg-red-50' },
                ].map(s => (
                  <div key={s.label} className={`${s.bg} rounded-xl p-2.5 text-center`}>
                    <p className={`text-sm font-bold ${s.color}`}>{s.value}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Transactions */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-50 flex items-center justify-between">
                <h3 className="font-bold text-gray-800 text-sm">آخر المعاملات</h3>
                <span className="text-xs text-gray-400">{myTransactions.length} معاملة</span>
              </div>
              {myTransactions.length === 0 ? (
                <EmptyState compact icon={Wallet} title="لا توجد معاملات بعد" />
              ) : (
                <div className="divide-y divide-gray-50">
                  {myTransactions.map(tx => {
                    const cfg = TX_CONFIG[tx.type];
                    const isExpanded = expandedTx === tx.id;
                    return (
                      <div key={tx.id}>
                        <button onClick={() => setExpandedTx(isExpanded ? null : tx.id)}
                          className="w-full flex items-center gap-3 px-4 py-3.5 text-right hover:bg-gray-50 transition-colors">
                          <div className={`w-10 h-10 ${cfg.bg} rounded-xl flex items-center justify-center shrink-0`}>
                            <span className={cfg.color}>{cfg.icon}</span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-gray-800 truncate">{tx.description}</p>
                            <p className="text-xs text-gray-400">{relTime(tx.created_at)}</p>
                          </div>
                          <div className="text-right shrink-0">
                            <p className={`text-sm font-bold ${cfg.color}`}>
                              {cfg.sign}{formatUSD(tx.amount_usd)}
                            </p>
                            <Badge variant={cfg.badge} size="sm">{cfg.label}</Badge>
                          </div>
                          <ChevronDown size={14} className={`text-gray-300 shrink-0 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                        </button>
                        <AnimatePresence>
                          {isExpanded && (
                            <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }}
                              className="overflow-hidden">
                              <div className="px-4 pb-3 bg-gray-50 text-xs text-gray-500 flex flex-col gap-1">
                                <div className="flex justify-between">
                                  <span>بالليرة السورية</span>
                                  <span className="font-semibold text-gray-700">{formatSYP(tx.amount_syp)}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>التاريخ</span>
                                  <span className="font-semibold text-gray-700">{new Date(tx.created_at).toLocaleDateString('ar-SY')}</span>
                                </div>
                                {tx.reference_id && (
                                  <div className="flex justify-between">
                                    <span>رقم المرجع</span>
                                    <span className="font-semibold text-gray-700">{tx.reference_id}</span>
                                  </div>
                                )}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* My advance requests */}
            {myAdvances.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-50">
                  <h3 className="font-bold text-gray-800 text-sm">طلبات السلف</h3>
                </div>
                <div className="divide-y divide-gray-50">
                  {myAdvances.map(adv => (
                    <div key={adv.id} className="px-4 py-3 flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        adv.status === 'pending' ? 'bg-amber-50' : adv.status === 'approved' ? 'bg-emerald-50' : 'bg-red-50'
                      }`}>
                        {adv.status === 'pending' ? <Clock size={18} className="text-amber-500" /> :
                         adv.status === 'approved' ? <CheckCircle size={18} className="text-emerald-500" /> :
                         <X size={18} className="text-red-500" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-800">{adv.reason}</p>
                        <p className="text-xs text-gray-400">{relTime(adv.created_at)}</p>
                        {adv.rejection_reason && <p className="text-xs text-red-500 mt-0.5">{adv.rejection_reason}</p>}
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-sm font-bold text-gray-800">{formatUSD(adv.amount_usd)}</p>
                        <Badge variant={adv.status === 'pending' ? 'warning' : adv.status === 'approved' ? 'success' : 'danger'} size="sm">
                          {adv.status === 'pending' ? 'معلق' : adv.status === 'approved' ? 'معتمد' : 'مرفوض'}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* Advances Tab */}
        {tab === 'advances' && (
          <>
            {/* Summary */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'معلقة', value: advanceRequests.filter(r => r.status === 'pending').length, color: 'text-amber-600', bg: 'bg-amber-50' },
                { label: 'معتمدة', value: advanceRequests.filter(r => r.status === 'approved').length, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                { label: 'مرفوضة', value: advanceRequests.filter(r => r.status === 'rejected').length, color: 'text-red-600', bg: 'bg-red-50' },
              ].map(s => (
                <div key={s.label} className={`${s.bg} rounded-2xl p-3 text-center`}>
                  <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
                  <p className="text-xs text-gray-500">{s.label}</p>
                </div>
              ))}
            </div>

            {/* Advance requests */}
            {advanceRequests.length === 0 ? (
              <EmptyState compact icon={CreditCard} title="لا توجد طلبات سلف" />
            ) : (
              <div className="space-y-3">
                {advanceRequests.map(adv => (
                  <div key={adv.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center shrink-0">
                        <User size={18} className="text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-bold text-gray-800 text-sm">{adv.worker_name}</p>
                          <Badge variant={adv.status === 'pending' ? 'warning' : adv.status === 'approved' ? 'success' : 'danger'} size="sm">
                            {adv.status === 'pending' ? 'معلق' : adv.status === 'approved' ? 'معتمد' : 'مرفوض'}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-500 mt-0.5">{adv.reason}</p>
                        <div className="flex items-center gap-3 mt-2">
                          <span className="text-sm font-bold text-gray-800">{formatUSD(adv.amount_usd)}</span>
                          <span className="text-xs text-gray-400">{relTime(adv.created_at)}</span>
                        </div>
                        {adv.rejection_reason && (
                          <p className="text-xs text-red-500 mt-1 bg-red-50 px-2 py-1 rounded-lg">
                            سبب الرفض: {adv.rejection_reason}
                          </p>
                        )}
                      </div>
                    </div>

                    {adv.status === 'pending' && isManager && (
                      <div className="flex gap-2 mt-3 pt-3 border-t border-gray-50">
                        <button onClick={() => approveAdvance(adv.id)}
                          className="flex-1 bg-emerald-500 text-white py-2.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-1.5 active:scale-95 transition-transform">
                          <ThumbsUp size={14} /> موافقة
                        </button>
                        <button onClick={() => setRejectId(adv.id)}
                          className="flex-1 bg-red-50 text-red-600 border border-red-200 py-2.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-1.5 active:scale-95 transition-transform">
                          <ThumbsDown size={14} /> رفض
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* All Wallets Tab (Manager) */}
        {tab === 'all' && isManager && (
          <>
            {/* Total */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-4 text-white">
              <p className="text-blue-100 text-sm mb-1">إجمالي محافظ الموظفين</p>
              <p className="text-3xl font-bold">{formatUSD(totalWalletUSD)}</p>
              <p className="text-blue-200 text-xs mt-1">{allWallets.length} محفظة نشطة</p>
            </div>

            {/* Wallets list */}
            <div className="space-y-3">
              {allWallets.map(({ employee, wallet, txs }) => {
                const lastTx = txs[0];
                return (
                  <div key={employee.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white font-bold text-sm shrink-0"
                        style={{ background: 'linear-gradient(135deg, #3b82f6, #6366f1)' }}>
                        {empName(employee.user_id, employee.position).charAt(0)}
                      </div>
                       <div className="flex-1 min-w-0">
                         <p className="font-bold text-gray-800 text-sm">{empName(employee.user_id, employee.position)}</p>
                        <p className="text-xs text-gray-400">{employee.position}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="font-bold text-emerald-600">{formatUSD(wallet.balanceUSD)}</p>
                        <p className="text-xs text-gray-400">{formatSYP(wallet.balanceSYP)}</p>
                      </div>
                    </div>
                    {lastTx && (
                      <div className="mt-3 pt-3 border-t border-gray-50 flex items-center justify-between text-xs text-gray-500">
                        <span>آخر معاملة: {TX_CONFIG[lastTx.type]?.label}</span>
                        <span>{relTime(lastTx.created_at)}</span>
                      </div>
                    )}
                    <div className="mt-2 flex gap-2">
                      <button onClick={() => {
                        setShowAddTxModal(true);
                      }} className="flex-1 bg-blue-50 text-blue-600 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1">
                        <Plus size={12} /> إضافة معاملة
                      </button>
                      <span className="flex-1 bg-gray-50 text-gray-500 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1">
                        <ChevronRight size={12} /> {txs.length} معاملة
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>

      {/* Modals */}
      {showAdvanceModal && <AdvanceModal onClose={() => setShowAdvanceModal(false)} />}
      {showAddTxModal && <AddTransactionModal onClose={() => setShowAddTxModal(false)} />}
      {rejectId && <RejectModal id={rejectId} onClose={() => setRejectId(null)} />}
    </div>
  );
}

export default React.memo(WalletPage);
