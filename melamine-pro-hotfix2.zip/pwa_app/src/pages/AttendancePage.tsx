import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  MapPin, CheckCircle, XCircle, AlertCircle,
  Calendar, TrendingUp, LogIn, LogOut, Wifi, WifiOff,
  RefreshCw, ChevronDown, ChevronUp, Navigation, Shield,
  Clock, Users, Activity, Timer
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Badge } from '../components/ui/Badge';
import { useAuth } from '../contexts/AuthContext';
import { useAppData } from '../contexts/AppDataContext';
import type { AttendanceStatus, AttendanceRecord } from '../types';
import { geoPreflight, geoErrorMessage, GEO_OPTIONS } from '../utils/geo';
import { haversineDistance } from '../utils/print';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { useCurrency } from '../contexts/CurrencyContext';

// ─── Types ─────────────────────────────────────────────────────────────────────
interface OfflineEntry { type: 'check_in' | 'check_out'; workerId: string; lat: number; lng: number; ts: string; }

// ─── Config ───────────────────────────────────────────────────────────────────
const STATUS_CONFIG: Record<AttendanceStatus, {
  label: string; badge: 'success' | 'danger' | 'warning' | 'info' | 'default';
  color: string; bg: string; icon: React.ReactNode;
}> = {
  present:  { label: 'حاضر',     badge: 'success', color: 'text-emerald-700', bg: 'bg-emerald-50', icon: <CheckCircle size={13} /> },
  absent:   { label: 'غائب',     badge: 'danger',  color: 'text-red-700',     bg: 'bg-red-50',     icon: <XCircle size={13} /> },
  late:     { label: 'متأخر',    badge: 'warning', color: 'text-amber-700',   bg: 'bg-amber-50',   icon: <Timer size={13} /> },
  half_day: { label: 'نصف يوم', badge: 'info',    color: 'text-blue-700',    bg: 'bg-blue-50',    icon: <Clock size={13} /> },
  on_leave: { label: 'إجازة',   badge: 'default', color: 'text-gray-700',    bg: 'bg-gray-50',    icon: <Calendar size={13} /> },
};

const WORKER_NAMES: Record<string, string> = {
  'demo-admin-001':      'أحمد المدير',
  'demo-manager-002':    'محمد المشرف',
  'demo-supervisor-003': 'خالد المراقب',
  'demo-worker-004':     'علي العامل',
  'demo-accountant-005': 'سمر المحاسبة',
  'demo-hr-006':         'ريم الموارد البشرية',
};

const WORKER_ROLES: Record<string, string> = {
  'demo-admin-001':      'مدير النظام',
  'demo-manager-002':    'مدير الإنتاج',
  'demo-supervisor-003': 'مشرف الإنتاج',
  'demo-worker-004':     'عامل إنتاج',
  'demo-accountant-005': 'محاسب',
  'demo-hr-006':         'موارد بشرية',
};

const getDistance = haversineDistance;

const formatTime = (iso?: string) => {
  if (!iso) return '--:--';
  return new Date(iso).toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' });
};

const formatDuration = (start?: string, end?: string): string => {
  if (!start) return '-';
  const ms = (end ? new Date(end) : new Date()).getTime() - new Date(start).getTime();
  if (ms < 0) return '-';
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  return `${h}س ${m}د`;
};

// ─── Live Clock ───────────────────────────────────────────────────────────────
const LiveClock: React.FC = () => {
  const [time, setTime] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setTime(new Date()), 1000); return () => clearInterval(t); }, []);
  return (
    <div className="text-center">
      <p className="text-4xl font-black text-white tracking-wider tabular-nums">
        {time.toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
      </p>
      <p className="text-white/70 text-sm mt-1">
        {time.toLocaleDateString('ar-SY', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
      </p>
    </div>
  );
};

// ─── Map Preview ───────────────────────────────────────────────────────────────
const MapPreview: React.FC<{ lat: number; lng: number; insideZone: boolean; distance: number }> = ({ lat, lng, insideZone, distance }) => (
  <div className="relative bg-gradient-to-br from-blue-100 to-teal-100 rounded-2xl h-44 overflow-hidden">
    <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
      <defs><pattern id="attgrid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="#3b82f6" strokeWidth="0.5"/></pattern></defs>
      <rect width="100%" height="100%" fill="url(#attgrid)"/>
    </svg>
    {/* Factory zone circle */}
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
      <div className={`w-20 h-20 rounded-full border-4 border-dashed ${insideZone ? 'border-emerald-400 bg-emerald-400/20' : 'border-red-400 bg-red-400/10'} flex items-center justify-center transition-colors`}>
        <div className="w-7 h-7 bg-blue-600 rounded-full flex items-center justify-center shadow-lg">
          <div className="w-3 h-3 bg-white rounded-full" />
        </div>
      </div>
    </div>
    {/* User pin */}
    {insideZone ? (
      <motion.div
        animate={{ y: [-3, 3, -3] }}
        transition={{ repeat: Infinity, duration: 1.4 }}
        className="absolute"
        style={{ top: 'calc(50% - 8px)', left: 'calc(50% + 12px)' }}
      >
        <div className="w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-md" />
      </motion.div>
    ) : (
      <div className="absolute bottom-10 right-10">
        <div className="w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-md" />
        <div className="w-1.5 h-3 bg-red-500 mx-auto rounded-b" />
      </div>
    )}
    {/* Labels */}
    <div className="absolute bottom-2 left-2 right-2 flex justify-between items-end">
      <span className="text-[9px] bg-white/80 backdrop-blur-sm px-1.5 py-0.5 rounded text-blue-700">{lat.toFixed(4)}°N</span>
      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${insideZone ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'}`}>
        {Math.round(distance)}م
      </span>
      <span className="text-[9px] bg-white/80 backdrop-blur-sm px-1.5 py-0.5 rounded text-blue-700">{lng.toFixed(4)}°E</span>
    </div>
    <div className="absolute top-2 right-2">
      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold ${insideZone ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
        {insideZone ? 'داخل النطاق' : 'خارج النطاق'}
      </span>
    </div>
  </div>
);

// ─── Check-in Button ───────────────────────────────────────────────────────────
const CheckinButton: React.FC<{ checkedIn: boolean; onPress: () => void; isLoading: boolean }> = ({ checkedIn, onPress, isLoading }) => (
  <div className="flex flex-col items-center gap-3">
    <button
      onClick={onPress}
      disabled={isLoading}
      className={`relative w-32 h-32 rounded-full flex flex-col items-center justify-center gap-1.5 shadow-2xl text-white font-bold text-base transition-all active:scale-95 ${
        checkedIn
          ? 'bg-gradient-to-br from-red-500 to-rose-600 shadow-red-500/40'
          : 'bg-gradient-to-br from-emerald-500 to-teal-600 shadow-emerald-500/40'
      } ${isLoading ? 'opacity-60' : ''}`}
    >
      {!checkedIn && !isLoading && <span className="absolute inset-0 rounded-full bg-emerald-400 animate-ping opacity-20" />}
      {isLoading ? <RefreshCw size={28} className="animate-spin" /> :
       checkedIn ? (<><LogOut size={26} /><span className="text-sm font-bold">خروج</span></>) :
                  (<><LogIn size={26} /><span className="text-sm font-bold">دخول</span></>)}
    </button>
    <p className="text-xs text-gray-500 text-center max-w-[160px]">
      {isLoading ? 'جاري التحقق من الموقع...' : checkedIn ? 'اضغط لتسجيل الانصراف' : 'اضغط لتسجيل الحضور بالموقع الجغرافي'}
    </p>
  </div>
);

// ─── Main Page ─────────────────────────────────────────────────────────────────
export const AttendancePage: React.FC = () => {
  const { user, isDemoMode } = useAuth();
  const { attendanceRecords, checkIn, checkOut, systemSettings, addNotification, employees } = useAppData();
  const { formatUSD } = useCurrency();

  const [viewMode, setViewMode]           = useState<'today' | 'week' | 'all'>('today');
  const [showGeoModal, setShowGeoModal]   = useState(false);
  const [isLocating, setIsLocating]       = useState(false);
  const [userLocation, setUserLocation]   = useState<{ lat: number; lng: number } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [isOffline, setIsOffline]         = useState(!navigator.onLine);
  const [offlineQueue, setOfflineQueue]   = useState<OfflineEntry[]>(() => {
    try { return JSON.parse(localStorage.getItem('att_offline_queue') || '[]'); } catch { return []; }
  });
  const [expandedId, setExpandedId]       = useState<string | null>(null);
  const [isSyncing, setIsSyncing]         = useState(false);
  const syncRef = useRef(false);

  const FACTORY = {
    lat: systemSettings.factoryLat,
    lng: systemSettings.factoryLng,
    radius: systemSettings.attendanceRadius,
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const myRecord = attendanceRecords.find(a => a.worker_id === user?.id && a.date === todayStr);
  const checkedIn = !!myRecord?.check_in && !myRecord?.check_out;

  // ── Computed stats ────────────────────────────────────────────────────────
  const todayRecords = attendanceRecords.filter(a => a.date === todayStr);
  const weekAgo      = new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0];
  const weekRecords  = attendanceRecords.filter(a => a.date >= weekAgo);
  const displayRecords = viewMode === 'today' ? todayRecords : viewMode === 'week' ? weekRecords : attendanceRecords;

  const presentCount    = todayRecords.filter(a => a.status === 'present' || a.status === 'late').length;
  const absentCount     = todayRecords.filter(a => a.status === 'absent').length;
  const lateCount       = todayRecords.filter(a => a.status === 'late').length;
  const attendancePct   = todayRecords.length > 0 ? Math.round((presentCount / todayRecords.length) * 100) : 0;

  // My weekly stats
  const myWeekRecords   = weekRecords.filter(a => a.worker_id === user?.id);
  const myPresentDays   = myWeekRecords.filter(a => a.status === 'present' || a.status === 'late').length;
  const myLateDays      = myWeekRecords.filter(a => a.status === 'late').length;
  const myTotalHours    = myWeekRecords.reduce((sum, r) => {
    if (!r.check_in) return sum;
    const ms = r.check_out ? new Date(r.check_out).getTime() - new Date(r.check_in).getTime() : 0;
    return sum + ms / 3600000;
  }, 0);

  // ── Online/Offline ────────────────────────────────────────────────────────
  const syncQueue = useCallback(async (queue: OfflineEntry[]) => {
    if (syncRef.current || queue.length === 0) return;
    syncRef.current = true;
    setIsSyncing(true);
    await new Promise(r => setTimeout(r, 1000)); // simulate sync
    queue.forEach(entry => {
      if (entry.type === 'check_in') checkIn(entry.workerId, entry.lat, entry.lng);
      else checkOut(entry.workerId, entry.lat, entry.lng);
    });
    setOfflineQueue([]);
    localStorage.removeItem('att_offline_queue');
    addNotification({ title: 'مزامنة الحضور', message: `تم مزامنة ${queue.length} سجل`, type: 'success', role_target: 'production_supervisor' });
    syncRef.current = false;
    setIsSyncing(false);
  }, [checkIn, checkOut, addNotification]);

  useEffect(() => {
    const onOnline  = () => { setIsOffline(false); const q = JSON.parse(localStorage.getItem('att_offline_queue') || '[]'); syncQueue(q); };
    const onOffline = () => setIsOffline(true);
    window.addEventListener('online',  onOnline);
    window.addEventListener('offline', onOffline);
    return () => { window.removeEventListener('online', onOnline); window.removeEventListener('offline', onOffline); };
  }, [syncQueue]);

  useEffect(() => {
    localStorage.setItem('att_offline_queue', JSON.stringify(offlineQueue));
  }, [offlineQueue]);

  // ── Geolocation ───────────────────────────────────────────────────────────
  const requestLocation = useCallback(() => {
    setIsLocating(true);
    setLocationError(null);
    setUserLocation(null);

    // Demo fallback places the user inside the zone so the demo flow always works.
    const demoFallback = (note?: string) => {
      if (note) setLocationError(note);
      setTimeout(() => {
        setUserLocation({ lat: FACTORY.lat + 0.0003, lng: FACTORY.lng + 0.0002 });
        setIsLocating(false);
      }, 1000);
    };

    // Support / secure-context (HTTPS) preflight.
    const blocked = geoPreflight();
    if (blocked) {
      if (isDemoMode) demoFallback(`${blocked} — وضع تجريبي`);
      else { setLocationError(blocked); setIsLocating(false); }
      return;
    }

    // Requesting the position triggers the device's location-permission prompt.
    navigator.geolocation.getCurrentPosition(
      pos => {
        setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocationError(null);
        setIsLocating(false);
      },
      err => {
        // Real mode: surface the real error so the worker can grant permission;
        // never fake a location. Demo mode keeps working with a sample position.
        if (isDemoMode) {
          demoFallback(`${geoErrorMessage(err)} — وضع تجريبي`);
        } else {
          setUserLocation(null);
          setLocationError(geoErrorMessage(err));
          setIsLocating(false);
        }
      },
      GEO_OPTIONS,
    );
  }, [FACTORY.lat, FACTORY.lng, isDemoMode]);

  const distance  = userLocation ? getDistance(FACTORY.lat, FACTORY.lng, userLocation.lat, userLocation.lng) : 0;
  const insideZone = userLocation ? distance <= FACTORY.radius : false;

  const handleCheckInPress = () => { setShowGeoModal(true); requestLocation(); };

  const handleCheckOutPress = () => {
    if (!user) return;
    if (navigator.vibrate) navigator.vibrate(100);
    const loc = userLocation ?? { lat: FACTORY.lat, lng: FACTORY.lng };
    if (isOffline) {
      const entry: OfflineEntry = { type: 'check_out', workerId: user.id, ...loc, ts: new Date().toISOString() };
      setOfflineQueue(q => [...q, entry]);
    } else {
      checkOut(user.id, loc.lat, loc.lng);
    }
  };

  const confirmCheckIn = () => {
    if (!user) return;
    if (!insideZone && !isOffline) return;
    if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
    const loc = userLocation ?? { lat: FACTORY.lat, lng: FACTORY.lng };
    if (isOffline) {
      const entry: OfflineEntry = { type: 'check_in', workerId: user.id, ...loc, ts: new Date().toISOString() };
      setOfflineQueue(q => [...q, entry]);
    } else {
      checkIn(user.id, loc.lat, loc.lng);
    }
    setShowGeoModal(false);
  };

  const isWorker  = user?.role === 'worker';
  const isManager = !!user?.role && ['admin', 'manager', 'hr', 'production_supervisor'].includes(user.role);

  const getEmpName = (workerId: string) => {
    const emp = employees.find(e => e.user_id === workerId);
    return WORKER_NAMES[workerId] || emp?.position || workerId;
  };

  const getEmpRole = (workerId: string) => WORKER_ROLES[workerId] || 'موظف';

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">

      {/* ── Offline Banner ─────────────────────────────────────────────── */}
      <AnimatePresence>
        {isOffline && (
          <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }}
            className="bg-amber-500 text-white overflow-hidden sticky top-0 z-20"
          >
            <div className="px-4 py-2 flex items-center gap-2">
              <WifiOff size={13} className="shrink-0" />
              <p className="text-xs font-medium flex-1">وضع بدون اتصال — سيتم مزامنة السجلات تلقائياً عند الاتصال</p>
              {offlineQueue.length > 0 && (
                <span className="bg-white/20 text-[10px] px-1.5 py-0.5 rounded-full">{offlineQueue.length} معلق</span>
              )}
            </div>
          </motion.div>
        )}
        {isSyncing && (
          <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }}
            className="bg-blue-500 text-white overflow-hidden"
          >
            <div className="px-4 py-2 flex items-center gap-2">
              <RefreshCw size={13} className="animate-spin shrink-0" />
              <p className="text-xs font-medium">جاري مزامنة سجلات الحضور...</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Hero Header ────────────────────────────────────────────────── */}
      <div className={`relative px-4 pt-6 pb-8 text-white transition-colors ${
        checkedIn ? 'bg-gradient-to-br from-emerald-600 via-teal-700 to-green-800' :
                    'bg-gradient-to-br from-blue-700 via-indigo-700 to-violet-800'
      }`}>
        {/* Pattern */}
        <div className="absolute inset-0 opacity-10">
          <svg width="100%" height="100%"><defs><pattern id="dots" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse"><circle cx="10" cy="10" r="1" fill="white"/></pattern></defs><rect width="100%" height="100%" fill="url(#dots)"/></svg>
        </div>

        <div className="relative">
          <LiveClock />

          {/* Check-in status card */}
          <div className="mt-5 bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/20">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className={`w-2.5 h-2.5 rounded-full ${checkedIn ? 'bg-emerald-300 animate-pulse' : 'bg-white/50'}`} />
                <span className="text-white/80 text-sm font-medium">
                  {checkedIn ? 'أنت في العمل' : myRecord ? 'انتهيت من العمل' : 'لم تسجل حضوراً بعد'}
                </span>
              </div>
              {myRecord && <Badge variant={STATUS_CONFIG[myRecord.status as AttendanceStatus]?.badge || 'default'} size="sm">{STATUS_CONFIG[myRecord.status as AttendanceStatus]?.label || myRecord.status}</Badge>}
            </div>

            <div className="grid grid-cols-3 gap-3 mb-4">
              {[
                { label: 'الدخول',   val: formatTime(myRecord?.check_in),  icon: <LogIn size={13}/>,  color: 'text-emerald-300' },
                { label: 'الخروج',  val: formatTime(myRecord?.check_out), icon: <LogOut size={13}/>, color: 'text-red-300' },
                { label: 'المدة',   val: formatDuration(myRecord?.check_in, myRecord?.check_out), icon: <Clock size={13}/>, color: 'text-blue-300' },
              ].map((item, i) => (
                <div key={i} className="text-center">
                  <div className={`flex justify-center mb-1 ${item.color}`}>{item.icon}</div>
                  <p className="text-white font-bold text-base tabular-nums">{item.val}</p>
                  <p className="text-white/60 text-[10px]">{item.label}</p>
                </div>
              ))}
            </div>

            <CheckinButton
              checkedIn={checkedIn}
              onPress={checkedIn ? handleCheckOutPress : handleCheckInPress}
              isLoading={isLocating && !showGeoModal}
            />
          </div>

          {/* My weekly stats */}
          <div className="mt-3 grid grid-cols-3 gap-2">
            {[
              { label: 'أيام هذا الأسبوع', val: myPresentDays, icon: <Calendar size={13}/> },
              { label: 'تأخيرات',           val: myLateDays,    icon: <Timer size={13}/> },
              { label: 'ساعات العمل',        val: `${myTotalHours.toFixed(1)}س`, icon: <Clock size={13}/> },
            ].map((s, i) => (
              <div key={i} className="bg-white/10 rounded-xl p-2.5 text-center backdrop-blur-sm">
                <div className="flex justify-center text-white/70 mb-1">{s.icon}</div>
                <p className="text-white font-black text-lg tabular-nums">{s.val}</p>
                <p className="text-white/60 text-[9px] leading-tight">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Manager/Supervisor View ─────────────────────────────────────── */}
      {isManager && (
        <div className="px-4 pt-5 space-y-4">

          {/* KPI cards */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'حاضر اليوم',  val: presentCount,    icon: <CheckCircle size={16}/>, color: 'bg-emerald-500', bg: 'bg-emerald-50' },
              { label: 'غائب اليوم',  val: absentCount,     icon: <XCircle size={16}/>,     color: 'bg-red-500',     bg: 'bg-red-50' },
              { label: 'متأخر اليوم', val: lateCount,       icon: <Timer size={16}/>,       color: 'bg-amber-500',   bg: 'bg-amber-50' },
              { label: 'نسبة الحضور', val: `${attendancePct}%`, icon: <TrendingUp size={16}/>, color: 'bg-blue-500', bg: 'bg-blue-50' },
            ].map((k, i) => (
              <div key={i} className={`${k.bg} rounded-2xl p-4 border border-white`}>
                <div className={`w-9 h-9 ${k.color} rounded-xl flex items-center justify-center text-white mb-2 shadow-sm`}>{k.icon}</div>
                <p className="text-2xl font-black text-gray-800 tabular-nums">{k.val}</p>
                <p className="text-xs text-gray-500 mt-0.5">{k.label}</p>
              </div>
            ))}
          </div>

          {/* Attendance rate bar */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Activity size={15} className="text-blue-500" />
                <span className="font-bold text-gray-800 text-sm">نسبة الحضور اليوم</span>
              </div>
              <span className="text-blue-600 font-black text-lg">{attendancePct}%</span>
            </div>
            <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${attendancePct}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
                className={`h-full rounded-full ${attendancePct >= 80 ? 'bg-emerald-500' : attendancePct >= 60 ? 'bg-amber-500' : 'bg-red-500'}`}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-400 mt-1.5">
              <span>{presentCount} حاضر</span>
              <span>{absentCount} غائب</span>
            </div>
          </div>

          {/* View filter */}
          <div className="flex gap-2">
            {(['today', 'week', 'all'] as const).map(m => (
              <button key={m} onClick={() => setViewMode(m)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${viewMode === m ? 'bg-blue-600 text-white shadow' : 'bg-white text-gray-500 border border-gray-200'}`}
              >
                {m === 'today' ? 'اليوم' : m === 'week' ? 'الأسبوع' : 'الكل'}
              </button>
            ))}
          </div>

          {/* Records list */}
          <div className="space-y-2 pb-6">
            <div className="flex items-center justify-between">
              <p className="text-sm font-bold text-gray-700 flex items-center gap-1.5"><Users size={14} />{displayRecords.length} سجل</p>
              {isOffline && offlineQueue.length > 0 && (
                <button onClick={() => syncQueue(offlineQueue)} className="flex items-center gap-1 text-xs text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
                  <RefreshCw size={11} />مزامنة ({offlineQueue.length})
                </button>
              )}
            </div>

            {displayRecords.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center shadow-sm border border-gray-100">
                <Calendar size={36} className="text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 text-sm">لا توجد سجلات حضور</p>
              </div>
            ) : (
              displayRecords.map(record => {
                const cfg = STATUS_CONFIG[record.status as AttendanceStatus];
                const isExpanded = expandedId === record.id;
                const workerHours = record.check_in ? formatDuration(record.check_in, record.check_out) : '-';
                return (
                  <div key={record.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                    <button
                      onClick={() => setExpandedId(isExpanded ? null : record.id)}
                      className="w-full flex items-center gap-3 p-4 text-right active:bg-gray-50 transition-colors"
                    >
                      {/* Avatar */}
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 text-white font-bold text-base ${
                        record.status === 'present' ? 'bg-emerald-500' :
                        record.status === 'late'    ? 'bg-amber-500' :
                        record.status === 'absent'  ? 'bg-red-500'   : 'bg-gray-400'
                      }`}>
                        {getEmpName(record.worker_id).charAt(0)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-gray-800 text-sm truncate">{getEmpName(record.worker_id)}</p>
                        <p className="text-gray-400 text-xs">{getEmpRole(record.worker_id)} • {record.date}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Badge variant={cfg?.badge || 'default'} size="sm">{cfg?.label || record.status}</Badge>
                        {isExpanded ? <ChevronUp size={15} className="text-gray-400" /> : <ChevronDown size={15} className="text-gray-400" />}
                      </div>
                    </button>

                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="border-t border-gray-100 overflow-hidden"
                        >
                          <div className="px-4 py-3 grid grid-cols-2 gap-3">
                            {[
                              { label: 'تسجيل الدخول',   val: formatTime(record.check_in),  icon: <LogIn size={12}/>,     color: 'text-emerald-600' },
                              { label: 'تسجيل الخروج',  val: formatTime(record.check_out), icon: <LogOut size={12}/>,    color: 'text-red-600' },
                              { label: 'ساعات العمل',    val: workerHours,                  icon: <Clock size={12}/>,     color: 'text-blue-600' },
                              { label: 'الموقع',         val: record.location_lat ? `${record.location_lat.toFixed(3)}°` : 'غير محدد', icon: <MapPin size={12}/>, color: 'text-purple-600' },
                            ].map((item, i) => (
                              <div key={i} className="bg-gray-50 rounded-xl p-2.5">
                                <div className={`flex items-center gap-1 mb-1 ${item.color}`}>{item.icon}<span className="text-[10px] font-medium text-gray-500">{item.label}</span></div>
                                <p className="text-gray-800 font-bold text-sm tabular-nums">{item.val}</p>
                              </div>
                            ))}
                          </div>
                          {record.notes && (
                            <div className="px-4 pb-3">
                              <p className="text-xs text-gray-500 bg-gray-50 rounded-xl p-2.5">{record.notes}</p>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ── Worker Only: My History ──────────────────────────────────────── */}
      {isWorker && (
        <div className="px-4 pt-5 space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm font-bold text-gray-700">سجل حضوري</p>
            <div className="flex gap-1.5">
              {(['today', 'week', 'all'] as const).map(m => (
                <button key={m} onClick={() => setViewMode(m)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${viewMode === m ? 'bg-blue-600 text-white' : 'bg-white text-gray-500 border border-gray-200'}`}
                >
                  {m === 'today' ? 'اليوم' : m === 'week' ? 'أسبوع' : 'الكل'}
                </button>
              ))}
            </div>
          </div>

          {attendanceRecords.filter(a => a.worker_id === user?.id && (viewMode === 'today' ? a.date === todayStr : viewMode === 'week' ? a.date >= weekAgo : true)).length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center shadow-sm border border-gray-100">
              <Calendar size={36} className="text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">لا توجد سجلات حضور</p>
            </div>
          ) : (
            attendanceRecords
              .filter(a => a.worker_id === user?.id && (viewMode === 'today' ? a.date === todayStr : viewMode === 'week' ? a.date >= weekAgo : true))
              .slice(0, 20)
              .map(record => {
                const cfg = STATUS_CONFIG[record.status as AttendanceStatus];
                return (
                  <div key={record.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Calendar size={14} className="text-gray-400" />
                        <span className="text-sm font-bold text-gray-700">{record.date}</span>
                      </div>
                      <Badge variant={cfg?.badge || 'default'} size="sm">{cfg?.label}</Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { label: 'الدخول',  val: formatTime(record.check_in),  color: 'text-emerald-600' },
                        { label: 'الخروج', val: formatTime(record.check_out), color: 'text-red-600' },
                        { label: 'المدة',  val: formatDuration(record.check_in, record.check_out), color: 'text-blue-600' },
                      ].map((item, i) => (
                        <div key={i} className="text-center bg-gray-50 rounded-xl p-2">
                          <p className={`font-bold text-sm tabular-nums ${item.color}`}>{item.val}</p>
                          <p className="text-gray-400 text-[10px]">{item.label}</p>
                        </div>
                      ))}
                    </div>
                    {record.location_lat && (
                      <div className="mt-2 flex items-center gap-1.5 text-[11px] text-gray-400">
                        <MapPin size={10} />
                        <span>{record.location_lat.toFixed(4)}, {record.location_lng?.toFixed(4)}</span>
                        <span className="mr-auto text-emerald-600 flex items-center gap-0.5"><CheckCircle size={10} />داخل النطاق</span>
                      </div>
                    )}
                  </div>
                );
              })
          )}
        </div>
      )}

      {/* ── Geo Modal ──────────────────────────────────────────────────────── */}
      <BottomSheetModal isOpen={showGeoModal} onClose={() => setShowGeoModal(false)}>
        <SheetHeader onClose={() => setShowGeoModal(false)}>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-100 rounded-xl flex items-center justify-center">
              <Navigation size={16} className="text-blue-600" />
            </div>
            <span className="font-bold text-gray-800">التحقق من الموقع</span>
          </div>
        </SheetHeader>
        <SheetBody>
          <div className="space-y-4">
            {isLocating ? (
              <div className="flex flex-col items-center gap-4 py-8">
                <div className="relative w-16 h-16">
                  <div className="absolute inset-0 rounded-full bg-blue-100 animate-ping opacity-60" />
                  <div className="relative w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center">
                    <Navigation size={28} className="text-white" />
                  </div>
                </div>
                <p className="text-gray-600 font-medium text-sm">جاري تحديد موقعك...</p>
                <p className="text-gray-400 text-xs text-center">يرجى السماح بالوصول إلى الموقع الجغرافي</p>
              </div>
            ) : userLocation ? (
              <>
                <MapPreview lat={userLocation.lat} lng={userLocation.lng} insideZone={insideZone} distance={distance} />
                <div className={`rounded-2xl p-4 border-2 ${insideZone ? 'bg-emerald-50 border-emerald-200' : 'bg-red-50 border-red-200'}`}>
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${insideZone ? 'bg-emerald-500' : 'bg-red-500'}`}>
                      {insideZone ? <CheckCircle size={20} className="text-white" /> : <XCircle size={20} className="text-white" />}
                    </div>
                    <div>
                      <p className={`font-bold text-sm ${insideZone ? 'text-emerald-700' : 'text-red-700'}`}>
                        {insideZone ? 'أنت داخل نطاق المصنع' : 'أنت خارج نطاق المصنع'}
                      </p>
                      <p className={`text-xs mt-0.5 ${insideZone ? 'text-emerald-600' : 'text-red-600'}`}>
                        المسافة: {Math.round(distance)}م • الحد المسموح: {FACTORY.radius}م
                      </p>
                    </div>
                  </div>
                </div>
                {locationError && (
                  <div className="bg-amber-50 rounded-xl p-3 flex items-center gap-2">
                    <AlertCircle size={14} className="text-amber-500 shrink-0" />
                    <p className="text-xs text-amber-700">{locationError}</p>
                  </div>
                )}
                <div className="bg-gray-50 rounded-xl p-3 space-y-1.5">
                  {[
                    { label: 'موقعك', val: `${userLocation.lat.toFixed(5)}, ${userLocation.lng.toFixed(5)}` },
                    { label: 'موقع المصنع', val: `${FACTORY.lat.toFixed(5)}, ${FACTORY.lng.toFixed(5)}` },
                    { label: 'الوقت', val: new Date().toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) },
                  ].map((item, i) => (
                    <div key={i} className="flex justify-between items-center text-xs">
                      <span className="text-gray-500">{item.label}</span>
                      <span className="font-mono text-gray-700 font-medium">{item.val}</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center gap-4 py-6">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                  <AlertCircle size={30} className="text-red-500" />
                </div>
                <p className="text-gray-700 font-bold text-sm text-center">
                  {locationError || 'تعذّر تحديد موقعك'}
                </p>
                <p className="text-gray-400 text-xs text-center leading-relaxed">
                  يحتاج تسجيل الحضور إلى إذن الوصول للموقع من جهازك. فعّل إذن الموقع
                  من إعدادات المتصفح/الجهاز ثم أعد المحاولة.
                </p>
                <button
                  onClick={requestLocation}
                  className="w-full py-3 bg-blue-600 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2">
                  <Navigation size={16} /> السماح بالوصول وإعادة المحاولة
                </button>
              </div>
            )}
          </div>
        </SheetBody>
        <SheetFooter>
          <div className="flex gap-3">
            <button onClick={() => setShowGeoModal(false)}
              className="flex-1 py-3.5 rounded-xl border-2 border-gray-200 text-gray-600 font-bold text-sm active:scale-95 transition-all"
            >إلغاء</button>
            <button
              onClick={confirmCheckIn}
              disabled={isLocating || (!insideZone && !isOffline)}
              className={`flex-1 py-3.5 rounded-xl font-bold text-sm text-white active:scale-95 transition-all ${
                isLocating || (!insideZone && !isOffline)
                  ? 'bg-gray-300 cursor-not-allowed'
                  : 'bg-emerald-500 shadow-lg shadow-emerald-200'
              }`}
            >
              {isLocating ? 'جاري التحديد...' : isOffline ? 'حفظ بدون اتصال' : !insideZone ? 'خارج النطاق' : 'تأكيد الحضور'}
            </button>
          </div>
        </SheetFooter>
      </BottomSheetModal>

    </div>
  );
};

export default React.memo(AttendancePage);
