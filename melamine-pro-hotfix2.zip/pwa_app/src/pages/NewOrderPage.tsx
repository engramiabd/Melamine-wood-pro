import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  ChevronLeft, ChevronRight, Check, Plus, Trash2,
  User, Phone, MapPin, Calendar, FileText,
  Package, AlertCircle, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAppData } from '../contexts/AppDataContext';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardBody } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { OrderPriority } from '../types';

// ── Schemas ─────────────────────────────────────────────────────────────────
const step1Schema = z.object({
  customer_name: z.string().min(2, 'اسم العميل مطلوب (حد أدنى حرفان)'),
  customer_phone: z.string().optional(),
  customer_address: z.string().optional(),
  due_date: z.string().optional(),
  priority: z.enum(['low', 'normal', 'high', 'urgent']),
  notes: z.string().optional(),
});

const step2Schema = z.object({
  items: z.array(z.object({
    product_id: z.string().min(1, 'اختر منتجاً'),
    quantity: z.number().min(1, 'الكمية يجب أن تكون 1 على الأقل').max(10000),
    custom_thickness: z.string().optional(),
    custom_size: z.string().optional(),
    custom_finish: z.string().optional(),
    custom_color: z.string().optional(),
    notes: z.string().optional(),
  })).min(1, 'أضف منتجاً واحداً على الأقل'),
});

type Step1Data = z.infer<typeof step1Schema>;
type OrderItem = {
  id: string;
  product_id: string;
  quantity: number;
  notes?: string;
};

// ── Step Indicator ──────────────────────────────────────────────────────────
const StepIndicator: React.FC<{ step: number; total: number; labels: string[] }> = ({ step, total, labels }) => (
  <div className="flex items-center justify-center gap-0 px-4">
    {Array.from({ length: total }).map((_, i) => (
      <React.Fragment key={i}>
        <div className="flex flex-col items-center">
          <motion.div
            animate={{
              scale: i === step ? 1.1 : 1,
              backgroundColor: i < step ? '#10b981' : i === step ? '#3b82f6' : '#e5e7eb',
            }}
            className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${i <= step ? 'text-white' : 'text-gray-500'}`}
          >
            {i < step ? <Check size={14} /> : i + 1}
          </motion.div>
          <p className={`text-[10px] mt-1 font-medium whitespace-nowrap ${i === step ? 'text-blue-600' : i < step ? 'text-emerald-600' : 'text-gray-400'}`}>
            {labels[i]}
          </p>
        </div>
        {i < total - 1 && (
          <div className={`h-0.5 w-12 mt-[-16px] mx-1 transition-colors ${i < step ? 'bg-emerald-400' : 'bg-gray-200'}`} />
        )}
      </React.Fragment>
    ))}
  </div>
);

// ── Product Selector Card ───────────────────────────────────────────────────
const ProductItemCard: React.FC<{
  item: OrderItem;
  index: number;
  onRemove: () => void;
  onUpdate: (updates: Partial<OrderItem>) => void;
  format: (usd: number, syp?: number) => string;
  products: ReturnType<typeof useAppData>['products'];
}> = ({ item, index, onRemove, onUpdate, format, products }) => {
  const selectedProduct = products.find(p => p.id === item.product_id);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm"
    >
      {/* Item header */}
      <div className="bg-blue-50 px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-blue-600 rounded-lg flex items-center justify-center text-white text-xs font-bold">
            {index + 1}
          </div>
          <span className="text-sm font-bold text-blue-800">منتج #{index + 1}</span>
        </div>
        {index > 0 && (
          <button onClick={onRemove} className="text-red-500 hover:text-red-700 transition-colors">
            <Trash2 size={15} />
          </button>
        )}
      </div>

      <div className="p-4 space-y-3">
        {/* Product Select */}
        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1.5">
            المنتج <span className="text-red-500">*</span>
          </label>
          <select
            value={item.product_id}
            onChange={e => onUpdate({ product_id: e.target.value })}
            className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">— اختر منتجاً —</option>
            {products.map(p => (
              <option key={p.id} value={p.id}>
                {p.name} | {p.thickness} | {p.finish}
              </option>
            ))}
          </select>
        </div>

        {selectedProduct && (
          <div className="bg-blue-50 rounded-xl p-3 flex items-center gap-3">
            <Package size={16} className="text-blue-600 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-blue-800">{selectedProduct.name}</p>
              <p className="text-[11px] text-blue-600">
                {selectedProduct.size} · {selectedProduct.finish} · {selectedProduct.color}
              </p>
            </div>
            <div className="text-left">
              <p className="text-xs font-black text-blue-800">{format(selectedProduct.price_usd, selectedProduct.price_syp)}</p>
              <p className="text-[10px] text-blue-500">للقطعة</p>
            </div>
          </div>
        )}

        {/* Quantity */}
        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1.5">
            الكمية (قطعة) <span className="text-red-500">*</span>
          </label>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onUpdate({ quantity: Math.max(1, item.quantity - 1) })}
              className="w-10 h-10 bg-gray-100 rounded-xl text-gray-700 flex items-center justify-center font-bold text-lg hover:bg-gray-200 transition-colors"
            >
              −
            </button>
            <input
              type="number"
              value={item.quantity}
              onChange={e => onUpdate({ quantity: Math.max(1, parseInt(e.target.value) || 1) })}
              className="flex-1 text-center px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-lg font-black focus:outline-none focus:ring-2 focus:ring-blue-500"
              min="1"
            />
            <button
              type="button"
              onClick={() => onUpdate({ quantity: item.quantity + 1 })}
              className="w-10 h-10 bg-blue-100 rounded-xl text-blue-700 flex items-center justify-center font-bold text-lg hover:bg-blue-200 transition-colors"
            >
              +
            </button>
          </div>
        </div>

        {/* Subtotal */}
        {selectedProduct && (
          <div className="bg-emerald-50 rounded-xl px-3 py-2 flex items-center justify-between">
            <span className="text-xs text-emerald-700">الإجمالي الفرعي:</span>
            <span className="text-sm font-black text-emerald-800">
              {format(selectedProduct.price_usd * item.quantity, selectedProduct.price_syp * item.quantity)}
            </span>
          </div>
        )}

        {/* Notes */}
        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1.5">ملاحظات المنتج</label>
          <textarea
            value={item.notes || ''}
            onChange={e => onUpdate({ notes: e.target.value })}
            rows={2}
            placeholder="أي تخصيص أو ملاحظات خاصة بهذا المنتج..."
            className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>
    </motion.div>
  );
};

// ── Main New Order Page ─────────────────────────────────────────────────────
export const NewOrderPage: React.FC = () => {
  const navigate = useNavigate();
  const { format } = useCurrency();
  const { products, addOrder, customers } = useAppData();
  const { user } = useAuth();
  const [step, setStep] = useState(0);
  const [step1Data, setStep1Data] = useState<Step1Data | null>(null);
  const [items, setItems] = useState<OrderItem[]>([
    { id: '1', product_id: '', quantity: 1 }
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { register, handleSubmit, formState: { errors }, watch, setValue } = useForm<Step1Data>({
    resolver: zodResolver(step1Schema),
    defaultValues: {
      priority: 'normal',
      customer_name: '',
      customer_phone: '',
      customer_address: '',
      notes: '',
    }
  });

  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [showCustomerSuggestions, setShowCustomerSuggestions] = useState(false);
  const customerNameValue = watch('customer_name');
  const customerSuggestions = React.useMemo(() => {
    const q = (customerNameValue || '').trim().toLowerCase();
    if (!q) return [];
    return customers.filter(c => c.name.toLowerCase().includes(q)).slice(0, 5);
  }, [customers, customerNameValue]);

  const priorityValue = watch('priority');

  // Calculate total
  const orderTotal = items.reduce((sum, item) => {
    const product = products.find(p => p.id === item.product_id);
    return sum + (product ? product.price_usd * item.quantity : 0);
  }, 0);
  const orderTotalSyp = items.reduce((sum, item) => {
    const product = products.find(p => p.id === item.product_id);
    return sum + (product ? product.price_syp * item.quantity : 0);
  }, 0);

  const addItem = useCallback(() => {
    setItems(prev => [...prev, { id: Date.now().toString(), product_id: '', quantity: 1 }]);
  }, []);

  const removeItem = useCallback((id: string) => {
    setItems(prev => prev.filter(i => i.id !== id));
  }, []);

  const updateItem = useCallback((id: string, updates: Partial<OrderItem>) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, ...updates } : i));
  }, []);

  const onStep1Submit = (data: Step1Data) => {
    setStep1Data(data);
    setStep(1);
  };

  const handleFinalSubmit = async () => {
    const validItems = items.filter(i => i.product_id);
    if (!validItems.length) {
      toast.error('أضف منتجاً واحداً على الأقل');
      return;
    }
    if (!step1Data) return;
    setIsSubmitting(true);
    await new Promise(r => setTimeout(r, 800));

    const orderItems = validItems.map(item => {
      const product = products.find(p => p.id === item.product_id)!;
      return {
        id: `oi_${Date.now()}_${Math.random().toString(36).slice(2)}`,
        order_id: '',
        product_id: item.product_id,
        product,
        quantity: item.quantity,
        unit_price_usd: product.price_usd,
        unit_price_syp: product.price_syp,
        total_usd: product.price_usd * item.quantity,
        total_syp: product.price_syp * item.quantity,
        notes: item.notes,
      };
    });

    const newOrder = addOrder({
      order_number: `ORD-${Date.now().toString().slice(-6)}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`,
      customer_name: step1Data.customer_name,
      customer_phone: step1Data.customer_phone,
      customer_address: step1Data.customer_address,
      customer_id: selectedCustomerId || undefined,
      due_date: step1Data.due_date,
      priority: step1Data.priority as OrderPriority,
      notes: step1Data.notes,
      status: 'pending',
      items: orderItems,
      total_usd: orderTotal,
      total_syp: orderTotalSyp,
      paid_usd: 0,
      payment_status: 'unpaid',
      created_by: user?.id || 'system',
      updated_at: new Date().toISOString(),
    });

    toast.success(`تم إنشاء الطلب ${newOrder.order_number} بنجاح`);
    setIsSubmitting(false);
    navigate(`/orders/${newOrder.id}`);
  };

  const stepLabels = ['بيانات العميل', 'المنتجات', 'المراجعة'];

  return (
    <div className="min-h-screen bg-gray-50 pb-24" dir="rtl">
      {/* ── Header ─────────────────────────────────────────────── */}
      <div className="bg-white sticky top-14 z-30 border-b border-gray-100 px-4 py-3">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={() => step > 0 ? setStep(step - 1) : navigate(-1)} className="w-9 h-9 bg-gray-100 rounded-xl flex items-center justify-center text-gray-600">
            <ChevronRight size={18} />
          </button>
          <div>
            <h1 className="text-base font-black text-gray-900">طلب إنتاج جديد</h1>
            <p className="text-xs text-gray-400">الخطوة {step + 1} من {stepLabels.length}</p>
          </div>
        </div>
        <StepIndicator step={step} total={3} labels={stepLabels} />
      </div>

      <div className="px-4 pt-5 space-y-4">
        <AnimatePresence mode="wait">
          {/* ── Step 0: Customer Info ───────────────────────────── */}
          {step === 0 && (
            <motion.div
              key="step0"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
            >
              <form onSubmit={handleSubmit(onStep1Submit)} className="space-y-4">
                <Card>
                  <CardBody className="space-y-4">
                    <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                      <User size={15} className="text-blue-600" /> معلومات العميل
                    </h3>

                    {/* Customer Name */}
                    <div style={{ position: 'relative' }}>
                      <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                        اسم العميل <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <User size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                        <input
                          {...register('customer_name', {
                            onChange: () => { setSelectedCustomerId(null); setShowCustomerSuggestions(true); },
                          })}
                          onFocus={() => setShowCustomerSuggestions(true)}
                          onBlur={() => setTimeout(() => setShowCustomerSuggestions(false), 150)}
                          placeholder="أدخل اسم العميل أو الشركة"
                          autoComplete="off"
                          className={`w-full pr-9 pl-4 py-3 bg-gray-50 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all ${errors.customer_name ? 'border-red-400 bg-red-50' : 'border-gray-200'}`}
                        />
                        {selectedCustomerId && (
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                            عميل مسجّل
                          </span>
                        )}
                      </div>
                      {showCustomerSuggestions && customerSuggestions.length > 0 && (
                        <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden">
                          {customerSuggestions.map(c => (
                            <button
                              key={c.id}
                              type="button"
                              onMouseDown={(e) => {
                                e.preventDefault();
                                setValue('customer_name', c.name);
                                setValue('customer_phone', c.phone);
                                setValue('customer_address', c.address || '');
                                setSelectedCustomerId(c.id);
                                setShowCustomerSuggestions(false);
                              }}
                              className="w-full text-right px-3 py-2.5 hover:bg-gray-50 border-b border-gray-50 last:border-0 flex items-center justify-between"
                            >
                              <span className="text-xs font-semibold text-gray-800">{c.name}</span>
                              <span className="text-[11px] text-gray-400" dir="ltr">{c.phone}</span>
                            </button>
                          ))}
                        </div>
                      )}
                      {errors.customer_name && (
                        <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                          <AlertCircle size={11} />{errors.customer_name.message}
                        </p>
                      )}
                    </div>

                    {/* Phone */}
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1.5">رقم الهاتف</label>
                      <div className="relative">
                        <Phone size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                        <input
                          {...register('customer_phone')}
                          type="tel"
                          placeholder="+963 ..."
                          className="w-full pr-9 pl-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                          dir="ltr"
                        />
                      </div>
                    </div>

                    {/* Address */}
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1.5">العنوان</label>
                      <div className="relative">
                        <MapPin size={15} className="absolute right-3 top-3 text-gray-400 pointer-events-none" />
                        <textarea
                          {...register('customer_address')}
                          rows={2}
                          placeholder="عنوان التسليم أو العميل"
                          className="w-full pr-9 pl-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                        />
                      </div>
                    </div>
                  </CardBody>
                </Card>

                <Card>
                  <CardBody className="space-y-4">
                    <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                      <Calendar size={15} className="text-blue-600" /> تفاصيل الطلب
                    </h3>

                    {/* Due Date */}
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1.5">تاريخ التسليم المطلوب</label>
                      <input
                        {...register('due_date')}
                        type="date"
                        min={new Date().toISOString().split('T')[0]}
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                      />
                    </div>

                    {/* Priority */}
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-2">الأولوية</label>
                      <div className="grid grid-cols-4 gap-2">
                        {[
                          { value: 'low', label: 'منخفضة', bg: 'bg-gray-100', activeBg: 'bg-gray-500', border: 'border-gray-300', activeBorder: 'border-gray-500', text: 'text-gray-500', activeText: 'text-white' },
                          { value: 'normal', label: 'عادية', bg: 'bg-blue-50', activeBg: 'bg-blue-500', border: 'border-blue-200', activeBorder: 'border-blue-500', text: 'text-blue-500', activeText: 'text-white' },
                          { value: 'high', label: 'عالية', bg: 'bg-orange-50', activeBg: 'bg-orange-500', border: 'border-orange-200', activeBorder: 'border-orange-500', text: 'text-orange-500', activeText: 'text-white' },
                          { value: 'urgent', label: 'عاجل', bg: 'bg-red-50', activeBg: 'bg-red-500', border: 'border-red-200', activeBorder: 'border-red-500', text: 'text-red-500', activeText: 'text-white' },
                        ].map(p => {
                          const isActive = priorityValue === p.value;
                          return (
                            <label key={p.value} className="cursor-pointer">
                              <input {...register('priority')} type="radio" value={p.value} className="sr-only" />
                              <div className={`flex flex-col items-center gap-1 p-2 rounded-xl border-2 transition-all ${isActive ? `${p.activeBorder} ${p.activeBg}` : `${p.border} ${p.bg}`}`}>
                                <div className={`w-3 h-3 rounded-full border-2 ${isActive ? 'border-white bg-white/40' : p.border}`} />
                                <span className={`text-[10px] font-bold ${isActive ? p.activeText : p.text}`}>{p.label}</span>
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Notes */}
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1.5">ملاحظات عامة</label>
                      <div className="relative">
                        <FileText size={15} className="absolute right-3 top-3 text-gray-400 pointer-events-none" />
                        <textarea
                          {...register('notes')}
                          rows={3}
                          placeholder="أي ملاحظات أو تعليمات خاصة بهذا الطلب..."
                          className="w-full pr-9 pl-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                        />
                      </div>
                    </div>
                  </CardBody>
                </Card>

                <Button type="submit" fullWidth size="lg" rightIcon={<ChevronLeft size={16} className="rotate-180" />}>
                  التالي: إضافة المنتجات
                </Button>
              </form>
            </motion.div>
          )}

          {/* ── Step 1: Products ────────────────────────────────── */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              className="space-y-4"
            >
              <AnimatePresence>
                {items.map((item, idx) => (
                  <ProductItemCard
                    key={item.id}
                    item={item}
                    index={idx}
                    onRemove={() => removeItem(item.id)}
                    onUpdate={(updates) => updateItem(item.id, updates)}
                    format={format}
                    products={products}
                  />
                ))}
              </AnimatePresence>

              {/* Add Product Button */}
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={addItem}
                className="w-full py-3.5 border-2 border-dashed border-blue-300 rounded-2xl text-blue-600 font-semibold text-sm flex items-center justify-center gap-2 hover:border-blue-500 hover:bg-blue-50 transition-all"
              >
                <Plus size={16} /> إضافة منتج آخر
              </motion.button>

              {/* Order Total Preview */}
              {orderTotal > 0 && (
                <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-4 text-white">
                  <p className="text-blue-200 text-xs mb-1">إجمالي الطلب</p>
                  <p className="text-2xl font-black">{format(orderTotal, orderTotalSyp)}</p>
                  <p className="text-blue-200 text-xs mt-1">{items.filter(i => i.product_id).length} منتج · {items.reduce((s, i) => s + i.quantity, 0)} قطعة</p>
                </div>
              )}

              <Button
                fullWidth size="lg"
                onClick={() => {
                  const hasProducts = items.some(i => i.product_id);
                  if (!hasProducts) { toast.error('أضف منتجاً واحداً على الأقل'); return; }
                  setStep(2);
                }}
                rightIcon={<ChevronLeft size={16} className="rotate-180" />}
              >
                التالي: مراجعة الطلب
              </Button>
            </motion.div>
          )}

          {/* ── Step 2: Review ──────────────────────────────────── */}
          {step === 2 && step1Data && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              className="space-y-4"
            >
              {/* Customer Summary */}
              <Card>
                <CardBody>
                  <h3 className="font-bold text-gray-800 text-sm mb-3 flex items-center gap-2">
                    <User size={15} className="text-blue-600" /> بيانات العميل
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-xs text-gray-500">الاسم</span>
                      <span className="text-xs font-bold text-gray-800">{step1Data.customer_name}</span>
                    </div>
                    {step1Data.customer_phone && (
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-500">الهاتف</span>
                        <span className="text-xs font-bold text-gray-800" dir="ltr">{step1Data.customer_phone}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-xs text-gray-500">الأولوية</span>
                       <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        step1Data.priority === 'urgent' ? 'bg-red-100 text-red-700' :
                        step1Data.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                        step1Data.priority === 'normal' ? 'bg-blue-100 text-blue-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {step1Data.priority === 'urgent' ? 'عاجل' : step1Data.priority === 'high' ? 'عالية' : step1Data.priority === 'normal' ? 'عادية' : 'منخفضة'}
                      </span>
                    </div>
                    {step1Data.due_date && (
                      <div className="flex justify-between">
                        <span className="text-xs text-gray-500">تاريخ التسليم</span>
                        <span className="text-xs font-bold text-gray-800">{new Date(step1Data.due_date).toLocaleDateString('ar-SY')}</span>
                      </div>
                    )}
                    {step1Data.notes && (
                      <div className="pt-2 border-t border-gray-100">
                        <p className="text-xs text-gray-500 mb-1">ملاحظات</p>
                        <p className="text-xs text-gray-700">{step1Data.notes}</p>
                      </div>
                    )}
                  </div>
                </CardBody>
              </Card>

              {/* Products Summary */}
              <Card>
                <CardBody>
                  <h3 className="font-bold text-gray-800 text-sm mb-3 flex items-center gap-2">
                    <Package size={15} className="text-blue-600" /> المنتجات المطلوبة
                  </h3>
                  <div className="space-y-3">
                    {items.filter(i => i.product_id).map((item, idx) => {
                      const product = products.find(p => p.id === item.product_id);
                      if (!product) return null;
                      return (
                        <div key={item.id} className="flex items-start gap-3">
                          <div className="w-6 h-6 bg-blue-100 rounded-lg flex items-center justify-center text-blue-700 text-xs font-bold shrink-0">
                            {idx + 1}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold text-gray-800 leading-tight">{product.name}</p>
                            <p className="text-[11px] text-gray-400">{product.size} · {product.finish}</p>
                          </div>
                          <div className="text-left shrink-0">
                            <p className="text-xs text-gray-500">{item.quantity} قطعة</p>
                            <p className="text-xs font-black text-gray-800">
                              {format(product.price_usd * item.quantity, product.price_syp * item.quantity)}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardBody>
              </Card>

              {/* Grand Total */}
              <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl p-4 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-emerald-200 text-xs">الإجمالي الكلي</p>
                    <p className="text-2xl font-black mt-0.5">{format(orderTotal, orderTotalSyp)}</p>
                  </div>
                  <div className="text-left">
                    <p className="text-emerald-200 text-xs">{items.filter(i => i.product_id).length} منتج</p>
                    <p className="text-emerald-200 text-xs">{items.reduce((s, i) => s + i.quantity, 0)} قطعة</p>
                  </div>
                </div>
              </div>

              {/* Submit */}
              <Button
                fullWidth size="lg"
                isLoading={isSubmitting}
                onClick={handleFinalSubmit}
                leftIcon={<Check size={18} />}
              >
                {isSubmitting ? 'جاري إنشاء الطلب...' : 'تأكيد وإنشاء الطلب'}
              </Button>

              <button
                onClick={() => setStep(1)}
                className="w-full py-3 text-gray-500 text-sm font-medium hover:text-gray-700 transition-colors"
              >
                العودة لتعديل المنتجات
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
