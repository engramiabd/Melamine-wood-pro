import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye, EyeOff, AlertCircle, ChevronDown, ChevronUp, LogIn, Shield, Briefcase, HardHat, Wrench, Calculator, Users } from 'lucide-react';
import { useAuth, DEMO_ACCOUNTS } from '../contexts/AuthContext';

// The plaintext password is shown in the demo card UI only — intentional UX.
// It is NOT stored anywhere; comparison uses SHA-256 hash in AuthContext.
const DEMO_DISPLAY_PASSWORD = 'demo123';

// ── Factory Logo SVG ─────────────────────────────────────────────────────────
const FactoryLogo: React.FC = () => (
  <motion.div
    animate={{ y: [0, -6, 0] }}
    transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
    className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-700 flex items-center justify-center shadow-2xl shadow-blue-500/40"
  >
    <svg width="44" height="44" viewBox="0 0 64 64" fill="none">
      <rect x="6"  y="34" width="52" height="24" rx="3" fill="white" fillOpacity="0.25"/>
      <rect x="12" y="26" width="12" height="32" rx="2" fill="white" fillOpacity="0.45"/>
      <rect x="26" y="22" width="12" height="36" rx="2" fill="white" fillOpacity="0.45"/>
      <rect x="40" y="28" width="10" height="30" rx="2" fill="white" fillOpacity="0.45"/>
      <rect x="14" y="12" width="5"  height="16" rx="2" fill="white" fillOpacity="0.85"/>
      <rect x="28" y="8"  width="5"  height="16" rx="2" fill="white" fillOpacity="0.85"/>
      <rect x="42" y="14" width="5"  height="16" rx="2" fill="white" fillOpacity="0.85"/>
      <circle cx="16" cy="10" r="4" fill="#34d399"/>
      <circle cx="30" cy="6"  r="4" fill="#34d399"/>
      <circle cx="44" cy="12" r="4" fill="#fbbf24"/>
    </svg>
  </motion.div>
);

// ── Role config using AuthContext DEMO_ACCOUNTS ──────────────────────────────
const ROLE_CONFIG: Record<string, {
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
  icon: React.ReactNode;
}> = {
  admin: {
    label: 'مدير النظام',
    color: 'from-red-500 to-rose-600',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/30',
    icon: <Shield size={14} className="text-red-400" />,
  },
  manager: {
    label: 'المدير التنفيذي',
    color: 'from-blue-500 to-indigo-600',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/30',
    icon: <Briefcase size={14} className="text-blue-400" />,
  },
  production_supervisor: {
    label: 'مشرف الإنتاج',
    color: 'from-purple-500 to-violet-600',
    bgColor: 'bg-purple-500/10',
    borderColor: 'border-purple-500/30',
    icon: <HardHat size={14} className="text-purple-400" />,
  },
  worker: {
    label: 'عامل الإنتاج',
    color: 'from-emerald-500 to-green-600',
    bgColor: 'bg-emerald-500/10',
    borderColor: 'border-emerald-500/30',
    icon: <Wrench size={14} className="text-emerald-400" />,
  },
  accountant: {
    label: 'المحاسب',
    color: 'from-amber-500 to-orange-600',
    bgColor: 'bg-amber-500/10',
    borderColor: 'border-amber-500/30',
    icon: <Calculator size={14} className="text-amber-400" />,
  },
  hr: {
    label: 'موارد بشرية',
    color: 'from-pink-500 to-rose-600',
    bgColor: 'bg-pink-500/10',
    borderColor: 'border-pink-500/30',
    icon: <Users size={14} className="text-pink-400" />,
  },
};

// ── Login Page ───────────────────────────────────────────────────────────────
export const LoginPage: React.FC = () => {
  const { login, loginDemo } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Redirect to original page after login, or home
  const from = (location.state as { from?: { pathname: string } })?.from?.pathname || '/';

  const [email, setEmail]         = useState('');
  const [password, setPassword]   = useState('');
  const [showPass, setShowPass]   = useState(false);
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState('');
  const [demoOpen, setDemoOpen]   = useState(false);
  const [activeIdx, setActiveIdx] = useState<number | null>(null);
  const [fillIdx, setFillIdx]     = useState<number | null>(null);

  // ── Handle manual login form submit ────────────────────────────────────────
  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError('يرجى إدخال البريد الإلكتروني وكلمة المرور');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const result = await login(email.trim(), password);
      if (result.error) {
        setError(result.error);
      } else {
        navigate(from, { replace: true });
      }
    } catch {
      setError('حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى');
    } finally {
      setLoading(false);
    }
  };

  // ── Fill form fields with demo account data ─────────────────────────────
  const handleFill = (idx: number) => {
    const acc = DEMO_ACCOUNTS[idx];
    setEmail(acc.email);
    setPassword(DEMO_DISPLAY_PASSWORD);
    setFillIdx(idx);
    setError('');
    setTimeout(() => setFillIdx(null), 1000);
  };

  // ── Quick login directly with demo account ──────────────────────────────
  const handleQuickLogin = async (idx: number) => {
    const acc = DEMO_ACCOUNTS[idx];
    setLoading(true);
    setError('');
    try {
      // Use loginDemo for instant demo login (no API call needed)
      loginDemo(acc);
      navigate(from, { replace: true });
    } catch {
      setError('خطأ في تسجيل الدخول التجريبي');
      setLoading(false);
    }
  };

  return (
    <div
      className="login-page bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950"
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'flex-start',
        paddingTop: 24,
        paddingBottom: 32,
        paddingLeft: 16,
        paddingRight: 16,
        position: 'relative',
      }}
      dir="rtl"
    >
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-10 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
        <svg className="absolute inset-0 w-full h-full opacity-[0.03]">
          <defs>
            <pattern id="dots" width="32" height="32" patternUnits="userSpaceOnUse">
              <circle cx="16" cy="16" r="1.2" fill="white" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dots)" />
        </svg>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className="relative z-10"
        style={{ width: '100%', maxWidth: 400 }}
      >
        <div className="bg-white/[0.07] backdrop-blur-2xl border border-white/10 rounded-3xl overflow-hidden shadow-2xl">

          {/* ── Header ── */}
          <div className="px-6 pt-8 pb-5 text-center">
            <FactoryLogo />
            <h1 className="text-2xl font-black text-white mt-5 mb-1 tracking-tight">ميلامين برو</h1>
            <p className="text-blue-300/80 text-sm">نظام إدارة مصنع الميلامين</p>
            <div className="flex flex-wrap gap-1.5 justify-center mt-3">
              {['PWA', 'ثنائي العملة', 'عربي كامل', 'متعدد الأدوار'].map(f => (
                <span
                  key={f}
                  className="text-[10px] px-2.5 py-1 rounded-full bg-white/10 text-blue-200 font-semibold border border-white/10"
                >
                  {f}
                </span>
              ))}
            </div>
          </div>

          {/* ── Form ── */}
          <form onSubmit={handleLogin} className="px-6 pb-5 space-y-3">
            {/* Error message */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -8, height: 0 }}
                  animate={{ opacity: 1, y: 0, height: 'auto' }}
                  exit={{ opacity: 0, y: -8, height: 0 }}
                  className="flex items-center gap-2 bg-red-500/20 border border-red-500/30 text-red-300 text-sm px-4 py-3 rounded-2xl"
                >
                  <AlertCircle size={15} className="shrink-0" />
                  <span>{error}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Email */}
            <div>
              <label className="block text-xs font-semibold text-blue-200/80 mb-1.5 text-right">
                البريد الإلكتروني
              </label>
              <input
                type="email"
                value={email}
                onChange={e => { setEmail(e.target.value); setError(''); }}
                placeholder="email@example.com"
                dir="ltr"
                autoComplete="email"
                className="w-full px-4 py-3.5 bg-white/10 border border-white/15 rounded-2xl text-white placeholder:text-white/25 text-sm focus:outline-none focus:border-blue-400/70 focus:bg-white/15 transition-all"
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold text-blue-200/80 mb-1.5 text-right">
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  placeholder="••••••••"
                  dir="ltr"
                  autoComplete="current-password"
                  className="w-full px-4 py-3.5 pr-12 bg-white/10 border border-white/15 rounded-2xl text-white placeholder:text-white/25 text-sm focus:outline-none focus:border-blue-400/70 focus:bg-white/15 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(s => !s)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-colors p-1"
                >
                  {showPass ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <motion.button
              type="submit"
              whileTap={{ scale: 0.97 }}
              disabled={loading}
              className="w-full py-4 rounded-2xl bg-gradient-to-l from-blue-600 to-indigo-600 text-white font-black text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed mt-1 hover:from-blue-500 hover:to-indigo-500 transition-all"
            >
              {loading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                />
              ) : (
                <>
                  <LogIn size={16} />
                  تسجيل الدخول
                </>
              )}
            </motion.button>
          </form>

          {/* ── Demo Accounts Section ── */}
          <div className="border-t border-white/10">
            <button
              type="button"
              onClick={() => setDemoOpen(o => !o)}
              className="w-full flex items-center justify-between px-6 py-4 text-sm text-blue-200 font-semibold hover:bg-white/5 transition-colors"
            >
              <span className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-[10px] text-blue-300 font-bold">
                  ؟
                </span>
                الحسابات التجريبية
              </span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-blue-400/70 font-normal">
                  {DEMO_ACCOUNTS.length} حسابات
                </span>
                {demoOpen
                  ? <ChevronUp size={16} className="text-blue-300" />
                  : <ChevronDown size={16} className="text-blue-300" />
                }
              </div>
            </button>

            <AnimatePresence>
              {demoOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25, ease: 'easeInOut' }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 space-y-2">
                    {DEMO_ACCOUNTS.map((acc, idx) => {
                      const cfg = ROLE_CONFIG[acc.role] ?? {
                        label: acc.full_name,
                        color: 'from-slate-500 to-slate-600',
                        bgColor: 'bg-slate-500/10',
                        borderColor: 'border-slate-500/30',
                        icon: <Shield size={14} />,
                      };
                      const isActive = activeIdx === idx;
                      const isFilled = fillIdx === idx;

                      return (
                        <motion.div
                          key={acc.email}
                          initial={{ opacity: 0, x: 12 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.04 }}
                          className={`rounded-2xl border overflow-hidden transition-all ${
                            isFilled
                              ? 'ring-2 ring-blue-400/60 border-blue-400/40'
                              : isActive
                              ? `${cfg.borderColor} ${cfg.bgColor}`
                              : 'border-white/8 hover:border-white/15'
                          }`}
                        >
                          {/* Account row */}
                          <button
                            type="button"
                            onClick={() => setActiveIdx(isActive ? null : idx)}
                            className="w-full flex items-center gap-3 px-4 py-3 bg-white/5 hover:bg-white/8 transition-colors text-right"
                          >
                            {/* Role icon */}
                            <div className={`w-8 h-8 rounded-xl ${cfg.bgColor} border ${cfg.borderColor} flex items-center justify-center flex-shrink-0`}>
                              {cfg.icon}
                            </div>

                            {/* Info */}
                            <div className="flex-1 min-w-0 text-right">
                              <p className="text-white text-xs font-bold">{cfg.label}</p>
                              <p className="text-blue-300/60 text-[10px] truncate font-mono" dir="ltr">
                                {acc.email}
                              </p>
                            </div>

                            {/* Chevron */}
                            <motion.div
                              animate={{ rotate: isActive ? 180 : 0 }}
                              transition={{ duration: 0.2 }}
                            >
                              <ChevronDown size={14} className="text-white/30" />
                            </motion.div>
                          </button>

                          {/* Expanded actions */}
                          <AnimatePresence>
                            {isActive && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.2 }}
                                className="overflow-hidden"
                              >
                                <div className="px-4 py-3 border-t border-white/8 space-y-2">
                                  {/* Credentials display */}
                                  <div className="flex items-center justify-between text-[10px]">
                                    <span className="text-blue-300/50">كلمة المرور:</span>
                                    <span className="font-mono text-blue-300/80 bg-white/5 px-2 py-0.5 rounded-lg">
                                      {DEMO_DISPLAY_PASSWORD}
                                    </span>
                                  </div>
                                  <p className="text-blue-300/50 text-[10px]">{acc.description}</p>

                                  {/* Action buttons */}
                                  <div className="flex gap-2 pt-1">
                                    <button
                                      type="button"
                                      onClick={() => handleFill(idx)}
                                      className="flex-1 py-2 rounded-xl bg-white/10 text-blue-200 text-[11px] font-bold hover:bg-white/15 active:scale-95 transition-all border border-white/10"
                                    >
                                      تعبئة الحقول
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleQuickLogin(idx)}
                                      disabled={loading}
                                      className={`flex-1 py-2 rounded-xl text-[11px] font-bold active:scale-95 transition-all bg-gradient-to-l ${cfg.color} text-white shadow-sm disabled:opacity-50 flex items-center justify-center gap-1`}
                                    >
                                      {loading ? (
                                        <motion.div
                                          animate={{ rotate: 360 }}
                                          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                                          className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full"
                                        />
                                      ) : (
                                        <>
                                          <LogIn size={11} />
                                          دخول مباشر
                                        </>
                                      )}
                                    </button>
                                  </div>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </motion.div>
                      );
                    })}
                  </div>

                  {/* Note */}
                  <div className="px-4 pb-4">
                    <p className="text-[10px] text-blue-300/40 text-center leading-relaxed">
                      جميع الحسابات التجريبية تستخدم كلمة مرور موحدة: <span className="font-mono text-blue-300/60">demo123</span>
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* ── Footer ── */}
          <div className="text-center px-6 py-4 border-t border-white/5">
            <p className="text-[11px] text-blue-300/40">
              ميلامين برو v1.0 · جميع البيانات تجريبية
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
