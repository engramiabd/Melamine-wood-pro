import { EmptyState } from '../components/ui/EmptyState';
import React, { useState, useMemo, useEffect } from 'react';
import {
  TrendingUp, Plus, Search,
  DollarSign, Calendar, Tag, ArrowUpRight, ArrowDownLeft,
  X, Filter, ChevronDown, PieChart as PieChartIcon,
  RefreshCw, Printer, Download, CheckCircle, Camera,
  FileText, Banknote, CreditCard, Repeat
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardBody } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { JournalEntryType, PaymentMethod } from '../types';
import { useAppData } from '../contexts/AppDataContext';
import { printJournal, exportCSV } from '../utils/print';
import { Pagination, usePagination } from '../components/ui/Pagination';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend
} from 'recharts';

// ─── Config ───────────────────────────────────────────────────────────────────
const TYPE_CONFIG: Record<JournalEntryType, {
  label: string; badge: 'success' | 'danger' | 'info';
  icon: React.ReactNode; color: string; bg: string; gradFrom: string; gradTo: string;
}> = {
  income:   { label: 'إيراد',   badge: 'success', icon: <ArrowUpRight size={16} />,   color: 'text-emerald-600', bg: 'bg-emerald-50', gradFrom: '#10b981', gradTo: '#059669' },
  expense:  { label: 'مصروف',  badge: 'danger',  icon: <ArrowDownLeft size={16} />,  color: 'text-red-600',     bg: 'bg-red-50',     gradFrom: '#ef4444', gradTo: '#dc2626' },
  transfer: { label: 'تحويل',  badge: 'info',    icon: <Repeat size={16} />,          color: 'text-blue-600',    bg: 'bg-blue-50',    gradFrom: '#3b82f6', gradTo: '#2563eb' },
};

const PAYMENT_CONFIG: Record<PaymentMethod, { label: string; icon: React.ReactNode }> = {
  cash:          { label: 'نقداً',         icon: <Banknote size={13} /> },
  bank_transfer: { label: 'تحويل بنكي',   icon: <CreditCard size={13} /> },
  check:         { label: 'شيك',           icon: <FileText size={13} /> },
  other:         { label: 'أخرى',          icon: <DollarSign size={13} /> },
};

const CATEGORIES = ['الكل', 'مبيعات', 'مواد خام', 'رواتب', 'كهرباء', 'صيانة', 'إيجار', 'مكافآت', 'سلف', 'أخرى'];

// No hardcoded data - all data comes from AppDataContext

// ─── Add Entry Modal ──────────────────────────────────────────────────────────
interface AddModalProps { onClose: () => void }
const AddModal: React.FC<AddModalProps> = ({ onClose }) => {
  const { formatUSD, exchangeRate } = useCurrency();
  const { addJournalEntry, addNotification } = useAppData();
  const { user } = useAuth();
  const [form, setForm] = useState({
    type: 'income' as JournalEntryType,
    category: '',
    amount: '',
    description: '',
    method: 'cash' as PaymentMethod,
    reference: '',
  });
  const [step, setStep] = useState<'form' | 'success'>('form');

  const set = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const handleSave = () => {
    if (!form.amount || !form.description || !form.category) return;
    const amt = parseFloat(form.amount);
    addJournalEntry({
      entry_number: `JNL-${Date.now().toString().slice(-6)}`,
      type: form.type,
      category: form.category,
      description: form.description,
      amount_usd: amt,
      amount_syp: amt * exchangeRate,
      currency: 'USD',
      payment_method: form.method,
      is_automatic: false,
      created_by: user?.id || 'unknown',
      entry_date: new Date().toISOString().split('T')[0],
      ...(form.reference ? { reference: form.reference } : {}),
    } as Parameters<typeof addJournalEntry>[0]);
    addNotification({
      title: form.type === 'income' ? 'قيد إيراد جديد' : 'قيد مصروف جديد',
      message: `${form.description} - ${formatUSD(amt)}`,
      type: form.type === 'income' ? 'success' : 'info',
      role_target: 'accountant',
    });
    setStep('success');
    setTimeout(onClose, 1200);
  };

  return (
    <BottomSheetModal isOpen onClose={onClose} maxHeight="90dvh">
      <SheetHeader onClose={onClose}>
        <h3 className="font-bold text-gray-900 text-base">قيد محاسبي جديد</h3>
      </SheetHeader>

      {step === 'success' ? (
        <SheetBody style={{ alignItems: 'center', justifyContent: 'center', padding: '40px 16px' }}>
          <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle size={40} className="text-emerald-500" />
          </div>
          <h3 className="text-xl font-bold text-gray-900 text-center">تم حفظ القيد!</h3>
          <p className="text-gray-500 text-sm mt-1 text-center">
            {form.type === 'income' ? '+' : '-'}{formatUSD(parseFloat(form.amount || '0'))} · {form.description}
          </p>
        </SheetBody>
      ) : (
        <>
          <SheetBody>
            {/* Type tabs */}
            <div className="grid grid-cols-3 gap-2">
              {(['income', 'expense', 'transfer'] as JournalEntryType[]).map(t => {
                const cfg = TYPE_CONFIG[t];
                const active = form.type === t;
                return (
                  <button key={t} onClick={() => set('type', t)}
                    className={`py-2.5 rounded-xl text-xs font-bold border-2 transition-all flex items-center justify-center gap-1.5
                      ${active
                        ? t==='income' ? 'bg-emerald-600 text-white border-emerald-600'
                          : t==='expense' ? 'bg-red-600 text-white border-red-600'
                          : 'bg-blue-600 text-white border-blue-600'
                        : 'border-gray-200 text-gray-600 bg-white'}`}>
                    {cfg.icon} {cfg.label}
                  </button>
                );
              })}
            </div>

            {/* Amount */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">المبلغ (USD) <span className="text-red-500">*</span></label>
              <div className="relative">
                <DollarSign size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input type="number" inputMode="decimal" value={form.amount} onChange={e => set('amount', e.target.value)}
                  placeholder="0.00"
                  className="w-full pr-9 pl-4 py-3 border-2 border-gray-200 rounded-xl text-base font-bold focus:outline-none focus:border-blue-400" />
              </div>
              {form.amount && <p className="text-xs text-gray-400 mt-1">= {(parseFloat(form.amount) * exchangeRate).toLocaleString('ar')} ل.س</p>}
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">الفئة</label>
              <div className="flex gap-1.5 flex-wrap">
                {CATEGORIES.filter(c => c !== 'الكل').map(c => (
                  <button key={c} onClick={() => set('category', c)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all
                      ${form.category === c ? 'bg-gray-800 text-white' : 'bg-gray-100 text-gray-600'}`}>
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">الوصف <span className="text-red-500">*</span></label>
              <textarea value={form.description} onChange={e => set('description', e.target.value)}
                placeholder="وصف القيد المحاسبي..." rows={2}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-400 resize-none" />
            </div>

            {/* Payment Method */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">طريقة الدفع</label>
              <div className="grid grid-cols-2 gap-2">
                {(['cash', 'bank_transfer', 'check', 'other'] as PaymentMethod[]).map(m => {
                  const cfg = PAYMENT_CONFIG[m];
                  return (
                    <button key={m} onClick={() => set('method', m)}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-medium border-2 transition-all
                        ${form.method === m ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 text-gray-600'}`}>
                      {cfg.icon} {cfg.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Reference */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">رقم المرجع (اختياري)</label>
              <input value={form.reference} onChange={e => set('reference', e.target.value)}
                placeholder="رقم الفاتورة، رقم الطلب..."
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-400" />
            </div>

            <button className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-gray-200 rounded-xl text-sm text-gray-500 active:bg-gray-50">
              <Camera size={16} /> إرفاق صورة / إيصال (اختياري)
            </button>
          </SheetBody>

          <SheetFooter>
            <div className="flex gap-3">
              <button aria-label="إغلاق" onClick={onClose} className="flex-1 py-3.5 rounded-xl border border-gray-200 text-gray-600 font-semibold text-sm">إلغاء</button>
              <button onClick={handleSave} disabled={!form.amount || !form.description}
                className={`flex-1 py-3.5 rounded-xl font-bold text-sm text-white flex items-center justify-center gap-2 disabled:opacity-40
                  ${form.type==='income' ? 'bg-emerald-600 active:bg-emerald-700'
                    : form.type==='expense' ? 'bg-red-600 active:bg-red-700'
                    : 'bg-blue-600 active:bg-blue-700'}`}>
                <CheckCircle size={15}/> حفظ القيد
              </button>
            </div>
          </SheetFooter>
        </>
      )}
    </BottomSheetModal>
  );
};

// ─── Main Page ─────────────────────────────────────────────────────────────────
export const JournalPage: React.FC = () => {
  const { formatUSD, formatSYP, exchangeRate } = useCurrency();
  const { user } = useAuth();
  const { journalEntries, deleteJournalEntry } = useAppData();
  const [search, setSearch]           = useState('');
  const [typeFilter, setTypeFilter]   = useState<'all' | JournalEntryType>('all');
  const [categoryFilter, setCategoryFilter] = useState('الكل');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showCharts, setShowCharts]   = useState(false);
  const [expandedId, setExpandedId]   = useState<string | null>(null);

  const canAdd = !!user?.role && ['admin', 'accountant'].includes(user.role);

  // Sort entries by date descending
  const sortedEntries = useMemo(() =>
    [...journalEntries].sort((a, b) => new Date(b.entry_date).getTime() - new Date(a.entry_date).getTime()),
    [journalEntries]);

  const filtered = useMemo(() => sortedEntries.filter(e => {
    const matchSearch = e.description.includes(search) || e.entry_number.includes(search) || ((e as any).reference ?? '').includes(search);
    const matchType   = typeFilter === 'all' || e.type === typeFilter;
    const matchCat    = categoryFilter === 'الكل' || e.category === categoryFilter;
    return matchSearch && matchType && matchCat;
  }), [sortedEntries, search, typeFilter, categoryFilter]);

  // ── Pagination ──────────────────────────────────────────────────────────
  const PAGE_SIZE = 25;
  const [page, setPage] = useState(1);
  useEffect(() => { setPage(1); }, [search, typeFilter, categoryFilter]);
  const { pageItems: pagedEntries, safePage } = usePagination(filtered, PAGE_SIZE, page);

  const totalIncome  = useMemo(() => journalEntries.filter(e => e.type === 'income').reduce((s, e) => s + e.amount_usd, 0), [journalEntries]);
  const totalExpense = useMemo(() => journalEntries.filter(e => e.type === 'expense').reduce((s, e) => s + e.amount_usd, 0), [journalEntries]);
  const netBalance   = totalIncome - totalExpense;

  const categoryTotals = useMemo(() => {
    const map: Record<string, number> = {};
    journalEntries.filter(e => e.type === 'expense').forEach(e => {
      map[e.category] = (map[e.category] ?? 0) + e.amount_usd;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [journalEntries]);

  // Weekly chart data from real entries
  const weeklyData = useMemo(() => {
    const days = ['السبت','الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'];
    const map: Record<string, { income: number; expense: number }> = {};
    days.forEach(d => { map[d] = { income: 0, expense: 0 }; });
    const now = new Date();
    journalEntries.forEach(e => {
      const d = new Date(e.entry_date);
      const diff = Math.floor((now.getTime() - d.getTime()) / 86400000);
      if (diff >= 0 && diff < 7) {
        const dayName = days[d.getDay()];
        if (e.type === 'income') map[dayName].income += e.amount_usd;
        if (e.type === 'expense') map[dayName].expense += e.amount_usd;
      }
    });
    return days.map(day => ({ day, ...map[day] }));
  }, [journalEntries]);

  const PIE_COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6', '#ec4899'];

  return (
    <div className="page-wrapper bg-gray-50" dir="rtl">
      {/* ── Page Header ──────────────────────────────────────── */}
      <div className="page-header">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-lg font-bold text-gray-900">السجل المحاسبي</h1>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowCharts(!showCharts)}
              className={`p-2 rounded-xl text-sm transition-colors ${showCharts ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'}`}
            >
              <PieChartIcon size={15} />
            </button>
            <button className="p-2 bg-gray-100 rounded-xl text-gray-600">
              <Printer size={15} />
            </button>
            <button className="p-2 bg-gray-100 rounded-xl text-gray-600">
              <Download size={15} />
            </button>
            {canAdd && (
              <button
                onClick={() => setShowAddModal(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 text-white rounded-xl text-xs font-medium active:scale-95 transition-all"
              >
                <Plus size={14} />
                قيد جديد
              </button>
            )}
          </div>
        </div>

        <div className="relative mb-3">
          <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="بحث في القيود، الأرقام، المراجع..."
            className="w-full pr-9 pl-9 py-2.5 bg-gray-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute left-3 top-1/2 -translate-y-1/2">
              <X size={13} className="text-gray-400" />
            </button>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          {([
            { value: 'all',      label: `الكل (${sortedEntries.length})` },
            { value: 'income',   label: 'إيرادات' },
            { value: 'expense',  label: 'مصروفات' },
            { value: 'transfer', label: 'تحويلات' },
          ] as const).map(f => (
            <button
              key={f.value}
              onClick={() => setTypeFilter(f.value)}
              className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                typeFilter === f.value
                  ? f.value === 'income'   ? 'bg-emerald-600 text-white'
                  : f.value === 'expense'  ? 'bg-red-600 text-white'
                  : f.value === 'transfer' ? 'bg-blue-600 text-white'
                  : 'bg-gray-800 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Summary Banner ────────────────────────────────────── */}
      <div className="mx-4 mt-4 bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl p-4 text-white">
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center">
            <p className="text-emerald-400 text-[10px] mb-0.5">إجمالي الإيرادات</p>
            <p className="text-base font-black text-white">{formatUSD(totalIncome)}</p>
            <p className="text-[9px] text-gray-400">{formatSYP(totalIncome * exchangeRate)}</p>
          </div>
          <div className="text-center border-x border-white/10">
            <p className="text-red-400 text-[10px] mb-0.5">إجمالي المصروفات</p>
            <p className="text-base font-black text-white">{formatUSD(totalExpense)}</p>
            <p className="text-[9px] text-gray-400">{formatSYP(totalExpense * exchangeRate)}</p>
          </div>
          <div className="text-center">
            <p className={`text-[10px] mb-0.5 ${netBalance >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              صافي {netBalance >= 0 ? 'ربح' : 'خسارة'}
            </p>
            <p className={`text-base font-black ${netBalance >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {formatUSD(Math.abs(netBalance))}
            </p>
            <p className="text-[9px] text-gray-400 flex items-center justify-center gap-0.5">
              {netBalance >= 0
                ? <TrendingUp size={9} className="text-emerald-400" />
                : <TrendingUp size={9} className="text-red-400 rotate-180" />
              }
              {Math.round((netBalance / totalIncome) * 100)}%
            </p>
          </div>
        </div>
      </div>

      {/* ── Charts (collapsible) ──────────────────────────────── */}
      <AnimatePresence>
        {showCharts && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="px-4 pt-4 space-y-4">
              <Card>
                <CardBody className="p-4">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                    <TrendingUp size={14} className="text-blue-500" />
                    الإيرادات والمصروفات (أسبوعي)
                  </h3>
                  <ResponsiveContainer width="100%" height={160}>
                    <AreaChart data={weeklyData}>
                      <defs>
                        <linearGradient id="incomeG" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="expenseG" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="day" tick={{ fontSize: 9, fontFamily: 'Cairo' }} />
                      <YAxis tick={{ fontSize: 9 }} tickFormatter={v => `$${v}`} />
                      <Tooltip formatter={(v) => [`$${Number(v).toLocaleString()}`, '']} />
                      <Area type="monotone" dataKey="income"  name="إيرادات"  stroke="#10b981" fill="url(#incomeG)"  strokeWidth={2} />
                      <Area type="monotone" dataKey="expense" name="مصروفات" stroke="#ef4444" fill="url(#expenseG)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardBody>
              </Card>

              <Card>
                <CardBody className="p-4">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                    <PieChartIcon size={14} className="text-purple-500" />
                    توزيع المصروفات بالفئة
                  </h3>
                  <ResponsiveContainer width="100%" height={160}>
                    <PieChart>
                      <Pie
                        data={categoryTotals}
                        cx="50%" cy="50%"
                        innerRadius={40} outerRadius={65}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${Math.round((percent ?? 0) * 100)}%`}
                        labelLine={false}
                      >
                        {categoryTotals.map((_, i) => (
                          <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Legend
                        formatter={(v) => <span style={{ fontSize: 10, fontFamily: 'Cairo' }}>{v}</span>}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </CardBody>
              </Card>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Category Filter ───────────────────────────────────── */}
      <div className="px-4 mt-4 mb-2">
        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`shrink-0 px-3 py-1 rounded-full text-xs font-medium transition-all ${
                categoryFilter === cat ? 'bg-gray-800 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-400'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* ── Sort + Count ──────────────────────────────────────── */}
      <div className="px-4 mb-2 flex items-center justify-between">
        <p className="text-xs text-gray-500">{filtered.length} قيد</p>
        <div className="flex items-center gap-1 text-xs text-gray-500 bg-white border border-gray-200 rounded-full px-2.5 py-1">
          <Filter size={10} />
          <select className="bg-transparent focus:outline-none text-xs appearance-none">
            <option>الأحدث أولاً</option>
            <option>الأقدم أولاً</option>
            <option>الأعلى مبلغاً</option>
          </select>
          <ChevronDown size={10} />
        </div>
      </div>

      {/* ── Entries List ──────────────────────────────────────── */}
      <div className="px-4 space-y-2.5 pb-24">
        {filtered.length === 0 ? (
          <EmptyState
            icon={FileText}
            title="لا توجد قيود مطابقة"
            description="جرّب تغيير البحث أو الفلاتر."
            action={{ label: 'مسح الفلاتر', onClick: () => { setSearch(''); setTypeFilter('all'); setCategoryFilter('الكل'); } }}
          />
        ) : (
          pagedEntries.map((entry, idx) => {
            const cfg = TYPE_CONFIG[entry.type];
            const isExpanded = expandedId === entry.id;

            return (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.03 }}
              >
                <Card className={`overflow-hidden border-r-4 ${
                  entry.type === 'income' ? 'border-r-emerald-400' :
                  entry.type === 'expense' ? 'border-r-red-400' : 'border-r-blue-400'
                }`}>
                  <CardBody className="p-0">
                    <button
                      className="w-full text-right p-4"
                      onClick={() => setExpandedId(isExpanded ? null : entry.id)}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-xl ${cfg.bg} flex items-center justify-center shrink-0 ${cfg.color}`}>
                          {cfg.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold text-gray-900 leading-tight truncate">
                                {entry.description}
                              </p>
                              <p className="text-xs text-gray-400 mt-0.5">{entry.entry_number}</p>
                            </div>
                            <div className="text-left shrink-0">
                              <p className={`text-base font-black ${cfg.color}`}>
                                {entry.type === 'expense' ? '-' : '+'}{formatUSD(entry.amount_usd)}
                              </p>
                              <p className="text-[10px] text-gray-400">{formatSYP(entry.amount_syp)}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge variant={cfg.badge}>{cfg.label}</Badge>
                            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                              <Tag size={8} />
                              {entry.category}
                            </span>
                            <span className="text-xs text-gray-400 flex items-center gap-1">
                              {PAYMENT_CONFIG[entry.payment_method].icon}
                              {PAYMENT_CONFIG[entry.payment_method].label}
                            </span>
                          </div>
                        </div>
                      </div>
                    </button>

                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden border-t border-gray-100"
                        >
                          <div className="px-4 py-3 bg-gray-50 space-y-2">
                            <div className="grid grid-cols-2 gap-2 text-xs">
                              <div>
                                <p className="text-gray-400">تاريخ القيد</p>
                                <p className="font-medium text-gray-700 flex items-center gap-1 mt-0.5">
                                  <Calendar size={10} />
                                  {new Date(entry.entry_date).toLocaleDateString('ar-SY', { day: 'numeric', month: 'long', year: 'numeric' })}
                                </p>
                              </div>
                              {entry.reference && (
                                <div>
                                  <p className="text-gray-400">المرجع</p>
                                  <p className="font-medium text-blue-600 mt-0.5">{entry.reference}</p>
                                </div>
                              )}
                              <div>
                                <p className="text-gray-400">أُدخل بواسطة</p>
                                <p className="font-medium text-gray-700 mt-0.5">المحاسب</p>
                              </div>
                              <div>
                                <p className="text-gray-400">المبلغ بالليرة</p>
                                <p className="font-medium text-gray-700 mt-0.5">{formatSYP(entry.amount_syp)}</p>
                              </div>
                            </div>
                            {canAdd && (
                              <div className="flex gap-2 pt-1">
                                <button className="px-3 py-1.5 text-xs bg-blue-50 text-blue-600 rounded-lg font-medium">تعديل</button>
                                <button className="px-3 py-1.5 text-xs bg-red-50 text-red-600 rounded-lg font-medium">حذف</button>
                                <button className="px-3 py-1.5 text-xs bg-gray-100 text-gray-600 rounded-lg font-medium flex items-center gap-1">
                                  <Printer size={10} />
                                  طباعة
                                </button>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </CardBody>
                </Card>
              </motion.div>
            );
          })
        )}
        {filtered.length > 0 && (
          <Pagination page={safePage} totalItems={filtered.length} pageSize={PAGE_SIZE} onPageChange={setPage} />
        )}
      </div>

      {/* ── FAB ───────────────────────────────────────────────── */}
      {canAdd && (
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setShowAddModal(true)}
          className="fixed bottom-24 left-4 w-14 h-14 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-600/40 flex items-center justify-center z-20"
        >
          <Plus size={22} />
        </motion.button>
      )}

      <motion.button
        whileTap={{ rotate: 360 }}
        transition={{ duration: 0.4 }}
        className="fixed bottom-24 right-4 w-12 h-12 bg-white shadow-md border border-gray-200 rounded-full flex items-center justify-center text-gray-500 z-20"
      >
        <RefreshCw size={16} />
      </motion.button>

      <AnimatePresence>
        {showAddModal && <AddModal onClose={() => setShowAddModal(false)} />}
      </AnimatePresence>
    </div>
  );
};
