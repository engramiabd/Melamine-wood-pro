import React, { useMemo, useState } from 'react';
import { ShieldCheck, Search, Filter } from 'lucide-react';
import { useAppData } from '../contexts/AppDataContext';
import { EmptyState } from '../components/ui/EmptyState';

const ENTITY_LABELS: Record<string, string> = {
  order: 'الطلبات',
  invoice: 'الفواتير',
  inventory: 'المخزون',
  production: 'الإنتاج',
  purchase: 'المشتريات',
  supplier: 'الموردون',
  wallet: 'المحافظ',
};

const ENTITY_COLORS: Record<string, string> = {
  order: '#6366f1', invoice: '#0891b2', inventory: '#16a34a',
  production: '#ea580c', purchase: '#7c3aed', supplier: '#db2777', wallet: '#0d9488',
};

function timeAgo(iso: string): string {
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'الآن';
  if (min < 60) return `قبل ${min} د`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `قبل ${hr} س`;
  return d.toLocaleDateString('ar-SY', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

export const AuditLogPage: React.FC = () => {
  const { auditLog } = useAppData();
  const [search, setSearch] = useState('');
  const [entity, setEntity] = useState<string>('all');

  const entityTypes = useMemo(
    () => Array.from(new Set(auditLog.map((e) => e.entity_type))),
    [auditLog],
  );

  const filtered = useMemo(() => {
    const q = search.trim();
    return auditLog.filter((e) => {
      const matchEntity = entity === 'all' || e.entity_type === entity;
      const matchSearch = !q || e.summary.includes(q) || e.actor.includes(q);
      return matchEntity && matchSearch;
    });
  }, [auditLog, search, entity]);

  return (
    <div className="min-h-full bg-gray-50 pb-10" dir="rtl">
      {/* Hero */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 px-5 pt-6 pb-8 text-white">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center">
            <ShieldCheck size={22} />
          </div>
          <div>
            <h1 className="text-lg font-extrabold">سجل التدقيق</h1>
            <p className="text-xs text-white/70">{auditLog.length} حركة مسجّلة</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="px-4 -mt-4">
        <div className="bg-white rounded-2xl shadow-sm p-3 space-y-3">
          <div className="relative">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث في الوصف أو المستخدم…"
              className="w-full bg-gray-50 rounded-xl py-2.5 pr-9 pl-3 text-sm outline-none focus:ring-2 focus:ring-slate-300"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <Filter size={14} className="text-gray-400 shrink-0" />
            <button
              onClick={() => setEntity('all')}
              className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium ${entity === 'all' ? 'bg-slate-800 text-white' : 'bg-gray-100 text-gray-600'}`}
            >
              الكل
            </button>
            {entityTypes.map((t) => (
              <button
                key={t}
                onClick={() => setEntity(t)}
                className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium ${entity === t ? 'text-white' : 'bg-gray-100 text-gray-600'}`}
                style={entity === t ? { backgroundColor: ENTITY_COLORS[t] || 'var(--text-secondary)' } : undefined}
              >
                {ENTITY_LABELS[t] || t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* List */}
      <div className="px-4 mt-4 space-y-2">
        {filtered.length === 0 && (
          <EmptyState compact title="لا توجد حركات مطابقة" description="جرّب تغيير الفلتر أو نطاق البحث." />
        )}
        {filtered.map((e) => (
          <div key={e.id} className="bg-white rounded-2xl p-3.5 shadow-sm flex items-start gap-3">
            <div
              className="w-1.5 self-stretch rounded-full shrink-0"
              style={{ backgroundColor: ENTITY_COLORS[e.entity_type] || 'var(--text-tertiary)' }}
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-semibold text-gray-800 truncate">{e.summary}</span>
                {typeof e.amount_usd === 'number' && (
                  <span className="text-xs font-bold text-emerald-600 shrink-0">${e.amount_usd}</span>
                )}
              </div>
              <div className="flex items-center gap-2 mt-1 text-[11px] text-gray-400">
                <span
                  className="px-1.5 py-0.5 rounded-md text-white"
                  style={{ backgroundColor: ENTITY_COLORS[e.entity_type] || 'var(--text-tertiary)' }}
                >
                  {ENTITY_LABELS[e.entity_type] || e.entity_type}
                </span>
                <span>•</span>
                <span>{e.actor}</span>
                <span>•</span>
                <span>{timeAgo(e.timestamp)}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AuditLogPage;
