import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Plus, Search, ShoppingCart, Zap, Clock, ChevronLeft,
  CheckCircle, XCircle, Filter, SortAsc, AlertTriangle, Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAppData } from '../contexts/AppDataContext';
import { Card, CardBody } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Pagination, usePagination } from '../components/ui/Pagination';
import { Order, OrderStatus } from '../types';

const STATUS_CONFIG: Record<OrderStatus, {
  label: string;
  variant: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple';
  bg: string; text: string;
}> = {
  pending: { label: 'معلق', variant: 'warning', bg: 'bg-amber-50', text: 'text-amber-700' },
  in_production: { label: 'في الإنتاج', variant: 'info', bg: 'bg-blue-50', text: 'text-blue-700' },
  quality_check: { label: 'مراجعة الجودة', variant: 'purple', bg: 'bg-purple-50', text: 'text-purple-700' },
  completed: { label: 'مكتمل', variant: 'success', bg: 'bg-emerald-50', text: 'text-emerald-700' },
  cancelled: { label: 'ملغي', variant: 'danger', bg: 'bg-red-50', text: 'text-red-700' },
  on_hold: { label: 'موقوف', variant: 'default', bg: 'bg-gray-50', text: 'text-gray-700' },
};

const PRIORITY_CONFIG = {
  low: { label: 'منخفضة', color: 'text-gray-400', dot: 'bg-gray-400' },
  normal: { label: 'عادية', color: 'text-blue-500', dot: 'bg-blue-400' },
  high: { label: 'عالية', color: 'text-orange-500', dot: 'bg-orange-400' },
  urgent: { label: 'عاجل', color: 'text-red-600', dot: 'bg-red-500' },
};

const STATUS_FILTERS: { value: 'all' | OrderStatus; label: string }[] = [
  { value: 'all', label: 'الكل' },
  { value: 'pending', label: 'معلقة' },
  { value: 'in_production', label: 'إنتاج' },
  { value: 'quality_check', label: 'جودة' },
  { value: 'completed', label: 'مكتملة' },
  { value: 'cancelled', label: 'ملغية' },
  { value: 'on_hold', label: 'موقوفة' },
];

// ── Desktop Table Row ───────────────────────────────────────────────────────
const DesktopOrderRow: React.FC<{
  order: Order;
  onView: () => void;
  onDelete?: () => void;
  format: (usd: number, syp?: number) => string;
  canDelete: boolean;
}> = ({ order, onView, onDelete, format, canDelete }) => {
  const sc = STATUS_CONFIG[order.status];
  const pc = PRIORITY_CONFIG[order.priority];
  const dueDate = order.due_date ? new Date(order.due_date) : null;
  const isOverdue = dueDate && dueDate < new Date() && order.status !== 'completed' && order.status !== 'cancelled';

  return (
    <tr className="border-b border-gray-50 hover:bg-blue-50/30 cursor-pointer transition-colors group" onClick={onView}>
      <td className="px-4 py-3.5">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${pc.dot}`} />
          <span className="text-sm font-bold text-gray-800">{order.order_number}</span>
        </div>
      </td>
      <td className="px-4 py-3.5">
        <div>
          <p className="text-sm font-semibold text-gray-800">{order.customer_name}</p>
          {order.customer_phone && <p className="text-xs text-gray-400">{order.customer_phone}</p>}
        </div>
      </td>
      <td className="px-4 py-3.5">
        <span className="text-sm text-gray-600">{order.items.length} منتج</span>
      </td>
      <td className="px-4 py-3.5">
        <p className="text-sm font-bold text-gray-900">{format(order.total_usd, order.total_syp)}</p>
      </td>
      <td className="px-4 py-3.5">
        <Badge variant={sc.variant}>{sc.label}</Badge>
      </td>
      <td className="px-4 py-3.5">
        <span className={`text-xs font-medium ${pc.color}`}>{pc.label}</span>
      </td>
      <td className="px-4 py-3.5">
        {dueDate ? (
          <span className={`text-xs flex items-center gap-1 ${isOverdue ? 'text-red-600 font-bold' : 'text-gray-500'}`}>
            {isOverdue && <AlertTriangle size={10} className="shrink-0" />}
            {dueDate.toLocaleDateString('ar-SY')}
          </span>
        ) : (
          <span className="text-xs text-gray-300">—</span>
        )}
      </td>
      <td className="px-4 py-3.5">
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          {canDelete && (
            <button
              onClick={e => { e.stopPropagation(); onDelete?.(); }}
              className="w-7 h-7 rounded-lg flex items-center justify-center text-red-400 hover:bg-red-50 hover:text-red-600 transition-colors"
            >
              <Trash2 size={13} />
            </button>
          )}
          <ChevronLeft size={16} className="text-gray-300 rotate-180" />
        </div>
      </td>
    </tr>
  );
};

// ── Mobile Order Card ───────────────────────────────────────────────────────
const MobileOrderCard: React.FC<{
  order: Order;
  onView: () => void;
  onStatusChange?: (status: OrderStatus) => void;
  format: (usd: number, syp?: number) => string;
  index: number;
  canManage: boolean;
}> = ({ order, onView, onStatusChange, format, index, canManage }) => {
  const sc = STATUS_CONFIG[order.status];
  const pc = PRIORITY_CONFIG[order.priority];
  const dueDate = order.due_date ? new Date(order.due_date) : null;
  const isOverdue = dueDate && dueDate < new Date() && order.status !== 'completed' && order.status !== 'cancelled';
  const [showActions, setShowActions] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
    >
      <Card>
        <CardBody className="p-0">
          <div className={`h-1 rounded-t-2xl ${order.priority === 'urgent' ? 'bg-red-500' : order.priority === 'high' ? 'bg-orange-400' : order.priority === 'normal' ? 'bg-blue-400' : 'bg-gray-300'}`} />
          <div className="p-4">
            {/* Header */}
            <div className="flex items-start justify-between gap-2 mb-3">
              <div className="flex-1 min-w-0" onClick={onView}>
                <div className="flex items-center gap-1.5 mb-0.5">
                  {order.priority === 'urgent' && <Zap size={11} className="text-red-500 shrink-0" />}
                  <p className="font-bold text-gray-900 truncate text-sm">{order.customer_name}</p>
                </div>
                <p className="text-xs text-gray-400 font-mono">{order.order_number}</p>
              </div>
              <div className="flex items-center gap-1.5">
                <Badge variant={sc.variant}>{sc.label}</Badge>
                {canManage && (
                  <button
                    onClick={e => { e.stopPropagation(); setShowActions(!showActions); }}
                    className="w-7 h-7 rounded-lg bg-gray-100 flex items-center justify-center"
                  >
                    <Filter size={12} className="text-gray-500" />
                  </button>
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <AnimatePresence>
              {showActions && canManage && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden mb-3"
                >
                  <div className="flex flex-wrap gap-1.5 p-2 bg-gray-50 rounded-xl">
                    {order.status === 'pending' && (
                      <button onClick={() => { onStatusChange?.('in_production'); setShowActions(false); }}
                        className="px-2.5 py-1 bg-blue-600 text-white rounded-lg text-xs font-medium flex items-center gap-1">
                        <CheckCircle size={11} /> بدء الإنتاج
                      </button>
                    )}
                    {order.status === 'in_production' && (
                      <button onClick={() => { onStatusChange?.('quality_check'); setShowActions(false); }}
                        className="px-2.5 py-1 bg-purple-600 text-white rounded-lg text-xs font-medium flex items-center gap-1">
                        <CheckCircle size={11} /> مراجعة الجودة
                      </button>
                    )}
                    {order.status === 'quality_check' && (
                      <button onClick={() => { onStatusChange?.('completed'); setShowActions(false); }}
                        className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-xs font-medium flex items-center gap-1">
                        <CheckCircle size={11} /> إكمال
                      </button>
                    )}
                    {!['completed', 'cancelled'].includes(order.status) && (
                      <button onClick={() => { onStatusChange?.('on_hold'); setShowActions(false); }}
                        className="px-2.5 py-1 bg-gray-500 text-white rounded-lg text-xs font-medium flex items-center gap-1">
                        <XCircle size={11} /> تعليق
                      </button>
                    )}
                    {!['completed', 'cancelled'].includes(order.status) && (
                      <button onClick={() => { onStatusChange?.('cancelled'); setShowActions(false); }}
                        className="px-2.5 py-1 bg-red-600 text-white rounded-lg text-xs font-medium flex items-center gap-1">
                        <XCircle size={11} /> إلغاء
                      </button>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Items */}
            <div className={`${sc.bg} rounded-xl p-2.5 mb-3`} onClick={onView}>
              {order.items.slice(0, 2).map(item => (
                <div key={item.id} className="flex items-center justify-between text-xs">
                  <span className={`${sc.text} truncate flex-1 font-medium`}>{item.product?.name || 'منتج'}</span>
                  <span className="text-gray-600 mr-2 font-bold">{item.quantity} قطعة</span>
                </div>
              ))}
              {order.items.length > 2 && (
                <p className="text-xs text-gray-400 mt-1">+{order.items.length - 2} منتجات أخرى</p>
              )}
            </div>

            {/* Meta row */}
            <div className="flex items-center gap-3 text-xs text-gray-500 mb-3" onClick={onView}>
              <span className="flex items-center gap-1">
                <div className={`w-1.5 h-1.5 rounded-full ${pc.dot}`} />
                <span className={pc.color}>{pc.label}</span>
              </span>
              {dueDate && (
                <span className={`flex items-center gap-1 ${isOverdue ? 'text-red-600 font-bold' : ''}`}>
                  <Clock size={10} />
                  {isOverdue ? 'متأخر!' : dueDate.toLocaleDateString('ar-SY')}
                </span>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-50" onClick={onView}>
              <div>
                <p className="text-xs text-gray-400 mb-0.5">الإجمالي</p>
                <div className="flex items-center gap-2">
                  <p className="text-base font-black text-gray-900">{format(order.total_usd, order.total_syp)}</p>
                  {order.payment_status === 'paid' && (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-600">مدفوع</span>
                  )}
                  {order.payment_status === 'partial' && (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-600">جزئي</span>
                  )}
                  {order.payment_status === 'unpaid' && order.status !== 'cancelled' && (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-red-50 text-red-600">غير مدفوع</span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-xs text-blue-600 font-semibold">عرض التفاصيل</span>
                <ChevronLeft size={14} className="text-blue-500 rotate-180" />
              </div>
            </div>
          </div>
        </CardBody>
      </Card>
    </motion.div>
  );
};

// ── Main Component ──────────────────────────────────────────────────────────
export const OrdersPage: React.FC = () => {
  const { user } = useAuth();
  const { format } = useCurrency();
  const { orders, updateOrderStatus, deleteOrder } = useAppData();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | OrderStatus>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState<'date' | 'amount' | 'priority'>('date');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const canCreate = user?.role && ['admin', 'manager'].includes(user.role);
  const canManage = user?.role && ['admin', 'manager', 'production_supervisor'].includes(user.role);
  const canDelete = user?.role === 'admin';

  const filtered = useMemo(() => {
    let result = orders.filter(order => {
      const q = search.toLowerCase();
      const matchSearch = !search ||
        order.customer_name.toLowerCase().includes(q) ||
        order.order_number.toLowerCase().includes(q) ||
        (order.customer_phone?.includes(search));
      const matchStatus = statusFilter === 'all' || order.status === statusFilter;
      return matchSearch && matchStatus;
    });

    if (sortBy === 'amount') result = [...result].sort((a, b) => b.total_usd - a.total_usd);
    if (sortBy === 'priority') {
      const pOrder = { urgent: 0, high: 1, normal: 2, low: 3 };
      result = [...result].sort((a, b) => pOrder[a.priority] - pOrder[b.priority]);
    }
    if (sortBy === 'date') result = [...result].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return result;
  }, [orders, search, statusFilter, sortBy]);

  // ── Pagination ──────────────────────────────────────────────────────────
  const PAGE_SIZE = 20;
  const [page, setPage] = useState(1);
  // Reset to page 1 whenever the filtered result set changes (new search/filter)
  useEffect(() => { setPage(1); }, [search, statusFilter, sortBy]);
  const { pageItems: paged, totalPages, safePage } = usePagination(filtered, PAGE_SIZE, page);

  const totalAmount = filtered.reduce((s, o) => s + o.total_usd, 0);
  const statusCounts = orders.reduce((acc, o) => {
    acc[o.status] = (acc[o.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const handleDelete = (orderId: string) => {
    deleteOrder(orderId);
    setDeleteConfirm(null);
  };

  return (
    <div className="page-wrapper bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="page-header">
        <div className="px-4 pt-3 pb-0">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h1 className="text-lg font-black text-gray-900">طلبات الإنتاج</h1>
              <p className="text-xs text-gray-400">{orders.length} طلب إجمالي</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`w-9 h-9 rounded-xl flex items-center justify-center border transition-colors ${showFilters ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white border-gray-200 text-gray-600'}`}
              >
                <Filter size={16} />
              </button>
              {canCreate && (
                <Button size="sm" leftIcon={<Plus size={14} />} onClick={() => navigate('/orders/new')}>
                  جديد
                </Button>
              )}
            </div>
          </div>

          {/* Search */}
          <div className="relative mb-3">
            <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="بحث بالعميل أو رقم الطلب..."
              className="w-full pr-9 pl-10 py-2.5 bg-gray-100 border border-transparent rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                <XCircle size={15} />
              </button>
            )}
          </div>

          {/* Status Filters */}
          <div className="filter-row" style={{ padding: '0 0 10px' }}>
            {STATUS_FILTERS.map(f => {
              const count = f.value === 'all' ? orders.length : (statusCounts[f.value] || 0);
              return (
                <button
                  key={f.value}
                  onClick={() => setStatusFilter(f.value)}
                  className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all flex items-center gap-1.5 ${statusFilter === f.value ? 'bg-blue-600 text-white shadow-md shadow-blue-200' : 'bg-gray-100 text-gray-600'}`}
                >
                  {f.label}
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${statusFilter === f.value ? 'bg-white/20 text-white' : 'bg-white text-gray-600'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Sort Options */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-t border-gray-100"
            >
              <div className="px-4 py-3 flex items-center gap-2">
                <SortAsc size={14} className="text-gray-500" />
                <span className="text-xs text-gray-500 font-medium">ترتيب حسب:</span>
                {[
                  { value: 'date', label: 'التاريخ' },
                  { value: 'amount', label: 'المبلغ' },
                  { value: 'priority', label: 'الأولوية' },
                ].map(s => (
                  <button
                    key={s.value}
                    onClick={() => setSortBy(s.value as typeof sortBy)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${sortBy === s.value ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'}`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Summary Strip */}
      <div className="px-4 py-3 flex items-center gap-3">
        <div className="flex items-center gap-1.5 text-sm">
          <span className="font-bold text-gray-800">{filtered.length}</span>
          <span className="text-gray-500">طلب</span>
        </div>
        <div className="w-px h-4 bg-gray-200" />
        <div className="flex items-center gap-1.5 text-sm">
          <span className="text-gray-500">مجموع:</span>
          <span className="font-black text-emerald-600">{format(totalAmount)}</span>
        </div>
        {filtered.some(o => o.status === 'pending') && (
          <>
            <div className="w-px h-4 bg-gray-200" />
            <div className="flex items-center gap-1 text-xs text-amber-600 font-medium">
              <Clock size={11} />
              {filtered.filter(o => o.status === 'pending').length} معلق
            </div>
          </>
        )}
      </div>

      {/* Desktop Table */}
      <div className="hidden md:block px-4" style={{ paddingBottom: 'var(--page-pb)' }}>
        {filtered.length === 0 ? (
          <EmptyOrders search={search} onClear={() => setSearch('')} onNew={() => navigate('/orders/new')} canCreate={!!canCreate} />
        ) : (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  {['رقم الطلب', 'العميل', 'المنتجات', 'المبلغ', 'الحالة', 'الأولوية', 'تاريخ التسليم', ''].map(h => (
                    <th key={h} className="px-4 py-3 text-right text-xs font-bold text-gray-500">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {paged.map(order => (
                  <DesktopOrderRow
                    key={order.id}
                    order={order}
                    onView={() => navigate(`/orders/${order.id}`)}
                    onDelete={() => setDeleteConfirm(order.id)}
                    format={format}
                    canDelete={!!canDelete}
                  />
                ))}
              </tbody>
            </table>
            <Pagination page={safePage} totalItems={filtered.length} pageSize={PAGE_SIZE} onPageChange={setPage} />
          </div>
        )}
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden px-4 space-y-3" style={{ paddingBottom: 'var(--page-pb)' }}>
        {filtered.length === 0 ? (
          <EmptyOrders search={search} onClear={() => setSearch('')} onNew={() => navigate('/orders/new')} canCreate={!!canCreate} />
        ) : (
          <>
            {paged.map((order, idx) => (
              <MobileOrderCard
                key={order.id}
                order={order}
                onView={() => navigate(`/orders/${order.id}`)}
                onStatusChange={(status) => updateOrderStatus(order.id, status)}
                format={format}
                index={idx}
                canManage={!!canManage}
              />
            ))}
            <Pagination page={safePage} totalItems={filtered.length} pageSize={PAGE_SIZE} onPageChange={setPage} />
          </>
        )}
      </div>

      {/* Delete Confirm Modal */}
      <AnimatePresence>
        {deleteConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ background: 'rgba(0,0,0,0.5)' }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-sm"
            >
              <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Trash2 size={24} className="text-red-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 text-center mb-2">حذف الطلب</h3>
              <p className="text-sm text-gray-500 text-center mb-6">هل أنت متأكد من حذف هذا الطلب؟ لا يمكن التراجع.</p>
              <div className="flex gap-3">
                <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2.5 bg-gray-100 text-gray-700 rounded-xl font-medium text-sm">إلغاء</button>
                <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 py-2.5 bg-red-600 text-white rounded-xl font-bold text-sm">حذف</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const EmptyOrders: React.FC<{
  search: string; onClear: () => void;
  onNew: () => void; canCreate: boolean;
}> = ({ search, onClear, onNew, canCreate }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="flex flex-col items-center justify-center py-20 text-center"
  >
    <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-4">
      <ShoppingCart size={32} className="text-gray-300" />
    </div>
    <h3 className="font-bold text-gray-700 mb-1">لا توجد طلبات</h3>
    <p className="text-sm text-gray-400 mb-5">
      {search ? `لا توجد نتائج لـ "${search}"` : 'ابدأ بإنشاء طلب إنتاج جديد'}
    </p>
    {search ? (
      <button onClick={onClear} className="px-4 py-2 bg-gray-100 text-gray-600 rounded-xl text-sm font-medium">مسح البحث</button>
    ) : canCreate ? (
      <button onClick={onNew} className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-md">
        <Plus size={16} /> إنشاء طلب جديد
      </button>
    ) : null}
  </motion.div>
);
