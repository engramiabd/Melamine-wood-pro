import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAppData } from '../contexts/AppDataContext';
import { EmptyState } from '../components/ui/EmptyState';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import { resolveActorName } from '../lib/workers';
import {
  Search, Plus, FileText, Printer, CheckCircle, X, DollarSign, Trash2,
} from 'lucide-react';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { Pagination, usePagination } from '../components/ui/Pagination';
import { Switch } from '../components/ui/Switch';
import { printInvoice } from '../utils/print';
import type { Invoice, InvoiceItem, InvoiceStatus, InvoiceType } from '../types';

const STATUS_CFG: Record<InvoiceStatus, { label: string; bg: string; text: string }> = {
  draft:     { label: 'مسودة',          bg: 'var(--border-color)', text: 'var(--text-tertiary)' },
  sent:      { label: 'مُرسلة',          bg: '#eff6ff', text: '#1d4ed8' },
  paid:      { label: 'مدفوعة بالكامل', bg: '#f0fdf4', text: '#16a34a' },
  partial:   { label: 'مدفوعة جزئياً',  bg: '#fffbeb', text: '#b45309' },
  overdue:   { label: 'متأخرة',          bg: '#fef2f2', text: '#dc2626' },
  cancelled: { label: 'ملغاة',           bg: '#fef2f2', text: 'var(--text-tertiary)' },
};

interface LineItemForm {
  description: string; quantity: string; unit_price_usd: string;
}

export default function InvoicesPage() {
  const { customers, managedProducts, invoices, addInvoice, addInvoicePayment, deleteInvoice, systemSettings } = useAppData();
  const { formatUSD, exchangeRate } = useCurrency();
  const { user, hasRole } = useAuth();
  const canManage = hasRole('admin') || hasRole('manager') || hasRole('accountant');

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | InvoiceType>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | InvoiceStatus>('all');
  const [createOpen, setCreateOpen] = useState(false);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [paymentOpen, setPaymentOpen] = useState(false);

  const sorted = useMemo(() =>
    [...invoices].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()),
  [invoices]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return sorted.filter(inv => {
      const matchSearch = !q || inv.invoice_number.toLowerCase().includes(q) || inv.customer_name.toLowerCase().includes(q);
      const matchType = typeFilter === 'all' || inv.type === typeFilter;
      const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
      return matchSearch && matchType && matchStatus;
    });
  }, [sorted, search, typeFilter, statusFilter]);

  const PAGE_SIZE = 15;
  const [page, setPage] = useState(1);
  useEffect(() => { setPage(1); }, [search, typeFilter, statusFilter]);
  const { pageItems: paged, safePage } = usePagination(filtered, PAGE_SIZE, page);

  const totals = useMemo(() => {
    const sales = invoices.filter(i => i.type === 'sale');
    return {
      totalBilled: sales.reduce((s, i) => s + i.total_usd, 0),
      totalPaid: sales.reduce((s, i) => s + i.paid_usd, 0),
      totalOutstanding: sales.reduce((s, i) => s + i.remaining_usd, 0),
    };
  }, [invoices]);

  const detailInvoice = detailId ? invoices.find(i => i.id === detailId) : undefined;

  return (
    <div style={{ minHeight: '100%', background: 'var(--surface-secondary)' }}>
      <div style={{ background: 'linear-gradient(135deg,#6366f1,#4f46e5)', padding: '20px 16px 20px' }}>
        <div style={{ marginBottom: 16 }}>
          <h1 style={{ fontSize: 20, fontWeight: 900, color: '#fff' }}>الفواتير وعروض الأسعار</h1>
          <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.8)' }}>{invoices.length} مستند</p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          <StatChip label="إجمالي المُفوتر" value={formatUSD(totals.totalBilled)} />
          <StatChip label="المُحصّل" value={formatUSD(totals.totalPaid)} positive />
          <StatChip label="المستحق" value={formatUSD(totals.totalOutstanding)} negative={totals.totalOutstanding > 0} />
        </div>
      </div>

      <div style={{ padding: 16 }}>
        <div style={{ position: 'relative', marginBottom: 12 }}>
          <Search size={16} style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="ابحث برقم الفاتورة أو اسم العميل..."
            style={{ width: '100%', padding: '12px 40px 12px 14px', borderRadius: 14, border: '1px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box', background: 'var(--surface)' }} />
        </div>

        <div style={{ display: 'flex', gap: 8, marginBottom: 14, overflowX: 'auto' }}>
          {(['all', 'sale', 'quotation'] as const).map(t => (
            <FilterPill key={t} active={typeFilter === t} onClick={() => setTypeFilter(t)}
              label={t === 'all' ? 'الكل' : t === 'sale' ? 'فواتير' : 'عروض أسعار'} />
          ))}
          <div style={{ width: 1, background: 'var(--border-color)', margin: '0 4px' }} />
          {(['all', 'paid', 'partial', 'sent', 'overdue'] as const).map(s => (
            <FilterPill key={s} active={statusFilter === s} onClick={() => setStatusFilter(s)}
              label={s === 'all' ? 'كل الحالات' : STATUS_CFG[s].label} />
          ))}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.length === 0 ? (
            <EmptyState icon={FileText} title="لا توجد فواتير مطابقة" description="جرّب تغيير البحث أو الفلتر، أو أنشئ فاتورة جديدة." />
          ) : (
            paged.map(inv => (
              <motion.div key={inv.id} layout onClick={() => setDetailId(inv.id)}
                style={{ background: 'var(--surface)', borderRadius: 16, padding: 14, border: '1px solid var(--border-color)', cursor: 'pointer', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>{inv.invoice_number}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 2 }}>{inv.customer_name}</div>
                  </div>
                  <span style={{ fontSize: 10, padding: '3px 9px', borderRadius: 99, background: STATUS_CFG[inv.status].bg, color: STATUS_CFG[inv.status].text, fontWeight: 700 }}>
                    {STATUS_CFG[inv.status].label}
                  </span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{new Date(inv.issued_date).toLocaleDateString('ar-SY')}</span>
                  <span style={{ fontSize: 16, fontWeight: 800, color: 'var(--text-primary)' }}>{formatUSD(inv.total_usd)}</span>
                </div>
              </motion.div>
            ))
          )}
          {filtered.length > 0 && <Pagination page={safePage} totalItems={filtered.length} pageSize={PAGE_SIZE} onPageChange={setPage} />}
        </div>
      </div>

      {canManage && (
        <button onClick={() => setCreateOpen(true)}
          style={{
            position: 'fixed', left: 20, bottom: `calc(var(--bottomnav-h) + var(--sab) + 16px)`,
            width: 52, height: 52, borderRadius: '50%',
            background: 'linear-gradient(135deg,#6366f1,#4f46e5)',
            color: '#fff', border: 'none', cursor: 'pointer', zIndex: 30,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 20px rgba(79,70,229,0.4)',
          }}>
          <Plus size={22} />
        </button>
      )}

      {createOpen && (
        <CreateInvoiceModal
          onClose={() => setCreateOpen(false)}
          customers={customers}
          products={managedProducts}
          exchangeRate={exchangeRate}
          taxRate={systemSettings.taxRate ?? 0}
          createdBy={user?.full_name || user?.id || 'النظام'}
          onCreate={(payload) => { addInvoice(payload); setCreateOpen(false); }}
        />
      )}

      {detailInvoice && (
        <BottomSheetModal isOpen onClose={() => setDetailId(null)}>
          <SheetHeader onClose={() => setDetailId(null)}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>{detailInvoice.invoice_number}</div>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{detailInvoice.customer_name}</div>
              </div>
              <span style={{ fontSize: 11, padding: '4px 10px', borderRadius: 99, background: STATUS_CFG[detailInvoice.status].bg, color: STATUS_CFG[detailInvoice.status].text, fontWeight: 700 }}>
                {STATUS_CFG[detailInvoice.status].label}
              </span>
            </div>
          </SheetHeader>
          <SheetBody>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 16 }}>
              {detailInvoice.items.map(item => (
                <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 10px', background: 'var(--surface-secondary)', borderRadius: 10 }}>
                  <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{item.description} × {item.quantity}</span>
                  <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-primary)' }}>{formatUSD(item.total_usd)}</span>
                </div>
              ))}
            </div>
            <div style={{ background: 'var(--surface-secondary)', borderRadius: 12, padding: 12, marginBottom: 16 }}>
              <Row label="المجموع الفرعي" value={formatUSD(detailInvoice.subtotal_usd)} />
              {detailInvoice.discount_usd > 0 && <Row label="الخصم" value={`-${formatUSD(detailInvoice.discount_usd)}`} />}
              {detailInvoice.tax_usd > 0 && <Row label={`الضريبة (${detailInvoice.tax_rate}%)`} value={formatUSD(detailInvoice.tax_usd)} />}
              <Row label="الإجمالي" value={formatUSD(detailInvoice.total_usd)} bold />
              {detailInvoice.paid_usd > 0 && (
                <>
                  <Row label="المدفوع" value={formatUSD(detailInvoice.paid_usd)} color="#16a34a" />
                  <Row label="المتبقي" value={formatUSD(detailInvoice.remaining_usd)} color={detailInvoice.remaining_usd > 0 ? '#dc2626' : '#16a34a'} />
                </>
              )}
              <div style={{ height: 1, background: 'var(--border-color)', margin: '6px 0' }} />
              <Row label="أصدرها" value={resolveActorName(detailInvoice.created_by)} />
              <Row label="تاريخ الإصدار" value={new Date(detailInvoice.issued_date).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric' })} />
            </div>
          </SheetBody>
          <SheetFooter>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => printInvoice(detailInvoice, systemSettings.factoryName)}
                style={{ flex: 1, padding: '13px', borderRadius: 12, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <Printer size={14} /> طباعة
              </button>
              {canManage && detailInvoice.type === 'sale' && detailInvoice.remaining_usd > 0 && (
                <button onClick={() => setPaymentOpen(true)}
                  style={{ flex: 2, padding: '13px', borderRadius: 12, border: 'none', background: '#16a34a', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                  <DollarSign size={14} /> تسجيل دفعة
                </button>
              )}
              {canManage && (
                <button onClick={() => { if (window.confirm(`حذف الفاتورة ${detailInvoice.invoice_number}؟`)) { deleteInvoice(detailInvoice.id); setDetailId(null); } }}
                  aria-label="حذف الفاتورة" style={{ padding: '13px 15px', borderRadius: 12, border: '1.5px solid #fecaca', background: 'var(--surface)', color: '#dc2626', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          </SheetFooter>
        </BottomSheetModal>
      )}

      {paymentOpen && detailInvoice && (
        <RecordPaymentModal
          invoice={detailInvoice}
          onClose={() => setPaymentOpen(false)}
          onSubmit={(amountUsd, method) => {
            addInvoicePayment({
              invoice_id: detailInvoice.id,
              amount_usd: amountUsd,
              amount_syp: amountUsd * exchangeRate,
              method, date: new Date().toISOString(),
            });
            setPaymentOpen(false);
          }}
        />
      )}
    </div>
  );
}

// ── Sub-components ──────────────────────────────────────────────────────────

const StatChip: React.FC<{ label: string; value: string; positive?: boolean; negative?: boolean }> = ({ label, value, positive, negative }) => (
  <div style={{ background: 'rgba(255,255,255,0.15)', borderRadius: 12, padding: '10px 8px', textAlign: 'center' }}>
    <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.7)', marginBottom: 3 }}>{label}</div>
    <div style={{ fontSize: 13, fontWeight: 800, color: negative ? '#fecaca' : positive ? '#bbf7d0' : '#fff' }}>{value}</div>
  </div>
);

const FilterPill: React.FC<{ active: boolean; onClick: () => void; label: string }> = ({ active, onClick, label }) => (
  <button onClick={onClick}
    style={{
      padding: '7px 14px', borderRadius: 99, whiteSpace: 'nowrap',
      background: active ? '#4f46e5' : '#fff', color: active ? 'var(--surface)' : 'var(--text-tertiary)',
      fontSize: 11, fontWeight: 700, cursor: 'pointer', border: active ? 'none' : '1px solid var(--border-color)',
    }}>
    {label}
  </button>
);

const Row: React.FC<{ label: string; value: string; bold?: boolean; color?: string }> = ({ label, value, bold, color }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderTop: bold ? '1px solid var(--border-color)' : 'none', marginTop: bold ? 6 : 0, paddingTop: bold ? 8 : 4 }}>
    <span style={{ fontSize: bold ? 13 : 12, color: bold ? '#0f172a' : 'var(--text-tertiary)', fontWeight: bold ? 700 : 500 }}>{label}</span>
    <span style={{ fontSize: bold ? 14 : 12, color: color || (bold ? '#0f172a' : 'var(--text-secondary)'), fontWeight: bold ? 800 : 600 }}>{value}</span>
  </div>
);

interface CreateInvoiceModalProps {
  onClose: () => void;
  customers: import('../types').Customer[];
  products: import('../types').Product[];
  exchangeRate: number;
  taxRate: number;
  createdBy: string;
  onCreate: (payload: Omit<Invoice, 'id' | 'created_at' | 'updated_at'>) => void;
}

const CreateInvoiceModal: React.FC<CreateInvoiceModalProps> = ({
  onClose, customers, products, exchangeRate, taxRate, createdBy, onCreate,
}) => {
  const [type, setType] = useState<InvoiceType>('sale');
  const [customerId, setCustomerId] = useState('');
  const [customerSearch, setCustomerSearch] = useState('');
  const [showCustomerList, setShowCustomerList] = useState(false);
  const [items, setItems] = useState<LineItemForm[]>([{ description: '', quantity: '1', unit_price_usd: '' }]);
  const [discount, setDiscount] = useState('0');
  const [applyTax, setApplyTax] = useState(false);
  const [dueDate, setDueDate] = useState('');
  const [notes, setNotes] = useState('');

  const selectedCustomer = customers.find(c => c.id === customerId);
  const filteredCustomers = useMemo(() => {
    const q = customerSearch.trim().toLowerCase();
    if (!q) return customers.slice(0, 8);
    return customers.filter(c => c.name.toLowerCase().includes(q) || c.phone.includes(q)).slice(0, 8);
  }, [customers, customerSearch]);

  const addItem = () => setItems(prev => [...prev, { description: '', quantity: '1', unit_price_usd: '' }]);
  const removeItem = (idx: number) => setItems(prev => prev.filter((_, i) => i !== idx));
  const updateItem = (idx: number, patch: Partial<LineItemForm>) =>
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, ...patch } : it));

  const pickProduct = (idx: number, productId: string) => {
    const p = products.find(pr => pr.id === productId);
    if (!p) return;
    updateItem(idx, { description: p.name, unit_price_usd: String(p.price_usd) });
  };

  const subtotal = items.reduce((s, it) => s + (parseFloat(it.quantity) || 0) * (parseFloat(it.unit_price_usd) || 0), 0);
  const discountVal = parseFloat(discount) || 0;
  const taxVal = applyTax ? (subtotal - discountVal) * (taxRate / 100) : 0;
  const total = Math.max(0, subtotal - discountVal + taxVal);

  const canSubmit = customerId && items.some(it => it.description.trim() && parseFloat(it.unit_price_usd) > 0);

  const handleSubmit = () => {
    if (!canSubmit || !selectedCustomer) return;
    const validItems = items.filter(it => it.description.trim() && parseFloat(it.unit_price_usd) > 0);
    const invoiceItems: InvoiceItem[] = validItems.map((it, i) => {
      const qty = parseFloat(it.quantity) || 1;
      const priceUsd = parseFloat(it.unit_price_usd) || 0;
      return {
        id: `ii_${Date.now()}_${i}`, invoice_id: '', description: it.description,
        quantity: qty, unit_price_usd: priceUsd, unit_price_syp: priceUsd * exchangeRate,
        total_usd: qty * priceUsd, total_syp: qty * priceUsd * exchangeRate,
      };
    });
    onCreate({
      invoice_number: `${type === 'sale' ? 'INV' : 'QUO'}-${Date.now().toString().slice(-6)}`,
      type, customer_id: selectedCustomer.id, customer_name: selectedCustomer.name,
      customer_phone: selectedCustomer.phone, customer_address: selectedCustomer.address,
      items: invoiceItems,
      subtotal_usd: subtotal, subtotal_syp: subtotal * exchangeRate,
      tax_rate: applyTax ? taxRate : 0, tax_usd: taxVal, tax_syp: taxVal * exchangeRate,
      discount_usd: discountVal, discount_syp: discountVal * exchangeRate,
      total_usd: total, total_syp: total * exchangeRate,
      paid_usd: 0, remaining_usd: total,
      status: type === 'quotation' ? 'draft' : 'sent',
      due_date: dueDate || undefined, notes: notes || undefined,
      created_by: createdBy, issued_date: new Date().toISOString(),
    });
  };

  return (
    <BottomSheetModal isOpen onClose={onClose} maxHeight="94dvh">
      <SheetHeader onClose={onClose}>
        <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>إنشاء {type === 'sale' ? 'فاتورة' : 'عرض سعر'} جديد</div>
      </SheetHeader>
      <SheetBody>
        {/* Type toggle */}
        <div style={{ display: 'flex', background: 'var(--border-color)', borderRadius: 12, padding: 4, marginBottom: 16 }}>
          {(['sale', 'quotation'] as const).map(t => (
            <button key={t} onClick={() => setType(t)}
              style={{ flex: 1, padding: '8px', borderRadius: 9, border: 'none', background: type === t ? 'var(--surface)' : 'transparent', color: type === t ? '#4f46e5' : 'var(--text-tertiary)', fontSize: 12, fontWeight: 700, cursor: 'pointer', boxShadow: type === t ? '0 1px 3px rgba(0,0,0,0.1)' : 'none' }}>
              {t === 'sale' ? 'فاتورة مبيعات' : 'عرض سعر'}
            </button>
          ))}
        </div>

        {/* Customer picker */}
        <div style={{ marginBottom: 16, position: 'relative' }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>العميل *</label>
          {selectedCustomer ? (
            <div onClick={() => { setCustomerId(''); setShowCustomerList(true); }}
              style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '11px 14px', borderRadius: 12, border: '1.5px solid #c7d2fe', background: '#eef2ff', cursor: 'pointer' }}>
              <span style={{ fontSize: 14, fontWeight: 700, color: '#3730a3' }}>{selectedCustomer.name}</span>
              <X size={14} color="#6366f1" />
            </div>
          ) : (
            <>
              <div style={{ position: 'relative' }}>
                <input value={customerSearch} onChange={e => { setCustomerSearch(e.target.value); setShowCustomerList(true); }}
                  onFocus={() => setShowCustomerList(true)}
                  placeholder="ابحث عن عميل بالاسم أو الهاتف..."
                  style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
              </div>
              {showCustomerList && (
                <div style={{ marginTop: 6, border: '1px solid var(--border-color)', borderRadius: 12, overflow: 'hidden', maxHeight: 200, overflowY: 'auto' }}>
                  {filteredCustomers.length === 0 ? (
                    <div style={{ padding: 12, fontSize: 12, color: 'var(--text-tertiary)', textAlign: 'center' }}>لا يوجد عملاء مطابقين</div>
                  ) : filteredCustomers.map(c => (
                    <div key={c.id} onClick={() => { setCustomerId(c.id); setShowCustomerList(false); setCustomerSearch(''); }}
                      style={{ padding: '10px 14px', borderBottom: '1px solid var(--border-color)', cursor: 'pointer' }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{c.name}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }} dir="ltr">{c.phone}</div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {/* Line items */}
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 8 }}>البنود *</label>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {items.map((item, idx) => (
              <div key={idx} style={{ background: 'var(--surface-secondary)', borderRadius: 12, padding: 10, position: 'relative' }}>
                {items.length > 1 && (
                  <button onClick={() => removeItem(idx)}
                    style={{ position: 'absolute', top: 8, left: 8, width: 20, height: 20, borderRadius: '50%', border: 'none', background: '#fee2e2', color: '#dc2626', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <X size={12} />
                  </button>
                )}
                {products.length > 0 && (
                  <select onChange={e => e.target.value && pickProduct(idx, e.target.value)} defaultValue=""
                    style={{ width: '100%', padding: '8px 10px', borderRadius: 8, border: '1px solid var(--border-color)', fontSize: 12, outline: 'none', background: 'var(--surface)', marginBottom: 8 }}>
                    <option value="">اختر من المنتجات (اختياري)...</option>
                    {products.map(p => <option key={p.id} value={p.id}>{p.name} - ${p.price_usd}</option>)}
                  </select>
                )}
                <input value={item.description} onChange={e => updateItem(idx, { description: e.target.value })}
                  placeholder="وصف البند" style={{ width: '100%', padding: '9px 10px', borderRadius: 8, border: '1px solid var(--border-color)', fontSize: 13, outline: 'none', marginBottom: 8, boxSizing: 'border-box' }} />
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                  <input type="number" value={item.quantity} onChange={e => updateItem(idx, { quantity: e.target.value })}
                    placeholder="الكمية" style={{ width: '100%', padding: '9px 10px', borderRadius: 8, border: '1px solid var(--border-color)', fontSize: 13, outline: 'none', boxSizing: 'border-box' }} />
                  <input type="number" value={item.unit_price_usd} onChange={e => updateItem(idx, { unit_price_usd: e.target.value })}
                    placeholder="السعر ($)" style={{ width: '100%', padding: '9px 10px', borderRadius: 8, border: '1px solid var(--border-color)', fontSize: 13, outline: 'none', boxSizing: 'border-box' }} />
                </div>
              </div>
            ))}
          </div>
          <button onClick={addItem}
            style={{ marginTop: 8, width: '100%', padding: '9px', borderRadius: 10, border: '1.5px dashed #c7d2fe', background: '#eef2ff', color: '#4f46e5', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>
            + إضافة بند
          </button>
        </div>

        {/* Discount & Tax */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>الخصم ($)</label>
            <input type="number" value={discount} onChange={e => setDiscount(e.target.value)}
              style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>تاريخ الاستحقاق</label>
            <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)}
              style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
          </div>
        </div>

        {taxRate > 0 && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginBottom: 16 }}>
            <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>تطبيق الضريبة ({taxRate}%)</span>
            <Switch checked={applyTax} onChange={setApplyTax} size="sm" color="blue" />
          </div>
        )}

        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>ملاحظات</label>
          <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2}
            style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', resize: 'none', boxSizing: 'border-box', marginBottom: 16 }} />
        </div>

        {/* Summary */}
        <div style={{ background: '#eef2ff', borderRadius: 12, padding: 12 }}>
          <Row label="المجموع الفرعي" value={`$${subtotal.toFixed(2)}`} />
          {discountVal > 0 && <Row label="الخصم" value={`-$${discountVal.toFixed(2)}`} />}
          {applyTax && taxVal > 0 && <Row label={`الضريبة (${taxRate}%)`} value={`$${taxVal.toFixed(2)}`} />}
          <Row label="الإجمالي" value={`$${total.toFixed(2)}`} bold />
        </div>
      </SheetBody>
      <SheetFooter>
        <button onClick={handleSubmit} disabled={!canSubmit}
          style={{
            width: '100%', padding: '14px', borderRadius: 12, border: 'none',
            background: !canSubmit ? 'var(--border-color)' : '#4f46e5',
            color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}>
          <CheckCircle size={16} /> إنشاء {type === 'sale' ? 'الفاتورة' : 'عرض السعر'}
        </button>
      </SheetFooter>
    </BottomSheetModal>
  );
};

const RecordPaymentModal: React.FC<{
  invoice: Invoice; onClose: () => void;
  onSubmit: (amountUsd: number, method: 'cash' | 'bank_transfer' | 'check' | 'other') => void;
}> = ({ invoice, onClose, onSubmit }) => {
  const [amount, setAmount] = useState(String(invoice.remaining_usd));
  const [method, setMethod] = useState<'cash' | 'bank_transfer' | 'check' | 'other'>('cash');
  const amountNum = parseFloat(amount) || 0;
  const valid = amountNum > 0 && amountNum <= invoice.remaining_usd;

  return (
    <BottomSheetModal isOpen onClose={onClose}>
      <SheetHeader onClose={onClose}>
        <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>تسجيل دفعة</div>
      </SheetHeader>
      <SheetBody>
        <div style={{ background: 'var(--surface-secondary)', borderRadius: 12, padding: 12, marginBottom: 16, textAlign: 'center' }}>
          <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 4 }}>المبلغ المتبقي</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: '#dc2626' }}>${invoice.remaining_usd.toFixed(2)}</div>
        </div>
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>المبلغ المدفوع ($) *</label>
          <input type="number" value={amount} onChange={e => setAmount(e.target.value)}
            style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 18, outline: 'none', boxSizing: 'border-box', fontWeight: 700 }} />
          {amountNum > invoice.remaining_usd && (
            <p style={{ fontSize: 11, color: '#dc2626', marginTop: 4 }}>المبلغ أكبر من المتبقي</p>
          )}
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>طريقة الدفع</label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
            {([['cash', 'نقدي'], ['bank_transfer', 'تحويل'], ['check', 'شيك'], ['other', 'أخرى']] as const).map(([v, l]) => (
              <button key={v} onClick={() => setMethod(v)}
                style={{ padding: '9px 4px', borderRadius: 10, border: `1.5px solid ${method === v ? '#16a34a' : 'var(--border-color)'}`, background: method === v ? '#f0fdf4' : '#fff', color: method === v ? '#16a34a' : 'var(--text-tertiary)', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>
                {l}
              </button>
            ))}
          </div>
        </div>
      </SheetBody>
      <SheetFooter>
        <button onClick={() => onSubmit(amountNum, method)} disabled={!valid}
          style={{
            width: '100%', padding: '14px', borderRadius: 12, border: 'none',
            background: !valid ? 'var(--border-color)' : '#16a34a',
            color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}>
          <DollarSign size={16} /> تأكيد الدفعة
        </button>
      </SheetFooter>
    </BottomSheetModal>
  );
};
