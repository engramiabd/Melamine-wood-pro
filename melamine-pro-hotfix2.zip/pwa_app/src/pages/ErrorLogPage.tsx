import React, { useMemo, useState } from 'react';
import { AlertOctagon, Search, Trash2, Download } from 'lucide-react';
import { useAppData } from '../contexts/AppDataContext';
import { EmptyState } from '../components/ui/EmptyState';
import { Pagination } from '../components/ui/Pagination';
import { downloadCSV } from '../utils/exportReports';

const PAGE = 20;

export const ErrorLogPage: React.FC = () => {
  const { errorLog, clearErrorLog } = useAppData();
  const [q, setQ] = useState('');
  const [level, setLevel] = useState<'all' | 'error' | 'warning'>('all');
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    const s = q.trim();
    return errorLog.filter(e =>
      (level === 'all' || e.level === level) &&
      (!s || e.message.includes(s) || e.source.includes(s)));
  }, [errorLog, q, level]);

  const counts = useMemo(() => ({
    error: errorLog.filter(e => e.level === 'error').length,
    warning: errorLog.filter(e => e.level === 'warning').length,
  }), [errorLog]);

  const exportCSV = () => {
    downloadCSV('سجل_الأخطاء', ['التاريخ', 'المستوى', 'المصدر', 'الرسالة'],
      filtered.map(e => [new Date(e.timestamp).toLocaleString('ar-SY'), e.level === 'error' ? 'خطأ' : 'تحذير', e.source, e.message]));
  };

  return (
    <div className="min-h-full bg-gray-50 pb-24" dir="rtl">
      <div className="bg-gradient-to-br from-slate-700 to-gray-900 px-5 pt-6 pb-8 text-white">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center"><AlertOctagon size={22} /></div>
          <div>
            <h1 className="text-lg font-extrabold">سجل الأخطاء التشغيلي</h1>
            <p className="text-xs text-white/60">أخطاء وتحذيرات العمليات</p>
          </div>
        </div>
      </div>

      {/* Stats + filter */}
      <div className="px-4 -mt-4 grid grid-cols-2 gap-2">
        <button onClick={() => { setLevel(level === 'error' ? 'all' : 'error'); setPage(1); }}
          className={`bg-white rounded-2xl p-3 shadow-sm text-center ${level === 'error' ? 'ring-2 ring-red-300' : ''}`}>
          <div className="text-xl font-black text-red-600">{counts.error}</div>
          <div className="text-[10px] text-gray-400">أخطاء</div>
        </button>
        <button onClick={() => { setLevel(level === 'warning' ? 'all' : 'warning'); setPage(1); }}
          className={`bg-white rounded-2xl p-3 shadow-sm text-center ${level === 'warning' ? 'ring-2 ring-amber-300' : ''}`}>
          <div className="text-xl font-black text-amber-500">{counts.warning}</div>
          <div className="text-[10px] text-gray-400">تحذيرات</div>
        </button>
      </div>

      {/* Search + actions */}
      <div className="px-4 mt-3 flex gap-2">
        <div className="relative flex-1">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={q} onChange={e => { setQ(e.target.value); setPage(1); }} placeholder="بحث في الأخطاء…"
            className="w-full bg-white rounded-xl py-2.5 pr-9 pl-3 text-sm shadow-sm outline-none focus:ring-2 focus:ring-slate-300" />
        </div>
        <button onClick={exportCSV} disabled={filtered.length === 0}
          aria-label="تصدير CSV" className="bg-white rounded-xl px-3 shadow-sm text-slate-600 disabled:opacity-40" title="تصدير CSV"><Download size={18} /></button>
        <button onClick={() => { if (window.confirm('مسح سجل الأخطاء بالكامل؟')) clearErrorLog(); }}
          aria-label="مسح السجل" className="bg-white rounded-xl px-3 shadow-sm text-red-500" title="مسح"><Trash2 size={18} /></button>
      </div>

      {/* List */}
      <div className="px-4 mt-3 space-y-2">
        {filtered.length === 0 && <EmptyState compact title="لا توجد سجلات" description="لا توجد أخطاء مسجّلة ضمن هذا الفلتر." />}
        {filtered.slice((page - 1) * PAGE, page * PAGE).map(e => (
          <div key={e.id} className="bg-white rounded-2xl p-3.5 shadow-sm">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-mono text-gray-500">{e.source}</span>
              <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${e.level === 'error' ? 'bg-red-50 text-red-600' : 'bg-amber-50 text-amber-600'}`}>
                {e.level === 'error' ? 'خطأ' : 'تحذير'}
              </span>
            </div>
            <p className="text-sm text-gray-800">{e.message}</p>
            <p className="text-[10px] text-gray-400 mt-1">{new Date(e.timestamp).toLocaleString('ar-SY')}</p>
          </div>
        ))}
        <div className="pt-1"><Pagination page={page} totalItems={filtered.length} pageSize={PAGE} onPageChange={setPage} /></div>
      </div>
    </div>
  );
};

export default ErrorLogPage;
