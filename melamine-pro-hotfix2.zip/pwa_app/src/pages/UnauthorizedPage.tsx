import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';

export const UnauthorizedPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  return (
    <div
      className="login-page flex flex-col items-center justify-center"
      style={{
        background: 'linear-gradient(135deg, #0f172a 0%, #3f0d0d 50%, #0f172a 100%)',
        padding: '24px',
      }}
      dir="rtl"
    >
      {/* Decorative */}
      <div style={{ position: 'fixed', top: '-80px', right: '-80px', width: '260px', height: '260px', borderRadius: '50%', background: 'rgba(239,68,68,0.08)', pointerEvents: 'none' }} />
      <div style={{ position: 'fixed', bottom: '-60px', left: '-60px', width: '200px', height: '200px', borderRadius: '50%', background: 'rgba(239,68,68,0.06)', pointerEvents: 'none' }} />

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, type: 'spring' }}
        style={{ textAlign: 'center', zIndex: 10 }}
      >
        {/* Shield Icon */}
        <motion.div
          animate={{ rotate: [0, -5, 5, -3, 3, 0] }}
          transition={{ duration: 0.6, delay: 0.4 }}
          style={{ marginBottom: '24px' }}
        >
          <div style={{
            width: '96px', height: '96px',
            background: 'rgba(239,68,68,0.15)',
            borderRadius: '28px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto',
            border: '2px solid rgba(239,68,68,0.3)',
          }}>
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              <line x1="12" y1="9" x2="12" y2="13"/>
              <circle cx="12" cy="16" r="0.5" fill="#ef4444"/>
            </svg>
          </div>
        </motion.div>

        {/* Text */}
        <h1 style={{ fontSize: '24px', fontWeight: 800, color: 'var(--border-color)', marginBottom: '10px' }}>
          غير مصرح بالوصول
        </h1>
        <p style={{ fontSize: '14px', color: 'var(--text-tertiary)', marginBottom: '8px', lineHeight: 1.6 }}>
          ليس لديك صلاحية للوصول إلى هذه الصفحة
        </p>

        {user && (
          <div style={{
            background: 'rgba(239,68,68,0.08)',
            border: '1px solid rgba(239,68,68,0.2)',
            borderRadius: '14px',
            padding: '12px 20px',
            marginBottom: '32px',
            display: 'inline-block',
          }}>
            <p style={{ fontSize: '13px', color: '#fca5a5' }}>
              مسجل الدخول كـ: <strong>{user.full_name}</strong>
            </p>
            <p style={{ fontSize: '11px', color: 'var(--text-tertiary)', marginTop: '2px' }}>
              الدور الحالي لا يملك صلاحية هذه الصفحة
            </p>
          </div>
        )}

        {/* Buttons */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxWidth: '280px', margin: '0 auto' }}>
          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={() => navigate('/')}
            style={{
              background: 'linear-gradient(135deg, #2563eb, #1d4ed8)',
              color: '#fff', border: 'none', borderRadius: '16px',
              padding: '14px 24px', fontSize: '15px', fontWeight: 700,
              cursor: 'pointer', fontFamily: 'inherit',
              boxShadow: '0 4px 20px rgba(37,99,235,0.4)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
            </svg>
            العودة للرئيسية
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={() => { logout(); navigate('/login'); }}
            style={{
              background: 'rgba(239,68,68,0.1)',
              color: '#fca5a5', border: '1px solid rgba(239,68,68,0.25)',
              borderRadius: '16px', padding: '13px 24px',
              fontSize: '14px', fontWeight: 600,
              cursor: 'pointer', fontFamily: 'inherit',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
            }}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            تسجيل الخروج
          </motion.button>
        </div>

        <p style={{ marginTop: '40px', fontSize: '11px', color: '#334155' }}>
          ميلامين برو · نظام إدارة المصنع
        </p>
      </motion.div>
    </div>
  );
};
