import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Calculator, Package, Zap, Users, TrendingUp,
  DollarSign, RefreshCw, ChevronDown, ChevronUp,
  Layers, Wrench, BarChart2, AlertCircle, CheckCircle,
  Coins, BarChart3, Scale, Sparkles, Save
} from 'lucide-react';
import { TotalCostIcon, BreakEvenIcon } from '../components/ui/StatusIcon';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAppData } from '../contexts/AppDataContext';
import { useAuth } from '../contexts/AuthContext';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';

// ── Types ────────────────────────────────────────────────────────────────────
interface CostComponent {
  key: string;
  label: string;
  icon: React.ReactNode;
  color: string;
  gradient: string;
  valueUSD: number;
  editable: boolean;
  description: string;
}

interface ProductSpec {
  thickness: string;
  size: string;
  finish: string;
  quantity: number;
}

// ── Constants ─────────────────────────────────────────────────────────────────
const THICKNESS_OPTIONS = ['8mm', '12mm', '16mm', '18mm', '25mm'];
const SIZE_OPTIONS = ['244x122 سم', '183x122 سم', '244x183 سم'];
const FINISH_OPTIONS = ['مطفي', 'لامع', 'خشبي', 'سادة'];

const THICKNESS_COST: Record<string, number> = {
  '8mm': 8, '12mm': 10, '16mm': 13, '18mm': 16, '25mm': 22
};

const FINISH_COST: Record<string, number> = {
  'مطفي': 2, 'لامع': 3.5, 'خشبي': 4, 'سادة': 1
};

const MARGIN_PRESETS = [
  { label: 'عادي',     value: 20, color: 'bg-blue-100 text-blue-700' },
  { label: 'متوسط',    value: 30, color: 'bg-emerald-100 text-emerald-700' },
  { label: 'مرتفع',    value: 40, color: 'bg-amber-100 text-amber-700' },
  { label: 'مميز',     value: 50, color: 'bg-purple-100 text-purple-700' },
];

const PIE_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EF4444'];

// ── Main Cost Page ────────────────────────────────────────────────────────────
export const CostPage: React.FC = () => {
  const { formatUSD, formatSYP, exchangeRate } = useCurrency();
  const { addJournalEntry, addNotification } = useAppData();
  const { user } = useAuth();
  const [savedToJournal, setSavedToJournal] = useState(false);

  const [spec, setSpec] = useState<ProductSpec>({
    thickness: '18mm',
    size: '244x122 سم',
    finish: 'مطفي',
    quantity: 100,
  });

  const [margin, setMargin] = useState(30);
  const [showBreakdown, setShowBreakdown] = useState(true);
  const [calculated, setCalculated] = useState(false);
  const [calculating, setCalculating] = useState(false);

  // ── Cost Calculation ──────────────────────────────────────────────────────
  const costs = useMemo<CostComponent[]>(() => {
    const rawMaterial = THICKNESS_COST[spec.thickness] + FINISH_COST[spec.finish];
    return [
      {
        key: 'raw_material',
        label: 'المواد الخام',
        icon: <Package size={14} />,
        color: 'text-blue-600',
        gradient: 'from-blue-500 to-indigo-600',
        valueUSD: rawMaterial,
        editable: true,
        description: 'لوح HDF + ورق ميلامين + راتنج',
      },
      {
        key: 'labor',
        label: 'العمالة',
        icon: <Users size={14} />,
        color: 'text-emerald-600',
        gradient: 'from-emerald-500 to-teal-600',
        valueUSD: 4.5,
        editable: true,
        description: 'رواتب العمال المباشرين',
      },
      {
        key: 'energy',
        label: 'الطاقة',
        icon: <Zap size={14} />,
        color: 'text-amber-600',
        gradient: 'from-amber-500 to-orange-600',
        valueUSD: 2.8,
        editable: true,
        description: 'كهرباء وغاز التشغيل',
      },
      {
        key: 'overhead',
        label: 'تكاليف عامة',
        icon: <Wrench size={14} />,
        color: 'text-purple-600',
        gradient: 'from-purple-500 to-violet-600',
        valueUSD: 3.2,
        editable: true,
        description: 'صيانة، إيجار، تأمين',
      },
      {
        key: 'packaging',
        label: 'التغليف',
        icon: <Layers size={14} />,
        color: 'text-rose-600',
        gradient: 'from-rose-500 to-pink-600',
        valueUSD: 1.5,
        editable: false,
        description: 'كرتون وتغليف',
      },
    ];
  }, [spec]);

  const [editableValues, setEditableValues] = useState<Record<string, number>>({});

  const getVal = (c: CostComponent) => editableValues[c.key] ?? c.valueUSD;

  const totalCostPerUnit = useMemo(() =>
    costs.reduce((sum, c) => sum + getVal(c), 0), [costs, editableValues]
  );

  const pricePerUnit = useMemo(() =>
    totalCostPerUnit * (1 + margin / 100), [totalCostPerUnit, margin]
  );

  const totalCost = totalCostPerUnit * spec.quantity;
  const totalRevenue = pricePerUnit * spec.quantity;
  const totalProfit = totalRevenue - totalCost;

  const pieData = costs.map(c => ({ name: c.label, value: Number(getVal(c).toFixed(2)) }));

  const comparisonData = THICKNESS_OPTIONS.map(t => {
    const rawMat = THICKNESS_COST[t] + FINISH_COST[spec.finish];
    const total = rawMat + 4.5 + 2.8 + 3.2 + 1.5;
    return {
      name: t,
      تكلفة: Number(total.toFixed(2)),
      سعر: Number((total * (1 + margin / 100)).toFixed(2)),
    };
  });

  const handleCalculate = () => {
    setCalculating(true);
    setTimeout(() => {
      setCalculating(false);
      setCalculated(true);
    }, 1200);
  };

  const handleSaveToJournal = () => {
    addJournalEntry({
      entry_number: `COST-${Date.now().toString().slice(-6)}`,
      type: 'expense',
      category: 'تكاليف إنتاج',
      description: `تكلفة إنتاج: ${spec.thickness} ${spec.finish} ${spec.size} × ${spec.quantity} لوح`,
      amount_usd: totalCost,
      amount_syp: totalCost * exchangeRate,
      currency: 'USD',
      payment_method: 'cash',
      created_by: user?.full_name || 'النظام',
      entry_date: new Date().toISOString().split('T')[0],
    });
    addNotification({
      title: 'تكاليف مُسجَّلة',
      message: `تم تسجيل تكلفة ${formatUSD(totalCost)} في السجل المحاسبي`,
      type: 'success',
      role_target: 'accountant',
    });
    setSavedToJournal(true);
    setTimeout(() => setSavedToJournal(false), 3000);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-28" dir="rtl">
      {/* Hero Header */}
      <div className="bg-gradient-to-br from-slate-800 via-blue-900 to-indigo-900 px-4 pt-6 pb-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(99,102,241,0.3),transparent_60%)]" />
        <div className="relative">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center">
              <Calculator size={18} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-black text-white">حاسبة التكاليف والتسعير</h1>
              <p className="text-blue-200 text-xs">احسب تكلفة الإنتاج وسعر البيع بدقة</p>
            </div>
          </div>

          {/* Quick KPIs */}
          {calculated && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-3 gap-2"
            >
              {[
                { label: 'تكلفة الوحدة', value: formatUSD(totalCostPerUnit), sub: formatSYP(totalCostPerUnit * exchangeRate), color: 'border-blue-400/40' },
                { label: 'سعر البيع',    value: formatUSD(pricePerUnit),     sub: formatSYP(pricePerUnit * exchangeRate),     color: 'border-emerald-400/40' },
                { label: 'هامش الربح',  value: `${margin}%`,                sub: formatUSD(pricePerUnit - totalCostPerUnit), color: 'border-amber-400/40' },
              ].map(s => (
                <div key={s.label} className={`bg-white/10 border ${s.color} rounded-xl p-3 text-center backdrop-blur-sm`}>
                  <p className="text-xs text-white/60 mb-1">{s.label}</p>
                  <p className="text-base font-black text-white">{s.value}</p>
                  <p className="text-[10px] text-white/50">{s.sub}</p>
                </div>
              ))}
            </motion.div>
          )}
        </div>
      </div>

      <div className="px-4 -mt-4 space-y-4">
        {/* Product Specs Card */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-lg overflow-hidden">
          <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
            <Package size={15} className="text-blue-600" />
            <h2 className="text-sm font-black text-gray-700">مواصفات المنتج</h2>
          </div>
          <div className="p-4 space-y-4">
            {/* Thickness */}
            <div>
              <label className="text-xs font-bold text-gray-600 mb-2 block">السماكة</label>
              <div className="flex gap-2 flex-wrap">
                {THICKNESS_OPTIONS.map(t => (
                  <motion.button
                    key={t}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => { setSpec(s => ({ ...s, thickness: t })); setCalculated(false); }}
                    className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all ${
                      spec.thickness === t
                        ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-200'
                        : 'bg-gray-50 text-gray-600 border-gray-200'
                    }`}
                  >
                    {t}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Finish */}
            <div>
              <label className="text-xs font-bold text-gray-600 mb-2 block">نوع السطح</label>
              <div className="grid grid-cols-4 gap-2">
                {FINISH_OPTIONS.map(f => (
                  <motion.button
                    key={f}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => { setSpec(s => ({ ...s, finish: f })); setCalculated(false); }}
                    className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                      spec.finish === f
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-gray-50 text-gray-600 border-gray-200'
                    }`}
                  >
                    {f}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Size */}
            <div>
              <label className="text-xs font-bold text-gray-600 mb-2 block">المقاس</label>
              <div className="space-y-2">
                {SIZE_OPTIONS.map(s => (
                  <motion.button
                    key={s}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => { setSpec(prev => ({ ...prev, size: s })); setCalculated(false); }}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border text-sm transition-all ${
                      spec.size === s
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-700 font-bold'
                        : 'bg-gray-50 border-gray-200 text-gray-600'
                    }`}
                  >
                    <span>{s}</span>
                    {spec.size === s && <CheckCircle size={15} className="text-emerald-600" />}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div>
              <label className="text-xs font-bold text-gray-600 mb-2 block">الكمية (لوح)</label>
              <div className="flex items-center gap-3">
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setSpec(s => ({ ...s, quantity: Math.max(1, s.quantity - 10) }))}
                  className="w-11 h-11 bg-gray-100 rounded-xl flex items-center justify-center text-gray-600 font-bold text-lg"
                >
                  −
                </motion.button>
                <input
                  type="number"
                  value={spec.quantity}
                  onChange={e => setSpec(s => ({ ...s, quantity: Math.max(1, Number(e.target.value)) }))}
                  className="flex-1 text-center py-3 bg-gray-50 border border-gray-200 rounded-xl text-base font-black text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setSpec(s => ({ ...s, quantity: s.quantity + 10 }))}
                  className="w-11 h-11 bg-gray-100 rounded-xl flex items-center justify-center text-gray-600 font-bold text-lg"
                >
                  +
                </motion.button>
              </div>
              {/* Quick quantity buttons */}
              <div className="flex gap-2 mt-2">
                {[50, 100, 200, 500].map(q => (
                  <button
                    key={q}
                    onClick={() => setSpec(s => ({ ...s, quantity: q }))}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      spec.quantity === q ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-500'
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Cost Breakdown */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-lg overflow-hidden">
          <button
            onClick={() => setShowBreakdown(!showBreakdown)}
            className="w-full bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <BarChart2 size={15} className="text-purple-600" />
              <h2 className="text-sm font-black text-gray-700">تفاصيل عناصر التكلفة</h2>
            </div>
            {showBreakdown ? <ChevronUp size={15} className="text-gray-400" /> : <ChevronDown size={15} className="text-gray-400" />}
          </button>

          <AnimatePresence>
            {showBreakdown && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="p-4 space-y-3">
                  {costs.map((cost, i) => {
                    const val = getVal(cost);
                    const pct = totalCostPerUnit > 0 ? (val / totalCostPerUnit) * 100 : 0;
                    return (
                      <motion.div
                        key={cost.key}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.06 }}
                        className="flex items-center gap-3"
                      >
                        <div className={`w-9 h-9 bg-gradient-to-br ${cost.gradient} rounded-xl flex items-center justify-center text-white shrink-0`}>
                          {cost.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-bold text-gray-700">{cost.label}</span>
                            <span className={`text-xs font-black ${cost.color}`}>${val.toFixed(2)}</span>
                          </div>
                          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${pct}%` }}
                              transition={{ delay: i * 0.06 + 0.2, duration: 0.6, ease: 'easeOut' }}
                              className={`h-full bg-gradient-to-r ${cost.gradient} rounded-full`}
                            />
                          </div>
                          <p className="text-[10px] text-gray-400 mt-0.5">{pct.toFixed(1)}% • {cost.description}</p>
                        </div>
                        {cost.editable && (
                          <input
                            type="number"
                            value={val}
                            onChange={e => setEditableValues(prev => ({ ...prev, [cost.key]: Number(e.target.value) }))}
                            className="w-16 text-center py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                            step="0.5"
                          />
                        )}
                      </motion.div>
                    );
                  })}

                  {/* Total */}
                  <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between">
                    <span className="text-sm font-black text-gray-800">إجمالي تكلفة الوحدة</span>
                    <div className="text-left">
                      <span className="text-lg font-black text-blue-600">{formatUSD(totalCostPerUnit)}</span>
                      <p className="text-xs text-gray-400">{formatSYP(totalCostPerUnit * exchangeRate)}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Margin & Pricing */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-lg overflow-hidden">
          <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
            <TrendingUp size={15} className="text-emerald-600" />
            <h2 className="text-sm font-black text-gray-700">هامش الربح والتسعير</h2>
          </div>
          <div className="p-4 space-y-4">
            {/* Margin Presets */}
            <div>
              <label className="text-xs font-bold text-gray-600 mb-2 block">هامش الربح المقترح</label>
              <div className="grid grid-cols-4 gap-2">
                {MARGIN_PRESETS.map(p => (
                  <motion.button
                    key={p.value}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setMargin(p.value)}
                    className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${
                      margin === p.value ? p.color + ' border-current ring-2 ring-offset-1 ring-current' : 'bg-gray-50 text-gray-500 border-gray-200'
                    }`}
                  >
                    <span className="block font-black">{p.value}%</span>
                    <span className="text-[10px]">{p.label}</span>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Custom Margin Slider */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-gray-600">هامش مخصص</label>
                <span className="text-lg font-black text-emerald-600">{margin}%</span>
              </div>
              <input
                type="range"
                min={5}
                max={100}
                value={margin}
                onChange={e => setMargin(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-full appearance-none cursor-pointer"
                style={{ accentColor: '#10B981' }}
              />
              <div className="flex justify-between text-xs text-gray-400 mt-1">
                <span>5%</span>
                <span>100%</span>
              </div>
            </div>

            {/* Price Preview */}
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-emerald-600 mb-1">سعر بيع الوحدة</p>
                  <p className="text-2xl font-black text-emerald-700">{formatUSD(pricePerUnit)}</p>
                  <p className="text-xs text-emerald-500">{formatSYP(pricePerUnit * exchangeRate)}</p>
                </div>
                <div>
                  <p className="text-xs text-emerald-600 mb-1">ربح الوحدة</p>
                  <p className="text-2xl font-black text-emerald-700">{formatUSD(pricePerUnit - totalCostPerUnit)}</p>
                  <p className="text-xs text-emerald-500">هامش {margin}%</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Calculate Button */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={handleCalculate}
          disabled={calculating}
          className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-lg rounded-3xl shadow-xl shadow-blue-200 disabled:opacity-60 flex items-center justify-center gap-3"
        >
          {calculating ? (
            <><div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin" style={{ borderWidth: 3 }} /> جاري الحساب...</>
          ) : (
            <><Calculator size={20} /> احسب التكاليف الكاملة</>
          )}
        </motion.button>

        {/* Results Section */}
        <AnimatePresence>
          {calculated && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              {/* Summary Cards */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  {
                    label: 'إجمالي التكلفة',
                    value: formatUSD(totalCost),
                    sub: `${spec.quantity} لوح × ${formatUSD(totalCostPerUnit)}`,
                    icon: <DollarSign size={22} className="text-white" />,
                    bg: 'from-blue-500 to-indigo-600',
                  },
                  {
                    label: 'إجمالي الإيراد',
                    value: formatUSD(totalRevenue),
                    sub: `${spec.quantity} لوح × ${formatUSD(pricePerUnit)}`,
                    icon: <TrendingUp size={22} className="text-white" />,
                    bg: 'from-emerald-500 to-teal-600',
                  },
                  {
                    label: 'إجمالي الربح',
                    value: formatUSD(totalProfit),
                    sub: `هامش ${margin}% • ${formatSYP(totalProfit * exchangeRate)}`,
                    icon: <Sparkles size={22} className="text-white" />,
                    bg: 'from-amber-500 to-orange-600',
                  },
                  {
                    label: 'نقطة التعادل',
                    value: `${Math.ceil(totalCost / pricePerUnit)} لوح`,
                    sub: 'الحد الأدنى للبيع بلا خسارة',
                    icon: <Scale size={22} className="text-white" />,
                    bg: 'from-purple-500 to-violet-600',
                  },
                ].map(s => (
                  <div key={s.label} className={`bg-gradient-to-br ${s.bg} rounded-2xl p-4 text-white`}>
                    <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center mb-3">{s.icon}</div>
                    <p className="text-lg font-black leading-tight">{s.value}</p>
                    <p className="text-white/60 text-[10px] mt-1 leading-tight">{s.sub}</p>
                    <p className="text-white/80 text-xs mt-1.5">{s.label}</p>
                  </div>
                ))}
              </div>

              {/* Pie Chart */}
              <div className="bg-white rounded-3xl border border-gray-100 shadow-lg p-4">
                <h3 className="text-sm font-black text-gray-700 mb-3 flex items-center gap-2">
                  <BarChart2 size={14} className="text-blue-600" />
                  توزيع عناصر التكلفة
                </h3>
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={75}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {pieData.map((_, i) => (
                        <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: unknown) => [`$${v}`, '']} contentStyle={{ fontSize: 11, borderRadius: 8, border: 'none' }} />
                    <Legend iconType="circle" iconSize={8} formatter={(value) => <span style={{ fontSize: 10 }}>{value}</span>} />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Comparison Chart */}
              <div className="bg-white rounded-3xl border border-gray-100 shadow-lg p-4">
                <h3 className="text-sm font-black text-gray-700 mb-3 flex items-center gap-2">
                  <BarChart2 size={14} className="text-purple-600" />
                  مقارنة التكاليف حسب السماكة
                </h3>
                <ResponsiveContainer width="100%" height={160}>
                  <BarChart data={comparisonData} barSize={18} barGap={4}>
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{ fontSize: 11, borderRadius: 8, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                      formatter={(v: unknown) => [`$${v}`, '']}
                    />
                    <Bar dataKey="تكلفة" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="سعر"   fill="#10B981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
                <div className="flex gap-4 justify-center mt-2">
                  <div className="flex items-center gap-1.5 text-xs text-gray-500">
                    <div className="w-3 h-3 rounded-sm bg-blue-500" /> التكلفة
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-gray-500">
                    <div className="w-3 h-3 rounded-sm bg-emerald-500" /> سعر البيع
                  </div>
                </div>
              </div>

              {/* Profitability Tip */}
              <div className={`rounded-2xl p-4 border flex items-start gap-3 ${
                margin >= 30
                  ? 'bg-emerald-50 border-emerald-200'
                  : 'bg-amber-50 border-amber-200'
              }`}>
                {margin >= 30
                  ? <CheckCircle size={18} className="text-emerald-600 shrink-0 mt-0.5" />
                  : <AlertCircle size={18} className="text-amber-600 shrink-0 mt-0.5" />
                }
                <div>
                  <p className={`text-sm font-bold ${margin >= 30 ? 'text-emerald-700' : 'text-amber-700'}`}>
                    {margin >= 30 ? 'هامش ربح جيد' : 'هامش ربح منخفض'}
                  </p>
                  <p className={`text-xs mt-0.5 ${margin >= 30 ? 'text-emerald-600' : 'text-amber-600'}`}>
                    {margin >= 30
                      ? `الربح الصافي ${formatUSD(totalProfit)} لـ ${spec.quantity} لوح • يُنصح بهامش لا يقل عن 25%`
                      : `هامش ${margin}% قد لا يغطي التكاليف غير المباشرة • يُنصح بزيادة الهامش إلى 30%`
                    }
                  </p>
                </div>
              </div>

              {/* Save to Journal Button */}
              <div className="pb-4">
                {savedToJournal ? (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                    className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center gap-3"
                  >
                    <CheckCircle size={20} className="text-emerald-500 shrink-0" />
                    <div>
                      <p className="text-emerald-700 font-bold text-sm">تم الحفظ في السجل المحاسبي</p>
                      <p className="text-emerald-600 text-xs mt-0.5">يمكنك مراجعته في صفحة السجل اليومي</p>
                    </div>
                  </motion.div>
                ) : (
                  <button onClick={handleSaveToJournal}
                    className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl font-bold text-sm shadow-lg shadow-blue-200 active:scale-95 transition-all flex items-center justify-center gap-2"
                  >
                    <Save size={16} />
                    حفظ التكاليف في السجل المحاسبي
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
