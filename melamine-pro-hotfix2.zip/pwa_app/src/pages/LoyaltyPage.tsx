import React, { useMemo, useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Flame, Star, Award, TrendingUp, Gift, Settings as SettingsIcon, Crown, Medal } from 'lucide-react';
import { toast } from 'sonner';
import { useAppData } from '../contexts/AppDataContext';
import { useAuth } from '../contexts/AuthContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { EmptyState } from '../components/ui/EmptyState';
import { resolveWorkerName, resolveWorkerRole, resolveWorkerRoleKey } from '../lib/workers';
import { Avatar } from '../components/ui/Avatar';
import {
  computeWorkerLoyalty, computeLeaderboard, getLoyaltyConfig, setLoyaltyConfig,
  getRedeemed, setRedeemed, unredeemed, DEFAULT_LOYALTY_CONFIG,
  monthlyChampion, detectTierUp,
  type LoyaltyConfig, type WorkerLoyalty,
} from '../utils/loyalty';

const RANK_ICON = [Crown, Medal, Award];
const RANK_COLOR = ['#f59e0b', '#9ca3af', '#cd7f32'];

export const LoyaltyPage: React.FC = () => {
  const { attendanceRecords, employees, addBonus, addNotification } = useAppData();
  const { user, hasRole } = useAuth();
  const { format } = useCurrency();

  const canManage = hasRole(['admin', 'manager']);
  const canViewBoard = hasRole(['admin', 'manager', 'hr']);
  const isAdmin = hasRole(['admin']);

  const [cfg, setCfg] = useState<LoyaltyConfig>(getLoyaltyConfig());
  const [showCfg, setShowCfg] = useState(false);
  const [tick, setTick] = useState(0); // force recompute after redeem

  const workerIds = useMemo(() => {
    const ids = new Set<string>(employees.map(e => e.user_id));
    attendanceRecords.forEach(r => ids.add(r.worker_id));
    return Array.from(ids);
  }, [employees, attendanceRecords]);

  const mine = useMemo(
    () => (user ? computeWorkerLoyalty(user.id, attendanceRecords, cfg) : null),
    [user, attendanceRecords, cfg, tick],
  );

  const board = useMemo(
    () => (canViewBoard ? computeLeaderboard(attendanceRecords, workerIds, cfg) : []),
    [canViewBoard, attendanceRecords, workerIds, cfg, tick],
  );

  const champion = useMemo(
    () => monthlyChampion(attendanceRecords, workerIds, undefined, cfg),
    [attendanceRecords, workerIds, cfg],
  );

  // Congratulate workers who climbed to a new tier (fires once per upgrade).
  useEffect(() => {
    const full = computeLeaderboard(attendanceRecords, workerIds, cfg);
    for (const w of full) {
      const up = detectTierUp(w.workerId, w.tier.name, cfg);
      if (up) {
        addNotification({
          title: 'ترقية مستوى الولاء 🎉',
          message: `${resolveWorkerName(w.workerId, employees)} وصل إلى المستوى ${w.tier.icon} ${up}!`,
          type: 'success',
          role_target: 'worker',
          target_user_id: w.workerId,
        });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attendanceRecords, workerIds]);

  const redeem = (w: WorkerLoyalty) => {
    const pts = unredeemed(w.workerId, w.totalPoints);
    if (pts <= 0) { toast.error('لا توجد نقاط غير مصروفة'); return; }
    const amount = Math.round(pts * cfg.pointValueUsd * 100) / 100;
    if (amount <= 0) { toast.error('قيمة المكافأة صفر'); return; }
    addBonus(w.workerId, amount, `مكافأة الالتزام بالحضور (${pts} نقطة)`);
    setRedeemed(w.workerId, w.totalPoints);
    setTick(t => t + 1);
    toast.success(`تم صرف مكافأة ${format(amount)} لـ ${resolveWorkerName(w.workerId, employees)}`);
  };

  const saveCfg = () => { setLoyaltyConfig(cfg); setShowCfg(false); toast.success('تم حفظ إعدادات النقاط'); };

  return (
    <div className="min-h-full" dir="rtl" style={{ background: 'var(--surface-secondary)' }}>
      {/* Hero */}
      <div className="px-5 pt-6 pb-7 text-white" style={{ background: 'linear-gradient(135deg,#f59e0b,#d97706)' }}>
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white/15 flex items-center justify-center">
            <Trophy size={22} />
          </div>
          <div>
            <h1 className="text-lg font-extrabold">نقاط الولاء والمكافآت</h1>
            <p className="text-xs text-white/80">كافئ الالتزام بالحضور والانضباط</p>
          </div>
          {isAdmin && (
            <button onClick={() => setShowCfg(s => !s)} className="mr-auto w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center" aria-label="إعدادات النقاط">
              <SettingsIcon size={18} />
            </button>
          )}
        </div>
      </div>

      {/* My points card */}
      {mine && (
        <div className="px-4 -mt-4">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            style={{ background: 'var(--surface)', border: '1px solid var(--border-color)', borderRadius: 20, padding: 18 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 12, color: 'var(--text-tertiary)', fontWeight: 600 }}>نقاطي</div>
                <div style={{ fontSize: 32, fontWeight: 900, color: 'var(--text-primary)', lineHeight: 1.1 }}>{mine.totalPoints}</div>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>≈ مكافأة {format(mine.rewardUsd)}</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 34 }}>{mine.tier.icon}</div>
                <div style={{ fontSize: 13, fontWeight: 800, color: mine.tier.color }}>{mine.tier.name}</div>
              </div>
            </div>

            {/* progress to next tier */}
            {mine.nextTier && (
              <div style={{ marginBottom: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10.5, color: 'var(--text-tertiary)', marginBottom: 4 }}>
                  <span>المستوى التالي: {mine.nextTier.name}</span>
                  <span>باقٍ {mine.toNextTier} نقطة</span>
                </div>
                <div style={{ height: 8, borderRadius: 999, background: 'var(--surface-tertiary)', overflow: 'hidden' }}>
                  <div style={{ height: '100%', borderRadius: 999, background: `linear-gradient(90deg,${mine.tier.color},#fbbf24)`,
                    width: `${Math.min(100, (mine.totalPoints / mine.nextTier.min) * 100)}%` }} />
                </div>
              </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginBottom: mine.badges.length ? 14 : 0 }}>
              <Stat icon={<Flame size={15} style={{ color: '#ef4444' }} />} label="سلسلة حالية" value={`${mine.currentStreak} يوم`} />
              <Stat icon={<TrendingUp size={15} style={{ color: '#10b981' }} />} label="أطول سلسلة" value={`${mine.longestStreak} يوم`} />
              <Stat icon={<Star size={15} style={{ color: '#f59e0b' }} />} label="حضور" value={`${mine.counts.present + mine.counts.late}/${mine.counts.total}`} />
            </div>

            {mine.badges.length > 0 && (
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {mine.badges.map(b => (
                  <span key={b.id} style={{ fontSize: 11, fontWeight: 700, padding: '5px 10px', borderRadius: 999,
                    background: 'var(--surface-tertiary)', color: 'var(--text-secondary)' }}>
                    {b.icon} {b.label}
                  </span>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      )}

      {/* Employee of the month */}
      {canViewBoard && champion && (
        <div className="px-4 mt-4">
          <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }}
            style={{ borderRadius: 20, padding: 18, color: '#fff', position: 'relative', overflow: 'hidden',
              background: 'linear-gradient(135deg,#b45309,#f59e0b 55%,#fbbf24)' }}>
            <div style={{ position: 'absolute', top: -18, left: -10, fontSize: 96, opacity: 0.18 }}>👑</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12, position: 'relative' }}>
              <Crown size={18} />
              <span style={{ fontSize: 13, fontWeight: 800 }}>عامل الشهر</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'relative', gap: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
                <Avatar
                  userId={champion.workerId}
                  name={resolveWorkerName(champion.workerId, employees)}
                  role={resolveWorkerRoleKey(champion.workerId, employees)}
                  size={52}
                  radius={16}
                  style={{ border: '2px solid rgba(255,255,255,0.55)', boxShadow: '0 4px 12px rgba(0,0,0,0.18)' }}
                />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 20, fontWeight: 900, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {resolveWorkerName(champion.workerId, employees)}
                  </div>
                  <div style={{ fontSize: 11.5, opacity: 0.9 }}>{resolveWorkerRole(champion.workerId, employees)}</div>
                  <div style={{ fontSize: 11.5, opacity: 0.9, marginTop: 4 }}>
                    🔥 سلسلة {champion.currentStreak} يوم • حضور {champion.counts.present + champion.counts.late}/{champion.counts.total}
                  </div>
                </div>
              </div>
              <div style={{ textAlign: 'center', flexShrink: 0 }}>
                <div style={{ fontSize: 30, fontWeight: 900, lineHeight: 1 }}>{champion.totalPoints}</div>
                <div style={{ fontSize: 10, opacity: 0.9 }}>نقطة هذا الشهر</div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Admin config */}
      {isAdmin && showCfg && (
        <div className="px-4 mt-4">
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border-color)', borderRadius: 16, padding: 16 }}>
            <p style={{ fontSize: 13, fontWeight: 800, color: 'var(--text-primary)', marginBottom: 12 }}>إعدادات النقاط</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <NumField label="حضور كامل" value={cfg.points.present} onChange={v => setCfg(c => ({ ...c, points: { ...c.points, present: v } }))} />
              <NumField label="تأخّر" value={cfg.points.late} onChange={v => setCfg(c => ({ ...c, points: { ...c.points, late: v } }))} />
              <NumField label="نصف يوم" value={cfg.points.halfDay} onChange={v => setCfg(c => ({ ...c, points: { ...c.points, halfDay: v } }))} />
              <NumField label="غياب" value={cfg.points.absent} onChange={v => setCfg(c => ({ ...c, points: { ...c.points, absent: v } }))} />
              <NumField label="مكافأة الأسبوع" value={cfg.weekStreakBonus} onChange={v => setCfg(c => ({ ...c, weekStreakBonus: v }))} />
              <NumField label="مكافأة الشهر" value={cfg.monthStreakBonus} onChange={v => setCfg(c => ({ ...c, monthStreakBonus: v }))} />
              <NumField label="قيمة النقطة ($)" value={cfg.pointValueUsd} step="0.01" onChange={v => setCfg(c => ({ ...c, pointValueUsd: v }))} />
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
              <button onClick={() => setCfg(DEFAULT_LOYALTY_CONFIG)}
                style={{ flex: 1, padding: '10px', borderRadius: 10, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>
                استعادة الافتراضي
              </button>
              <button onClick={saveCfg}
                style={{ flex: 2, padding: '10px', borderRadius: 10, border: 'none', background: 'linear-gradient(135deg,#f59e0b,#d97706)', color: '#fff', fontSize: 12, fontWeight: 800, cursor: 'pointer' }}>
                حفظ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Leaderboard */}
      {canViewBoard && (
        <div className="px-4 mt-5 pb-24">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <Trophy size={16} style={{ color: '#f59e0b' }} />
            <span style={{ fontSize: 14, fontWeight: 800, color: 'var(--text-primary)' }}>لوحة الصدارة</span>
          </div>

          {board.length === 0 ? (
            <EmptyState compact icon={Trophy} title="لا توجد بيانات حضور بعد" description="ستظهر نقاط العمّال فور تسجيل الحضور." />
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {board.map((w, i) => {
                const RankIcon = i < 3 ? RANK_ICON[i] : null;
                const pendingPts = unredeemed(w.workerId, w.totalPoints);
                const pendingUsd = Math.round(pendingPts * cfg.pointValueUsd * 100) / 100;
                return (
                  <motion.div key={w.workerId} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}
                    style={{ background: 'var(--surface)', border: '1px solid var(--border-color)', borderRadius: 14, padding: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{ width: 30, textAlign: 'center', flexShrink: 0 }}>
                      {RankIcon ? <RankIcon size={20} style={{ color: RANK_COLOR[i] }} /> : <span style={{ fontSize: 14, fontWeight: 800, color: 'var(--text-tertiary)' }}>{i + 1}</span>}
                    </div>
                    <Avatar
                      userId={w.workerId}
                      name={resolveWorkerName(w.workerId, employees)}
                      role={resolveWorkerRoleKey(w.workerId, employees)}
                      size={38}
                      radius={12}
                    />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 800, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {resolveWorkerName(w.workerId, employees)}
                      </div>
                      <div style={{ fontSize: 10.5, color: 'var(--text-tertiary)' }}>
                        {w.tier.icon} {w.tier.name} • 🔥 {w.currentStreak} يوم • حضور {w.counts.present + w.counts.late}/{w.counts.total}
                      </div>
                    </div>
                    <div style={{ textAlign: 'left', flexShrink: 0 }}>
                      <div style={{ fontSize: 16, fontWeight: 900, color: 'var(--text-primary)' }}>{w.totalPoints}</div>
                      <div style={{ fontSize: 9.5, color: 'var(--text-tertiary)' }}>نقطة</div>
                    </div>
                    {canManage && (
                      <button onClick={() => redeem(w)} disabled={pendingPts <= 0}
                        style={{ flexShrink: 0, padding: '8px 10px', borderRadius: 10, border: 'none', cursor: pendingPts > 0 ? 'pointer' : 'not-allowed',
                          background: pendingPts > 0 ? '#10b981' : 'var(--surface-tertiary)', color: pendingPts > 0 ? '#fff' : 'var(--text-tertiary)',
                          fontSize: 11, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 4 }}>
                        <Gift size={13} /> {pendingPts > 0 ? format(pendingUsd) : 'مصروفة'}
                      </button>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}

          <p style={{ fontSize: 10.5, color: 'var(--text-tertiary)', textAlign: 'center', marginTop: 14, lineHeight: 1.7 }}>
            النقاط مكافأة تشجيعية فوق الأجر. الإجازة الموافَق عليها لا تكسر السلسلة، والغياب فقط هو ما يصفّرها.
            عند الصرف تُضاف المكافأة إلى محفظة العامل تلقائياً.
          </p>
        </div>
      )}
    </div>
  );
};

const Stat: React.FC<{ icon: React.ReactNode; label: string; value: string }> = ({ icon, label, value }) => (
  <div style={{ background: 'var(--surface-secondary)', borderRadius: 12, padding: 10, textAlign: 'center' }}>
    <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 4 }}>{icon}</div>
    <div style={{ fontSize: 13, fontWeight: 800, color: 'var(--text-primary)' }}>{value}</div>
    <div style={{ fontSize: 9.5, color: 'var(--text-tertiary)' }}>{label}</div>
  </div>
);

const NumField: React.FC<{ label: string; value: number; step?: string; onChange: (v: number) => void }> = ({ label, value, step, onChange }) => (
  <div>
    <label style={{ fontSize: 10.5, color: 'var(--text-tertiary)', fontWeight: 600, display: 'block', marginBottom: 4 }}>{label}</label>
    <input type="number" value={value} step={step} onChange={e => onChange(parseFloat(e.target.value) || 0)}
      style={{ width: '100%', padding: '8px 10px', borderRadius: 10, border: '1.5px solid var(--border-color)', background: 'var(--surface-secondary)', color: 'var(--text-primary)', fontSize: 13, outline: 'none', boxSizing: 'border-box' }} />
  </div>
);

export default LoyaltyPage;
