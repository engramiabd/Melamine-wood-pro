import React, { useState, useMemo } from 'react';
import {
  TrendingUp, TrendingDown, DollarSign, ShoppingCart,
  Download, BarChart2, PieChartIcon, ArrowUpRight, ArrowDownRight,
  Award, Package, RefreshCw, Users, Target, Percent
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip,
  BarChart, Bar, CartesianGrid, PieChart, Pie, Cell,
  LineChart, Line, Legend
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAppData } from '../contexts/AppDataContext';
import { Card, CardBody, CardHeader } from '../components/ui/Card';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4'];

const CustomTooltip = ({ active, payload, label }: {
  active?: boolean;
  payload?: Array<{ value: number; name: string; color: string }>;
  label?: string;
}) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-gray-900 rounded-xl p-3 shadow-xl text-white text-xs min-w-[140px]" dir="rtl">
      <p className="text-gray-400 mb-1.5 font-medium">{label}</p>
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2 mb-0.5">
          <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-gray-300">{p.name}:</span>
          <span className="font-bold">{typeof p.value === 'number' && p.value > 100 ? `$${p.value.toLocaleString()}` : p.value}</span>
        </div>
      ))}
    </div>
  );
};

export const SalesPanel: React.FC = () => {
  const { format, toggleCurrency, currency } = useCurrency();
  const { orders, products } = useAppData();
  const [period, setPeriod] = useState<'week' | 'month' | 'year'>('month');
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'customers'>('overview');
  const [isExporting, setIsExporting] = useState(false);

  // Compute real revenue data from orders
  // Only completed orders count as real revenue
  const completedOrders = useMemo(() => orders.filter(o => o.status === 'completed'), [orders]);

  const totalRevenue = useMemo(() => completedOrders.reduce((s, o) => s + o.total_usd, 0), [completedOrders]);
  const totalOrderCount = completedOrders.length;
  const avgOrderValue = totalOrderCount > 0 ? totalRevenue / totalOrderCount : 0;

  // Monthly revenue data from real orders
  const monthlyData = useMemo(() => {
    const months: Record<string, { revenue: number; orders: number; target: number }> = {};

    const mnNames = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    completedOrders.forEach(o => {
      const d = new Date(o.created_at);
      const key = mnNames[d.getMonth()];
      if (!months[key]) months[key] = { revenue: 0, orders: 0, target: 35000 };
      months[key].revenue += o.total_usd;
      months[key].orders += 1;
    });

    // Build chart data from real orders grouped by month
    const monthNames = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    const lastMonths = period === 'week' ? 1 : period === 'month' ? 6 : 12;
    return monthNames.slice(-lastMonths).map(name => ({
      name,
      month: name,
      revenue: months[name]?.revenue || 0,
      orders: months[name]?.orders || 0,
      target: 35000,
      expenses: 0,
    }));
  }, [completedOrders, period]);

  const revenueGrowth = useMemo(() => {
    if (monthlyData.length < 2) return 0;
    const cur = monthlyData[monthlyData.length - 1].revenue;
    const prev = monthlyData[monthlyData.length - 2].revenue;
    return prev > 0 ? ((cur - prev) / prev) * 100 : 0;
  }, [monthlyData]);

  // Product sales analysis from real orders
  const productSalesData = useMemo(() => {
    const productMap: Record<string, { name: string; sold: number; revenue: number }> = {};
    completedOrders.forEach(o => {
      o.items.forEach(item => {
        const key = item.product?.name || item.product_id;
        if (!productMap[key]) productMap[key] = { name: key, sold: 0, revenue: 0 };
        productMap[key].sold += item.quantity;
        productMap[key].revenue += item.total_usd;
      });
    });
    return Object.values(productMap)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5)
      .map((p, i) => ({ ...p, color: COLORS[i] }));
  }, [completedOrders]);

  // Customer analysis from real orders
  const customerData = useMemo(() => {
    const custMap: Record<string, { name: string; orders: number; revenue: number; phone?: string }> = {};
    completedOrders.forEach(o => {
      if (!custMap[o.customer_name]) custMap[o.customer_name] = { name: o.customer_name, orders: 0, revenue: 0, phone: o.customer_phone };
      custMap[o.customer_name].orders += 1;
      custMap[o.customer_name].revenue += o.total_usd;
    });
    const list = Object.values(custMap)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 8);
    // Real, deterministic signal: how far each customer's revenue sits above or
    // below the average of the top customers (replaces the old random value).
    const avgRev = list.reduce((s, c) => s + c.revenue, 0) / Math.max(list.length, 1);
    return list.map((c) => ({ ...c, growth: avgRev > 0 ? Math.round((c.revenue / avgRev - 1) * 100) : 0 }));
  }, [completedOrders]);

  // Finish distribution from real products
  const finishDistribution = useMemo(() => {
    const finishMap: Record<string, number> = {};
    completedOrders.forEach(o => {
      o.items.forEach(item => {
        const finish = (item as any).finish || 'مطفي';
        finishMap[finish] = (finishMap[finish] || 0) + item.quantity;
      });
    });
    const total = Object.values(finishMap).reduce((s, v) => s + v, 0);
    return Object.entries(finishMap).map(([name, val], i) => ({
      name, value: total > 0 ? Math.round((val / total) * 100) : 0, color: COLORS[i]
    })).filter(d => d.value > 0);
  }, [completedOrders]);

  // Weekly data
  const weeklyData = useMemo(() => {
    const days = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
    const dayMap: Record<string, { revenue: number; orders: number }> = {};
    days.forEach(d => { dayMap[d] = { revenue: 0, orders: 0 }; });

    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 86400000);
    completedOrders
      .filter(o => new Date(o.created_at) >= weekAgo)
      .forEach(o => {
        const d = new Date(o.created_at);
        const dayName = days[d.getDay()];
        dayMap[dayName].revenue += o.total_usd;
        dayMap[dayName].orders += 1;
      });

    return days.map(day => ({ day, ...dayMap[day] }));
  }, [completedOrders]);

  const handleExport = () => {
    setIsExporting(true);
    const data = completedOrders.map(o => ({
      رقم_الطلب: o.order_number,
      العميل: o.customer_name,
      الإجمالي: o.total_usd,
      التاريخ: o.created_at,
    }));
    const csv = [Object.keys(data[0] || {}).join(','), ...data.map(r => Object.values(r).join(','))].join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'sales-report.csv'; a.click();
    URL.revokeObjectURL(url);
    setTimeout(() => setIsExporting(false), 2000);
  };

  const currentMonthData = monthlyData[monthlyData.length - 1] || { revenue: 0, orders: 0, target: 0 };
  const targetAchievement = currentMonthData.target > 0 ? Math.round((currentMonthData.revenue / currentMonthData.target) * 100) : 0;

  return (
    <div className="min-h-screen bg-gray-50 pb-28" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 px-4 pt-4 pb-10">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-black text-white">المبيعات والإيرادات</h1>
            <p className="text-indigo-200 text-xs mt-0.5">{totalOrderCount} طلب مكتمل</p>
          </div>
          <div className="flex gap-2">
            <button onClick={toggleCurrency} className="w-9 h-9 bg-white/15 rounded-xl flex items-center justify-center">
              <span className="text-white text-xs font-bold">{currency}</span>
            </button>
            <button onClick={handleExport} className="w-9 h-9 bg-white/15 rounded-xl flex items-center justify-center">
              <Download size={16} className={`text-white ${isExporting ? 'animate-bounce' : ''}`} />
            </button>
          </div>
        </div>

        <div className="flex gap-2 bg-white/10 backdrop-blur rounded-2xl p-1">
          {[{ key: 'week', label: 'أسبوعي' }, { key: 'month', label: 'شهري' }, { key: 'year', label: 'سنوي' }].map(p => (
            <button key={p.key} onClick={() => setPeriod(p.key as typeof period)}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${period === p.key ? 'bg-white text-indigo-700 shadow-sm' : 'text-white/70'}`}>
              {p.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="bg-white/10 rounded-2xl p-3">
            <p className="text-indigo-200 text-xs mb-1">إجمالي الإيرادات</p>
            <p className="text-white font-black text-xl">{format(totalRevenue)}</p>
            <div className="flex items-center gap-1 mt-1">
              {revenueGrowth >= 0 ? <ArrowUpRight size={12} className="text-emerald-300" /> : <ArrowDownRight size={12} className="text-red-300" />}
              <span className={`text-xs ${revenueGrowth >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>
                {Math.abs(revenueGrowth).toFixed(1)}% هذا الشهر
              </span>
            </div>
          </div>
          <div className="bg-white/10 rounded-2xl p-3">
            <p className="text-indigo-200 text-xs mb-1">إجمالي الطلبات</p>
            <p className="text-white font-black text-xl">{totalOrderCount}</p>
            <p className="text-indigo-300 text-xs mt-1">متوسط {format(avgOrderValue)} / طلب</p>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-4 space-y-4">
        {/* Quick KPIs */}
        <div className="grid grid-cols-3 gap-2 -mt-2">
          {[
            { label: 'هذا الشهر', value: format(currentMonthData.revenue || 0), icon: DollarSign, color: 'from-blue-500 to-blue-600' },
            { label: 'إنجاز الهدف', value: `${targetAchievement}%`, icon: Target, color: 'from-purple-500 to-purple-600' },
            { label: 'متوسط الطلب', value: format(avgOrderValue), icon: ShoppingCart, color: 'from-emerald-500 to-emerald-600' },
          ].map((kpi, i) => {
            const Icon = kpi.icon;
            return (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                className={`bg-gradient-to-br ${kpi.color} rounded-2xl p-3 text-white text-center shadow-md`}>
                <Icon size={16} className="mx-auto mb-1 opacity-80" />
                <p className="font-black text-sm leading-tight">{kpi.value}</p>
                <p className="text-white/70 text-[10px] mt-0.5">{kpi.label}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-1 bg-gray-100 rounded-2xl p-1">
          {[
            { key: 'overview', label: 'نظرة عامة', icon: BarChart2 },
            { key: 'products', label: 'المنتجات', icon: Package },
            { key: 'customers', label: 'العملاء', icon: Users },
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button key={tab.key} onClick={() => setActiveTab(tab.key as typeof activeTab)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === tab.key ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'}`}>
                <Icon size={12} />{tab.label}
              </button>
            );
          })}
        </div>

        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div key="overview" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2"><TrendingUp size={16} className="text-indigo-600" /><h3 className="font-bold text-gray-800 text-sm">الإيرادات الشهرية</h3></div>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${revenueGrowth >= 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                      {revenueGrowth >= 0 ? '+' : ''}{revenueGrowth.toFixed(1)}%
                    </span>
                  </div>
                </CardHeader>
                <CardBody className="pt-2 pb-3 px-2">
                  <ResponsiveContainer width="100%" height={200}>
                    <AreaChart data={monthlyData} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                      <defs>
                        <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                      <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Area type="monotone" dataKey="revenue" name="الإيرادات" stroke="#6366f1" strokeWidth={2.5} fill="url(#revenueGrad)" dot={false} activeDot={{ r: 4 }} />
                      <Area type="monotone" dataKey="expenses" name="المصاريف" stroke="#10b981" strokeWidth={1.5} strokeDasharray="5 5" fill="none" dot={false} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardBody>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2"><BarChart2 size={16} className="text-purple-600" /><h3 className="font-bold text-gray-800 text-sm">الطلبات الأسبوعية</h3></div>
                </CardHeader>
                <CardBody className="pt-0 pb-3 px-2">
                  <ResponsiveContainer width="100%" height={150}>
                    <BarChart data={weeklyData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                      <XAxis dataKey="day" tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="revenue" name="الإيرادات" fill="#6366f1" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardBody>
              </Card>

              {finishDistribution.length > 0 && (
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2"><PieChartIcon size={16} className="text-amber-600" /><h3 className="font-bold text-gray-800 text-sm">توزيع المبيعات حسب نوع السطح</h3></div>
                  </CardHeader>
                  <CardBody>
                    <div className="flex items-center gap-4">
                      <PieChart width={100} height={100}>
                        <Pie data={finishDistribution} cx={50} cy={50} innerRadius={28} outerRadius={46} dataKey="value" stroke="none" paddingAngle={3}>
                          {finishDistribution.map((entry, index) => (<Cell key={index} fill={entry.color} />))}
                        </Pie>
                      </PieChart>
                      <div className="flex-1 space-y-2">
                        {finishDistribution.map(entry => (
                          <div key={entry.name} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
                              <span className="text-xs text-gray-600">{entry.name}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="w-16 bg-gray-100 rounded-full h-1.5">
                                <div className="h-1.5 rounded-full" style={{ width: `${entry.value}%`, backgroundColor: entry.color }} />
                              </div>
                              <span className="text-xs font-bold text-gray-800 w-8 text-left">{entry.value}%</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardBody>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <h3 className="font-bold text-gray-800 text-sm">آخر الطلبات</h3>
                </CardHeader>
                <CardBody className="p-0">
                  {completedOrders.slice(0, 5).map((order, idx) => (
                    <motion.div key={order.id} whileTap={{ scale: 0.98 }}
                      className={`flex items-center gap-3 px-4 py-3 ${idx < 4 ? 'border-b border-gray-50' : ''}`}>
                      <div className="w-9 h-9 bg-indigo-100 rounded-xl flex items-center justify-center shrink-0">
                        <ShoppingCart size={15} className="text-indigo-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-800 truncate">{order.customer_name}</p>
                        <p className="text-[11px] text-gray-500">{order.order_number}</p>
                      </div>
                      <div className="text-left shrink-0">
                        <p className="text-sm font-bold text-gray-900">{format(order.total_usd, order.total_syp)}</p>
                        <p className="text-[10px] text-gray-400">{order.items.length} منتج</p>
                      </div>
                    </motion.div>
                  ))}
                  {completedOrders.length === 0 && (
                    <div className="text-center py-8 text-gray-400 text-sm">لا توجد طلبات بعد</div>
                  )}
                </CardBody>
              </Card>
            </motion.div>
          )}

          {activeTab === 'products' && (
            <motion.div key="products" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-4">
              {productSalesData.length > 0 ? (
                <>
                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-2"><BarChart2 size={16} className="text-blue-600" /><h3 className="font-bold text-gray-800 text-sm">أكثر المنتجات مبيعاً</h3></div>
                    </CardHeader>
                    <CardBody className="pt-0 pb-3 px-2">
                      <ResponsiveContainer width="100%" height={180}>
                        <BarChart data={productSalesData} layout="vertical" margin={{ top: 0, right: 10, left: 10, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false} />
                          <XAxis type="number" tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                          <YAxis type="category" dataKey="name" tick={{ fontSize: 8, fill: '#9ca3af' }} axisLine={false} tickLine={false} width={80}
                            tickFormatter={(v) => v.length > 12 ? v.substring(0, 12) + '...' : v} />
                          <Tooltip content={<CustomTooltip />} />
                          <Bar dataKey="sold" name="الكمية" radius={[0, 6, 6, 0]}>
                            {productSalesData.map((entry, index) => (<Cell key={index} fill={entry.color} />))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </CardBody>
                  </Card>

                  {productSalesData.map((product, idx) => (
                    <motion.div key={product.name} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: idx * 0.07 }}>
                      <Card>
                        <CardBody className="py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-3 h-12 rounded-full shrink-0" style={{ backgroundColor: product.color }} />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-bold text-gray-800 mb-1">{product.name}</p>
                              <div className="flex items-center gap-3">
                                <span className="text-xs text-gray-500">مباع: <strong className="text-gray-800">{product.sold} لوح</strong></span>
                                <span className="text-xs text-gray-500">إيراد: <strong className="text-gray-800">{format(product.revenue)}</strong></span>
                              </div>
                              <div className="w-full bg-gray-100 rounded-full h-1.5 mt-2">
                                <motion.div className="h-1.5 rounded-full" style={{ backgroundColor: product.color }}
                                  initial={{ width: 0 }}
                                  animate={{ width: `${productSalesData[0].sold > 0 ? (product.sold / productSalesData[0].sold) * 100 : 0}%` }}
                                  transition={{ delay: 0.2 + idx * 0.1, duration: 0.8 }} />
                              </div>
                            </div>
                            <div className="text-left shrink-0">
                              <p className="text-lg font-black" style={{ color: product.color }}>{idx + 1}</p>
                              <p className="text-[10px] text-gray-400">#تصنيف</p>
                            </div>
                          </div>
                        </CardBody>
                      </Card>
                    </motion.div>
                  ))}
                </>
              ) : (
                <div className="text-center py-16">
                  <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-3"><Package size={36} className="text-gray-300" /></div>
                  <p className="text-gray-500 font-medium">لا توجد بيانات منتجات بعد</p>
                  <p className="text-gray-400 text-sm mt-1">أنشئ طلبات لرؤية إحصائيات المنتجات</p>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'customers' && (
            <motion.div key="customers" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <Card><CardBody className="py-4 text-center">
                  <p className="text-2xl font-black text-indigo-600">{customerData.length}</p>
                  <p className="text-xs text-gray-500 mt-1">إجمالي العملاء</p>
                </CardBody></Card>
                <Card><CardBody className="py-4 text-center">
                  <p className="text-2xl font-black text-emerald-600">{format(customerData.reduce((s, c) => s + c.revenue, 0))}</p>
                  <p className="text-xs text-gray-500 mt-1">إجمالي الإيرادات</p>
                </CardBody></Card>
              </div>

              {customerData.length > 0 ? customerData.map((customer, idx) => (
                <motion.div key={customer.name} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: idx * 0.08 }}>
                  <Card><CardBody className="py-3.5">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${idx === 0 ? 'bg-amber-100' : idx === 1 ? 'bg-gray-100' : 'bg-blue-50'}`}>
                        {idx === 0 ? <Award size={16} className="text-amber-600" /> : <span className="text-xs font-black text-gray-600">{idx + 1}</span>}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-gray-800 truncate">{customer.name}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-xs text-gray-500">{customer.orders} طلبات</span>
                          <div className={`flex items-center gap-0.5 ${customer.growth >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                            {customer.growth >= 0 ? <ArrowUpRight size={11} /> : <ArrowDownRight size={11} />}
                            <span className="text-[10px] font-bold">{Math.abs(customer.growth)}%</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-left shrink-0">
                        <p className="text-sm font-bold text-gray-900">{format(customer.revenue)}</p>
                        <p className="text-[10px] text-gray-400">إجمالي الإيرادات</p>
                      </div>
                    </div>
                  </CardBody></Card>
                </motion.div>
              )) : (
                <div className="text-center py-16">
                  <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-3"><Users size={36} className="text-gray-300" /></div>
                  <p className="text-gray-500 font-medium">لا توجد بيانات عملاء بعد</p>
                </div>
              )}

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2"><TrendingUp size={16} className="text-indigo-600" /><h3 className="font-bold text-gray-800 text-sm">نمو الإيرادات</h3></div>
                </CardHeader>
                <CardBody className="pt-0 pb-3 px-2">
                  <ResponsiveContainer width="100%" height={150}>
                    <LineChart data={monthlyData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                      <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Line type="monotone" dataKey="revenue" name="الإيرادات" stroke="#6366f1" strokeWidth={2.5} dot={{ fill: '#6366f1', r: 3 }} activeDot={{ r: 5 }} />
                      <Line type="monotone" dataKey="expenses" name="المصاريف" stroke="#10b981" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardBody>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
        <div className="h-4" />
      </div>
    </div>
  );
};
