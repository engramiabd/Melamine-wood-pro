import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, UserPlus, Calendar, CheckCircle, XCircle,
  Clock, Briefcase, DollarSign, ChevronDown,
  Search, Award, TrendingUp, Edit3, Activity,
  Hash, Shield, ChevronRight, Star,
} from 'lucide-react';
import { Badge } from '../components/ui/Badge';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import { useAppData } from '../contexts/AppDataContext';
import { EmptyState } from '../components/ui/EmptyState';
import { Avatar } from '../components/ui/Avatar';
import { resolveWorkerRoleKey } from '../lib/workers';
import { LeaveType, LeaveStatus, Employee } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { printPayroll } from '../utils/print';


import {
  DEPT_COLORS, WORKER_NAMES, WORKER_AVATARS,
  LEAVE_TYPE_LABELS, LEAVE_STATUS_CONFIG,
  EmployeeDetailSheet, BonusModal, AddEmployeeModal,
} from './HR/HRModals';

// ── Main HR Page ───────────────────────────────────────────────────────────────
export const HRPage: React.FC = () => {
  const { formatUSD, formatSYP, exchangeRate } = useCurrency();
  const { user } = useAuth();
  const { employees, leaveRequests, approveLeave, rejectLeave, addBonus, processPayroll, wallets, computePayrollFromAttendance, can } = useAppData();

  const [tab, setTab]                     = useState<HRTab>('employees');
  const [search, setSearch]               = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [bonusEmployee, setBonusEmployee] = useState<Employee | null>(null);
  const [showAddModal, setShowAddModal]   = useState(false);
  const [leaveActions, setLeaveActions]   = useState<Record<string, LeaveStatus>>({});
  const [showRejectInput, setShowRejectInput] = useState<Record<string, boolean>>({});
  const [rejectReason, setRejectReason]   = useState<Record<string, string>>({});
  const [processingPayroll, setProcessingPayroll] = useState(false);
  const [payrollSuccess, setPayrollSuccess]       = useState(false);

  const canManage = can('hr.manage');
  const canPayroll = can('payroll.process');

  const totalSalaryUSD = employees.reduce((s, e) => s + e.salary_usd, 0);
  const totalSalarySYP = employees.reduce((s, e) => s + e.salary_syp, 0);
  // Real monthly bonus/deduction totals derived from attendance (overtime vs
  // absence+late), replacing the old hardcoded $450/$320 figures.
  const _payNow = new Date();
  const payrollTotals = employees.reduce((acc, e) => {
    const pr = computePayrollFromAttendance(e.id, _payNow.getFullYear(), _payNow.getMonth() + 1);
    if (pr) { acc.bonus += pr.overtime_pay_usd; acc.deduction += pr.absence_deduction_usd + pr.late_deduction_usd; }
    return acc;
  }, { bonus: 0, deduction: 0 });

  const filteredEmployees = employees.filter(e => {
    const name = WORKER_NAMES[e.user_id] ?? e.user_id;
    return name.includes(search) || e.department.includes(search) || e.position.includes(search);
  });

  const deptData = Object.entries(
    employees.reduce((acc, e) => { acc[e.department] = (acc[e.department] ?? 0) + 1; return acc; }, {} as Record<string, number>)
  ).map(([name, count]) => ({ name, count }));

  const salaryData = employees.map(e => ({
    name: (WORKER_NAMES[e.user_id] ?? e.user_id).split(' ')[0],
    salary: e.salary_usd,
  }));

  const handleBonus = (empId: string, amount: number, reason: string) => {
    addBonus(empId, amount, reason);
  };

  const handlePayroll = async () => {
    setProcessingPayroll(true);
    await new Promise(r => setTimeout(r, 1800));
    processPayroll();
    setProcessingPayroll(false);
    setPayrollSuccess(true);
    setTimeout(() => setPayrollSuccess(false), 4000);
  };

  const handlePrintPayroll = () => {
    const month = new Date().toLocaleDateString('ar-SY', { month: 'long', year: 'numeric' });
    printPayroll(employees, wallets, exchangeRate);
  };

  const TABS: { key: HRTab; label: string; icon: React.ReactNode }[] = [
    { key: 'employees', label: 'الموظفون',   icon: <Users size={14} />    },
    { key: 'leaves',    label: 'الإجازات',   icon: <Calendar size={14} /> },
    { key: 'payroll',   label: 'الرواتب',    icon: <DollarSign size={14} /> },
    { key: 'analytics', label: 'التحليلات', icon: <TrendingUp size={14} /> },
  ];

  return (
    <div dir="rtl" style={{ padding: '0 0 16px' }}>
      {/* ── Page Header ── */}
      <div className="page-header" style={{ padding: '16px' }}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-black text-gray-900">الموارد البشرية</h1>
            <p className="text-xs text-gray-400">{employees.length} موظف مسجل</p>
          </div>
          {canManage && (
            <button
              onClick={() => setShowAddModal(true)}
              style={{ minHeight: 'unset' }}
              className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold"
            >
              <UserPlus size={14} /> إضافة
            </button>
          )}
        </div>

        {/* KPI row */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: 'الإجمالي',  value: employees.length,                              color: 'text-blue-600',    bg: 'bg-blue-50 border-blue-100'   },
            { label: 'نشطون',     value: employees.filter(e => e.is_active).length,    color: 'text-emerald-600', bg: 'bg-emerald-50 border-emerald-100' },
            { label: 'الأقسام',   value: new Set(employees.map(e => e.department)).size, color: 'text-purple-600',  bg: 'bg-purple-50 border-purple-100' },
            { label: 'إجازة',     value: leaveRequests.filter(l => l.status === 'pending').length, color: 'text-amber-600', bg: 'bg-amber-50 border-amber-100' },
          ].map(s => (
            <div key={s.label} className={`${s.bg} border rounded-2xl p-2.5 text-center`}>
              <p className={`text-lg font-black ${s.color}`}>{s.value}</p>
              <p className="text-[10px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Tab Bar ── */}
      <div style={{ padding: '0 16px', overflowX: 'auto', display: 'flex', gap: 8, scrollbarWidth: 'none' }}>
        {TABS.map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            style={{ minHeight: 'unset', flexShrink: 0 }}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-sm font-bold transition-all ${
              tab === t.key
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-200'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* ── Tab Content ── */}
      <div style={{ padding: '16px' }}>

        {/* ── EMPLOYEES ── */}
        {tab === 'employees' && (
          <div className="space-y-3">
            {/* Search */}
            <div className="relative">
              <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="ابحث عن موظف..."
                className="w-full pr-9 pl-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm"
                style={{ fontSize: 16 }}
              />
              {search && (
                <button onClick={() => setSearch('')} style={{ minHeight: 'unset', position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}>
                  <XCircle size={14} className="text-gray-400" />
                </button>
              )}
            </div>

            {/* Employee cards */}
            {filteredEmployees.map((emp, i) => {
              const name = WORKER_NAMES[emp.user_id] ?? emp.user_id;
              const grad = WORKER_AVATARS[emp.user_id] ?? 'from-gray-400 to-gray-600';
              const dept = DEPT_COLORS[emp.department] ?? { bg: 'bg-gray-50', text: 'text-gray-700' };
              return (
                <motion.div
                  key={emp.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  onClick={() => setSelectedEmployee(emp)}
                  className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden cursor-pointer"
                  style={{ WebkitTapHighlightColor: 'transparent' }}
                >
                  <div className={`h-0.5 bg-gradient-to-r ${grad}`} />
                  <div className="p-4 flex items-center gap-3">
                    <div className="shrink-0">
                      <Avatar
                        userId={emp.user_id}
                        name={name}
                        role={resolveWorkerRoleKey(emp.user_id, [emp])}
                        size={48}
                        radius={12}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-gray-900 truncate">{name}</p>
                      <p className="text-xs text-gray-500 truncate">{emp.position}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${dept.bg} ${dept.text}`}>
                          {emp.department}
                        </span>
                        <span className="text-xs text-gray-400">{emp.employee_number}</span>
                      </div>
                    </div>
                    <div className="shrink-0 text-left">
                      <p className="text-sm font-bold text-emerald-600">{formatUSD(emp.salary_usd)}</p>
                      <p className="text-xs text-gray-400">/شهر</p>
                      <ChevronRight size={14} className="text-gray-300 mt-1 mr-auto" />
                    </div>
                  </div>
                </motion.div>
              );
            })}

            {filteredEmployees.length === 0 && (
              <EmptyState compact icon={Users} title="لا توجد نتائج" description="جرّب تعديل البحث أو الفلتر." />
            )}
          </div>
        )}

        {/* ── LEAVES ── */}
        {tab === 'leaves' && (
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'معلقة',   count: leaveRequests.filter(l => l.status === 'pending').length,  color: 'text-amber-600',   bg: 'bg-amber-50 border-amber-100'   },
                { label: 'معتمدة', count: leaveRequests.filter(l => l.status === 'approved').length, color: 'text-emerald-600', bg: 'bg-emerald-50 border-emerald-100' },
                { label: 'مرفوضة', count: leaveRequests.filter(l => l.status === 'rejected').length, color: 'text-red-600',     bg: 'bg-red-50 border-red-100'       },
              ].map(s => (
                <div key={s.label} className={`${s.bg} border rounded-2xl p-3 text-center`}>
                  <p className={`text-2xl font-black ${s.color}`}>{s.count}</p>
                  <p className="text-xs text-gray-500">{s.label}</p>
                </div>
              ))}
            </div>

            {leaveRequests.map(leave => {
              const emp = employees.find(e => e.id === leave.employee_id);
              const name = emp ? (WORKER_NAMES[emp.user_id] ?? emp.user_id) : 'موظف';
              const grad = emp ? (WORKER_AVATARS[emp.user_id] ?? 'from-gray-400 to-gray-600') : 'from-gray-400 to-gray-600';
              const action = leaveActions[leave.id];
              const effectiveStatus = action ?? leave.status;
              const cfg = LEAVE_STATUS_CONFIG[effectiveStatus as LeaveStatus];

              return (
                <div key={leave.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                  <div className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="shrink-0">
                        <Avatar
                          userId={emp?.user_id}
                          name={name}
                          role={emp ? resolveWorkerRoleKey(emp.user_id, [emp]) : undefined}
                          size={40}
                          radius={11}
                        />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-sm font-bold text-gray-900">{name}</p>
                          <Badge variant={cfg.badge}>{cfg.label}</Badge>
                        </div>
                        <p className="text-xs text-blue-600 font-medium">{LEAVE_TYPE_LABELS[leave.leave_type]}</p>
                      </div>
                    </div>

                    <div className="mt-3 bg-gray-50 rounded-xl p-3 grid grid-cols-3 gap-2 text-center">
                      <div>
                        <p className="text-xs text-gray-400">من</p>
                        <p className="text-xs font-bold text-gray-700">{new Date(leave.start_date).toLocaleDateString('ar-SY', { month: 'short', day: 'numeric' })}</p>
                      </div>
                      <div className="border-x border-gray-200">
                        <p className="text-xs text-gray-400">المدة</p>
                        <p className="text-sm font-black text-blue-600">{leave.days_count} يوم</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">إلى</p>
                        <p className="text-xs font-bold text-gray-700">{new Date(leave.end_date).toLocaleDateString('ar-SY', { month: 'short', day: 'numeric' })}</p>
                      </div>
                    </div>

                    <p className="text-xs text-gray-500 mt-2">{leave.reason}</p>

                    {action === undefined && leave.status === 'pending' && canManage && (
                      <div className="mt-3 space-y-2">
                        <div className="flex gap-2">
                          <button
                            onClick={() => { setLeaveActions(p => ({ ...p, [leave.id]: 'approved' })); approveLeave(leave.id); }}
                            style={{ minHeight: 'unset' }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-emerald-600 text-white text-xs font-bold rounded-xl"
                          >
                            <CheckCircle size={13} /> موافقة
                          </button>
                          <button
                            onClick={() => setShowRejectInput(p => ({ ...p, [leave.id]: !p[leave.id] }))}
                            style={{ minHeight: 'unset' }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-red-500 text-white text-xs font-bold rounded-xl"
                          >
                            <XCircle size={13} /> رفض
                          </button>
                        </div>
                        <AnimatePresence>
                          {showRejectInput[leave.id] && (
                            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden space-y-2">
                              <input
                                value={rejectReason[leave.id] ?? ''}
                                onChange={e => setRejectReason(p => ({ ...p, [leave.id]: e.target.value }))}
                                placeholder="سبب الرفض..."
                                className="w-full px-3 py-2 bg-red-50 border border-red-200 rounded-xl text-xs"
                                style={{ fontSize: 16 }}
                              />
                              <button
                                onClick={() => {
                                  rejectLeave(leave.id, rejectReason[leave.id]);
                                  setLeaveActions(p => ({ ...p, [leave.id]: 'rejected' }));
                                  setShowRejectInput(p => ({ ...p, [leave.id]: false }));
                                }}
                                style={{ minHeight: 'unset' }}
                                className="w-full py-2 bg-red-500 text-white rounded-xl text-xs font-bold"
                              >
                                تأكيد الرفض
                              </button>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ── PAYROLL ── */}
        {tab === 'payroll' && (
          <div className="space-y-3">
            <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-3xl p-5 text-white relative overflow-hidden">
              <div className="absolute -left-4 -top-4 w-24 h-24 bg-white/10 rounded-full" />
              <p className="text-emerald-200 text-xs mb-1">إجمالي رواتب الشهر</p>
              <p className="text-3xl font-black">{formatUSD(totalSalaryUSD)}</p>
              <p className="text-emerald-200 text-sm">{formatSYP(totalSalarySYP)}</p>
              <div className="grid grid-cols-3 gap-2 mt-4">
                {[
                  { label: 'موظف نشط',  value: employees.filter(e => e.is_active).length },
                  { label: 'المكافآت',  value: formatUSD(Math.round(payrollTotals.bonus)) },
                  { label: 'الخصومات', value: formatUSD(Math.round(payrollTotals.deduction)) },
                ].map(s => (
                  <div key={s.label} className="bg-white/15 rounded-xl p-2.5 text-center">
                    <p className="font-black text-sm">{s.value}</p>
                    <p className="text-emerald-200 text-[10px]">{s.label}</p>
                  </div>
                ))}
              </div>
            </div>

            <AnimatePresence>
              {payrollSuccess && (
                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center shrink-0">
                    <CheckCircle size={20} className="text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-emerald-800">تم صرف الرواتب بنجاح</p>
                    <p className="text-xs text-emerald-600">تم تحديث محافظ العمال وإنشاء القيود المحاسبية</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {employees.map((emp, i) => {
              const name = WORKER_NAMES[emp.user_id] ?? emp.user_id;
              const grad = WORKER_AVATARS[emp.user_id] ?? 'from-gray-400 to-gray-600';
              const _now = new Date();
              const pr = computePayrollFromAttendance(emp.id, _now.getFullYear(), _now.getMonth() + 1);
              const hasAttendance = !!pr && (pr.present_days + pr.absent_days + pr.late_days) > 0;
              const bonus = pr ? pr.overtime_pay_usd : 0;
              const deduction = pr ? pr.absence_deduction_usd + pr.late_deduction_usd : 0;
              const net = pr ? pr.net_salary_usd : emp.salary_usd;
              return (
                <motion.div key={emp.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                  <div className="flex items-center gap-3">
                    <div className="shrink-0">
                      <Avatar
                        userId={emp.user_id}
                        name={name}
                        role={resolveWorkerRoleKey(emp.user_id, [emp])}
                        size={44}
                        radius={12}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-gray-900 truncate">{name}</p>
                      <p className="text-xs text-gray-400 truncate">{emp.position}</p>
                    </div>
                    <div className="shrink-0 text-left">
                      <p className="text-base font-black text-emerald-600">{formatUSD(net)}</p>
                      <p className="text-[10px] text-gray-400">صافي الراتب</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mt-3 text-center">
                    <div className="bg-blue-50 rounded-xl p-2">
                      <p className="text-xs font-bold text-blue-700">{formatUSD(emp.salary_usd)}</p>
                      <p className="text-[10px] text-gray-400">أساسي</p>
                    </div>
                    <div className={`rounded-xl p-2 ${bonus > 0 ? 'bg-emerald-50' : 'bg-gray-50'}`}>
                      <p className={`text-xs font-bold ${bonus > 0 ? 'text-emerald-700' : 'text-gray-400'}`}>{bonus > 0 ? `+${formatUSD(bonus)}` : '-'}</p>
                      <p className="text-[10px] text-gray-400">مكافأة</p>
                    </div>
                    <div className={`rounded-xl p-2 ${deduction > 0 ? 'bg-red-50' : 'bg-gray-50'}`}>
                      <p className={`text-xs font-bold ${deduction > 0 ? 'text-red-700' : 'text-gray-400'}`}>{deduction > 0 ? `-${formatUSD(deduction)}` : '-'}</p>
                      <p className="text-[10px] text-gray-400">خصم</p>
                    </div>
                  </div>

                  {hasAttendance && pr && (
                    <div className="mt-3 pt-3 border-t border-dashed border-gray-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] text-gray-500">محتسب من الحضور (هذا الشهر)</span>
                        <span className="text-sm font-black text-indigo-600">{formatUSD(pr.net_salary_usd)}</span>
                      </div>
                      <div className="grid grid-cols-4 gap-1.5 text-center">
                        {[
                          { l: 'حضور', v: pr.present_days, c: 'text-emerald-600' },
                          { l: 'غياب', v: pr.absent_days, c: 'text-red-500' },
                          { l: 'تأخير', v: pr.late_days, c: 'text-amber-500' },
                          { l: 'إضافي(س)', v: pr.overtime_hours, c: 'text-blue-600' },
                        ].map((x) => (
                          <div key={x.l} className="bg-gray-50 rounded-lg py-1.5">
                            <p className={`text-xs font-bold ${x.c}`}>{x.v}</p>
                            <p className="text-[9px] text-gray-400">{x.l}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              );
            })}

            {canPayroll && (
              <div className="flex gap-3">
                <button
                  onClick={handlePrintPayroll}
                  style={{ minHeight: 'unset' }}
                  className="flex-1 py-4 bg-white border-2 border-gray-200 text-gray-700 font-bold text-sm rounded-2xl flex items-center justify-center gap-2"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                  طباعة
                </button>
                <button
                  onClick={handlePayroll}
                  disabled={processingPayroll}
                  style={{ minHeight: 'unset' }}
                  className="flex-[2] py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-base rounded-2xl shadow-lg disabled:opacity-60 flex items-center justify-center gap-3"
                >
                  {processingPayroll ? (
                    <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> جاري الصرف...</>
                  ) : (
                    <><DollarSign size={18} /> صرف رواتب الشهر الحالي</>
                  )}
                </button>
              </div>
            )}
          </div>
        )}

        {/* ── ANALYTICS ── */}
        {tab === 'analytics' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <p className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                <Users size={14} className="text-blue-600" /> توزيع الموظفين بالأقسام
              </p>
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={deptData} barSize={28}>
                  <XAxis dataKey="name" tick={{ fontSize: 9, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                  <Bar dataKey="count" radius={[6, 6, 0, 0]} fill="#3B82F6" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <p className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                <DollarSign size={14} className="text-emerald-600" /> مقارنة الرواتب (دولار)
              </p>
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={salaryData} barSize={22}>
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} formatter={(v: unknown) => [`$${v}`, 'الراتب']} />
                  <Bar dataKey="salary" radius={[6, 6, 0, 0]}>
                    {salaryData.map((_, i) => <Cell key={i} fill={`hsl(${140 + i * 30}, 60%, 50%)`} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'متوسط الراتب',            value: formatUSD(totalSalaryUSD / Math.max(employees.length, 1)), icon: <DollarSign size={20} className="text-blue-500" />,   bg: 'bg-blue-50 border-blue-100'   },
                { label: 'الراتب الأعلى',           value: formatUSD(Math.max(...employees.map(e => e.salary_usd), 0)), icon: <Award size={20} className="text-amber-500" />,     bg: 'bg-amber-50 border-amber-100'   },
                { label: 'معدل الاحتفاظ',           value: '95%',                                                       icon: <TrendingUp size={20} className="text-emerald-500" />, bg: 'bg-emerald-50 border-emerald-100' },
                { label: 'طلبات إجازة هذا الشهر', value: leaveRequests.length,                                         icon: <Calendar size={20} className="text-purple-500" />,   bg: 'bg-purple-50 border-purple-100' },
              ].map(s => (
                <div key={s.label} className={`${s.bg} border rounded-2xl p-4`}>
                  <div className="mb-2">{s.icon}</div>
                  <p className="text-lg font-black text-gray-900">{s.value}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* Bottom spacer */}
      <div style={{ height: 'var(--page-pb, 80px)' }} />

      {/* ── Modals — all Portal-based, NEVER behind BottomNav ── */}
      <EmployeeDetailSheet
        emp={selectedEmployee}
        onClose={() => setSelectedEmployee(null)}
        onBonus={emp => { setBonusEmployee(emp); }}
        formatUSD={formatUSD}
        formatSYP={formatSYP}
      />

      <BonusModal
        emp={bonusEmployee}
        onClose={() => setBonusEmployee(null)}
        onSave={handleBonus}
        formatUSD={formatUSD}
      />

      {showAddModal && <AddEmployeeModal onClose={() => setShowAddModal(false)} />}
    </div>
  );
};

export default React.memo(HRPage);
