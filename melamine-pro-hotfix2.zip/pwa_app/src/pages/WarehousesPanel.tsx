import React, { useMemo, useState } from 'react';
import { Fuel, AlertTriangle, Package, Layers, FileText, Droplet, Download, Printer } from 'lucide-react';
import { useAppData } from '../contexts/AppDataContext';
import { Pagination } from '../components/ui/Pagination';
import { downloadCSV, printReport } from '../utils/exportReports';
import {
  FACTORY, MIN_MDF_BOARDS, MIN_PAPER_SHEETS,
  mdfLabel, paperLabel, dieselStatus,
} from '../lib/factoryConfig';

type Tab = 'overview' | 'shortages';
const PAGE = 12;

export const WarehousesPanel: React.FC = () => {
  const { managedProducts, inventoryItems, addInventoryTransaction } = useAppData();
  const [tab, setTab] = useState<Tab>('overview');
  const [page, setPage] = useState(1);
  const [liters, setLiters] = useState('');

  const w = useMemo(() => {
    const melamineBoards = managedProducts.reduce((s, p) => s + (p.stock_quantity || 0), 0);
    const melamineInStock = managedProducts.filter(p => (p.stock_quantity || 0) > 0).length;
    const mdfItems = inventoryItems.filter(i => i.code.startsWith('MDF-'));
    const mdfBoards = mdfItems.reduce((s, i) => s + i.stock_quantity, 0);
    const paperItems = inventoryItems.filter(i => i.code.startsWith('PAPER-'));
    const paperSheets = paperItems.reduce((s, i) => s + i.stock_quantity, 0);
    const diesel = inventoryItems.find(i => i.code === 'DIESEL');
    return { melamineBoards, melamineInStock, mdfItems, mdfBoards, paperItems, paperSheets, diesel };
  }, [managedProducts, inventoryItems]);

  const shortages = useMemo(() => {
    const paperStock = new Map<number, number>();
    inventoryItems.filter(i => i.code.startsWith('PAPER-')).forEach(i => {
      const n = Number(i.code.replace('PAPER-', ''));
      paperStock.set(n, (paperStock.get(n) || 0) + i.stock_quantity);
    });
    const melamineLow = managedProducts.filter(p => (p.stock_quantity || 0) < FACTORY.minMelamineBoards);
    const noPaper = managedProducts.filter(p => p.color_number != null && !(paperStock.get(p.color_number) > 0));
    const mdfLow = w.mdfItems.filter(i => i.stock_quantity < MIN_MDF_BOARDS);
    const paperLow = w.paperItems.filter(i => i.stock_quantity < MIN_PAPER_SHEETS);
    return { melamineLow, noPaper, mdfLow, paperLow };
  }, [managedProducts, inventoryItems, w]);

  const dieselLiters = w.diesel?.stock_quantity ?? 0;
  const ds = dieselStatus(dieselLiters);

  const logDiesel = (amount: number) => {
    if (!w.diesel || amount <= 0) return;
    addInventoryTransaction(w.diesel.id, 'out', amount, undefined, 'استهلاك تشغيل');
    setLiters('');
  };

  const exportInventory = () => {
    downloadCSV('تقرير_المخزون', ['الرمز', 'الاسم', 'الفئة', 'الرصيد', 'الوحدة', 'الحد الأدنى'],
      inventoryItems.map(i => [i.code, i.name, i.category || '', i.stock_quantity, i.unit, i.reorder_level]));
  };
  const exportShortages = () => {
    const rows: (string | number)[][] = [];
    shortages.melamineLow.forEach(p => rows.push(['ميلامين تحت 40', p.code, `${p.thickness} ${p.faces || ''}`, p.stock_quantity || 0]));
    shortages.noPaper.forEach(p => rows.push(['ميلامين بدون ورق', p.code, `لون ${p.color_number}`, 0]));
    shortages.mdfLow.forEach(i => rows.push(['MDF منخفض', i.code, i.name, i.stock_quantity]));
    shortages.paperLow.forEach(i => rows.push(['ورق منخفض', i.code, i.name, i.stock_quantity]));
    downloadCSV('تقرير_النواقص', ['النوع', 'الرمز', 'التفاصيل', 'الرصيد'], rows);
  };
  const printInventory = () => printReport('تقرير المخزون', ['الرمز', 'الاسم', 'الفئة', 'الرصيد', 'الوحدة'],
    inventoryItems.map(i => [i.code, i.name, i.category || '', i.stock_quantity, i.unit]), { subtitle: 'المستودعات' });

  return (
    <div dir="rtl">
      {/* Tabs */}
      <div>
        <div className="bg-white rounded-2xl shadow-sm p-1 flex">
          {([['overview', 'نظرة عامة'], ['shortages', 'النواقص']] as const).map(([k, l]) => (
            <button key={k} onClick={() => { setTab(k as Tab); setPage(1); }}
              className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition ${tab === k ? 'bg-teal-600 text-white' : 'text-gray-500'}`}>
              {l}{k === 'shortages' && shortages.melamineLow.length + shortages.noPaper.length > 0 ? '' : ''}
            </button>
          ))}
        </div>
      </div>

      {tab === 'overview' && (
        <div className="mt-3 space-y-3">
          {/* Warehouse cards */}
          <div className="grid grid-cols-2 gap-3">
            <WCard icon={<Package size={18} />} accent="#0d9488" title="الميلامين (تام)"
              main={`${w.melamineBoards.toLocaleString()} لوح`} sub={`${w.melamineInStock} صنف به رصيد`} />
            <WCard icon={<Layers size={18} />} accent="#7c3aed" title="MDF"
              main={mdfLabel(w.mdfBoards)} sub={`${w.mdfBoards.toLocaleString()} لوح إجمالاً`} />
            <WCard icon={<FileText size={18} />} accent="#0891b2" title="الورق"
              main={paperLabel(w.paperSheets)} sub={`${w.paperSheets.toLocaleString()} ورقة • ${w.paperItems.length} لون`} />
            <WCard icon={<Fuel size={18} />} accent={ds.color} title="المازوت"
              main={`${dieselLiters.toLocaleString()} لتر`} sub={`الحالة: ${ds.label}`} />
          </div>

          {/* Diesel panel */}
          <div className="flex gap-2">
            <button onClick={exportInventory} className="flex-1 bg-white rounded-2xl p-3 shadow-sm flex items-center justify-center gap-2 text-teal-700 font-bold text-sm">
              <Download size={16} /> تصدير المخزون (CSV)
            </button>
            <button onClick={printInventory} aria-label="طباعة / PDF" className="bg-white rounded-2xl px-4 shadow-sm flex items-center justify-center text-teal-700">
              <Printer size={18} />
            </button>
          </div>
          <div className="bg-white rounded-2xl shadow-sm p-4">
            <div className="flex items-center gap-2 mb-3">
              <Droplet size={16} style={{ color: ds.color }} />
              <h3 className="font-bold text-gray-800 text-sm">المازوت — تسجيل استهلاك</h3>
            </div>
            <div className="h-2 rounded-full bg-gray-100 overflow-hidden mb-1">
              <div className="h-full rounded-full" style={{ width: `${Math.min(100, (dieselLiters / FACTORY.dieselMax) * 100)}%`, background: ds.color }} />
            </div>
            <div className="flex justify-between text-[10px] text-gray-400 mb-3">
              <span>حرج {FACTORY.dieselMin}</span><span>متوسط {FACTORY.dieselAvg}</span><span>أقصى {FACTORY.dieselMax}</span>
            </div>
            <div className="flex gap-2">
              <button onClick={() => logDiesel(FACTORY.dieselPerDay)} className="flex-1 bg-teal-50 text-teal-700 rounded-xl py-2 text-xs font-bold">يوم تشغيل (−{FACTORY.dieselPerDay})</button>
              <button onClick={() => logDiesel(FACTORY.dieselPerHour)} className="flex-1 bg-teal-50 text-teal-700 rounded-xl py-2 text-xs font-bold">ساعة (−{FACTORY.dieselPerHour})</button>
            </div>
            <div className="flex gap-2 mt-2">
              <input value={liters} onChange={e => setLiters(e.target.value.replace(/[^0-9]/g, ''))}
                inputMode="numeric" placeholder="لتر مخصّص"
                className="flex-1 bg-gray-50 rounded-xl px-3 py-2 text-sm outline-none" />
              <button onClick={() => logDiesel(Number(liters))} disabled={!liters}
                className="bg-teal-600 text-white rounded-xl px-4 py-2 text-sm font-bold disabled:opacity-40">خصم</button>
            </div>
          </div>
        </div>
      )}

      {tab === 'shortages' && (
        <div className="mt-3 space-y-3">
          {/* shortage summary */}
          <div className="grid grid-cols-2 gap-2">
            <SCard label="ميلامين تحت 40" count={shortages.melamineLow.length} color="#d97706" />
            <SCard label="ميلامين بدون ورق" count={shortages.noPaper.length} color="#dc2626" />
            <SCard label={`MDF تحت ${MIN_MDF_BOARDS} لوح`} count={shortages.mdfLow.length} color="#7c3aed" />
            <SCard label={`ورق تحت ${MIN_PAPER_SHEETS} ورقة`} count={shortages.paperLow.length} color="#0891b2" />
          </div>

          <button onClick={exportShortages} className="w-full bg-white rounded-2xl p-3 shadow-sm flex items-center justify-center gap-2 text-teal-700 font-bold text-sm">
            <Download size={16} /> تصدير تقرير النواقص (CSV)
          </button>

          {/* MDF / paper raw shortages */}
          {(shortages.mdfLow.length > 0 || shortages.paperLow.length > 0) && (
            <div className="bg-white rounded-2xl shadow-sm p-3 space-y-2">
              <h3 className="text-xs font-bold text-gray-500">نواقص المواد الخام</h3>
              {shortages.mdfLow.map(i => (
                <Row key={i.id} name={i.name} val={mdfLabel(i.stock_quantity)} warn />
              ))}
              {shortages.paperLow.map(i => (
                <Row key={i.id} name={i.name} val={`${i.stock_quantity.toLocaleString()} ورقة`} warn />
              ))}
            </div>
          )}

          {/* Melamine without paper */}
          <div className="bg-white rounded-2xl shadow-sm p-3">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle size={14} className="text-red-500" />
              <h3 className="text-xs font-bold text-gray-500">ميلامين بدون ورق ({shortages.noPaper.length})</h3>
            </div>
            {shortages.noPaper.slice((page - 1) * PAGE, page * PAGE).map(p => (
              <Row key={p.id} name={`${p.code} — ${p.thickness} ${p.faces || ''}`} val={`لون ${p.color_number}`} warn />
            ))}
            {shortages.noPaper.length === 0 && <p className="text-center text-gray-400 text-xs py-4">لا يوجد</p>}
            <div className="pt-1"><Pagination page={page} totalItems={shortages.noPaper.length} pageSize={PAGE} onPageChange={setPage} /></div>
          </div>
        </div>
      )}
    </div>
  );
};

const WCard: React.FC<{ icon: React.ReactNode; accent: string; title: string; main: string; sub: string }> = ({ icon, accent, title, main, sub }) => (
  <div className="bg-white rounded-2xl shadow-sm p-3.5">
    <div className="flex items-center gap-2 mb-2">
      <div className="w-8 h-8 rounded-xl flex items-center justify-center text-white" style={{ background: accent }}>{icon}</div>
      <span className="text-xs font-bold text-gray-500">{title}</span>
    </div>
    <div className="text-[15px] font-black text-gray-800 leading-tight">{main}</div>
    <div className="text-[10px] text-gray-400 mt-0.5">{sub}</div>
  </div>
);

const SCard: React.FC<{ label: string; count: number; color: string }> = ({ label, count, color }) => (
  <div className="bg-white rounded-2xl shadow-sm p-3 text-center">
    <div className="text-xl font-black" style={{ color }}>{count.toLocaleString()}</div>
    <div className="text-[10px] text-gray-400 mt-0.5">{label}</div>
  </div>
);

const Row: React.FC<{ name: string; val: string; warn?: boolean }> = ({ name, val, warn }) => (
  <div className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
    <span className="text-sm text-gray-700">{name}</span>
    <span className={`text-xs font-bold ${warn ? 'text-red-600' : 'text-gray-500'}`}>{val}</span>
  </div>
);
