import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Package, Users, FileText, ShoppingCart, Boxes, ChevronLeft } from 'lucide-react';
import { useAppData } from '../contexts/AppDataContext';

const PER_GROUP = 6;

export const SearchPage: React.FC = () => {
  const { orders, managedProducts, customers, invoices, inventoryItems, can } = useAppData();
  const navigate = useNavigate();
  const [q, setQ] = useState('');

  const results = useMemo(() => {
    const s = q.trim();
    if (s.length < 2) return null;
    const has = (...vals: (string | number | undefined)[]) => vals.some(v => String(v ?? '').includes(s));
    return {
      orders: can('orders.view') ? orders.filter(o => has(o.order_number, o.customer_name)).slice(0, PER_GROUP) : [],
      products: (can('orders.view') || can('inventory.view')) ? managedProducts.filter(p => has(p.code, p.name)).slice(0, PER_GROUP) : [],
      customers: can('orders.view') ? customers.filter(c => has(c.name, c.phone)).slice(0, PER_GROUP) : [],
      invoices: can('invoices.view') ? invoices.filter(i => has(i.invoice_number, i.customer_name)).slice(0, PER_GROUP) : [],
      inventory: can('inventory.view') ? inventoryItems.filter(i => has(i.code, i.name)).slice(0, PER_GROUP) : [],
    };
  }, [q, orders, managedProducts, customers, invoices, inventoryItems, can]);

  const total = results ? results.orders.length + results.products.length + results.customers.length + results.invoices.length + results.inventory.length : 0;

  return (
    <div className="min-h-full bg-gray-50 pb-24" dir="rtl">
      <div className="bg-gradient-to-br from-blue-600 to-indigo-700 px-5 pt-6 pb-8 text-white">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center"><Search size={22} /></div>
          <div>
            <h1 className="text-lg font-extrabold">البحث الشامل</h1>
            <p className="text-xs text-white/70">طلبات • منتجات • عملاء • فواتير • مخزون</p>
          </div>
        </div>
        <div className="relative">
          <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/60" />
          <input value={q} onChange={e => setQ(e.target.value)} autoFocus
            placeholder="اكتب رقم طلب، رمز منتج، اسم عميل…"
            className="w-full bg-white/15 rounded-xl py-3 pr-10 pl-3 text-sm text-white placeholder-white/50 outline-none focus:bg-white/20" />
        </div>
      </div>

      <div className="px-4 mt-4 space-y-4">
        {!results && <p className="text-center text-gray-400 text-sm py-12">اكتب حرفين على الأقل للبحث</p>}
        {results && total === 0 && <p className="text-center text-gray-400 text-sm py-12">لا توجد نتائج مطابقة لـ «{q}»</p>}

        {results && results.orders.length > 0 && (
          <Group icon={<ShoppingCart size={15} />} title="الطلبات" color="#2563eb" onMore={() => navigate('/orders')}>
            {results.orders.map(o => (
              <Item key={o.id} onClick={() => navigate('/orders')}
                main={`طلب ${o.order_number}`} sub={`${o.customer_name} • $${(o.total_usd || 0).toLocaleString()}`} />
            ))}
          </Group>
        )}

        {results && results.products.length > 0 && (
          <Group icon={<Package size={15} />} title="المنتجات" color="#db2777" onMore={() => navigate('/products')}>
            {results.products.map(p => (
              <Item key={p.id} onClick={() => navigate('/products')}
                main={`${p.code} — ${p.name}`} sub={`${p.thickness || ''} ${p.faces || ''} • رصيد ${p.stock_quantity || 0}`} />
            ))}
          </Group>
        )}

        {results && results.customers.length > 0 && (
          <Group icon={<Users size={15} />} title="العملاء" color="#0891b2" onMore={() => navigate('/customers')}>
            {results.customers.map(c => (
              <Item key={c.id} onClick={() => navigate('/customers')}
                main={c.name} sub={c.phone || 'بدون هاتف'} />
            ))}
          </Group>
        )}

        {results && results.invoices.length > 0 && (
          <Group icon={<FileText size={15} />} title="الفواتير" color="#7c3aed" onMore={() => navigate('/invoices')}>
            {results.invoices.map(i => (
              <Item key={i.id} onClick={() => navigate('/invoices')}
                main={`فاتورة ${i.invoice_number}`} sub={`${i.customer_name} • $${(i.total_usd || 0).toLocaleString()}`} />
            ))}
          </Group>
        )}

        {results && results.inventory.length > 0 && (
          <Group icon={<Boxes size={15} />} title="المخزون" color="#0d9488" onMore={() => navigate('/inventory')}>
            {results.inventory.map(i => (
              <Item key={i.id} onClick={() => navigate('/inventory')}
                main={`${i.code} — ${i.name}`} sub={`${i.stock_quantity.toLocaleString()} ${i.unit}`} />
            ))}
          </Group>
        )}
      </div>
    </div>
  );
};

const Group: React.FC<{ icon: React.ReactNode; title: string; color: string; onMore: () => void; children: React.ReactNode }> = ({ icon, title, color, onMore, children }) => (
  <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
    <div className="flex items-center justify-between px-4 py-2.5 border-b border-gray-50">
      <div className="flex items-center gap-2">
        <span style={{ color }}>{icon}</span>
        <span className="text-xs font-bold text-gray-600">{title}</span>
      </div>
      <button onClick={onMore} className="text-[11px] text-gray-400 flex items-center gap-0.5">عرض الكل <ChevronLeft size={12} /></button>
    </div>
    <div>{children}</div>
  </div>
);

const Item: React.FC<{ main: string; sub: string; onClick: () => void }> = ({ main, sub, onClick }) => (
  <button onClick={onClick} className="w-full text-right px-4 py-2.5 border-b border-gray-50 last:border-0 active:bg-gray-50">
    <div className="text-sm font-bold text-gray-800 truncate">{main}</div>
    <div className="text-[11px] text-gray-400 truncate">{sub}</div>
  </button>
);

export default SearchPage;
