import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  Shield, Briefcase, HardHat, Wrench,
  Calculator, Users, LogIn, ChevronRight,
  Info, Star, Zap, Lock, Eye, EyeOff,
  BarChart2, Factory, MapPin, DollarSign, Smartphone,
} from 'lucide-react';
import { useAuth, DEMO_ACCOUNTS } from '../contexts/AuthContext';
import { UserRole } from '../types';

// ── Role UI Config ─────────────────────────────────────────────────────────────
const ROLE_CONFIG: Record<UserRole, {
  label: string;
  badge: string;
  gradient: string;
  iconBg: string;
  icon: React.ReactNode;
  permissions: string[];
}> = {
  admin: {
    label: 'أحمد المدير',
    badge: 'مدير النظام',
    gradient: 'from-red-500 to-rose-600',
    iconBg: 'bg-red-50',
    icon: <Shield size={22} className="text-red-500" />,
    permissions: ['لوحة الإدارة', 'إدارة المستخدمين', 'الإعدادات', 'جميع التقارير', 'الموافقات'],
  },
  manager: {
    label: 'محمد المشرف',
    badge: 'مدير',
    gradient: 'from-blue-500 to-indigo-600',
    iconBg: 'bg-blue-50',
    icon: <Briefcase size={22} className="text-blue-500" />,
    permissions: ['الطلبات', 'خطوط الإنتاج', 'المخزون', 'الموارد البشرية', 'التكاليف'],
  },
  production_supervisor: {
    label: 'خالد المراقب',
    badge: 'مشرف إنتاج',
    gradient: 'from-emerald-500 to-teal-600',
    iconBg: 'bg-emerald-50',
    icon: <HardHat size={22} className="text-emerald-500" />,
    permissions: ['خطوط الإنتاج', 'الطلبات', 'المخزون', 'الحضور'],
  },
  worker: {
    label: 'علي العامل',
    badge: 'عامل',
    gradient: 'from-amber-500 to-orange-600',
    iconBg: 'bg-amber-50',
    icon: <Wrench size={22} className="text-amber-500" />,
    permissions: ['الحضور الجغرافي', 'المحفظة المالية', 'طلب سلفة', 'خطوط الإنتاج'],
  },
  accountant: {
    label: 'سمر المحاسبة',
    badge: 'محاسب',
    gradient: 'from-purple-500 to-violet-600',
    iconBg: 'bg-purple-50',
    icon: <Calculator size={22} className="text-purple-500" />,
    permissions: ['السجل المحاسبي', 'التقارير المالية', 'الطلبات', 'العملات'],
  },
  hr: {
    label: 'ريم الموارد البشرية',
    badge: 'موارد بشرية',
    gradient: 'from-pink-500 to-rose-500',
    iconBg: 'bg-pink-50',
    icon: <Users size={22} className="text-pink-500" />,
    permissions: ['الموظفون', 'الإجازات', 'الرواتب', 'السلف'],
  },
};

// ── Feature Highlights ────────────────────────────────────────────────────────
const FEATURES = [
  { icon: <BarChart2 size={20} className="text-blue-500" />,    bg: 'bg-blue-50',    label: 'لوحة تحكم تفاعلية',    desc: 'رسوم بيانية حية' },
  { icon: <Factory size={20} className="text-emerald-500" />,   bg: 'bg-emerald-50', label: 'خطوط إنتاج مباشرة',    desc: 'مراقبة الكفاءة' },
  { icon: <MapPin size={20} className="text-red-500" />,        bg: 'bg-red-50',     label: 'حضور جغرافي',          desc: 'تحقق من الموقع' },
  { icon: <DollarSign size={20} className="text-amber-500" />,  bg: 'bg-amber-50',   label: 'عملتان مزدوجتان',      desc: 'دولار وليرة' },
  { icon: <Smartphone size={20} className="text-purple-500" />, bg: 'bg-purple-50',  label: 'تطبيق PWA',            desc: 'يعمل أوفلاين' },
  { icon: <Shield size={20} className="text-indigo-500" />,     bg: 'bg-indigo-50',  label: '6 أدوار مختلفة',       desc: 'صلاحيات دقيقة' },
];

// ── Demo Page ─────────────────────────────────────────────────────────────────
export const DemoPage: React.FC = () => {
  const { loginDemo } = useAuth();
  const navigate = useNavigate();
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [loggingIn, setLoggingIn]       = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = (role: UserRole) => {
    // Find the matching DEMO_ACCOUNT from AuthContext
    const account = DEMO_ACCOUNTS.find(a => a.role === role);
    if (!account) return;

    setLoggingIn(true);
    try {
      loginDemo(account);   // sets user + persists to localStorage
      navigate('/');
    } catch {
      setLoggingIn(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* ── Hero ── */}
      <div className="bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 px-5 pt-12 pb-10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-indigo-500/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

        <div className="relative text-center">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', damping: 15 }}
            className="w-20 h-20 bg-white/10 border border-white/20 rounded-3xl flex items-center justify-center mx-auto mb-4 backdrop-blur-sm"
          >
            <svg width="40" height="40" viewBox="0 0 64 64" fill="none">
              <rect x="6"  y="34" width="52" height="24" rx="3" fill="white" fillOpacity="0.25"/>
              <rect x="12" y="26" width="12" height="32" rx="2" fill="white" fillOpacity="0.45"/>
              <rect x="26" y="22" width="12" height="36" rx="2" fill="white" fillOpacity="0.45"/>
              <rect x="40" y="28" width="10" height="30" rx="2" fill="white" fillOpacity="0.45"/>
              <rect x="14" y="12" width="5"  height="16" rx="2" fill="white" fillOpacity="0.85"/>
              <rect x="28" y="8"  width="5"  height="16" rx="2" fill="white" fillOpacity="0.85"/>
              <rect x="42" y="14" width="5"  height="16" rx="2" fill="white" fillOpacity="0.85"/>
              <circle cx="16" cy="10" r="4" fill="#34d399"/>
              <circle cx="30" cy="6"  r="4" fill="#34d399"/>
              <circle cx="44" cy="12" r="4" fill="#fbbf24"/>
            </svg>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <div className="inline-flex items-center gap-2 bg-amber-400/20 border border-amber-400/30 px-3 py-1 rounded-full mb-3">
              <Star size={12} className="text-amber-400" />
              <span className="text-amber-300 text-xs font-bold">وضع تجريبي</span>
            </div>
            <h1 className="text-2xl font-black text-white mb-2">مصنع ألواح الميلامين</h1>
            <p className="text-blue-200 text-sm max-w-xs mx-auto leading-relaxed">
              جرّب النظام كاملاً باستخدام حسابات وهمية — لا تسجيل مطلوب
            </p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex gap-2 overflow-x-auto mt-5 pb-1"
          style={{ scrollbarWidth: 'none' }}
        >
          {['PWA', 'عربي RTL', 'عملتان', '6 أدوار', 'GPS', 'أوفلاين'].map(tag => (
            <span
              key={tag}
              className="shrink-0 bg-white/10 border border-white/20 text-white/80 text-xs px-3 py-1.5 rounded-full font-medium"
            >
              {tag}
            </span>
          ))}
        </motion.div>
      </div>

      <div className="px-4 py-5 space-y-5 pb-24">
        {/* Info Banner */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-start gap-3"
        >
          <Info size={16} className="text-blue-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-blue-800">كيفية الاستخدام</p>
            <p className="text-xs text-blue-600 mt-0.5 leading-relaxed">
              اختر دوراً ثم اضغط «الدخول» للدخول فوراً. جميع البيانات وهمية ومحلية.
            </p>
          </div>
        </motion.div>

        {/* Demo Accounts */}
        <div>
          <h2 className="text-base font-black text-gray-800 mb-3 flex items-center gap-2">
            <Zap size={16} className="text-amber-500" />
            اختر دوراً وادخل الآن
          </h2>

          <div className="space-y-3">
            {DEMO_ACCOUNTS.map((account, i) => {
              const cfg = ROLE_CONFIG[account.role];
              const isSelected = selectedRole === account.role;

              return (
                <motion.div
                  key={account.role}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.07 }}
                >
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedRole(isSelected ? null : account.role)}
                    className={`w-full text-right bg-white border-2 rounded-2xl overflow-hidden shadow-sm transition-all ${
                      isSelected ? 'border-blue-500 shadow-lg shadow-blue-100' : 'border-gray-100'
                    }`}
                  >
                    <div className="p-4 flex items-center gap-3">
                      {/* Icon */}
                      <div className={`w-12 h-12 ${cfg.iconBg} rounded-xl flex items-center justify-center shrink-0`}>
                        {cfg.icon}
                      </div>
                      {/* Info */}
                      <div className="flex-1 min-w-0 text-right">
                        <div className="flex items-center gap-2 mb-0.5">
                          <p className="text-sm font-black text-gray-900">{cfg.label}</p>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold bg-gradient-to-r ${cfg.gradient} text-white`}>
                            {cfg.badge}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 leading-relaxed line-clamp-2">
                          {account.description}
                        </p>
                      </div>
                      {/* Chevron */}
                      <motion.div animate={{ rotate: isSelected ? 90 : 0 }} transition={{ duration: 0.2 }}>
                        <ChevronRight size={16} className={isSelected ? 'text-blue-500' : 'text-gray-300'} />
                      </motion.div>
                    </div>

                    {/* Expanded section */}
                    <AnimatePresence>
                      {isSelected && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="px-4 pb-4 border-t border-gray-100 pt-3 space-y-3">
                            {/* Credentials */}
                            <div className="bg-gray-50 rounded-xl p-3">
                              <p className="text-xs font-bold text-gray-600 mb-2">بيانات الدخول</p>
                              <div className="space-y-1.5">
                                <div className="flex items-center justify-between">
                                  <span className="text-[10px] text-gray-400">البريد الإلكتروني</span>
                                  <span className="text-xs font-mono font-bold text-gray-700 truncate max-w-[180px]" dir="ltr">
                                    {account.email}
                                  </span>
                                </div>
                                <div className="flex items-center justify-between">
                                  <span className="text-[10px] text-gray-400">كلمة المرور</span>
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-xs font-mono font-bold text-gray-700">
                                      {showPassword ? account.password : '••••••••'}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={e => { e.stopPropagation(); setShowPassword(v => !v); }}
                                      className="p-0.5 text-gray-400 hover:text-gray-600"
                                    >
                                      {showPassword
                                        ? <EyeOff size={12} />
                                        : <Eye size={12} />
                                      }
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Permissions */}
                            <div>
                              <p className="text-[10px] font-bold text-gray-500 mb-2">الصلاحيات المتاحة:</p>
                              <div className="flex flex-wrap gap-1.5">
                                {cfg.permissions.map(p => (
                                  <span
                                    key={p}
                                    className={`text-[10px] px-2 py-1 rounded-lg font-semibold bg-gradient-to-r ${cfg.gradient} text-white flex items-center gap-1`}
                                  >
                                    <svg width="8" height="8" viewBox="0 0 12 12" fill="none">
                                      <polyline points="2 6 5 9 10 3" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                                    </svg>
                                    {p}
                                  </span>
                                ))}
                              </div>
                            </div>

                            {/* Login Button */}
                            <motion.button
                              whileTap={{ scale: 0.96 }}
                              onClick={e => { e.stopPropagation(); handleLogin(account.role); }}
                              disabled={loggingIn}
                              className={`w-full py-3 bg-gradient-to-r ${cfg.gradient} text-white font-black text-sm rounded-xl shadow-md disabled:opacity-60 flex items-center justify-center gap-2`}
                            >
                              {loggingIn ? (
                                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                              ) : (
                                <>
                                  <LogIn size={16} />
                                  الدخول كـ {cfg.label}
                                </>
                              )}
                            </motion.button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.button>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Features */}
        <div>
          <h2 className="text-base font-black text-gray-800 mb-3 flex items-center gap-2">
            <Star size={16} className="text-amber-500" />
            ميزات النظام
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {FEATURES.map((f, i) => (
              <motion.div
                key={f.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.07 }}
                className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm"
              >
                <div className={`w-10 h-10 ${f.bg} rounded-xl flex items-center justify-center mb-2`}>
                  {f.icon}
                </div>
                <p className="text-sm font-bold text-gray-800">{f.label}</p>
                <p className="text-xs text-gray-400 mt-0.5">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Security Notice */}
        <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex items-start gap-3">
          <Lock size={15} className="text-gray-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-bold text-gray-600">ملاحظة أمان</p>
            <p className="text-xs text-gray-400 mt-0.5 leading-relaxed">
              جميع بيانات الوضع التجريبي محلية. لا يتم إرسال أي بيانات حقيقية أو الاتصال بخوادم خارجية.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
