import React, { useMemo, useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Send, TrendingUp, AlertTriangle, Package, Clock, Users, Bot, User as UserIcon, Settings as SettingsIcon } from 'lucide-react';
import { useAppData } from '../contexts/AppDataContext';
import { useCurrency } from '../contexts/CurrencyContext';
import {
  generateInsights, answerQuestion, buildContextSummary,
  type Insight, type InsightData,
} from '../utils/insights';
import { askAI, isAIConfigured, getAIConfig, setAIConfig } from '../utils/aiAssistant';
import { useAuth } from '../contexts/AuthContext';
import { productDemandForecast } from '../utils/forecast';

interface Msg { role: 'user' | 'assistant'; text: string; pending?: boolean }

const SEVERITY_STYLE: Record<Insight['severity'], { bg: string; fg: string }> = {
  good:     { bg: 'rgba(16,185,129,0.12)', fg: '#10b981' },
  info:     { bg: 'rgba(59,130,246,0.12)', fg: '#3b82f6' },
  warning:  { bg: 'rgba(245,158,11,0.12)', fg: '#f59e0b' },
  critical: { bg: 'rgba(239,68,68,0.12)',  fg: '#ef4444' },
};

const SEVERITY_ICON: Record<Insight['severity'], React.ComponentType<{ size?: number; style?: React.CSSProperties }>> = {
  good: TrendingUp, info: Package, warning: AlertTriangle, critical: AlertTriangle,
};

const SUGGESTIONS: { q: string; need?: 'finance' | 'inventory' | 'orders' }[] = [
  { q: 'كم الإيرادات؟', need: 'finance' },
  { q: 'ما هي النواقص؟', need: 'inventory' },
  { q: 'هل هناك فواتير متأخّرة؟', need: 'finance' },
  { q: 'كيف الحضور اليوم؟' },
  { q: 'من أعلى العملاء؟', need: 'finance' },
];

export const AssistantPage: React.FC = () => {
  const { orders, invoices, managedProducts, inventoryItems, attendanceRecords, can } = useAppData();
  const { format } = useCurrency();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const fmt = (n: number) => format(n);

  const perms = useMemo(() => ({
    finance: can('finance.view'),
    orders: can('orders.view'),
    inventory: can('inventory.view'),
  }), [can]);

  const [showCfg, setShowCfg] = useState(false);
  const [cfg, setCfg] = useState(getAIConfig());
  const [cfgSaved, setCfgSaved] = useState(false);
  const saveCfg = () => { setAIConfig(cfg); setCfgSaved(true); setTimeout(() => setCfgSaved(false), 2000); };

  const data: InsightData = useMemo(() => ({
    orders, invoices, products: managedProducts, inventory: inventoryItems, attendance: attendanceRecords,
  }), [orders, invoices, managedProducts, inventoryItems, attendanceRecords]);

  const insights = useMemo(() => generateInsights(data, perms), [data, perms]);
  const forecasts = useMemo(
    () => (perms.inventory ? productDemandForecast(orders, managedProducts).filter(f => f.severity !== 'ok').slice(0, 6) : []),
    [orders, managedProducts, perms.inventory],
  );

  const [messages, setMessages] = useState<Msg[]>([{
    role: 'assistant',
    text: 'مرحباً! أنا مساعدك الذكي. اسألني عن الإيرادات، النواقص، الفواتير المتأخّرة، الحضور، أو العملاء — وسأجيب من بيانات مصنعك.',
  }]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const send = async (text: string) => {
    const q = text.trim();
    if (!q || busy) return;
    setInput('');
    setMessages(m => [...m, { role: 'user', text: q }]);

    // 1) Try the local insights engine (instant, offline).
    const local = answerQuestion(q, data, fmt, perms);
    if (local) {
      setMessages(m => [...m, { role: 'assistant', text: local }]);
      return;
    }

    // 2) Otherwise forward to the optional AI layer (if configured).
    if (!isAIConfigured()) {
      setMessages(m => [...m, {
        role: 'assistant',
        text: 'لا أملك إجابة مباشرة لهذا السؤال من البيانات. لتفعيل الأسئلة الحرّة، اضبط خدمة الذكاء الاصطناعي (نقطة النهاية والمفتاح) من إعدادات المدير.',
      }]);
      return;
    }

    setBusy(true);
    setMessages(m => [...m, { role: 'assistant', text: '…', pending: true }]);
    const summary = buildContextSummary(data, fmt, perms);
    const res = await askAI(q, summary);
    setBusy(false);
    let replyText: string;
    if (res.ok && res.text) {
      replyText = res.text;
    } else if (res.reason === 'network') {
      replyText = 'تعذّر الوصول لخدمة الذكاء (تحقّق من الاتصال أو الإعدادات).';
    } else if (res.reason === 'not_configured') {
      replyText = 'خدمة الذكاء غير مُعدّة. اضبطها من إعدادات المدير.';
    } else {
      replyText = 'وصل ردّ غير صالح من خدمة الذكاء.';
    }
    setMessages(m => [...m.filter(x => !x.pending), { role: 'assistant', text: replyText }]);
  };

  return (
    <div className="min-h-full" dir="rtl" style={{ background: 'var(--surface-secondary)' }}>
      {/* Hero */}
      <div className="px-5 pt-6 pb-7 text-white" style={{ background: 'linear-gradient(135deg,#6366f1,#8b5cf6)' }}>
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white/15 flex items-center justify-center">
            <Sparkles size={22} />
          </div>
          <div>
            <h1 className="text-lg font-extrabold">المساعد الذكي</h1>
            <p className="text-xs text-white/75">رؤى وإجابات من بيانات مصنعك</p>
          </div>
          {isAdmin && (
            <button onClick={() => setShowCfg(s => !s)} className="mr-auto w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center" aria-label="إعداد الذكاء">
              <SettingsIcon size={18} />
            </button>
          )}
        </div>
        {isAdmin && showCfg && (
          <div style={{ marginTop: 14, background: 'rgba(255,255,255,0.1)', borderRadius: 14, padding: 14 }}>
            <p style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>خدمة الذكاء الاصطناعي (اختياري)</p>
            <p style={{ fontSize: 10.5, color: 'rgba(255,255,255,0.7)', marginBottom: 6, lineHeight: 1.6 }}>
              للأسئلة الحرّة. المفتاح يُحفظ على هذا الجهاز فحسب ولا يُرسَل لخوادمنا.
            </p>
            {/* Security notice */}
            <div style={{ background: 'rgba(251,191,36,0.18)', border: '1px solid rgba(251,191,36,0.4)', borderRadius: 8, padding: '7px 10px', marginBottom: 10, fontSize: 10.5, color: '#fde68a', lineHeight: 1.5 }}>
              ⚠ الاتصال المباشر بـAPI يُظهر مفتاحك في سجلات الشبكة.
              للأمان استخدم <strong>وسيطاً (proxy)</strong> بدلاً من الاتصال المباشر.
            </div>
            <input value={cfg.endpoint} onChange={e => setCfg(c => ({ ...c, endpoint: e.target.value }))}
              placeholder="نقطة النهاية (Endpoint URL)" dir="ltr"
              style={{ width: '100%', padding: '9px 12px', borderRadius: 10, border: 'none', fontSize: 12, marginBottom: 8, boxSizing: 'border-box' }} />
            <input value={cfg.apiKey} onChange={e => setCfg(c => ({ ...c, apiKey: e.target.value }))}
              placeholder="مفتاح API" dir="ltr" type="password"
              style={{ width: '100%', padding: '9px 12px', borderRadius: 10, border: 'none', fontSize: 12, marginBottom: 8, boxSizing: 'border-box' }} />
            <input value={cfg.model} onChange={e => setCfg(c => ({ ...c, model: e.target.value }))}
              placeholder="اسم النموذج" dir="ltr"
              style={{ width: '100%', padding: '9px 12px', borderRadius: 10, border: 'none', fontSize: 12, marginBottom: 10, boxSizing: 'border-box' }} />
            <button onClick={saveCfg}
              style={{ width: '100%', padding: '9px', borderRadius: 10, border: 'none', cursor: 'pointer', background: '#fff', color: '#6366f1', fontSize: 12, fontWeight: 800 }}>
              {cfgSaved ? '✓ تم الحفظ' : 'حفظ الإعدادات'}
            </button>
          </div>
        )}
      </div>

      {/* Insights cards */}
      <div className="px-4 -mt-4">
        <div className="grid grid-cols-2 gap-2.5">
          {insights.map(ins => {
            const st = SEVERITY_STYLE[ins.severity];
            const Icon = SEVERITY_ICON[ins.severity];
            return (
              <motion.div
                key={ins.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                style={{ background: 'var(--surface)', border: '1px solid var(--border-color)', borderRadius: 16, padding: 14 }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div style={{ width: 28, height: 28, borderRadius: 8, background: st.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon size={15} style={{ color: st.fg }} />
                  </div>
                </div>
                <div style={{ fontSize: 18, fontWeight: 900, color: 'var(--text-primary)' }}>{ins.value}</div>
                <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-secondary)', marginTop: 2 }}>{ins.title}</div>
                {ins.detail && <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginTop: 3 }}>{ins.detail}</div>}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Predictive stockout forecast */}
      {forecasts.length > 0 && (
        <div className="px-4 mt-4">
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border-color)', borderRadius: 16, padding: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <Clock size={16} style={{ color: '#f59e0b' }} />
              <span style={{ fontSize: 13, fontWeight: 800, color: 'var(--text-primary)' }}>توقّع نفاد المخزون</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {forecasts.map(f => {
                const c = f.severity === 'critical' ? '#ef4444' : '#f59e0b';
                return (
                  <div key={f.productId} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{f.name}</div>
                      <div style={{ fontSize: 10.5, color: 'var(--text-tertiary)' }}>المخزون: {f.stock} • الطلب اليومي ≈ {f.dailyDemand.toFixed(1)}</div>
                    </div>
                    <div style={{ flexShrink: 0, textAlign: 'left' }}>
                      <span style={{ fontSize: 13, fontWeight: 900, color: c }}>~{Math.max(0, Math.round(f.daysLeft))} يوم</span>
                      {f.stockoutDate && <div style={{ fontSize: 9.5, color: 'var(--text-tertiary)' }}>حتى {f.stockoutDate}</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Chat */}
      <div className="px-4 mt-5">
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border-color)', borderRadius: 18, overflow: 'hidden' }}>
          <div ref={scrollRef} style={{ maxHeight: 360, overflowY: 'auto', padding: 14, display: 'flex', flexDirection: 'column', gap: 12 }}>
            {messages.map((m, i) => (
              <div key={i} style={{ display: 'flex', gap: 8, flexDirection: m.role === 'user' ? 'row-reverse' : 'row' }}>
                <div style={{ width: 28, height: 28, borderRadius: 9, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: m.role === 'user' ? 'rgba(59,130,246,0.12)' : 'rgba(139,92,246,0.12)' }}>
                  {m.role === 'user' ? <UserIcon size={15} style={{ color: '#3b82f6' }} /> : <Bot size={15} style={{ color: '#8b5cf6' }} />}
                </div>
                <div style={{
                  maxWidth: '78%', padding: '9px 13px', borderRadius: 14, fontSize: 13, lineHeight: 1.7, whiteSpace: 'pre-wrap',
                  background: m.role === 'user' ? 'linear-gradient(135deg,#3b82f6,#6366f1)' : 'var(--surface-tertiary)',
                  color: m.role === 'user' ? '#fff' : 'var(--text-primary)',
                  opacity: m.pending ? 0.6 : 1,
                }}>
                  {m.text}
                </div>
              </div>
            ))}
          </div>

          {/* Suggestions */}
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', padding: '0 14px 10px' }}>
            {SUGGESTIONS.filter(s => !s.need || perms[s.need]).map(s => (
              <button key={s.q} onClick={() => send(s.q)} disabled={busy}
                style={{ fontSize: 11, fontWeight: 600, padding: '6px 11px', borderRadius: 999, cursor: 'pointer',
                  background: 'var(--surface-tertiary)', color: 'var(--text-secondary)', border: '1px solid var(--border-color)' }}>
                {s.q}
              </button>
            ))}
          </div>

          {/* Input */}
          <div style={{ display: 'flex', gap: 8, padding: 12, borderTop: '1px solid var(--border-color)' }}>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') send(input); }}
              placeholder="اكتب سؤالك…"
              disabled={busy}
              style={{ flex: 1, padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)',
                background: 'var(--surface-secondary)', color: 'var(--text-primary)', fontSize: 14, outline: 'none' }}
            />
            <motion.button whileTap={{ scale: 0.94 }} onClick={() => send(input)} disabled={busy || !input.trim()}
              style={{ width: 46, borderRadius: 12, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: 'linear-gradient(135deg,#6366f1,#8b5cf6)', color: '#fff', opacity: busy || !input.trim() ? 0.5 : 1 }}>
              <Send size={18} />
            </motion.button>
          </div>
        </div>
        <p style={{ fontSize: 10.5, color: 'var(--text-tertiary)', textAlign: 'center', margin: '10px 0 24px', lineHeight: 1.6 }}>
          الإجابات السريعة تُحسب محلياً من بياناتك. الأسئلة الحرّة تتطلّب ضبط خدمة الذكاء من إعدادات المدير.
        </p>
      </div>
    </div>
  );
};

export default AssistantPage;
