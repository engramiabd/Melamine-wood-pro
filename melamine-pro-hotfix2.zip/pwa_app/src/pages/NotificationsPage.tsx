import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bell, CheckCircle, AlertTriangle, Info,
  Factory, DollarSign, Users, Trash2, Check, Filter,
  ShoppingCart, XCircle,
} from 'lucide-react';
import { useAppData } from '../contexts/AppDataContext';
import { EmptyState } from '../components/ui/EmptyState';
import type { Notification } from '../contexts/AppDataContext';

type FilterType = 'all' | 'info' | 'warning' | 'success' | 'error';

const TYPE_CONFIG: Record<string, { icon: React.ReactNode; color: string; bg: string; label: string }> = {
  info:    { icon: <Info size={16} />,          color: 'text-blue-600',    bg: 'bg-blue-50',    label: 'معلومات' },
  success: { icon: <CheckCircle size={16} />,   color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'نجاح' },
  warning: { icon: <AlertTriangle size={16} />, color: 'text-amber-600',   bg: 'bg-amber-50',   label: 'تحذير' },
  error:   { icon: <XCircle size={16} />,       color: 'text-red-600',     bg: 'bg-red-50',     label: 'خطأ' },
};

const FILTER_TABS: { key: FilterType; label: string }[] = [
  { key: 'all',     label: 'الكل' },
  { key: 'warning', label: 'تحذيرات' },
  { key: 'success', label: 'نجاح' },
  { key: 'error',   label: 'أخطاء' },
  { key: 'info',    label: 'معلومات' },
];

const getRelativeTime = (iso: string): string => {
  const diff = Date.now() - new Date(iso).getTime();
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days  = Math.floor(diff / 86400000);
  if (mins < 1)   return 'الآن';
  if (mins < 60)  return `منذ ${mins} دقيقة`;
  if (hours < 24) return `منذ ${hours} ساعة`;
  if (days < 7)   return `منذ ${days} يوم`;
  return new Date(iso).toLocaleDateString('ar-SY');
};

// Role target to icon mapping
const getRoleIcon = (roleTarget: string): React.ReactNode => {
  if (roleTarget === 'production_supervisor' || roleTarget === 'manager') return <Factory size={16} className="text-indigo-600" />;
  if (roleTarget === 'hr') return <Users size={16} className="text-rose-600" />;
  if (roleTarget === 'accountant') return <DollarSign size={16} className="text-teal-600" />;
  if (roleTarget === 'admin') return <ShoppingCart size={16} className="text-purple-600" />;
  return null;
};

export const NotificationsPage: React.FC = () => {
  const {
    visibleNotifications, markNotificationRead, markAllNotificationsRead,
    deleteNotification, clearNotifications, unreadCount,
  } = useAppData();

  const [filter, setFilter] = useState<FilterType>('all');

  const filtered = filter === 'all'
    ? visibleNotifications
    : visibleNotifications.filter((n: Notification) => n.type === filter);

  const handleClick = (notif: Notification) => {
    markNotificationRead(notif.id);
  };

  return (
    <div className="min-h-full bg-gray-50 pb-10" dir="rtl">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-lg font-black text-gray-900">الإشعارات</h1>
            {unreadCount > 0 && (
              <p className="text-xs text-gray-400 mt-0.5">{unreadCount} إشعار غير مقروء</p>
            )}
          </div>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                onClick={markAllNotificationsRead}
                className="flex items-center gap-1.5 text-xs text-blue-600 font-bold px-3 py-1.5 bg-blue-50 rounded-xl"
              >
                <Check size={12} /> قراءة الكل
              </button>
            )}
            {visibleNotifications.length > 0 && (
              <button
                onClick={clearNotifications}
                className="flex items-center gap-1.5 text-xs text-red-500 font-bold px-3 py-1.5 bg-red-50 rounded-xl"
              >
                <Trash2 size={12} /> مسح الكل
              </button>
            )}
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {FILTER_TABS.map(t => {
            const count = t.key === 'all'
              ? visibleNotifications.length
              : visibleNotifications.filter((n: Notification) => n.type === t.key).length;
            return (
              <button
                key={t.key}
                onClick={() => setFilter(t.key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-150 ${
                  filter === t.key
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-gray-100 text-gray-500'
                }`}
              >
                <Filter size={10} />
                {t.label}
                {count > 0 && (
                  <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-full ${
                    filter === t.key ? 'bg-white/20 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>{count}</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Stats Bar */}
      <div className="bg-white border-b border-gray-50 px-4 py-3">
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: 'الكل',      val: visibleNotifications.length,                                           color: 'text-gray-700',  bg: 'bg-gray-50' },
            { label: 'غير مقروء', val: unreadCount,                                                   color: 'text-blue-600',  bg: 'bg-blue-50' },
            { label: 'تحذيرات',   val: visibleNotifications.filter((n: Notification) => n.type === 'warning').length, color: 'text-amber-600', bg: 'bg-amber-50' },
            { label: 'أخطاء',     val: visibleNotifications.filter((n: Notification) => n.type === 'error').length,   color: 'text-red-600',   bg: 'bg-red-50' },
          ].map(s => (
            <div key={s.label} className={`${s.bg} rounded-xl p-2 text-center`}>
              <p className={`text-lg font-black ${s.color}`}>{s.val}</p>
              <p className="text-[10px] text-gray-400">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Notifications List */}
      <div className="px-4 py-3 space-y-2">
        <AnimatePresence>
          {filtered.length === 0 ? (
            <EmptyState
              icon={Bell}
              title="لا توجد إشعارات"
              description="جميع الإشعارات مقروءة أو محذوفة"
              action={{ label: 'عرض الكل', onClick: () => setFilter('all') }}
            />
          ) : (
            filtered.map((notif: Notification, i: number) => {
              const cfg = TYPE_CONFIG[notif.type] || TYPE_CONFIG.info;
              const roleIcon = getRoleIcon(notif.role_target);
              return (
                <motion.div
                  key={notif.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: 20, height: 0, marginBottom: 0 }}
                  transition={{ delay: i * 0.03, duration: 0.2 }}
                  onClick={() => handleClick(notif)}
                  className={`bg-white rounded-2xl border p-4 cursor-pointer transition-all duration-150 active:scale-[0.98] ${
                    !notif.is_read
                      ? 'border-blue-100 shadow-sm shadow-blue-50'
                      : 'border-gray-100'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Unread dot + Icon */}
                    <div className="relative shrink-0">
                      <div className={`w-10 h-10 ${cfg.bg} rounded-xl flex items-center justify-center ${cfg.color}`}>
                        {roleIcon || cfg.icon}
                      </div>
                      {!notif.is_read && (
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full border-2 border-white" />
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className={`text-sm font-bold leading-snug ${notif.is_read ? 'text-gray-700' : 'text-gray-900'}`}>
                          {notif.title}
                        </p>
                        <button
                          onClick={e => { e.stopPropagation(); deleteNotification(notif.id); }}
                          className="w-6 h-6 flex items-center justify-center text-gray-300 hover:text-red-400 transition-colors shrink-0 rounded-lg hover:bg-red-50"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-1 leading-relaxed line-clamp-2">
                        {notif.message}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <p className="text-[10px] text-gray-300">{getRelativeTime(notif.created_at)}</p>
                        <div className="flex items-center gap-2">
                          {!notif.is_read && (
                            <button
                              onClick={e => { e.stopPropagation(); markNotificationRead(notif.id); }}
                              className="text-[10px] text-blue-500 font-bold flex items-center gap-0.5"
                            >
                              <Check size={9} /> قراءة
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </div>

      <div className="h-6" />
    </div>
  );
};
