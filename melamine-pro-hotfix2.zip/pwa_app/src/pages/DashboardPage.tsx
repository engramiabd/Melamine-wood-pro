import React, { useState, useEffect, useMemo, useCallback, lazy, Suspense } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  PieChart, Pie, Cell, RadialBarChart, RadialBar, ResponsiveContainer, Tooltip,
} from 'recharts';
import { useAuth } from '../contexts/AuthContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAppData } from '../contexts/AppDataContext';
import { computeWorkerLoyalty, getLoyaltyConfig } from '../utils/loyalty';
import {
  DAYS_AR, MONTHS_AR, ORDER_STATUS, LINE_STATUS,
  greeting, fmtTime, fmtDate, relTime,
  LiveClock, PulseDot, AnimNum, ChartTooltip,
  MetricCard, QuickActionBtn, SectionTitle, StatusStrip,
} from './Dashboard/DashboardHelpers';
import { DashboardCharts } from './Dashboard/DashboardCharts';


/* ═══════════════════════════════════════════════════════════════════════════
   MAIN COMPONENT
═══════════════════════════════════════════════════════════════════════════ */
export const DashboardPage: React.FC = () => {
  const { user, hasRole } = useAuth();
  const { format, formatUSD } = useCurrency();
  const navigate = useNavigate();
  const {
    orders, productionLines, inventoryItems, journalEntries,
    employees, attendanceRecords, visibleNotifications: notifications, wallets,
    advanceRequests, markAllNotificationsRead, can,
  } = useAppData();

  const [chartTab, setChartTab] = useState<'revenue' | 'production' | 'attendance'>('revenue');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isOnline, setIsOnline] = useState(() => navigator.onLine);
  const [showNotif, setShowNotif] = useState(false);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  const handleRefresh = useCallback(() => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    if (navigator.vibrate) navigator.vibrate(10);
    setTimeout(() => setIsRefreshing(false), 1400);
  }, [isRefreshing]);

  /* ── Computed data ──────────────────────────────────────────────────── */
  const todayStr = useMemo(() => now.toISOString().split('T')[0], [now]);

  const stats = useMemo(() => {
    const active        = orders.filter(o => ['in_production', 'quality_check'].includes(o.status)).length;
    const pending       = orders.filter(o => o.status === 'pending').length;
    const completed     = orders.filter(o => o.status === 'completed').length;
    const completedToday = orders.filter(o => o.status === 'completed' && (o.completed_at || '').startsWith(todayStr)).length;
    const activeLines   = productionLines.filter(l => l.status === 'active').length;
    const stoppedLines  = productionLines.filter(l => l.status === 'stopped').length;
    const totalRev      = journalEntries.filter(e => e.type === 'income').reduce((s, e) => s + e.amount_usd, 0);
    const totalExp      = journalEntries.filter(e => e.type === 'expense').reduce((s, e) => s + e.amount_usd, 0);
    const lowStock      = inventoryItems.filter(i => i.stock_quantity <= i.reorder_level).length;
    const criticalStock = inventoryItems.filter(i => i.stock_quantity <= i.reorder_level * 0.5).length;
    const pendingAdv    = advanceRequests.filter(a => a.status === 'pending').length;
    const netProfit     = totalRev - totalExp;
    const margin        = totalRev > 0 ? ((netProfit / totalRev) * 100).toFixed(1) : '0.0';
    return { active, pending, completed, completedToday, activeLines, stoppedLines, totalRev, totalExp, netProfit, margin, lowStock, criticalStock, pendingAdv };
  }, [orders, productionLines, journalEntries, inventoryItems, advanceRequests, todayStr]);

  const attStats = useMemo(() => {
    const todayRecs = attendanceRecords.filter(a => a.date === todayStr);
    const present   = todayRecs.filter(a => a.status === 'present' || a.status === 'late').length;
    const late      = todayRecs.filter(a => a.status === 'late').length;
    const absent    = Math.max(0, employees.length - present);
    const total     = employees.length || 1;
    const pct       = Math.round((present / total) * 100);
    return { present, late, absent, total, pct };
  }, [attendanceRecords, employees, todayStr]);

  // Revenue & expense chart — last 7 days
  // Uses entry_date (the accounting date) consistently with JournalPage.
  // Demo base values are shown only when the app has NO journal entries at all
  // (pure demo mode with no real transactions recorded yet).
  const revenueData = useMemo(() => {
    const BASE_REV = [3200, 4100, 2800, 5200, 4800, 6100, 4700];
    const BASE_EXP = [1800, 2200, 1600, 2900, 2500, 3100, 2400];
    const hasRealData = journalEntries.length > 0;
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(now);
      d.setDate(d.getDate() - (6 - i));
      const ds      = d.toISOString().split('T')[0];
      const dayName = i === 6 ? 'اليوم' : DAYS_AR[d.getDay()];
      const rev     = journalEntries.filter(e => e.type === 'income'  && e.entry_date === ds).reduce((s, e) => s + e.amount_usd, 0);
      const exp     = journalEntries.filter(e => e.type === 'expense' && e.entry_date === ds).reduce((s, e) => s + e.amount_usd, 0);
      return {
        day: dayName,
        rev: hasRealData ? rev : BASE_REV[i],
        exp: hasRealData ? exp : BASE_EXP[i],
        profit: hasRealData ? rev - exp : BASE_REV[i] - BASE_EXP[i],
      };
    });
  }, [journalEntries, now]);

  // Production chart
  const productionData = useMemo(() =>
    productionLines.map(l => ({
      name:   l.code || l.name.substring(0, 8),
      actual: l.total_produced_today  || 0,
      target: l.capacity_per_day      || 200,
      defect: l.total_defective_today || 0,
    }))
  , [productionLines]);

  // Attendance chart — last 7 days
  const attChartData = useMemo(() =>
    Array.from({ length: 7 }, (_, i) => {
      const d = new Date(now);
      d.setDate(d.getDate() - (6 - i));
      const ds      = d.toISOString().split('T')[0];
      const recs    = attendanceRecords.filter(a => a.date === ds);
      const present = recs.filter(a => a.status === 'present' || a.status === 'late').length;
      const late    = recs.filter(a => a.status === 'late').length;
      return { day: i === 6 ? 'اليوم' : DAYS_AR[d.getDay()], present, late, absent: Math.max(0, employees.length - present) };
    })
  , [attendanceRecords, employees, now]);

  // Pie chart — order distribution
  const pieData = useMemo(() => {
    const counts: Record<string, number> = {};
    orders.forEach(o => { counts[o.status] = (counts[o.status] || 0) + 1; });
    const PIE_COLORS: Record<string, string> = {
      in_production: '#3b82f6', completed: '#10b981', pending: '#f59e0b',
      quality_check: '#8b5cf6', cancelled: '#ef4444', on_hold: '#6b7280',
    };
    return Object.entries(counts)
      .map(([k, v]) => ({ name: ORDER_STATUS[k]?.label || k, value: v, color: PIE_COLORS[k] || '#6b7280' }))
      .sort((a, b) => b.value - a.value);
  }, [orders]);

  // Low stock
  const lowStockItems = useMemo(() =>
    inventoryItems.filter(i => i.stock_quantity <= i.reorder_level).sort((a, b) => a.stock_quantity / a.reorder_level - b.stock_quantity / b.reorder_level).slice(0, 4)
  , [inventoryItems]);

  // Recent orders
  const recentOrders = useMemo(() =>
    [...orders].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).slice(0, 5)
  , [orders]);

  // Wallet total
  const totalWalletBalance = useMemo(() => wallets.reduce((s, w) => s + w.balanceUSD, 0), [wallets]);

  // Unread notifications
  const unreadNotifs = useMemo(() => notifications.filter(n => !n.is_read), [notifications]);

  // Activity feed
  const activityFeed = useMemo(() => {
    const feed: Array<{ icon: React.ReactNode; text: string; time: string; accent: string; light: string }> = [];

    [...orders].filter(o => o.status === 'completed')
      .sort((a, b) => new Date(b.updated_at || b.created_at).getTime() - new Date(a.updated_at || a.created_at).getTime())
      .slice(0, 2).forEach(o => feed.push({
        icon: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>,
        text: `اكتمل طلب ${o.customer_name} • ${o.order_number}`,
        time: relTime(o.updated_at || o.created_at),
        accent: 'bg-emerald-500', light: 'bg-emerald-50 text-emerald-700',
      }));

    orders.filter(o => o.status === 'pending').slice(0, 1).forEach(o => feed.push({
      icon: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><rect x="3" y="3" width="18" height="18" rx="3"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>,
      text: `طلب جديد من ${o.customer_name} ينتظر الموافقة`,
      time: relTime(o.created_at),
      accent: 'bg-blue-500', light: 'bg-blue-50 text-blue-700',
    }));

    productionLines.filter(l => l.status === 'stopped').slice(0, 1).forEach(l => feed.push({
      icon: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>,
      text: `${l.name} متوقف — ${l.stop_reason || 'سبب غير محدد'}`,
      time: 'اليوم',
      accent: 'bg-red-500', light: 'bg-red-50 text-red-700',
    }));

    lowStockItems.slice(0, 1).forEach(item => feed.push({
      icon: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><rect x="2" y="14" width="6" height="7" rx="1"/><rect x="9" y="11" width="6" height="10" rx="1"/><rect x="16" y="8" width="6" height="13" rx="1"/></svg>,
      text: `مخزون ${item.name} منخفض • ${item.stock_quantity} ${item.unit}`,
      time: 'اليوم',
      accent: 'bg-amber-500', light: 'bg-amber-50 text-amber-700',
    }));

    unreadNotifs.slice(0, 1).forEach(n => feed.push({
      icon: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>,
      text: n.title,
      time: relTime(n.created_at),
      accent: 'bg-violet-500', light: 'bg-violet-50 text-violet-700',
    }));

    return feed.slice(0, 6);
  }, [orders, productionLines, lowStockItems, unreadNotifs]);

  // Quick actions based on role
  const quickActions = useMemo(() => [
    hasRole(['admin', 'manager']) && {
      icon: (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>),
      label: 'طلب جديد', sub: 'إضافة طلب',
      gradient: 'bg-gradient-to-br from-blue-500 to-indigo-600',
      path: '/orders/new', badge: stats.pending,
    },
    hasRole(['admin', 'manager', 'production_supervisor']) && {
      icon: (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/><line x1="12" y1="12" x2="12" y2="16"/><line x1="10" y1="14" x2="14" y2="14"/></svg>),
      label: 'الإنتاج', sub: 'خطوط الإنتاج',
      gradient: 'bg-gradient-to-br from-violet-500 to-purple-700',
      path: '/production-lines', badge: stats.stoppedLines > 0 ? stats.stoppedLines : undefined,
    },
    hasRole(['admin', 'manager', 'production_supervisor']) && {
      icon: (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="14" width="6" height="7" rx="1"/><rect x="9" y="11" width="6" height="10" rx="1"/><rect x="16" y="8" width="6" height="13" rx="1"/></svg>),
      label: 'المخزون', sub: 'إدارة المواد',
      gradient: 'bg-gradient-to-br from-emerald-500 to-teal-600',
      path: '/inventory', badge: stats.lowStock > 0 ? stats.lowStock : undefined,
    },
    hasRole(['admin', 'accountant', 'manager']) && {
      icon: (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><line x1="9" y1="9" x2="15" y2="9"/><line x1="9" y1="13" x2="13" y2="13"/></svg>),
      label: 'السجل', sub: 'القيود المحاسبية',
      gradient: 'bg-gradient-to-br from-amber-500 to-orange-600',
      path: '/journal',
    },
    {
      icon: (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>),
      label: 'الحضور', sub: 'تسجيل دخول',
      gradient: 'bg-gradient-to-br from-cyan-500 to-sky-600',
      path: '/attendance',
    },
    hasRole(['admin', 'manager']) && {
      icon: (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>),
      label: 'محافظ', sub: 'إدارة السلف',
      gradient: 'bg-gradient-to-br from-rose-500 to-pink-600',
      path: '/wallet', badge: stats.pendingAdv > 0 ? stats.pendingAdv : undefined,
    },
  ].filter(Boolean) as { icon: React.ReactNode; label: string; sub: string; gradient: string; path: string; badge?: number }[], [hasRole, stats]);

  const weekRev    = revenueData.reduce((s, d) => s + d.rev, 0);
  const weekExp    = revenueData.reduce((s, d) => s + d.exp, 0);
  const weekProfit = weekRev - weekExp;
  const profitPct  = weekRev > 0 ? ((weekProfit / weekRev) * 100).toFixed(1) : '0.0';

  // Worker-facing stats (shown instead of financials to non-finance roles).
  const canFinance = can('finance.view');
  const myLoyalty = useMemo(
    () => (user ? computeWorkerLoyalty(user.id, attendanceRecords, getLoyaltyConfig()) : null),
    [user, attendanceRecords],
  );
  const myMonthAttendance = useMemo(() => {
    if (!user) return { present: 0, total: 0 };
    const ym = new Date().toISOString().slice(0, 7);
    const mine = attendanceRecords.filter(a => a.worker_id === user.id && (a.date || '').slice(0, 7) === ym);
    return { present: mine.filter(a => a.status === 'present' || a.status === 'late').length, total: mine.length };
  }, [user, attendanceRecords]);

  useEffect(() => {
    if (!canFinance && chartTab === 'revenue') setChartTab('production');
  }, [canFinance, chartTab]);

  /* ─────────────────────────────────────────────────────────────────────── */
  return (
    <div style={{ background: 'linear-gradient(180deg, #f0f4ff 0%, #f4f6fb 120px)' }} dir="rtl">

      {/* ══ HERO BANNER ════════════════════════════════════════════════════ */}
      <div className="relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #1d4ed8 0%, #1e40af 40%, #312e81 100%)' }}>
        {/* Background patterns */}
        <div className="absolute inset-0 opacity-[0.06]" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }} />
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-blue-400/10 blur-2xl" />
        <div className="absolute top-10 -left-16 w-56 h-56 rounded-full bg-indigo-300/10 blur-2xl" />
        <div className="absolute bottom-0 right-1/2 w-40 h-40 rounded-full bg-purple-400/10 blur-xl" />

        <div className="relative px-4 pt-4 pb-8">
          {/* Top row */}
          <div className="flex items-start justify-between mb-5">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-blue-300 text-[12px] font-medium">{greeting()}،</span>
                {isOnline
                  ? <div className="flex items-center gap-1"><PulseDot color="bg-emerald-400" size={1.5} /><span className="text-[10px] text-emerald-400 font-semibold">متصل</span></div>
                  : <div className="flex items-center gap-1"><span className="w-2 h-2 bg-red-400 rounded-full" /><span className="text-[10px] text-red-400 font-semibold">غير متصل</span></div>
                }
              </div>
              <h2 className="text-[20px] font-black text-white leading-tight truncate">{user?.full_name}</h2>
              <div className="flex items-center gap-1.5 mt-1">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#93c5fd" strokeWidth="2.5"><rect x="3" y="4" width="18" height="18" rx="2.5"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                <span className="text-blue-200/60 text-[11px]">{fmtDate(now)}</span>
                <span className="text-blue-400/30">·</span>
                <LiveClock />
              </div>
            </div>

            <div className="flex items-center gap-2 flex-shrink-0">
              {/* Notification bell */}
              <button
                onClick={() => setShowNotif(v => !v)}
                className="relative w-9 h-9 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/15 active:bg-white/20 transition-colors"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                </svg>
                {unreadNotifs.length > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[16px] h-4 bg-red-500 rounded-full border-2 border-blue-800 flex items-center justify-center text-[9px] font-black text-white px-0.5">
                    {unreadNotifs.length > 9 ? '9+' : unreadNotifs.length}
                  </span>
                )}
              </button>
              {/* Refresh */}
              <button
                onClick={handleRefresh}
                className="w-9 h-9 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center border border-white/15 active:bg-white/20 transition-colors"
              >
                <motion.svg
                  width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2"
                  strokeLinecap="round" strokeLinejoin="round"
                  animate={{ rotate: isRefreshing ? 360 : 0 }}
                  transition={{ duration: 0.8, ease: 'linear', repeat: isRefreshing ? Infinity : 0 }}
                >
                  <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                  <path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>
                </motion.svg>
              </button>
            </div>
          </div>

          {/* Status strip — 3 mini cards */}
          <StatusStrip items={[
            {
              label: 'طلبات نشطة', value: <AnimNum value={stats.active} />,
              icon: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><rect x="3" y="3" width="18" height="18" rx="3"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>,
              bg: 'bg-gradient-to-br from-blue-400/25 to-blue-600/15 border-blue-400/20', text: 'text-white',
            },
            {
              label: 'خطوط نشطة', value: <>{stats.activeLines}<span className="text-[10px] opacity-60">/{productionLines.length}</span></>,
              icon: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>,
              bg: 'bg-gradient-to-br from-violet-400/25 to-violet-600/15 border-violet-400/20', text: 'text-white',
            },
            {
              label: 'الحضور اليوم', value: <>{attStats.present}<span className="text-[10px] opacity-60">/{attStats.total}</span></>,
              icon: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>,
              bg: 'bg-gradient-to-br from-emerald-400/25 to-emerald-600/15 border-emerald-400/20', text: 'text-white',
            },
          ]} />
        </div>

        {/* Wave divider */}
        <svg viewBox="0 0 390 28" fill="#f0f4ff" xmlns="http://www.w3.org/2000/svg" className="w-full block" style={{ marginBottom: -1 }}>
          <path d="M0 28 C130 0 260 0 390 28 L390 28 L0 28Z" />
        </svg>
      </div>

      {/* ══ NOTIFICATION PANEL ═══════════════════════════════════════════ */}
      <AnimatePresence>
        {showNotif && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowNotif(false)} className="fixed inset-0 z-40 bg-black/20 backdrop-blur-[2px]" />
            <motion.div
              initial={{ opacity: 0, y: -12, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -12, scale: 0.96 }}
              transition={{ type: 'spring', stiffness: 400, damping: 30 }}
              className="fixed top-[58px] left-3 right-3 z-50 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden"
              dir="rtl"
            >
              <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" strokeWidth="2.5"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                  <span className="font-bold text-gray-800 text-[13px]">الإشعارات</span>
                  {unreadNotifs.length > 0 && (
                    <span className="text-[10px] font-black px-1.5 py-0.5 bg-blue-500 text-white rounded-full">{unreadNotifs.length}</span>
                  )}
                </div>
                <button onClick={() => { markAllNotificationsRead(); setShowNotif(false); }} className="text-blue-600 text-[11px] font-bold px-2 py-1 bg-blue-50 rounded-lg">قراءة الكل</button>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.slice(0, 6).map(n => {
                  const C = { success: '#10b981', error: '#ef4444', warning: '#f59e0b', info: '#3b82f6' }[n.type] || '#3b82f6';
                  return (
                    <div key={n.id} className={`flex items-start gap-3 px-4 py-3 border-b border-gray-50 last:border-0 transition-colors ${!n.is_read ? 'bg-blue-50/60' : ''}`}>
                      <div className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ background: n.is_read ? '#cbd5e1' : C }} />
                      <div className="flex-1 min-w-0">
                        <p className="text-[12px] font-semibold text-gray-800">{n.title}</p>
                        <p className="text-[10px] text-gray-500 mt-0.5 leading-relaxed line-clamp-2">{n.message}</p>
                        <p className="text-[10px] text-gray-400 mt-1">{relTime(n.created_at)}</p>
                      </div>
                    </div>
                  );
                })}
                {notifications.length === 0 && (
                  <div className="py-8 text-center">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" strokeWidth="1.5" className="mx-auto mb-2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                    <p className="text-gray-400 text-sm">لا توجد إشعارات</p>
                  </div>
                )}
              </div>
              {notifications.length > 6 && (
                <button onClick={() => { setShowNotif(false); navigate('/notifications'); }}
                  className="w-full py-3 text-blue-600 text-[12px] font-bold border-t border-gray-100 bg-gray-50 hover:bg-gray-100 transition-colors">
                  عرض كل الإشعارات ({notifications.length})
                </button>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ══ MAIN CONTENT ═════════════════════════════════════════════════ */}
      <div className="px-4 space-y-5 -mt-1" style={{ paddingBottom: 16 }}>

        {/* ── KPI GRID ────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 gap-3">
          {canFinance && (
          <MetricCard
            label="إيرادات الأسبوع"
            value={<span className="text-[20px]">{format(weekRev)}</span>}
            sub={`هامش الربح ${profitPct}%`}
            icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>}
            gradient="bg-gradient-to-br from-emerald-50 via-green-50 to-teal-50"
            trend={{ val: 12, positive: true }}
            onClick={() => navigate('/finance')} delay={0}
          />
          )}
          {can('orders.view') && (
          <MetricCard
            label="طلبات معلقة"
            value={<AnimNum value={stats.pending} />}
            sub={`${stats.completedToday} مكتمل اليوم`}
            icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#d97706" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>}
            gradient="bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50"
            trend={{ val: stats.pending, positive: stats.pending === 0 }}
            onClick={() => navigate('/orders')} delay={0.06}
          />
          )}
          {canFinance && (
          <MetricCard
            label="مصاريف الأسبوع"
            value={<span className="text-[20px]">{format(weekExp)}</span>}
            sub={`صافي ${format(weekProfit)}`}
            icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>}
            gradient="bg-gradient-to-br from-red-50 via-rose-50 to-pink-50"
            onClick={() => navigate('/journal')} delay={0.12}
          />
          )}
          {can('inventory.view') && (
          <MetricCard
            label="المخزون المنخفض"
            value={<AnimNum value={stats.lowStock} />}
            sub={stats.criticalStock > 0 ? `${stats.criticalStock} حرجة` : 'لا يوجد حرجي'}
            icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="14" width="6" height="7" rx="1"/><rect x="9" y="11" width="6" height="10" rx="1"/><rect x="16" y="8" width="6" height="13" rx="1"/></svg>}
            gradient="bg-gradient-to-br from-violet-50 via-purple-50 to-fuchsia-50"
            trend={stats.lowStock > 0 ? { val: stats.lowStock, positive: false } : undefined}
            onClick={() => navigate('/inventory')} delay={0.18}
          />
          )}
          {!canFinance && myLoyalty && (
          <MetricCard
            label="نقاط الولاء"
            value={<AnimNum value={myLoyalty.totalPoints} />}
            sub={`${myLoyalty.tier.icon} ${myLoyalty.tier.name}`}
            icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15 9 22 9 17 14 19 21 12 17 5 21 7 14 2 9 9 9"/></svg>}
            gradient="bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50"
            onClick={() => navigate('/loyalty')} delay={0}
          />
          )}
          {!canFinance && (
          <MetricCard
            label="حضوري هذا الشهر"
            value={<span className="text-[20px]">{myMonthAttendance.present}/{myMonthAttendance.total}</span>}
            sub={`🔥 سلسلة ${myLoyalty?.currentStreak ?? 0} يوم`}
            icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>}
            gradient="bg-gradient-to-br from-blue-50 via-sky-50 to-cyan-50"
            onClick={() => navigate('/attendance')} delay={0.06}
          />
          )}
        </div>

        {/* ── QUICK ACTIONS ───────────────────────────────────────────── */}
        {quickActions.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-1 h-5 bg-blue-500 rounded-full" />
              <h3 className="font-bold text-gray-800 text-[14px]">إجراءات سريعة</h3>
            </div>
            <div className="grid grid-cols-3 gap-2.5">
              {quickActions.slice(0, 6).map((qa, i) => (
                <QuickActionBtn key={i} icon={qa.icon} label={qa.label} sub={qa.sub}
                  gradient={qa.gradient} onClick={() => navigate(qa.path)}
                  delay={0.04 + i * 0.04} badge={qa.badge}
                />
              ))}
            </div>
          </div>
        )}

        <DashboardCharts
          chartTab={chartTab}
          setChartTab={setChartTab}
          canFinance={canFinance}
          revenueData={revenueData}
          productionData={productionData}
          attChartData={attChartData}
          profitPct={profitPct}
          formatUSD={formatUSD}
          onNavigateReports={() => navigate('/reports')}
        />

        {/* ── PRODUCTION LINES ────────────────────────────────────────── */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-4 pt-4 pb-3 border-b border-gray-50">
            <SectionTitle
              icon={<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>}
              title="خطوط الإنتاج" accent="bg-violet-500"
              action={{ label: 'عرض الكل', onClick: () => navigate('/production-lines') }}
            />
          </div>
          <div>
            {productionLines.slice(0, 4).map((line, i) => {
              const cfg = LINE_STATUS[line.status as keyof typeof LINE_STATUS] || LINE_STATUS.idle;
              const eff = line.efficiency_percentage || 0;
              const produced = line.total_produced_today || 0;
              const target = line.capacity_per_day || 200;
              return (
                <motion.button key={line.id}
                  onClick={() => navigate('/production-lines')}
                  initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 + i * 0.06 }}
                  className="w-full flex items-center gap-3 px-4 py-3.5 text-right border-b border-gray-50 last:border-0 active:bg-gray-50 transition-colors"
                >
                  {/* Status avatar */}
                  <div className={`relative w-10 h-10 rounded-xl flex items-center justify-center text-xs font-black ring-2 ${cfg.ring} ${cfg.light} flex-shrink-0`}>
                    <span style={{ color: cfg.color }}>{line.code?.replace('LINE-', '') || (i + 1)}</span>
                    {cfg.pulse && (
                      <>
                        <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white animate-ping opacity-60" />
                        <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white" />
                      </>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[13px] font-semibold text-gray-800 truncate">{line.name}</span>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <span className="text-[10px] font-medium text-gray-400">{produced}/{target}</span>
                        <span className="text-[10px] font-bold" style={{ color: cfg.color }}>{cfg.label}</span>
                      </div>
                    </div>
                    {/* Efficiency bar */}
                    <div className="relative w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ background: `linear-gradient(90deg, ${cfg.color}cc, ${cfg.color})` }}
                        initial={{ width: 0 }}
                        animate={{ width: `${eff}%` }}
                        transition={{ delay: 0.3 + i * 0.1, duration: 0.9, ease: 'easeOut' }}
                      />
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-[9px] text-gray-400">الكفاءة</span>
                      <span className="text-[9px] font-bold text-gray-600">{eff}%</span>
                    </div>
                  </div>

                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" strokeWidth="2" className="flex-shrink-0 rotate-180"><polyline points="15 18 9 12 15 6" /></svg>
                </motion.button>
              );
            })}
            {productionLines.length === 0 && (
              <div className="py-8 text-center text-gray-400 text-sm">لا توجد خطوط إنتاج</div>
            )}
          </div>
        </div>

        {/* ── ORDERS + PIE ─────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {/* Recent orders — wider on desktop */}
          <div className="md:col-span-3 bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-4 pt-4 pb-3 border-b border-gray-50">
              <SectionTitle
                icon={<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><rect x="3" y="3" width="18" height="18" rx="3"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>}
                title="آخر الطلبات" accent="bg-blue-500"
                action={{ label: 'عرض الكل', onClick: () => navigate('/orders') }}
              />
            </div>
            <div>
              {recentOrders.map((order, i) => {
                const st = ORDER_STATUS[order.status] || ORDER_STATUS.pending;
                const isUrgent = order.priority === 'urgent';
                const dateStr = new Date(order.created_at).toLocaleDateString('ar-SY', { month: 'short', day: 'numeric' });
                return (
                  <motion.button key={order.id}
                    onClick={() => navigate(`/orders/${order.id}`)}
                    initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="w-full flex items-center gap-3 px-4 py-3 text-right border-b border-gray-50 last:border-0 active:bg-gray-50 transition-colors"
                  >
                    {/* Priority bar */}
                    <div className={`w-0.5 h-10 rounded-full flex-shrink-0 ${isUrgent ? 'bg-red-400' : order.priority === 'high' ? 'bg-amber-400' : 'bg-gray-200'}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-0.5">
                        <p className="text-[12px] font-semibold text-gray-800 truncate">{order.customer_name}</p>
                        <p className="text-[12px] font-bold text-gray-700 flex-shrink-0">{format(order.total_usd)}</p>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-[10px] text-gray-400">{order.order_number} · {dateStr}</p>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-md border font-semibold ${st.bg} ${st.text} ${st.border}`}>{st.label}</span>
                      </div>
                    </div>
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" strokeWidth="2" className="flex-shrink-0 rotate-180"><polyline points="15 18 9 12 15 6" /></svg>
                  </motion.button>
                );
              })}
              {recentOrders.length === 0 && (
                <div className="py-8 text-center text-gray-400 text-sm">لا توجد طلبات</div>
              )}
            </div>
          </div>

          {/* Pie Chart */}
          <div className="md:col-span-2 bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-4 pt-4 pb-3 border-b border-gray-50">
              <SectionTitle
                icon={<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>}
                title="توزيع الطلبات" accent="bg-violet-500"
              />
            </div>
            <div className="p-4">
              <div className="flex justify-center mb-3">
                <div className="relative">
                  <ResponsiveContainer width={120} height={120}>
                    <PieChart>
                      <Pie
                        data={pieData.length ? pieData : [{ name: 'لا يوجد', value: 1, color: 'var(--border-color)' }]}
                        cx="50%" cy="50%" innerRadius={38} outerRadius={55}
                        dataKey="value" startAngle={90} endAngle={-270} paddingAngle={2}
                      >
                        {(pieData.length ? pieData : [{ color: 'var(--border-color)' }]).map((entry, index) => (
                          <Cell key={index} fill={entry.color} strokeWidth={0} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  {/* Center label */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <p className="text-[18px] font-black text-gray-800">{orders.length}</p>
                    <p className="text-[9px] text-gray-400 font-medium">طلب</p>
                  </div>
                </div>
              </div>
              <div className="space-y-1.5">
                {pieData.slice(0, 5).map((d, i) => (
                  <div key={i} className="flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: d.color }} />
                      <span className="text-gray-600 truncate max-w-[80px]">{d.name}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-14 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${(d.value / orders.length) * 100}%`, background: d.color }} />
                      </div>
                      <span className="font-bold text-gray-800 w-4 text-center">{d.value}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── LOW STOCK ALERT ─────────────────────────────────────────── */}
        {lowStockItems.length > 0 && (
          <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200/60 rounded-3xl overflow-hidden">
            <div className="px-4 pt-4 pb-3 border-b border-amber-100/80">
              <SectionTitle
                icon={<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>}
                title="تنبيه المخزون" accent="bg-amber-500"
                action={{ label: 'إدارة', onClick: () => navigate('/inventory') }}
              />
            </div>
            <div className="p-4 space-y-3">
              {lowStockItems.map((item, i) => {
                const pct = Math.round((item.stock_quantity / item.max_quantity) * 100);
                const isCritical = item.stock_quantity <= item.reorder_level * 0.5;
                return (
                  <motion.div key={item.id}
                    initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.07 }}
                    className="flex items-center gap-3"
                  >
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${isCritical ? 'bg-red-100' : 'bg-amber-100'}`}>
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={isCritical ? '#ef4444' : '#d97706'} strokeWidth="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></svg>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[12px] font-semibold text-gray-800 truncate">{item.name}</span>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          {isCritical && <span className="text-[9px] font-black text-red-600 bg-red-100 px-1.5 py-0.5 rounded-md">حرج</span>}
                          <span className={`text-[10px] font-bold ${isCritical ? 'text-red-600' : 'text-amber-600'}`}>{item.stock_quantity} {item.unit}</span>
                        </div>
                      </div>
                      <div className="relative w-full h-1.5 bg-white/60 rounded-full overflow-hidden">
                        <motion.div
                          className={`h-full rounded-full ${isCritical ? 'bg-red-500' : 'bg-amber-500'}`}
                          initial={{ width: 0 }}
                          animate={{ width: `${Math.max(pct, 3)}%` }}
                          transition={{ delay: 0.3 + i * 0.1, duration: 0.8, ease: 'easeOut' }}
                        />
                        {/* Reorder line indicator */}
                        <div className="absolute top-0 bottom-0 w-px bg-gray-400/50"
                          style={{ right: `${100 - Math.round((item.reorder_level / item.max_quantity) * 100)}%` }} />
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── WALLET SUMMARY ──────────────────────────────────────────── */}
        {hasRole(['admin', 'manager', 'hr', 'accountant']) && wallets.length > 0 && (
          <div className="relative overflow-hidden rounded-3xl shadow-lg" style={{ background: 'linear-gradient(135deg, #059669 0%, #0d9488 50%, #0e7490 100%)' }}>
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 30% 50%, white 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
            <div className="absolute -top-8 -left-8 w-32 h-32 rounded-full bg-white/10 blur-xl" />
            <div className="relative p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center">
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="20" height="14" rx="2.5"/><path d="M2 10h20"/><path d="M14 15h4"/></svg>
                  </div>
                  <div>
                    <p className="text-white font-bold text-[14px]">محافظ العمال</p>
                    <p className="text-white/60 text-[10px]">{wallets.length} محفظة نشطة</p>
                  </div>
                </div>
                <button onClick={() => navigate('/wallet')}
                  className="text-white text-[11px] font-bold bg-white/15 rounded-xl px-3 py-2 border border-white/20 active:bg-white/25 transition-colors">
                  إدارة
                </button>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-white/10 rounded-2xl p-3 text-center border border-white/15">
                  <p className="text-white/60 text-[9px] font-medium mb-1">إجمالي الأرصدة</p>
                  <p className="text-white font-black text-[15px] tabular-nums">{format(totalWalletBalance)}</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-3 text-center border border-white/15">
                  <p className="text-white/60 text-[9px] font-medium mb-1">سلف معلقة</p>
                  <p className="text-white font-black text-[15px]">{stats.pendingAdv}</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-3 text-center border border-white/15">
                  <p className="text-white/60 text-[9px] font-medium mb-1">عدد العمال</p>
                  <p className="text-white font-black text-[15px]">{employees.length}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── ATTENDANCE SUMMARY ──────────────────────────────────────── */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-4 pt-4 pb-3 border-b border-gray-50">
            <SectionTitle
              icon={<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>}
              title="الحضور اليوم" accent="bg-cyan-500"
              action={{ label: 'لوحة الحضور', onClick: () => navigate('/attendance/dashboard') }}
            />
          </div>
          <div className="p-4">
            {/* Attendance rate circle */}
            <div className="flex items-center gap-4 mb-4">
              <div className="relative w-20 h-20 flex-shrink-0">
                <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                  <circle cx="18" cy="18" r="15.9" fill="none" stroke="var(--border-color)" strokeWidth="3" />
                  <motion.circle cx="18" cy="18" r="15.9" fill="none"
                    stroke={attStats.pct >= 80 ? '#10b981' : attStats.pct >= 60 ? '#f59e0b' : '#ef4444'}
                    strokeWidth="3" strokeLinecap="round"
                    strokeDasharray="100 100"
                    initial={{ strokeDashoffset: 100 }}
                    animate={{ strokeDashoffset: 100 - attStats.pct }}
                    transition={{ duration: 1.2, ease: 'easeOut' }}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <p className="text-[18px] font-black text-gray-800">{attStats.pct}%</p>
                </div>
              </div>
              <div className="flex-1 grid grid-cols-2 gap-2">
                {[
                  { label: 'حاضر', value: attStats.present, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                  { label: 'غائب', value: attStats.absent, color: 'text-red-600', bg: 'bg-red-50' },
                  { label: 'متأخر', value: attStats.late, color: 'text-amber-600', bg: 'bg-amber-50' },
                  { label: 'الإجمالي', value: attStats.total, color: 'text-gray-600', bg: 'bg-gray-50' },
                ].map((item, i) => (
                  <div key={i} className={`${item.bg} rounded-xl p-2 text-center`}>
                    <p className={`text-[16px] font-black ${item.color}`}>{item.value}</p>
                    <p className="text-[9px] text-gray-400 font-medium">{item.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── ACTIVITY FEED ───────────────────────────────────────────── */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-4 pt-4 pb-3 border-b border-gray-50">
            <SectionTitle
              icon={<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>}
              title="سجل النشاط" accent="bg-slate-500"
              action={{ label: 'الكل', onClick: () => navigate('/notifications') }}
            />
          </div>
          <div className="p-4 relative">
            {/* Timeline line */}
            <div className="absolute right-[30px] top-6 bottom-6 w-px bg-gray-100" />
            <div className="space-y-3">
              {activityFeed.map((act, i) => (
                <motion.div key={i}
                  initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                  className="flex items-start gap-3 relative"
                >
                  <div className={`relative z-10 w-8 h-8 ${act.accent} rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm border border-white/20`}>
                    <div className="text-white">{act.icon}</div>
                  </div>
                  <div className="flex-1 min-w-0 bg-gray-50/60 rounded-2xl px-3 py-2.5 border border-gray-100/60">
                    <p className="text-[12px] text-gray-700 font-medium leading-snug">{act.text}</p>
                    <p className={`text-[10px] mt-1 font-semibold ${act.light.split(' ')[1]}`}>{act.time}</p>
                  </div>
                </motion.div>
              ))}
              {activityFeed.length === 0 && (
                <div className="py-6 text-center text-gray-400 text-sm">لا يوجد نشاط حديث</div>
              )}
            </div>
          </div>
        </div>

        {/* ── FINANCIAL SUMMARY ───────────────────────────────────────── */}
        {hasRole(['admin', 'manager', 'accountant']) && (
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl p-4 text-white shadow-lg relative overflow-hidden">
              <div className="absolute -bottom-4 -left-4 w-20 h-20 rounded-full bg-white/10" />
              <p className="text-white/70 text-[10px] font-medium mb-1">الإيرادات الكلية</p>
              <p className="text-white font-black text-[17px] leading-tight">{format(stats.totalRev)}</p>
              <div className="flex items-center gap-1 mt-2">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#86efac" strokeWidth="2.5"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/></svg>
                <span className="text-green-300 text-[10px] font-bold">ارتفع 12%</span>
              </div>
            </div>
            <div className="bg-gradient-to-br from-slate-700 to-slate-900 rounded-2xl p-4 text-white shadow-lg relative overflow-hidden">
              <div className="absolute -bottom-4 -left-4 w-20 h-20 rounded-full bg-white/5" />
              <p className="text-white/70 text-[10px] font-medium mb-1">صافي الربح</p>
              <p className={`font-black text-[17px] leading-tight ${stats.netProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{format(Math.abs(stats.netProfit))}</p>
              <div className="flex items-center gap-1 mt-2">
                <span className="text-white/50 text-[10px]">هامش</span>
                <span className={`text-[10px] font-bold ${Number(stats.margin) >= 20 ? 'text-emerald-400' : 'text-amber-400'}`}>{stats.margin}%</span>
              </div>
            </div>
          </div>
        )}

        <div style={{ height: 8 }} />
      </div>
    </div>
  );
};

export default React.memo(DashboardPage);
