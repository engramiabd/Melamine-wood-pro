import React, { useState, useRef, useCallback } from 'react';
import { Switch } from '../components/ui/Switch';
import { StorageMonitor } from '../components/ui/StorageMonitor';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Shield, Users, Settings, Database, Activity,
  Bell, Lock, BarChart2, CheckCircle, XCircle,
  RefreshCw, Trash2, Edit3, Plus, Eye, EyeOff,
  Server, Download, Upload, Clock, TrendingUp,
  AlertTriangle, Package, DollarSign, MapPin, Crosshair, Loader2,
  FileText, RotateCcw
} from 'lucide-react';
import { useCurrency } from '../contexts/CurrencyContext';
import { geoPreflight, geoErrorMessage, GEO_OPTIONS } from '../utils/geo';
import { fetchUsdToSypRate } from '../utils/exchangeRate';
import { useAuth } from '../contexts/AuthContext';
import { useAppData } from '../contexts/AppDataContext';
import { UserRole } from '../types';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter, CenterModal } from '../components/ui/Modal';
import {
  LogLevelIcon, IconShield, IconBriefcase, IconFactory, IconHardHat, IconJournal, IconHR
} from '../components/ui/Icons';

type AdminTab = 'overview' | 'users' | 'system' | 'logs';

interface SystemLog {
  id: string;
  level: 'info' | 'warning' | 'error' | 'success';
  message: string;
  user: string;
  timestamp: string;
  module: string;
}

const WORKER_NAMES: Record<string, string> = {
  'demo-admin-001': 'أحمد المدير',
  'demo-manager-002': 'محمد المشرف',
  'demo-supervisor-003': 'خالد المراقب',
  'demo-worker-004': 'علي العامل',
  'demo-accountant-005': 'سمر المحاسبة',
  'demo-hr-006': 'ريم الموارد البشرية',
};

const WORKER_AVATARS: Record<string, string> = {
  'demo-admin-001': 'from-red-500 to-rose-600',
  'demo-manager-002': 'from-blue-500 to-indigo-600',
  'demo-supervisor-003': 'from-emerald-500 to-teal-600',
  'demo-worker-004': 'from-amber-500 to-orange-600',
  'demo-accountant-005': 'from-purple-500 to-violet-600',
  'demo-hr-006': 'from-pink-500 to-rose-500',
};

const ROLE_LABELS: Record<UserRole, string> = {
  admin: 'مدير النظام', manager: 'مدير',
  production_supervisor: 'مشرف إنتاج', worker: 'عامل',
  accountant: 'محاسب', hr: 'موارد بشرية',
};

const ROLE_COLORS: Record<UserRole, string> = {
  admin: 'bg-red-100 text-red-700 border-red-200',
  manager: 'bg-blue-100 text-blue-700 border-blue-200',
  production_supervisor: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  worker: 'bg-amber-100 text-amber-700 border-amber-200',
  accountant: 'bg-purple-100 text-purple-700 border-purple-200',
  hr: 'bg-pink-100 text-pink-700 border-pink-200',
};

const ROLE_ICONS: Record<UserRole, React.ReactNode> = {
  admin: <IconShield size={13} />, manager: <IconBriefcase size={13} />,
  production_supervisor: <IconFactory size={13} />, worker: <IconHardHat size={13} />,
  accountant: <IconJournal size={13} />, hr: <IconHR size={13} />,
};

const logLevelConfig = {
  info: { color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200' },
  warning: { color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200' },
  error: { color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200' },
  success: { color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' },
};

function buildLogsFromContext(
  orders: ReturnType<typeof useAppData>['orders'],
  notifications: ReturnType<typeof useAppData>['notifications'],
  attendanceRecords: ReturnType<typeof useAppData>['attendanceRecords'],
): SystemLog[] {
  const logs: SystemLog[] = [];
  notifications.slice(0, 5).forEach((n, i) => {
    logs.push({
      id: `n-${i}`, level: n.type === 'error' ? 'error' : n.type === 'warning' ? 'warning' : n.type === 'success' ? 'success' : 'info',
      message: n.message, user: 'النظام', timestamp: n.created_at, module: 'الإشعارات',
    });
  });
  orders.slice(0, 3).forEach((o, i) => {
    logs.push({
      id: `o-${i}`, level: o.status === 'completed' ? 'success' : o.status === 'cancelled' ? 'error' : 'info',
      message: `طلب ${o.order_number} - ${o.customer_name} - ${o.status === 'completed' ? 'مكتمل' : o.status === 'pending' ? 'معلق' : 'قيد الإنتاج'}`,
      user: o.created_by, timestamp: o.created_at, module: 'الطلبات',
    });
  });
  attendanceRecords.slice(0, 3).forEach((r, i) => {
    logs.push({
      id: `a-${i}`,
      level: r.status === 'late' ? 'warning' : r.status === 'absent' ? 'error' : 'success',
      message: `تسجيل ${r.status === 'late' ? 'حضور متأخر' : r.status === 'absent' ? 'غياب' : 'حضور'} - ${r.date}`,
      user: r.worker_id, timestamp: r.created_at, module: 'الحضور',
    });
  });
  return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

// ── User Modal ──────────────────────────────────────────────────────────────────
const UserModal: React.FC<{
  emp: { id: string; user_id: string; position: string; is_active: boolean };
  onClose: () => void;
  onSave: (id: string, data: { is_active: boolean; userId?: string; newPassword?: string }) => void;
}> = ({ emp, onClose, onSave }) => {
  const name = WORKER_NAMES[emp.user_id] ?? emp.position;
  const grad = WORKER_AVATARS[emp.user_id] ?? 'from-gray-400 to-gray-600';
  const [saving, setSaving] = useState(false);
  const [isActive, setIsActive] = useState(emp.is_active);
  const [showPassword, setShowPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [saved, setSaved] = useState(false);

  const currentRole: UserRole = emp.user_id === 'demo-admin-001' ? 'admin'
    : emp.user_id === 'demo-manager-002' ? 'manager'
    : emp.user_id === 'demo-supervisor-003' ? 'production_supervisor'
    : emp.user_id === 'demo-worker-004' ? 'worker'
    : emp.user_id === 'demo-accountant-005' ? 'accountant' : 'hr';

  const handleSave = () => {
    setSaving(true);
    setTimeout(() => {
      onSave(emp.id, { is_active: isActive, userId: emp.user_id, newPassword: newPassword.length >= 6 ? newPassword : undefined });
      setSaving(false);
      setSaved(true);
      setTimeout(() => { setSaved(false); onClose(); }, 1000);
    }, 800);
  };

  return (
    <BottomSheetModal isOpen onClose={onClose} maxHeight="90dvh">
      <SheetHeader noPadding>
        <div className={`bg-gradient-to-r ${grad} px-5 pt-3 pb-5`}>
          <div className="flex items-center gap-3 mt-1">
            <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center text-white text-xl font-black border-2 border-white/30">
              {name.charAt(0)}
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-black text-white">{name}</h2>
              <p className="text-white/70 text-sm">{emp.position}</p>
              <span className="text-[10px] bg-white/20 text-white px-2 py-0.5 rounded-full mt-1 inline-block">
                {ROLE_LABELS[currentRole]}
              </span>
            </div>
            <button aria-label="إغلاق" onClick={onClose} className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center" style={{ minHeight: 'unset' }}>
              <XCircle size={16} className="text-white" />
            </button>
          </div>
        </div>
      </SheetHeader>

      <SheetBody>
        <AnimatePresence>
          {saved && (
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
              className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 flex items-center gap-2">
              <CheckCircle size={16} className="text-emerald-600" />
              <p className="text-sm font-bold text-emerald-700">تم حفظ التغييرات</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Role Display */}
        <div>
          <label className="text-xs font-bold text-gray-600 mb-2 flex items-center gap-1.5">
            <Shield size={12} /> الدور في النظام
          </label>
          <div className="grid grid-cols-2 gap-2">
            {(Object.entries(ROLE_LABELS) as [UserRole, string][]).map(([role, label]) => (
              <div key={role}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold border flex items-center gap-1.5 ${
                  role === currentRole ? `${ROLE_COLORS[role]} ring-2 ring-offset-1 ring-current` : 'border-gray-200 text-gray-400 bg-gray-50'
                }`}>
                {ROLE_ICONS[role]}{label}
              </div>
            ))}
          </div>
        </div>

        {/* Password Reset */}
        <div>
          <label className="text-xs font-bold text-gray-600 mb-2 flex items-center gap-1.5">
            <Lock size={12} /> إعادة تعيين كلمة المرور
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              placeholder="كلمة مرور جديدة..."
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm"
            />
            <button onClick={() => setShowPassword(!showPassword)} style={{ minHeight: 'unset' }}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
              {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
            </button>
          </div>
          {newPassword.length > 0 && newPassword.length < 6 && (
            <p className="text-xs text-red-500 mt-1">كلمة المرور يجب أن تكون 6 أحرف على الأقل</p>
          )}
        </div>

        {/* Status Toggle */}
        <div className="flex items-center justify-between bg-gray-50 rounded-xl px-4 py-3.5">
          <div>
            <p className="text-sm font-bold text-gray-700">حالة الحساب</p>
            <p className="text-xs text-gray-400">{isActive ? 'الحساب نشط ومفعّل' : 'الحساب معطل'}</p>
          </div>
          <Switch checked={isActive} onChange={setIsActive} color="emerald" size="md" />
        </div>

        {/* Account Info */}
        <div className="bg-blue-50 border border-blue-100 rounded-xl p-3">
          <p className="text-xs font-bold text-blue-700 mb-1.5 flex items-center gap-1.5">
            <Shield size={11} /> معلومات الحساب
          </p>
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-gray-500">معرف المستخدم</span>
              <span className="font-mono text-gray-700 text-[10px]">{emp.user_id}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-gray-500">الصلاحية</span>
              <span className="font-bold text-blue-700">{ROLE_LABELS[currentRole]}</span>
            </div>
          </div>
        </div>
      </SheetBody>

      <SheetFooter>
        <div className="grid grid-cols-2 gap-3">
          <button onClick={handleSave} disabled={saving}
            className="py-3.5 bg-blue-600 text-white rounded-xl text-sm font-bold disabled:opacity-60 flex items-center justify-center gap-2">
            {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <CheckCircle size={14} />}
            حفظ التغييرات
          </button>
          <button onClick={onClose}
            className="py-3.5 bg-gray-100 text-gray-700 rounded-xl text-sm font-bold flex items-center justify-center gap-2">
            إلغاء
          </button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

// ── Clear Data Confirm Modal ────────────────────────────────────────────────────
const ConfirmDestructiveModal: React.FC<{
  title: string; message: string; confirmLabel: string;
  onConfirm: () => void | Promise<void>; onClose: () => void;
}> = ({ title, message, confirmLabel, onConfirm, onClose }) => (
  <CenterModal isOpen onClose={onClose}>
    <div className="p-6 text-center" dir="rtl">
      <div className="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
        <Trash2 size={24} className="text-red-600" />
      </div>
      <h3 className="text-lg font-bold text-gray-900 mb-2">{title}</h3>
      <p className="text-sm text-gray-500 mb-6">{message}</p>
      <div className="flex gap-3">
        <button aria-label="إغلاق" onClick={onClose} className="flex-1 py-3 border border-gray-200 rounded-xl text-sm font-medium text-gray-600">إلغاء</button>
        <button onClick={() => { onConfirm(); onClose(); }} className="flex-1 py-3 bg-red-600 text-white rounded-xl text-sm font-bold">{confirmLabel}</button>
      </div>
    </div>
  </CenterModal>
);

// ── Main Admin Page ─────────────────────────────────────────────────────────────
export const AdminPage: React.FC = () => {
  const { exchangeRate, toggleCurrency, currency } = useCurrency();
  const { user } = useAuth();
  const {
    employees, orders, notifications, attendanceRecords,
    exportData, importData, clearAllData, resetToDemo,
    updateEmployee, updateSystemSettings, systemSettings,
    adminSetUserPassword,
    addNotification,
  } = useAppData();

  const [tab, setTab] = useState<AdminTab>('overview');
  const [selectedUser, setSelectedUser] = useState<{ id: string; user_id: string; position: string; is_active: boolean } | null>(null);
  const [logFilter, setLogFilter] = useState<'all' | 'info' | 'warning' | 'error' | 'success'>('all');
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [importing, setImporting] = useState(false);
  const [locatingFactory, setLocatingFactory] = useState(false);
  const [factoryGeoMsg, setFactoryGeoMsg] = useState('');

  const captureFactoryLocation = useCallback(() => {
    setFactoryGeoMsg('');
    const blocked = geoPreflight();
    if (blocked) { setFactoryGeoMsg(blocked); return; }
    setLocatingFactory(true);
    navigator.geolocation.getCurrentPosition(
      pos => {
        setLocalSettings(p => ({ ...p, factoryLat: +pos.coords.latitude.toFixed(6), factoryLng: +pos.coords.longitude.toFixed(6) }));
        setLocatingFactory(false);
        setFactoryGeoMsg('تم التقاط الموقع — اضغط حفظ لاعتماده');
      },
      err => { setLocatingFactory(false); setFactoryGeoMsg(geoErrorMessage(err)); },
      GEO_OPTIONS,
    );
  }, []);
  const fileRef = useRef<HTMLInputElement>(null);

  // Local settings state synced with systemSettings
  const [localSettings, setLocalSettings] = useState({
    factoryName: systemSettings.factoryName,
    factoryLat: systemSettings.factoryLat,
    factoryLng: systemSettings.factoryLng,
    exchangeRate: systemSettings.exchangeRate,
    currency: systemSettings.currency,
    attendanceRadius: systemSettings.attendanceRadius,
    workStartTime: systemSettings.workStartTime,
    workEndTime: systemSettings.workEndTime,
    lateThresholdMinutes: systemSettings.lateThresholdMinutes,
    maxAdvanceAmount: systemSettings.maxAdvanceAmount,
    payrollDay: systemSettings.payrollDay,
    taxRate: systemSettings.taxRate ?? 0,
    notifyNewOrder: systemSettings.notifyNewOrder,
    notifyLowStock: systemSettings.notifyLowStock,
    notifyAttendance: systemSettings.notifyAttendance,
  });

  const realLogs = buildLogsFromContext(orders, notifications, attendanceRecords);
  const filteredLogs = logFilter === 'all' ? realLogs : realLogs.filter(l => l.level === logFilter);

  // ── Live USD→SYP reference rate (admin reviews, then saves) ──────────────
  const [rateFetching, setRateFetching] = useState(false);
  const [rateNote, setRateNote] = useState('');
  const fetchLiveRate = useCallback(async () => {
    setRateFetching(true);
    setRateNote('جارٍ جلب السعر المرجعي…');
    const r = await fetchUsdToSypRate();
    setRateFetching(false);
    if (r) {
      setLocalSettings(p => ({ ...p, exchangeRate: r.rate }));
      setRateNote(`سعر مرجعي ${r.rate.toLocaleString()} (${r.source}) — راجِعه ثم اضغط حفظ`);
    } else {
      setRateNote('تعذّر الجلب (قد يكون بلا اتصال) — أبقِ السعر اليدوي');
    }
  }, []);

  const handleSaveSettings = useCallback(() => {
    setSaving(true);
    setTimeout(() => {
      updateSystemSettings({
        factoryName: localSettings.factoryName,
        factoryLat: localSettings.factoryLat,
        factoryLng: localSettings.factoryLng,
        exchangeRate: localSettings.exchangeRate,
        attendanceRadius: localSettings.attendanceRadius,
        workStartTime: localSettings.workStartTime,
        workEndTime: localSettings.workEndTime,
        lateThresholdMinutes: localSettings.lateThresholdMinutes,
        maxAdvanceAmount: localSettings.maxAdvanceAmount,
        payrollDay: localSettings.payrollDay,
        taxRate: localSettings.taxRate,
        notifyNewOrder: localSettings.notifyNewOrder,
        notifyLowStock: localSettings.notifyLowStock,
        notifyAttendance: localSettings.notifyAttendance,
      });
      setSaving(false);
      setSaveSuccess(true);
      addNotification({ title: 'تم حفظ الإعدادات', message: 'تم تحديث إعدادات النظام بنجاح', type: 'success', role_target: 'admin' });
      setTimeout(() => setSaveSuccess(false), 3000);
    }, 1000);
  }, [localSettings, updateSystemSettings, addNotification]);

  const handleImport = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    importData(file, () => setImporting(false));
    e.target.value = '';
  }, [importData]);

  const handleSaveUser = useCallback((id: string, data: { is_active: boolean; userId?: string; newPassword?: string }) => {
    updateEmployee(id, { is_active: data.is_active });
    if (data.newPassword && data.userId) adminSetUserPassword(data.userId, data.newPassword);
    addNotification({ title: 'تحديث المستخدم', message: 'تم تحديث بيانات المستخدم بنجاح', type: 'success', role_target: 'admin' });
  }, [updateEmployee, adminSetUserPassword, addNotification]);

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-8 text-center" dir="rtl">
        <div className="w-20 h-20 bg-red-100 rounded-3xl flex items-center justify-center mx-auto mb-4">
          <XCircle size={40} className="text-red-400" />
        </div>
        <h2 className="text-xl font-black text-gray-800 mb-2">غير مصرح بالوصول</h2>
        <p className="text-gray-400 text-sm">هذه الصفحة متاحة للمديرين فقط</p>
      </div>
    );
  }

  const totalOrders = orders.length;
  const completedOrders = orders.filter(o => o.status === 'completed').length;
  const totalRevenue = orders.filter(o => o.status === 'completed').reduce((s, o) => s + o.total_usd, 0);

  return (
    <div className="page-wrapper bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 px-4 pt-5 pb-0 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center">
              <Shield size={18} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-black text-white">لوحة الإدارة</h1>
              <p className="text-slate-400 text-xs">مرحباً، {user.full_name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-emerald-500/20 border border-emerald-500/30 px-3 py-1.5 rounded-full">
            <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
            <span className="text-emerald-300 text-xs font-bold">النظام يعمل</span>
          </div>
        </div>

        <div className="flex gap-0 overflow-x-auto scrollbar-hide">
          {[
            { value: 'overview', label: 'النظرة العامة', icon: BarChart2 },
            { value: 'users', label: 'المستخدمون', icon: Users },
            { value: 'system', label: 'الإعدادات', icon: Settings },
            { value: 'logs', label: 'السجلات', icon: Activity },
          ].map(t => {
            const Icon = t.icon;
            return (
              <button key={t.value} onClick={() => setTab(t.value as AdminTab)}
                className={`flex items-center gap-1.5 px-4 py-3 text-xs font-bold whitespace-nowrap border-b-2 transition-all ${
                  tab === t.value ? 'border-blue-400 text-blue-300' : 'border-transparent text-slate-400'
                }`}>
                <Icon size={13} />{t.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-4 py-4">
        <AnimatePresence mode="wait">

          {/* ── OVERVIEW ── */}
          {tab === 'overview' && (
            <motion.div key="overview" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
              {/* System Health */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="bg-gradient-to-r from-emerald-500 to-teal-600 px-4 py-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Server size={16} className="text-white" />
                    <span className="text-white font-bold text-sm">حالة النظام</span>
                  </div>
                  <span className="bg-white/20 text-white text-xs px-2 py-1 rounded-full font-bold">99.8% uptime</span>
                </div>
                <div className="p-4 grid grid-cols-2 gap-3">
                  {[
                    { label: 'قاعدة البيانات', status: 'متصل', color: 'emerald', Icon: Database },
                    { label: 'الخادم', status: 'يعمل', color: 'emerald', Icon: Server },
                    { label: 'الإشعارات', status: `${notifications.filter(n => !n.is_read).length} جديد`, color: 'blue', Icon: Bell },
                    { label: 'النسخ الاحتياطي', status: 'محدّث', color: 'blue', Icon: RefreshCw },
                  ].map(({ label, status, color, Icon }) => (
                    <div key={label} className={`flex items-center gap-2 bg-${color}-50 border border-${color}-100 rounded-xl p-3`}>
                      <div className={`w-8 h-8 bg-${color}-100 rounded-lg flex items-center justify-center`}>
                        <Icon size={14} className={`text-${color}-600`} />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-gray-700">{label}</p>
                        <p className={`text-xs text-${color}-600 font-medium`}>● {status}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Live Stats from real data */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'إجمالي الموظفين', value: employees.length, Icon: Users, bg: 'from-blue-500 to-indigo-600' },
                  { label: 'إجمالي الطلبات', value: totalOrders, Icon: FileText, bg: 'from-emerald-500 to-teal-600' },
                  { label: 'الإيرادات', value: `$${totalRevenue.toLocaleString()}`, Icon: DollarSign, bg: 'from-amber-500 to-orange-600' },
                  { label: 'مكتمل', value: `${completedOrders}/${totalOrders}`, Icon: CheckCircle, bg: 'from-purple-500 to-violet-600' },
                ].map(s => (
                  <div key={s.label} className={`bg-gradient-to-br ${s.bg} rounded-2xl p-4 text-white`}>
                    <div className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center mb-3">
                      <s.Icon size={18} className="text-white" />
                    </div>
                    <p className="text-xl font-black">{s.value}</p>
                    <p className="text-white/70 text-xs mt-0.5">{s.label}</p>
                  </div>
                ))}
              </div>

              {/* Recent Activity from real notifications */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                  <Activity size={14} className="text-blue-600" /> آخر النشاطات
                </h3>
                <div className="space-y-2">
                  {realLogs.slice(0, 5).map(log => {
                    const cfg = logLevelConfig[log.level];
                    const minAgo = Math.floor((Date.now() - new Date(log.timestamp).getTime()) / 60000);
                    return (
                      <div key={log.id} className={`flex items-center gap-3 p-2.5 ${cfg.bg} border ${cfg.border} rounded-xl`}>
                        <LogLevelIcon level={log.level} size={15} />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-gray-800 truncate">{log.message}</p>
                          <p className="text-[10px] text-gray-400">{log.module}</p>
                        </div>
                        <span className="text-[10px] text-gray-400 shrink-0">
                          {minAgo < 60 ? `${minAgo}د` : `${Math.floor(minAgo / 60)}س`}
                        </span>
                      </div>
                    );
                  })}
                  {realLogs.length === 0 && (
                    <p className="text-sm text-gray-400 text-center py-4">لا توجد نشاطات حديثة</p>
                  )}
                </div>
              </div>

              {/* Quick Actions — all connected to real functions */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                <h3 className="text-sm font-bold text-gray-700 mb-3">إجراءات سريعة</h3>
                <div className="grid grid-cols-2 gap-3">
                  <button onClick={exportData}
                    className="flex items-center gap-2 p-3 border border-blue-200 rounded-xl text-sm font-bold bg-blue-50 text-blue-700 active:scale-95 transition-transform">
                    <Download size={15} /> تصدير البيانات
                  </button>
                  <button onClick={() => fileRef.current?.click()} disabled={importing}
                    className="flex items-center gap-2 p-3 border border-emerald-200 rounded-xl text-sm font-bold bg-emerald-50 text-emerald-700 active:scale-95 transition-transform disabled:opacity-60">
                    {importing ? <div className="w-4 h-4 border-2 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin" /> : <Upload size={15} />}
                    استيراد بيانات
                  </button>
                  <button onClick={() => setShowResetConfirm(true)}
                    className="flex items-center gap-2 p-3 border border-purple-200 rounded-xl text-sm font-bold bg-purple-50 text-purple-700 active:scale-95 transition-transform">
                    <RotateCcw size={15} /> استعادة تجريبية
                  </button>
                  <button onClick={() => setShowClearConfirm(true)}
                    className="flex items-center gap-2 p-3 border border-red-200 rounded-xl text-sm font-bold bg-red-50 text-red-700 active:scale-95 transition-transform">
                    <Trash2 size={15} /> مسح البيانات
                  </button>
                </div>
                <input ref={fileRef} type="file" accept=".json" onChange={handleImport} className="hidden" />
              </div>

              {/* Storage usage monitor */}
              <StorageMonitor />
            </motion.div>
          )}

          {/* ── USERS ── */}
          {tab === 'users' && (
            <motion.div key="users" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-3">
              {/* Role summary */}
              <div className="grid grid-cols-3 gap-2">
                {(['admin', 'manager', 'worker'] as UserRole[]).map(role => {
                  const count = employees.filter(e => {
                    const r = e.user_id === 'demo-admin-001' ? 'admin'
                      : e.user_id === 'demo-manager-002' ? 'manager'
                      : e.user_id === 'demo-supervisor-003' ? 'production_supervisor'
                      : e.user_id === 'demo-worker-004' ? 'worker'
                      : e.user_id === 'demo-accountant-005' ? 'accountant' : 'hr';
                    return r === role;
                  }).length;
                  return (
                    <div key={role} className={`border rounded-2xl p-3 text-center ${ROLE_COLORS[role]}`}>
                      <div className="flex justify-center mb-1">{ROLE_ICONS[role]}</div>
                      <p className="text-xl font-black">{count || employees.length}</p>
                      <p className="text-[10px] mt-0.5 opacity-80">{ROLE_LABELS[role]}</p>
                    </div>
                  );
                })}
              </div>

              {/* Currency Toggle */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-bold text-gray-700">عملة العرض</p>
                    <p className="text-xs text-gray-400">العملة الحالية: {currency === 'USD' ? 'دولار أمريكي' : 'ليرة سورية'}</p>
                  </div>
                  <button onClick={toggleCurrency}
                    className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${currency === 'USD' ? 'bg-blue-600 text-white' : 'bg-amber-500 text-white'}`}>
                    {currency === 'USD' ? '$ USD' : 'ل.س SYP'}
                  </button>
                </div>
                <div className="mt-3 bg-gray-50 rounded-xl p-3 flex items-center justify-between">
                  <span className="text-xs text-gray-600">سعر الصرف الحالي</span>
                  <span className="text-sm font-black text-gray-800">{exchangeRate.toLocaleString()} ل.س/دولار</span>
                </div>
              </div>

              {/* Employee list */}
              {employees.map((emp, i) => {
                const name = WORKER_NAMES[emp.user_id] ?? emp.position;
                const grad = WORKER_AVATARS[emp.user_id] ?? 'from-gray-400 to-gray-600';
                const role: UserRole = emp.user_id === 'demo-admin-001' ? 'admin'
                  : emp.user_id === 'demo-manager-002' ? 'manager'
                  : emp.user_id === 'demo-supervisor-003' ? 'production_supervisor'
                  : emp.user_id === 'demo-worker-004' ? 'worker'
                  : emp.user_id === 'demo-accountant-005' ? 'accountant' : 'hr';

                return (
                  <motion.div key={emp.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                    className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div className="p-4 flex items-center gap-3">
                      <div className={`w-12 h-12 bg-gradient-to-br ${grad} rounded-xl flex items-center justify-center text-white font-black text-base shrink-0`}>
                        {name.charAt(0)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-bold text-gray-900 truncate">{name}</p>
                          <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${emp.is_active ? 'bg-emerald-500' : 'bg-red-400'}`} />
                        </div>
                        <p className="text-xs text-gray-400">{emp.position}</p>
                        <span className={`inline-flex items-center gap-1 mt-1 text-[10px] px-2 py-0.5 rounded-full font-bold border ${ROLE_COLORS[role]}`}>
                          {ROLE_ICONS[role]}{ROLE_LABELS[role]}
                        </span>
                      </div>
                      <button onClick={() => setSelectedUser(emp)}
                        className="w-9 h-9 bg-gray-100 rounded-xl flex items-center justify-center hover:bg-blue-50 transition-colors"
                        style={{ minHeight: 'unset' }}>
                        <Edit3 size={15} className="text-gray-500" />
                      </button>
                    </div>
                    <div className="px-4 pb-3 flex flex-wrap gap-1.5">
                      {role === 'admin' && ['كل الصلاحيات', 'الإدارة', 'التقارير'].map(p => (
                        <span key={p} className="text-[10px] bg-red-50 text-red-600 border border-red-200 px-2 py-0.5 rounded-full">{p}</span>
                      ))}
                      {role === 'manager' && ['الطلبات', 'الإنتاج', 'الموارد البشرية', 'التقارير'].map(p => (
                        <span key={p} className="text-[10px] bg-blue-50 text-blue-600 border border-blue-200 px-2 py-0.5 rounded-full">{p}</span>
                      ))}
                      {role === 'worker' && ['الحضور', 'المحفظة', 'الإنتاج'].map(p => (
                        <span key={p} className="text-[10px] bg-amber-50 text-amber-600 border border-amber-200 px-2 py-0.5 rounded-full">{p}</span>
                      ))}
                      {role === 'accountant' && ['السجل المحاسبي', 'التقارير المالية', 'المبيعات'].map(p => (
                        <span key={p} className="text-[10px] bg-purple-50 text-purple-600 border border-purple-200 px-2 py-0.5 rounded-full">{p}</span>
                      ))}
                      {role === 'hr' && ['الموظفون', 'الإجازات', 'الرواتب'].map(p => (
                        <span key={p} className="text-[10px] bg-pink-50 text-pink-600 border border-pink-200 px-2 py-0.5 rounded-full">{p}</span>
                      ))}
                      {role === 'production_supervisor' && ['الإنتاج', 'الطلبات', 'المخزون'].map(p => (
                        <span key={p} className="text-[10px] bg-emerald-50 text-emerald-600 border border-emerald-200 px-2 py-0.5 rounded-full">{p}</span>
                      ))}
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          )}

          {/* ── SYSTEM SETTINGS ── */}
          {tab === 'system' && (
            <motion.div key="system" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
              <AnimatePresence>
                {saveSuccess && (
                  <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
                    className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 flex items-center gap-3">
                    <CheckCircle size={18} className="text-emerald-600" />
                    <p className="text-sm font-bold text-emerald-700">تم حفظ الإعدادات بنجاح</p>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* General Settings */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                  <Settings size={13} className="text-gray-500" />
                  <h3 className="text-sm font-black text-gray-700">عام</h3>
                </div>
                <div className="divide-y divide-gray-50">
                  <div className="px-4 py-4">
                    <p className="text-sm font-bold text-gray-800 mb-1">اسم المصنع</p>
                    <input value={localSettings.factoryName}
                      onChange={e => setLocalSettings(p => ({ ...p, factoryName: e.target.value }))}
                      className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm" />
                  </div>
                  <div className="px-4 py-4">
                    <div className="flex items-center gap-1.5 mb-2">
                      <MapPin size={13} className="text-blue-600" />
                      <p className="text-sm font-bold text-gray-800">موقع المصنع (للحضور)</p>
                    </div>
                    <button onClick={captureFactoryLocation} disabled={locatingFactory}
                      className="w-full mb-2 px-3 py-2.5 bg-emerald-50 text-emerald-700 rounded-xl text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-60">
                      {locatingFactory ? <Loader2 size={15} className="animate-spin" /> : <Crosshair size={15} />}
                      {locatingFactory ? 'جارٍ تحديد الموقع…' : 'استخدام موقعي الحالي'}
                    </button>
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <label className="text-[11px] text-gray-500 mb-1 block">خط العرض</label>
                        <input type="number" step="any" value={localSettings.factoryLat}
                          onChange={e => setLocalSettings(p => ({ ...p, factoryLat: +e.target.value }))}
                          className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" dir="ltr" />
                      </div>
                      <div className="flex-1">
                        <label className="text-[11px] text-gray-500 mb-1 block">خط الطول</label>
                        <input type="number" step="any" value={localSettings.factoryLng}
                          onChange={e => setLocalSettings(p => ({ ...p, factoryLng: +e.target.value }))}
                          className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" dir="ltr" />
                      </div>
                    </div>
                    {factoryGeoMsg && <p className="text-[11px] mt-2 text-blue-700 bg-blue-50 rounded-lg px-3 py-1.5">{factoryGeoMsg}</p>}
                  </div>
                  <div className="px-4 py-4 flex flex-col gap-2.5">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="text-sm font-bold text-gray-800">سعر صرف الدولار</p>
                        <p className="text-xs text-gray-400">ليرة سورية / دولار أمريكي</p>
                      </div>
                      <input type="number" value={localSettings.exchangeRate}
                        onChange={e => setLocalSettings(p => ({ ...p, exchangeRate: +e.target.value }))}
                        className="w-28 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm text-center" />
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <button type="button" onClick={fetchLiveRate} disabled={rateFetching}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-600 text-xs font-bold rounded-lg disabled:opacity-60">
                        <RefreshCw size={13} className={rateFetching ? 'animate-spin' : ''} /> جلب السعر تلقائياً
                      </button>
                      {rateNote && <span className="text-[11px] text-gray-400 leading-snug flex-1">{rateNote}</span>}
                    </div>
                  </div>
                  <div className="px-4 py-4 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-bold text-gray-800">نسبة الضريبة الافتراضية</p>
                      <p className="text-xs text-gray-400">تُطبّق على الفواتير عند التفعيل (%)</p>
                    </div>
                    <input type="number" min={0} max={100} value={localSettings.taxRate}
                      onChange={e => setLocalSettings(p => ({ ...p, taxRate: +e.target.value }))}
                      className="w-20 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm text-center" />
                  </div>
                  <div className="px-4 py-4 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-bold text-gray-800">الحد الأقصى للسلفة</p>
                      <p className="text-xs text-gray-400">بالدولار الأمريكي</p>
                    </div>
                    <input type="number" value={localSettings.maxAdvanceAmount}
                      onChange={e => setLocalSettings(p => ({ ...p, maxAdvanceAmount: +e.target.value }))}
                      className="w-24 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm text-center" />
                  </div>
                  <div className="px-4 py-4 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-bold text-gray-800">يوم صرف الرواتب</p>
                      <p className="text-xs text-gray-400">رقم اليوم من الشهر</p>
                    </div>
                    <input type="number" min={1} max={31} value={localSettings.payrollDay}
                      onChange={e => setLocalSettings(p => ({ ...p, payrollDay: +e.target.value }))}
                      className="w-20 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm text-center" />
                  </div>
                </div>
              </div>

              {/* Attendance Settings */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                  <MapPin size={13} className="text-gray-500" />
                  <h3 className="text-sm font-black text-gray-700">الحضور</h3>
                </div>
                <div className="divide-y divide-gray-50">
                  <div className="px-4 py-4 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-bold text-gray-800">نطاق الحضور (متر)</p>
                      <p className="text-xs text-gray-400">الحد الأقصى للمسافة عن المصنع</p>
                    </div>
                    <input type="number" value={localSettings.attendanceRadius}
                      onChange={e => setLocalSettings(p => ({ ...p, attendanceRadius: +e.target.value }))}
                      className="w-24 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm text-center" />
                  </div>
                  <div className="px-4 py-4 grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-xs font-bold text-gray-700 mb-1.5">بداية العمل</p>
                      <input type="time" value={localSettings.workStartTime}
                        onChange={e => setLocalSettings(p => ({ ...p, workStartTime: e.target.value }))}
                        className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" dir="ltr" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-700 mb-1.5">نهاية العمل</p>
                      <input type="time" value={localSettings.workEndTime}
                        onChange={e => setLocalSettings(p => ({ ...p, workEndTime: e.target.value }))}
                        className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm" dir="ltr" />
                    </div>
                  </div>
                  <div className="px-4 py-4 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-bold text-gray-800">حد التأخير (دقيقة)</p>
                      <p className="text-xs text-gray-400">دقائق بعد الدوام للاعتبار متأخراً</p>
                    </div>
                    <input type="number" value={localSettings.lateThresholdMinutes}
                      onChange={e => setLocalSettings(p => ({ ...p, lateThresholdMinutes: +e.target.value }))}
                      className="w-20 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm text-center" />
                  </div>
                </div>
              </div>

              {/* Notification Settings */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                  <Bell size={13} className="text-gray-500" />
                  <h3 className="text-sm font-black text-gray-700">الإشعارات</h3>
                </div>
                <div className="divide-y divide-gray-50">
                  {[
                    { key: 'notifyNewOrder', label: 'طلبات جديدة', desc: 'إشعار عند إنشاء طلب جديد', color: 'blue' as const },
                    { key: 'notifyLowStock', label: 'مخزون منخفض', desc: 'إشعار عند نقص المواد', color: 'amber' as const },
                    { key: 'notifyAttendance', label: 'الحضور والغياب', desc: 'إشعار عند تسجيل الحضور', color: 'emerald' as const },
                  ].map(({ key, label, desc, color }) => (
                    <div key={key} className="px-4 py-4 flex items-center justify-between gap-3">
                      <div>
                        <p className="text-sm font-bold text-gray-800">{label}</p>
                        <p className="text-xs text-gray-400">{desc}</p>
                      </div>
                      <Switch
                        checked={localSettings[key as keyof typeof localSettings] as boolean}
                        onChange={v => setLocalSettings(p => ({ ...p, [key]: v }))}
                        color={color} size="md"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Save Button */}
              <button onClick={handleSaveSettings} disabled={saving}
                className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-base rounded-2xl shadow-lg shadow-blue-200 disabled:opacity-60 flex items-center justify-center gap-3 active:scale-[0.98] transition-transform">
                {saving ? (
                  <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> جاري الحفظ...</>
                ) : (
                  <><CheckCircle size={18} /> حفظ جميع الإعدادات</>
                )}
              </button>
            </motion.div>
          )}

          {/* ── LOGS ── */}
          {tab === 'logs' && (
            <motion.div key="logs" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-3">
              <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
                {[
                  { value: 'all', label: 'الكل' },
                  { value: 'success', label: 'نجاح' },
                  { value: 'info', label: 'معلومات' },
                  { value: 'warning', label: 'تحذير' },
                  { value: 'error', label: 'خطأ' },
                ].map(f => (
                  <button key={f.value} onClick={() => setLogFilter(f.value as typeof logFilter)}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                      logFilter === f.value
                        ? f.value === 'all' ? 'bg-gray-800 text-white'
                        : f.value === 'success' ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                        : f.value === 'info' ? 'bg-blue-100 text-blue-700 border border-blue-200'
                        : f.value === 'warning' ? 'bg-amber-100 text-amber-700 border border-amber-200'
                        : 'bg-red-100 text-red-700 border border-red-200'
                        : 'bg-gray-100 text-gray-500'
                    }`}>
                    {f.label}
                    <span className="bg-white/50 rounded-full px-1 ml-0.5">
                      {f.value === 'all' ? realLogs.length : realLogs.filter(l => l.level === f.value).length}
                    </span>
                  </button>
                ))}
              </div>

              <div className="flex items-center justify-between text-xs text-gray-400 px-1">
                <span>{filteredLogs.length} سجل</span>
                <button onClick={() => window.location.reload()}
                  className="text-blue-600 font-bold flex items-center gap-1" style={{ minHeight: 'unset' }}>
                  <RefreshCw size={11} /> تحديث
                </button>
              </div>

              {filteredLogs.length === 0 ? (
                <div className="text-center py-12">
                  <AlertTriangle size={32} className="text-gray-300 mx-auto mb-3" />
                  <p className="text-sm text-gray-400">لا توجد سجلات</p>
                </div>
              ) : filteredLogs.map((log, i) => {
                const cfg = logLevelConfig[log.level];
                const minAgo = Math.floor((Date.now() - new Date(log.timestamp).getTime()) / 60000);
                const timeStr = minAgo < 60 ? `منذ ${minAgo} دقيقة` : `منذ ${Math.floor(minAgo / 60)} ساعة`;
                return (
                  <motion.div key={log.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.03 }}
                    className={`${cfg.bg} border ${cfg.border} rounded-2xl p-4`}>
                    <div className="flex items-start gap-3">
                      <LogLevelIcon level={log.level} size={16} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-gray-800">{log.message}</p>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <span className={`text-xs font-medium ${cfg.color}`}>#{log.module}</span>
                          <span className="text-xs text-gray-300">•</span>
                          <span className="text-xs text-gray-400 flex items-center gap-1">
                            <Clock size={9} /> {timeStr}
                          </span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          )}

        </AnimatePresence>
      </div>

      {selectedUser && (
        <UserModal emp={selectedUser} onClose={() => setSelectedUser(null)} onSave={handleSaveUser} />
      )}
      {showClearConfirm && (
        <ConfirmDestructiveModal
          title="مسح جميع البيانات"
          message="هل أنت متأكد؟ سيتم مسح جميع البيانات بشكل نهائي ولا يمكن التراجع عن هذا الإجراء."
          confirmLabel="مسح نهائياً"
          onConfirm={clearAllData}
          onClose={() => setShowClearConfirm(false)}
        />
      )}
      {showResetConfirm && (
        <ConfirmDestructiveModal
          title="استعادة البيانات التجريبية"
          message="سيتم حذف جميع البيانات الحالية واستبدالها بالبيانات التجريبية. هذا الإجراء لا يمكن التراجع عنه."
          confirmLabel="استعادة تجريبية"
          onConfirm={resetToDemo}
          onClose={() => setShowResetConfirm(false)}
        />
      )}
    </div>
  );
};

export default React.memo(AdminPage);
