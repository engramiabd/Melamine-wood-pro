import React, { useState, useEffect } from 'react';
import {
  DollarSign, Bell, Shield, Globe, Moon, Sun,
  ChevronLeft, LogOut, Info, Smartphone, RefreshCw,
  Download, CheckCircle, Edit3, Save, X, Star,
  Wifi, WifiOff, Lock, Eye, EyeOff, Database,
  Factory, Zap, Phone, Building, AlertCircle,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import { useAppData } from '../contexts/AppDataContext';
import { SyncStatus } from '../components/ui/SyncStatus';
import { useTheme } from '../contexts/ThemeContext';
import { useNavigate } from 'react-router-dom';
import { Switch, SwitchRow, ToggleGroup } from '../components/ui/Switch';
import { systemNotificationsEnabled, setSystemNotificationsEnabled, requestNotificationPermission, notificationPermission } from '../utils/systemNotifications';

// ── Constants ─────────────────────────────────────────────────────────────────
const ROLE_LABELS: Record<string, string> = {
  admin:                 'مدير النظام',
  manager:               'مدير إنتاج',
  production_supervisor: 'مشرف إنتاج',
  worker:                'عامل',
  accountant:            'محاسب',
  hr:                    'موارد بشرية',
};

const ROLE_GRADIENTS: Record<string, string> = {
  admin:                 'from-red-500 to-rose-600',
  manager:               'from-blue-500 to-indigo-600',
  production_supervisor: 'from-purple-500 to-violet-600',
  worker:                'from-emerald-500 to-teal-600',
  accountant:            'from-amber-500 to-orange-600',
  hr:                    'from-pink-500 to-rose-500',
};

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

// ── Section Header ─────────────────────────────────────────────────────────────
const SectionLabel: React.FC<{ icon: React.ReactNode; label: string }> = ({ icon, label }) => (
  <div className="flex items-center gap-2 px-1 mb-2 mt-1">
    <div className="w-5 h-5 flex items-center justify-center text-gray-400">{icon}</div>
    <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">{label}</span>
  </div>
);

// ── Main Component ────────────────────────────────────────────────────────────
export const SettingsPage: React.FC = () => {
  const { currency, exchangeRate, toggleCurrency, setExchangeRate } = useCurrency();
  const { theme, setTheme } = useTheme();
  const { user, logout, isDemoMode } = useAuth();
  const { systemSettings, updateSystemSettings, saveUserProfile, changePassword, orders, employees, productionLines } = useAppData();
  const navigate = useNavigate();

  /* ── Local State ── */
  const [notifications,    setNotifications]    = useState(systemSettings.notifyNewOrder);
  const [darkMode,         setDarkMode]         = useState(false);
  const [soundEnabled,     setSoundEnabled]     = useState(true);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [autoSync,         setAutoSync]         = useState(true);
  const [notifyLowStock,   setNotifyLowStock]   = useState(systemSettings.notifyLowStock);
  const [sysNotif,         setSysNotif]         = useState(systemNotificationsEnabled() && notificationPermission() === 'granted');
  const [notifyAttendance, setNotifyAttendance] = useState(systemSettings.notifyAttendance);
  const [rateInput,        setRateInput]        = useState(String(exchangeRate));
  const [showRateEdit,     setShowRateEdit]     = useState(false);
  const [editingProfile,   setEditingProfile]   = useState(false);
  const [savedProfile,     setSavedProfile]     = useState(false);
  const [showPassword,     setShowPassword]     = useState(false);
  const [pwdSection,       setPwdSection]       = useState(false);
  const [installPrompt,    setInstallPrompt]    = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled,      setIsInstalled]      = useState(false);
  const [isOnline,         setIsOnline]         = useState(navigator.onLine);
  const [profileName,      setProfileName]      = useState(user?.full_name || '');
  const [profilePhone,     setProfilePhone]     = useState(user?.phone || '');
  const [currentPwd,       setCurrentPwd]       = useState('');
  const [newPwd,           setNewPwd]           = useState('');
  const [confirmPwd,       setConfirmPwd]       = useState('');
  const [pwdError,         setPwdError]         = useState('');
  const [pwdSuccess,       setPwdSuccess]       = useState(false);

  /* ── Effects ── */
  useEffect(() => {
    const handler = (e: Event) => { e.preventDefault(); setInstallPrompt(e as BeforeInstallPromptEvent); };
    window.addEventListener('beforeinstallprompt', handler);
    if (window.matchMedia('(display-mode: standalone)').matches) setIsInstalled(true);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  useEffect(() => {
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  if (!user) return null;

  /* ── Handlers ── */
  const handleRateSave = () => {
    const rate = Number(rateInput);
    if (!isNaN(rate) && rate > 0) {
      setExchangeRate(rate);
      setShowRateEdit(false);
    }
  };

  const handleSysNotifToggle = async (val: boolean) => {
    if (val) {
      const perm = await requestNotificationPermission();
      if (perm === 'granted') { setSystemNotificationsEnabled(true); setSysNotif(true); }
      else { setSysNotif(false); }
    } else {
      setSystemNotificationsEnabled(false); setSysNotif(false);
    }
  };

  const handleNotifToggle = (key: 'notifyNewOrder' | 'notifyLowStock' | 'notifyAttendance', val: boolean) => {
    updateSystemSettings({ [key]: val });
  };

  const handleProfileSave = () => {
    saveUserProfile({ full_name: profileName, phone: profilePhone, email: user?.email || '' });
    setEditingProfile(false);
    setSavedProfile(true);
    setTimeout(() => setSavedProfile(false), 2500);
  };

  const handlePasswordChange = async () => {
    setPwdError('');
    if (!currentPwd || !newPwd || !confirmPwd) { setPwdError('جميع الحقول مطلوبة'); return; }
    if (newPwd !== confirmPwd) { setPwdError('كلمتا المرور غير متطابقتين'); return; }
    if (newPwd.length < 6) { setPwdError('كلمة المرور يجب أن تكون 6 أحرف على الأقل'); return; }
    const result = await changePassword(currentPwd, newPwd);
    if (!result.success) { setPwdError(result.error || 'خطأ في تغيير كلمة المرور'); return; }
    setPwdSuccess(true);
    setCurrentPwd(''); setNewPwd(''); setConfirmPwd('');
    setTimeout(() => { setPwdSuccess(false); setPwdSection(false); }, 2500);
  };

  const handleInstallPWA = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === 'accepted') { setIsInstalled(true); setInstallPrompt(null); }
  };

  /* ── Render ── */
  return (
    <div className="min-h-full bg-gray-50 pb-10" dir="rtl">

      {/* ── Offline Banner ── */}
      <AnimatePresence>
        {!isOnline && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="bg-amber-500 text-white text-xs text-center py-2 font-medium flex items-center justify-center gap-2 overflow-hidden"
          >
            <WifiOff size={12} /> أنت غير متصل بالإنترنت
          </motion.div>
        )}
      </AnimatePresence>

      <div className="px-4 py-4 space-y-5">

        {/* ── Cloud sync ── */}
        <SyncStatus />

        {/* ── Profile Card ── */}
        <div className={`bg-gradient-to-br ${ROLE_GRADIENTS[user.role] ?? 'from-slate-600 to-slate-800'} rounded-3xl p-5 text-white relative overflow-hidden`}>
          <div className="absolute -top-8 -left-8 w-36 h-36 bg-white/5 rounded-full" />
          <div className="absolute -bottom-6 -right-6 w-28 h-28 bg-white/5 rounded-full" />

          <div className="relative">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                {/* Avatar */}
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center font-black text-2xl border-2 border-white/30 shadow-lg">
                  {user.full_name.charAt(0)}
                </div>
                <div>
                  {editingProfile ? (
                    <input
                      value={profileName}
                      onChange={e => setProfileName(e.target.value)}
                      className="bg-white/20 text-white placeholder-white/60 text-lg font-bold rounded-xl px-3 py-1 w-40 focus:outline-none focus:ring-2 focus:ring-white/30 mb-1"
                      placeholder="الاسم الكامل"
                    />
                  ) : (
                    <h2 className="text-xl font-black">{user.full_name}</h2>
                  )}
                  <p className="text-white/70 text-xs">{user.email}</p>
                </div>
              </div>

              {/* Edit/Save button */}
              <motion.button
                whileTap={{ scale: 0.88 }}
                onClick={() => editingProfile ? handleProfileSave() : setEditingProfile(true)}
                className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center"
              >
                {editingProfile
                  ? <Save size={15} className="text-white" />
                  : <Edit3 size={15} className="text-white" />}
              </motion.button>
            </div>

            {/* Badges */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs px-3 py-1 rounded-full bg-white/20 font-bold">
                {ROLE_LABELS[user.role] ?? user.role}
              </span>
              {isDemoMode && (
                <span className="text-xs px-3 py-1 rounded-full bg-amber-400/30 text-amber-100 font-medium">
                  وضع تجريبي
                </span>
              )}
              <span className={`text-xs px-3 py-1 rounded-full flex items-center gap-1 font-medium ${
                isOnline ? 'bg-emerald-400/20 text-emerald-100' : 'bg-red-400/20 text-red-100'
              }`}>
                {isOnline ? <Wifi size={9} /> : <WifiOff size={9} />}
                {isOnline ? 'متصل' : 'غير متصل'}
              </span>
            </div>

            {/* Edit fields */}
            <AnimatePresence>
              {editingProfile && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                  className="mt-3 space-y-2"
                >
                  <input
                    value={profilePhone}
                    onChange={e => setProfilePhone(e.target.value)}
                    className="w-full bg-white/20 text-white placeholder-white/60 text-sm rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-white/30"
                    placeholder="رقم الهاتف"
                    dir="ltr"
                  />
                  <div className="flex gap-2">
                    <button onClick={handleProfileSave} className="flex-1 bg-white text-blue-700 font-bold text-sm py-2 rounded-xl">
                      حفظ التغييرات
                    </button>
                    <button
                      onClick={() => { setEditingProfile(false); setProfileName(user.full_name); }}
                      className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
                    >
                      <X size={15} className="text-white" />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Save success */}
            <AnimatePresence>
              {savedProfile && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
                  className="mt-2 flex items-center gap-2 text-emerald-300 text-xs"
                >
                  <CheckCircle size={12} /> تم حفظ الملف الشخصي بنجاح
                </motion.div>
              )}
            </AnimatePresence>

            {/* Info row */}
            {!editingProfile && (user.phone || user.department) && (
              <div className="mt-3 flex gap-4 text-white/60 text-xs">
                {user.phone && (
                  <span className="flex items-center gap-1"><Phone size={10} /> {user.phone}</span>
                )}
                {user.department && (
                  <span className="flex items-center gap-1"><Building size={10} /> {user.department}</span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* ── PWA Install ── */}
        {!isInstalled && installPrompt && (
          <motion.div
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-4 text-white"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <Download size={20} className="text-white" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-sm">ثبّت التطبيق</p>
                <p className="text-blue-200 text-xs">وصول سريع من الشاشة الرئيسية</p>
              </div>
              <motion.button whileTap={{ scale: 0.95 }} onClick={handleInstallPWA}
                className="bg-white text-blue-700 font-bold text-sm px-4 py-2 rounded-xl"
              >
                تثبيت
              </motion.button>
            </div>
          </motion.div>
        )}

        {isInstalled && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4">
            <div className="flex items-center gap-3">
              <CheckCircle size={20} className="text-emerald-600" />
              <div>
                <p className="font-bold text-sm text-emerald-800">التطبيق مثبت</p>
                <p className="text-emerald-600 text-xs">يمكنك الوصول من الشاشة الرئيسية</p>
              </div>
            </div>
          </div>
        )}

        {/* ── Appearance ── */}
        <div>
          <SectionLabel icon={<Moon size={14} />} label="المظهر" />
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-4 py-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-9 h-9 bg-indigo-100 rounded-xl flex items-center justify-center">
                  <Moon size={16} className="text-indigo-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-800">وضع العرض</p>
                  <p className="text-xs text-gray-400">فاتح، داكن، أو حسب إعدادات الجهاز</p>
                </div>
              </div>
              <ToggleGroup
                value={theme}
                onChange={(v) => setTheme(v as 'light' | 'dark' | 'system')}
                options={[
                  { value: 'light',  label: 'فاتح',          icon: <Sun size={14} /> },
                  { value: 'dark',   label: 'داكن',           icon: <Moon size={14} /> },
                  { value: 'system', label: 'حسب الجهاز',     icon: <Smartphone size={14} /> },
                ]}
              />
              <p className="text-[11px] text-amber-600 bg-amber-50 rounded-lg px-3 py-2 mt-3">
                ℹ️ الوضع الداكن مدعوم للهيكل ومعظم الشاشات؛ يجري تحويل ما تبقّى من الشاشات تدريجياً.
              </p>
            </div>
          </div>
        </div>

        {/* ── Currency ── */}
        <div>
          <SectionLabel icon={<DollarSign size={14} />} label="إعدادات العملة" />
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden divide-y divide-gray-50">

            {/* Currency Toggle */}
            <div className="px-4 py-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-emerald-100 rounded-xl flex items-center justify-center">
                    <DollarSign size={16} className="text-emerald-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-800">العملة الافتراضية</p>
                    <p className="text-xs text-gray-400">دولار أمريكي أو ليرة سورية</p>
                  </div>
                </div>
              </div>

              {/* Segmented currency toggle */}
              <ToggleGroup
                value={currency}
                onChange={(v) => { if (v !== currency) toggleCurrency(); }}
                options={[
                  {
                    value: 'USD',
                    label: 'دولار USD',
                    icon: (
                      <svg viewBox="0 0 20 14" className="w-5 h-3.5 rounded-sm overflow-hidden shrink-0">
                        <rect width="20" height="14" fill="#B22234"/>
                        <rect y="1" width="20" height="1.08" fill="white"/>
                        <rect y="3.08" width="20" height="1.08" fill="white"/>
                        <rect y="5.15" width="20" height="1.08" fill="white"/>
                        <rect y="7.23" width="20" height="1.08" fill="white"/>
                        <rect y="9.31" width="20" height="1.08" fill="white"/>
                        <rect y="11.38" width="20" height="1.08" fill="white"/>
                        <rect width="8" height="7.69" fill="#3C3B6E"/>
                      </svg>
                    ),
                  },
                  {
                    value: 'SYP',
                    label: 'ليرة سورية',
                    icon: (
                      <svg viewBox="0 0 20 14" className="w-5 h-3.5 rounded-sm overflow-hidden shrink-0">
                        <rect width="20" height="4.67" fill="#007A3D"/>
                        <rect y="4.67" width="20" height="4.67" fill="white"/>
                        <rect y="9.33" width="20" height="4.67" fill="#CE1126"/>
                        <circle cx="10" cy="7" r="2" fill="#007A3D" opacity="0.3"/>
                      </svg>
                    ),
                  },
                ]}
                className="mt-1"
              />
            </div>

            {/* Exchange Rate */}
            <div className="px-4 py-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-blue-100 rounded-xl flex items-center justify-center">
                    <RefreshCw size={15} className="text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-800">سعر الصرف</p>
                    <p className="text-xs text-gray-400">1 USD = {exchangeRate.toLocaleString('ar')} ل.س</p>
                  </div>
                </div>
                <motion.button
                  whileTap={{ scale: 0.94 }}
                  onClick={() => setShowRateEdit(!showRateEdit)}
                  className="text-xs text-blue-600 font-bold px-3 py-1.5 bg-blue-50 rounded-xl"
                >
                  {showRateEdit ? 'إلغاء' : 'تعديل'}
                </motion.button>
              </div>
              <AnimatePresence>
                {showRateEdit && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                    className="flex gap-2 mt-2"
                  >
                    <input
                      type="number"
                      value={rateInput}
                      onChange={e => setRateInput(e.target.value)}
                      className="flex-1 px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50"
                      placeholder="سعر الصرف"
                      dir="ltr"
                    />
                    <motion.button
                      whileTap={{ scale: 0.95 }}
                      onClick={handleRateSave}
                      className="px-5 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold"
                    >
                      حفظ
                    </motion.button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* ── Notifications & App ── */}
        <div>
          <SectionLabel icon={<Bell size={14} />} label="الإشعارات والتطبيق" />
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <SwitchRow
              checked={systemSettings.notifyNewOrder} onChange={(v) => { setNotifications(v); updateSystemSettings({ notifyNewOrder: v }); }}
              label="إشعارات الطلبات" description="تنبيه عند إنشاء طلب جديد"
              icon={<Bell size={16} className="text-red-500" />} iconBg="bg-red-50"
              color="blue"
            />
            <SwitchRow
              checked={systemSettings.notifyLowStock} onChange={(v) => { setNotifyLowStock(v); updateSystemSettings({ notifyLowStock: v }); }}
              label="إشعارات المخزون" description="تنبيه عند نقص المواد"
              icon={<Database size={16} className="text-amber-500" />} iconBg="bg-amber-50"
              color="amber"
            />
            <SwitchRow
              checked={systemSettings.notifyAttendance} onChange={(v) => { setNotifyAttendance(v); updateSystemSettings({ notifyAttendance: v }); }}
              label="إشعارات الحضور" description="تنبيه عند تسجيل الحضور"
              icon={<Bell size={16} className="text-violet-500" />} iconBg="bg-violet-50"
              color="violet"
            />
            <SwitchRow
              checked={sysNotif} onChange={handleSysNotifToggle}
              label="تنبيهات النظام" description="إظهار التنبيهات على مستوى الجهاز"
              icon={<Bell size={16} className="text-emerald-500" />} iconBg="bg-emerald-50"
              color="emerald" last
            />
          </div>
        </div>

        {/* ── Language ── */}
        <div>
          <SectionLabel icon={<Globe size={14} />} label="اللغة والمنطقة" />
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3.5">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Globe size={16} className="text-purple-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-800">اللغة</p>
                  <p className="text-xs text-gray-400">العربية — Arabic</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs bg-purple-100 text-purple-700 px-2.5 py-1 rounded-lg font-bold">عربي</span>
                <ChevronLeft size={15} className="text-gray-300 rotate-180" />
              </div>
            </div>
          </div>
        </div>

        {/* ── Security ── */}
        <div>
          <SectionLabel icon={<Lock size={14} />} label="الأمان والخصوصية" />
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">

            {/* Password Change */}
            <button
              onClick={() => setPwdSection(!pwdSection)}
              className="w-full flex items-center justify-between px-4 py-3.5 border-t border-gray-50 hover:bg-gray-50/80 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-amber-100 rounded-xl flex items-center justify-center">
                  <Shield size={16} className="text-amber-600" />
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-gray-800">تغيير كلمة المرور</p>
                  <p className="text-xs text-gray-400">تحديث بيانات الأمان</p>
                </div>
              </div>
              <ChevronLeft
                size={15}
                className={`text-gray-400 transition-transform duration-200 ${pwdSection ? '-rotate-90' : 'rotate-180'}`}
              />
            </button>

            <AnimatePresence>
              {pwdSection && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 space-y-3 pt-2">
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={currentPwd}
                        onChange={e => setCurrentPwd(e.target.value)}
                        placeholder="كلمة المرور الحالية"
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 pl-10"
                        dir="ltr"
                        style={{ fontSize: 16 }}
                      />
                      <button onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                        {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                      </button>
                    </div>
                    <input type="password" placeholder="كلمة المرور الجديدة"
                      value={newPwd} onChange={e => setNewPwd(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50"
                      dir="ltr" style={{ fontSize: 16 }}
                    />
                    <input type="password" placeholder="تأكيد كلمة المرور الجديدة"
                      value={confirmPwd} onChange={e => setConfirmPwd(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50"
                      dir="ltr" style={{ fontSize: 16 }}
                    />
                    <AnimatePresence>
                      {pwdError && (
                        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                          className="text-xs text-red-600 bg-red-50 px-3 py-2 rounded-xl flex items-center gap-2">
                          <AlertCircle size={12} /> {pwdError}
                        </motion.p>
                      )}
                      {pwdSuccess && (
                        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                          className="text-xs text-emerald-600 bg-emerald-50 px-3 py-2 rounded-xl flex items-center gap-2">
                          <CheckCircle size={12} /> تم تغيير كلمة المرور بنجاح
                        </motion.p>
                      )}
                    </AnimatePresence>
                    <motion.button whileTap={{ scale: 0.97 }} onClick={handlePasswordChange}
                      className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2"
                    >
                      <CheckCircle size={15} /> تحديث كلمة المرور
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Sessions */}
            <button className="w-full flex items-center justify-between px-4 py-3.5 border-t border-gray-50 hover:bg-gray-50/80 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Smartphone size={16} className="text-blue-600" />
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-gray-800">جلسات تسجيل الدخول</p>
                  <p className="text-xs text-gray-400">جهاز واحد نشط حالياً</p>
                </div>
              </div>
              <ChevronLeft size={15} className="text-gray-300 rotate-180" />
            </button>
          </div>
        </div>

        {/* ── About ── */}
        <div>
          <SectionLabel icon={<Info size={14} />} label="عن التطبيق" />
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="p-5">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-200">
                  <Factory size={26} className="text-white" />
                </div>
                <div>
                  <p className="font-black text-gray-900 text-lg leading-tight">ميلامين برو</p>
                  <p className="text-xs text-gray-400 mt-0.5">الإصدار 1.0.0 (Build 100)</p>
                  <div className="flex items-center gap-0.5 mt-1.5">
                    {[1,2,3,4,5].map(s => (
                      <Star key={s} size={12} className="text-amber-400 fill-amber-400" />
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 mb-4">
                {[
                  { label: 'المستخدمون', value: '6' },
                  { label: 'خطوط الإنتاج', value: '4' },
                  { label: 'الطلبات', value: '5' },
                ].map(stat => (
                  <div key={stat.label} className="bg-gray-50 rounded-xl p-3 text-center">
                    <p className="text-sm font-black text-gray-800">{stat.value}</p>
                    <p className="text-[10px] text-gray-400 mt-0.5">{stat.label}</p>
                  </div>
                ))}
              </div>

              <p className="text-xs text-gray-400 leading-relaxed mb-3">
                نظام متكامل لإدارة مصانع الميلامين. يشمل إدارة الإنتاج، المخزون، الموارد البشرية، والمحاسبة.
                مبني بأحدث تقنيات الويب مع دعم كامل للعمل دون إنترنت.
              </p>
              <div className="flex items-center gap-1.5 text-xs text-gray-400">
                <Info size={11} />
                <span>© 2024 ميلامين برو — جميع الحقوق محفوظة</span>
              </div>
            </div>
          </div>
        </div>

        {/* ── Demo Mode Banner ── */}
        {isDemoMode && (
          <motion.div
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            className="bg-amber-50 border border-amber-200 rounded-2xl p-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
                <Info size={18} className="text-amber-600" />
              </div>
              <div>
                <p className="font-bold text-amber-800 text-sm">وضع تجريبي نشط</p>
                <p className="text-amber-600 text-xs mt-0.5">جميع البيانات وهمية لأغراض العرض والتجربة فقط</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* ── Logout ── */}
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => { logout(); navigate('/login'); }}
          className="w-full flex items-center justify-center gap-3 py-4 bg-red-50 border-2 border-red-100 text-red-600 font-black rounded-2xl active:bg-red-100 transition-colors text-sm"
        >
          <LogOut size={17} />
          تسجيل الخروج
        </motion.button>

        <div className="h-2" />
      </div>
    </div>
  );
};
