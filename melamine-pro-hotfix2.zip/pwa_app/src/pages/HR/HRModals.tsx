/**
 * HRModals — sub-components used by HRPage:
 * EmployeeDetailSheet, BonusModal, AddEmployeeModal, and HR constants.
 */
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, UserPlus, Calendar, CheckCircle, XCircle,
  Clock, Briefcase, DollarSign, ChevronDown,
  Search, Award, TrendingUp, Edit3, Activity,
  Hash, Shield, ChevronRight, Star,
} from 'lucide-react';
import { Badge } from '../components/ui/Badge';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import { useAppData } from '../contexts/AppDataContext';
import { EmptyState } from '../components/ui/EmptyState';
import { Avatar } from '../components/ui/Avatar';
import { resolveWorkerRoleKey } from '../lib/workers';
import { LeaveType, LeaveStatus, Employee } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { printPayroll } from '../utils/print';


// ── Constants ──────────────────────────────────────────────────────────────────
export const DEPT_COLORS: Record<string, { bg: string; text: string }> = {
  'الإدارة':         { bg: 'bg-red-50',     text: 'text-red-700'     },
  'الإنتاج':         { bg: 'bg-blue-50',    text: 'text-blue-700'    },
  'المالية':         { bg: 'bg-amber-50',   text: 'text-amber-700'   },
  'الموارد البشرية': { bg: 'bg-pink-50',    text: 'text-pink-700'    },
  'خط الإنتاج A':    { bg: 'bg-emerald-50', text: 'text-emerald-700' },
  'خط الإنتاج B':    { bg: 'bg-teal-50',    text: 'text-teal-700'    },
};

export const WORKER_NAMES: Record<string, string> = {
  'demo-admin-001':      'أحمد المدير',
  'demo-manager-002':    'محمد المشرف',
  'demo-supervisor-003': 'خالد المراقب',
  'demo-worker-004':     'علي العامل',
  'demo-accountant-005': 'سمر المحاسبة',
  'demo-hr-006':         'ريم الموارد البشرية',
};

export const WORKER_AVATARS: Record<string, string> = {
  'demo-admin-001':      'from-red-500 to-rose-600',
  'demo-manager-002':    'from-blue-500 to-indigo-600',
  'demo-supervisor-003': 'from-emerald-500 to-teal-600',
  'demo-worker-004':     'from-amber-500 to-orange-600',
  'demo-accountant-005': 'from-purple-500 to-violet-600',
  'demo-hr-006':         'from-pink-500 to-rose-500',
};

export const LEAVE_TYPE_LABELS: Record<LeaveType, string> = {
  annual:    'إجازة سنوية',
  sick:      'إجازة مرضية',
  emergency: 'طارئ',
  unpaid:    'بدون راتب',
  maternity: 'أمومة',
};

export const LEAVE_STATUS_CONFIG: Record<LeaveStatus, { label: string; badge: 'success' | 'danger' | 'warning' }> = {
  pending:  { label: 'معلقة',   badge: 'warning' },
  approved: { label: 'معتمدة', badge: 'success'  },
  rejected: { label: 'مرفوضة', badge: 'danger'   },
};

type HRTab = 'employees' | 'leaves' | 'payroll' | 'analytics';

// ── Employee Detail Sheet (Portal-based — never behind BottomNav) ─────────────
export const EmployeeDetailSheet: React.FC<{
  emp: Employee | null;
  onClose: () => void;
  onBonus: (emp: Employee) => void;
  formatUSD: (v: number) => string;
  formatSYP: (v: number) => string;
}> = ({ emp, onClose, onBonus, formatUSD, formatSYP }) => {
  const name = emp ? (WORKER_NAMES[emp.user_id] ?? emp.user_id) : '';
  const grad = emp ? (WORKER_AVATARS[emp.user_id] ?? 'from-gray-400 to-gray-600') : 'from-gray-400 to-gray-600';
  const yearsOfService = emp
    ? Math.floor((Date.now() - new Date(emp.hire_date).getTime()) / (365.25 * 24 * 3600000))
    : 0;

  const performanceData = [
    { month: 'أكت', score: 88 },
    { month: 'نوف', score: 92 },
    { month: 'ديس', score: 85 },
    { month: 'يناير', score: 94 },
  ];

  return (
    // BottomSheetModal renders via createPortal into document.body
    // so it is NEVER clipped by .app-shell and sits above the BottomNav
    <BottomSheetModal isOpen={!!emp} onClose={onClose} maxHeight="90dvh">
      {/* Gradient header */}
      <SheetHeader onClose={onClose} className={`bg-gradient-to-r ${grad} px-5 pt-3 pb-5`}>
        <div className="flex items-center gap-4">
          <Avatar
            userId={emp?.user_id}
            name={name}
            role={emp ? resolveWorkerRoleKey(emp.user_id, [emp]) : undefined}
            size={64}
            radius={16}
            style={{ border: '2px solid rgba(255,255,255,0.35)' }}
          />
          <div>
            <h2 className="text-xl font-black text-white">{name}</h2>
            <p className="text-white/80 text-sm">{emp?.position}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className="bg-white/20 text-white text-xs px-2 py-0.5 rounded-full">{emp?.department}</span>
              <span className="text-white/70 text-xs">{emp?.employee_number}</span>
            </div>
          </div>
        </div>
      </SheetHeader>

      {/* Scrollable body */}
      <SheetBody>
        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: 'سنوات الخدمة', value: `${yearsOfService}`, unit: 'سنة',  icon: <Award size={16} className="text-amber-500" />,      bg: 'bg-amber-50 border-amber-100'   },
            { label: 'الراتب',        value: formatUSD(emp?.salary_usd ?? 0), unit: '', icon: <DollarSign size={16} className="text-emerald-500" />, bg: 'bg-emerald-50 border-emerald-100' },
            { label: 'ساعات العمل', value: `${emp?.working_hours ?? 0}`, unit: 'ساعة', icon: <Clock size={16} className="text-blue-500" />,      bg: 'bg-blue-50 border-blue-100'     },
          ].map(s => (
            <div key={s.label} className={`${s.bg} border rounded-2xl p-3 text-center`}>
              <div className="flex justify-center mb-1">{s.icon}</div>
              <p className="text-sm font-black text-gray-900">{s.value}</p>
              {s.unit && <p className="text-xs text-gray-500">{s.unit}</p>}
              <p className="text-[10px] text-gray-400 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Info rows */}
        <div className="bg-gray-50 rounded-2xl p-4 space-y-2.5">
          <p className="text-xs font-bold text-gray-600 mb-2">معلومات الموظف</p>
          {emp && [
            { icon: Hash,      label: 'الرقم الوظيفي', value: emp.employee_number },
            { icon: Briefcase, label: 'القسم',          value: emp.department },
            { icon: Shield,    label: 'المسمى الوظيفي', value: emp.position },
            { icon: Calendar,  label: 'تاريخ التعيين',  value: new Date(emp.hire_date).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric' }) },
            { icon: Activity,  label: 'الحالة',          value: emp.is_active ? 'نشط' : 'غير نشط' },
          ].map(({ icon: Icon, label, value }) => (
            <div key={label} className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-gray-500">
                <Icon size={13} />
                <span className="text-xs">{label}</span>
              </div>
              <span className="text-xs font-semibold text-gray-800">{value}</span>
            </div>
          ))}
        </div>

        {/* Salary */}
        {emp && (
          <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-4">
            <p className="text-xs font-bold text-emerald-700 mb-2 flex items-center gap-1.5">
              <DollarSign size={13} /> تفاصيل الراتب
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-emerald-600">بالدولار</p>
                <p className="text-lg font-black text-emerald-800">{formatUSD(emp.salary_usd)}</p>
              </div>
              <div>
                <p className="text-xs text-emerald-600">بالليرة السورية</p>
                <p className="text-sm font-bold text-emerald-800">{formatSYP(emp.salary_syp)}</p>
              </div>
            </div>
          </div>
        )}

        {/* Performance chart */}
        <div className="bg-white border border-gray-100 rounded-2xl p-4">
          <p className="text-xs font-bold text-gray-700 mb-3 flex items-center gap-1.5">
            <TrendingUp size={13} className="text-blue-600" /> أداء آخر 4 أشهر
          </p>
          <ResponsiveContainer width="100%" height={90}>
            <BarChart data={performanceData} barSize={18}>
              <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
              <YAxis domain={[70, 100]} tick={{ fontSize: 10, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
              <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                {performanceData.map((_, i) => (
                  <Cell key={i} fill={i === performanceData.length - 1 ? '#3B82F6' : '#BFDBFE'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </SheetBody>

      {/* Action buttons — FIXED at bottom via SheetFooter, NEVER behind BottomNav */}
      <SheetFooter>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <button
            onClick={onClose}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              gap: 6, padding: '14px 0',
              background: '#2563EB', color: '#fff',
              borderRadius: 14, border: 'none', cursor: 'pointer',
              fontSize: 13, fontWeight: 700, minHeight: 'unset',
            }}
          >
            <Edit3 size={14} />
            تعديل البيانات
          </button>
          <button
            onClick={() => { if (emp) { onBonus(emp); onClose(); } }}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              gap: 6, padding: '14px 0',
              background: '#059669', color: '#fff',
              borderRadius: 14, border: 'none', cursor: 'pointer',
              fontSize: 13, fontWeight: 700, minHeight: 'unset',
            }}
          >
            <Award size={14} />
            إضافة مكافأة
          </button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

// ── Bonus Modal (Portal-based) ─────────────────────────────────────────────────
export const BonusModal: React.FC<{
  emp: Employee | null;
  onClose: () => void;
  onSave: (empId: string, amount: number, reason: string) => void;
  formatUSD: (v: number) => string;
}> = ({ emp, onClose, onSave, formatUSD }) => {
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const QUICK = [50, 100, 150, 200, 300, 500];

  const handleSave = async () => {
    if (!emp || !amount) return;
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    onSave(emp.id, parseFloat(amount), reason || 'مكافأة');
    setSaving(false);
    onClose();
  };

  const name = emp ? (WORKER_NAMES[emp.user_id] ?? emp.user_id) : '';

  return (
    <BottomSheetModal isOpen={!!emp} onClose={onClose} maxHeight="85dvh">
      {/* Header */}
      <SheetHeader className="px-5 pt-3 pb-4 bg-gradient-to-r from-amber-500 to-orange-500">
        <h2 className="text-lg font-black text-white">إضافة مكافأة</h2>
        <p className="text-white/80 text-sm">للموظف: {name}</p>
      </SheetHeader>

      {/* Scrollable content */}
      <SheetBody>
        {/* Quick amounts */}
        <div>
          <p className="text-xs font-bold text-gray-600 mb-2">مبالغ سريعة (دولار)</p>
          <div className="grid grid-cols-3 gap-2">
            {QUICK.map(q => (
              <button
                key={q}
                onClick={() => setAmount(String(q))}
                style={{ minHeight: 'unset' }}
                className={`py-2.5 rounded-xl text-sm font-bold transition-all ${
                  amount === String(q) ? 'bg-amber-500 text-white' : 'bg-gray-100 text-gray-700'
                }`}
              >
                ${q}
              </button>
            ))}
          </div>
        </div>

        {/* Custom amount */}
        <div>
          <label className="text-xs font-bold text-gray-600 mb-1.5 block">مبلغ مخصص ($)</label>
          <input
            type="number"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            placeholder="0.00"
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl"
            style={{ fontSize: 16 }}
          />
          {amount && (
            <p className="text-xs text-emerald-600 mt-1">{formatUSD(parseFloat(amount) || 0)}</p>
          )}
        </div>

        {/* Reason */}
        <div>
          <label className="text-xs font-bold text-gray-600 mb-1.5 block">السبب</label>
          <textarea
            value={reason}
            onChange={e => setReason(e.target.value)}
            placeholder="سبب المكافأة..."
            rows={3}
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm resize-none"
            style={{ fontSize: 16 }}
          />
        </div>
      </SheetBody>

      {/* Footer — always visible above BottomNav */}
      <SheetFooter>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 10 }}>
          <button
            onClick={onClose}
            style={{
              padding: '14px 0', borderRadius: 14, border: '1.5px solid #E2E8F0',
              background: 'var(--surface)', color: '#64748B', fontSize: 13, fontWeight: 700,
              cursor: 'pointer', minHeight: 'unset',
            }}
          >
            إلغاء
          </button>
          <button
            onClick={handleSave}
            disabled={!amount || saving}
            style={{
              padding: '14px 0', borderRadius: 14, border: 'none',
              background: saving || !amount ? '#9CA3AF' : '#F59E0B',
              color: '#fff', fontSize: 13, fontWeight: 700,
              cursor: saving || !amount ? 'not-allowed' : 'pointer',
              minHeight: 'unset',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            }}
          >
            {saving ? (
              <><div style={{ width: 16, height: 16, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 1s linear infinite' }} /> جاري الحفظ</>
            ) : (
              <><Award size={14} /> إضافة المكافأة</>
            )}
          </button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

// ── Add Employee Modal ────────────────────────────────────────────────────────
export const AddEmployeeModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { addEmployee } = useAppData();
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Form state — controlled inputs
  const [form, setForm] = useState({
    department: '', position: '', hire_date: '',
    salary_usd: '', salary_syp: '',
  });
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const step1Valid = form.position.trim() && form.hire_date;
  const step2Valid = form.department.trim();
  const step3Valid = form.salary_usd.trim();

  const handleNext = () => {
    if (step === 1 && !step1Valid) return;
    if (step === 2 && !step2Valid) return;
    if (step < 3) { setStep(s => s + 1); return; }
    // Final step — save
    if (!step3Valid) return;
    setSaving(true);
    const uid = `u_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    addEmployee({
      user_id: uid,
      employee_number: `EMP-${Date.now().toString().slice(-4)}`,
      department: form.department,
      position: form.position,
      hire_date: form.hire_date,
      salary_usd: parseFloat(form.salary_usd) || 0,
      salary_syp: parseFloat(form.salary_syp) || 0,
      working_hours: 8,
      is_active: true,
    });
    setSaving(false);
    setSaved(true);
    setTimeout(onClose, 1200);
  };

  const ROLES: { value: import('../types').UserRole; label: string }[] = [
    { value: 'worker', label: 'عامل' },
    { value: 'production_supervisor', label: 'مشرف إنتاج' },
    { value: 'hr', label: 'موارد بشرية' },
    { value: 'accountant', label: 'محاسب' },
    { value: 'manager', label: 'مدير' },
  ];

  return (
    <BottomSheetModal isOpen onClose={onClose} maxHeight="92dvh">
      <SheetHeader className="px-5 pt-3 pb-4 bg-gradient-to-r from-blue-600 to-indigo-600">
        <h2 className="text-lg font-black text-white">إضافة موظف جديد</h2>
        <div className="flex gap-2 mt-3">
          {[1, 2, 3].map(s => (
            <div key={s} className={`h-1 flex-1 rounded-full transition-all ${s <= step ? 'bg-white' : 'bg-white/30'}`} />
          ))}
        </div>
        <p className="text-white/70 text-xs mt-1">الخطوة {step} من 3</p>
      </SheetHeader>

      <SheetBody>
        {saved ? (
          <div className="flex flex-col items-center justify-center py-8 gap-3">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center">
              <CheckCircle size={32} className="text-emerald-600" />
            </div>
            <p className="font-bold text-gray-800">تم إضافة الموظف بنجاح</p>
          </div>
        ) : (
          <>
            {step === 1 && (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-3">
                <p className="font-bold text-gray-700">بيانات التوظيف</p>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">المسمى الوظيفي *</label>
                  <input value={form.position} onChange={e => set('position', e.target.value)}
                    placeholder="مشرف إنتاج" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm" style={{ fontSize: 16 }} />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">تاريخ التعيين *</label>
                  <input type="date" value={form.hire_date} onChange={e => set('hire_date', e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm" style={{ fontSize: 16 }} />
                </div>
              </motion.div>
            )}
            {step === 2 && (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-3">
                <p className="font-bold text-gray-700">القسم</p>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">القسم *</label>
                  <input value={form.department} onChange={e => set('department', e.target.value)}
                    placeholder="الإنتاج" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm" style={{ fontSize: 16 }} />
                </div>
              </motion.div>
            )}
            {step === 3 && (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-3">
                <p className="font-bold text-gray-700">الراتب والمزايا</p>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">الراتب بالدولار ($) *</label>
                  <input type="number" value={form.salary_usd} onChange={e => set('salary_usd', e.target.value)}
                    placeholder="500" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm" style={{ fontSize: 16 }} />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 mb-1 block">الراتب بالليرة (ل.س)</label>
                  <input type="number" value={form.salary_syp} onChange={e => set('salary_syp', e.target.value)}
                    placeholder="يحتسب تلقائياً" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm" style={{ fontSize: 16 }} />
                </div>
              </motion.div>
            )}
          </>
        )}
      </SheetBody>

      {!saved && (
        <SheetFooter>
          <div style={{ display: 'grid', gridTemplateColumns: step > 1 ? '1fr 2fr' : '1fr', gap: 10 }}>
            {step > 1 && (
              <button onClick={() => setStep(s => s - 1)}
                style={{ padding: '14px 0', borderRadius: 14, border: '1.5px solid #E2E8F0', background: 'var(--surface)', color: '#64748B', fontSize: 13, fontWeight: 700, cursor: 'pointer', minHeight: 'unset' }}>
                السابق
              </button>
            )}
            <button onClick={handleNext} disabled={saving || (step === 1 && !step1Valid) || (step === 2 && !step2Valid) || (step === 3 && !step3Valid)}
              style={{
                padding: '14px 0', borderRadius: 14, border: 'none',
                background: saving ? '#9CA3AF' : '#3B82F6',
                color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer',
                minHeight: 'unset', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              }}>
              {saving
                ? <><div style={{ width: 16, height: 16, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 1s linear infinite' }} /> جاري الحفظ</>
                : step < 3 ? 'التالي ←' : '✓ حفظ الموظف'}
            </button>
          </div>
        </SheetFooter>
      )}
    </BottomSheetModal>
  );
};

