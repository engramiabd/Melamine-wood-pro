import { supplierSchema, collectErrors } from '../lib/validation';
import React, { useMemo, useState } from 'react';
import { Truck, Plus, PackageCheck, X, Trash2, ShoppingCart } from 'lucide-react';
import { useAppData } from '../contexts/AppDataContext';
import { useAuth } from '../contexts/AuthContext';
import type { PurchaseOrderItem } from '../types';

const STATUS_META: Record<string, { label: string; color: string; bg: string }> = {
  draft:     { label: 'مسودة',   color: 'var(--text-tertiary)', bg: 'var(--border-color)' },
  sent:      { label: 'مُرسل',    color: '#0891b2', bg: '#ecfeff' },
  received:  { label: 'مُستلم',   color: '#16a34a', bg: '#f0fdf4' },
  cancelled: { label: 'ملغى',     color: '#ef4444', bg: '#fef2f2' },
};

export const SuppliersPage: React.FC = () => {
  const {
    suppliers, addSupplier,
    purchaseOrders, addPurchaseOrder, receivePurchaseOrder, cancelPurchaseOrder,
    inventoryItems, systemSettings, can,
  } = useAppData();
  const { user } = useAuth();
  const canManage = can('purchasing.manage');

  const [tab, setTab] = useState<'suppliers' | 'orders'>('suppliers');
  const [showSupplier, setShowSupplier] = useState(false);
  const [showPO, setShowPO] = useState(false);

  return (
    <div className="min-h-full bg-gray-50 pb-24" dir="rtl">
      {/* Hero */}
      <div className="bg-gradient-to-br from-violet-600 to-indigo-700 px-5 pt-6 pb-8 text-white">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center">
            <Truck size={22} />
          </div>
          <div>
            <h1 className="text-lg font-extrabold">الموردون والمشتريات</h1>
            <p className="text-xs text-white/70">{suppliers.length} مورّد • {purchaseOrders.length} أمر شراء</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 -mt-4">
        <div className="bg-white rounded-2xl shadow-sm p-1 flex">
          {([['suppliers', 'الموردون'], ['orders', 'أوامر الشراء']] as const).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition ${tab === key ? 'bg-indigo-600 text-white' : 'text-gray-500'}`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Suppliers tab */}
      {tab === 'suppliers' && (
        <div className="px-4 mt-4 space-y-2">
          {canManage && (
            <button
              onClick={() => setShowSupplier(true)}
              className="w-full bg-white rounded-2xl p-3.5 shadow-sm flex items-center justify-center gap-2 text-indigo-600 font-bold text-sm"
            >
              <Plus size={18} /> إضافة مورّد
            </button>
          )}
          {suppliers.map((s) => (
            <div key={s.id} className="bg-white rounded-2xl p-3.5 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="font-bold text-gray-800">{s.name}</span>
                {s.category && <span className="text-[11px] px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-600">{s.category}</span>}
              </div>
              <div className="mt-1 text-xs text-gray-400 flex flex-wrap gap-x-3">
                {s.contact_person && <span>{s.contact_person}</span>}
                {s.phone && <span dir="ltr">{s.phone}</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Purchase orders tab */}
      {tab === 'orders' && (
        <div className="px-4 mt-4 space-y-2">
          {canManage && (
            <button
              onClick={() => setShowPO(true)}
              className="w-full bg-white rounded-2xl p-3.5 shadow-sm flex items-center justify-center gap-2 text-indigo-600 font-bold text-sm"
            >
              <ShoppingCart size={18} /> أمر شراء جديد
            </button>
          )}
          {purchaseOrders.length === 0 && (
            <div className="text-center text-gray-400 text-sm py-12">لا توجد أوامر شراء بعد</div>
          )}
          {purchaseOrders.map((po) => {
            const meta = STATUS_META[po.status] || STATUS_META.draft;
            return (
              <div key={po.id} className="bg-white rounded-2xl p-3.5 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-gray-800">{po.po_number}</span>
                    <p className="text-xs text-gray-400">{po.supplier_name}</p>
                  </div>
                  <span className="text-[11px] px-2 py-1 rounded-full font-bold" style={{ color: meta.color, background: meta.bg }}>
                    {meta.label}
                  </span>
                </div>
                <div className="mt-2 text-xs text-gray-500">
                  {po.items.length} صنف • الإجمالي <span className="font-bold text-gray-700">${po.total_usd.toLocaleString()}</span>
                </div>
                {po.status !== 'received' && po.status !== 'cancelled' && canManage && (
                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() => receivePurchaseOrder(po.id)}
                      className="flex-1 bg-emerald-600 text-white rounded-xl py-2 text-sm font-bold flex items-center justify-center gap-1.5"
                    >
                      <PackageCheck size={16} /> استلام وإضافة للمخزون
                    </button>
                    <button
                      onClick={() => cancelPurchaseOrder(po.id)}
                      className="px-3 bg-gray-100 text-gray-500 rounded-xl"
                    >
                      <X size={16} />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {showSupplier && (
        <SupplierModal
          onClose={() => setShowSupplier(false)}
          onSave={(data) => { addSupplier(data); setShowSupplier(false); }}
        />
      )}
      {showPO && (
        <PurchaseOrderModal
          suppliers={suppliers}
          items={inventoryItems}
          exchangeRate={systemSettings.exchangeRate}
          createdBy={user?.full_name || 'مستخدم'}
          onClose={() => setShowPO(false)}
          onSave={(po) => { addPurchaseOrder(po); setShowPO(false); setTab('orders'); }}
        />
      )}
    </div>
  );
};

/* ── Supplier modal ─────────────────────────────────────────── */
const SupplierModal: React.FC<{
  onClose: () => void;
  onSave: (data: { name: string; contact_person?: string; phone?: string; category?: string; balance_usd: number; is_active: boolean }) => void;
}> = ({ onClose, onSave }) => {
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [phone, setPhone] = useState('');
  const [category, setCategory] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const submit = () => {
    const errs = collectErrors(supplierSchema, { name, phone });
    if (errs) { setErrors(errs); return; }
    setErrors({});
    onSave({ name: name.trim(), contact_person: contact || undefined, phone: phone || undefined, category: category || undefined, balance_usd: 0, is_active: true });
  };

  return (
    <Overlay onClose={onClose} title="مورّد جديد">
      <div className="space-y-3">
        <Field label="اسم المورّد"><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} />{errors.name && <span style={{ fontSize: 11, color: '#ef4444', marginTop: 4, display: 'block' }}>{errors.name}</span>}</Field>
        <Field label="جهة الاتصال"><input className={inputCls} value={contact} onChange={(e) => setContact(e.target.value)} /></Field>
        <Field label="الهاتف"><input dir="ltr" className={inputCls} value={phone} onChange={(e) => setPhone(e.target.value)} />{errors.phone && <span style={{ fontSize: 11, color: '#ef4444', marginTop: 4, display: 'block' }}>{errors.phone}</span>}</Field>
        <Field label="الفئة (ما يورّده)"><input className={inputCls} value={category} onChange={(e) => setCategory(e.target.value)} /></Field>
      </div>
      <button
        disabled={!name.trim()}
        onClick={submit}
        className="w-full mt-4 bg-indigo-600 disabled:opacity-40 text-white rounded-xl py-3 font-bold"
      >
        حفظ المورّد
      </button>
    </Overlay>
  );
};

/* ── Purchase order modal ───────────────────────────────────── */
const PurchaseOrderModal: React.FC<{
  suppliers: { id: string; name: string }[];
  items: { id: string; name: string; unit: string; current_price: number }[];
  exchangeRate: number;
  createdBy: string;
  onClose: () => void;
  onSave: (po: {
    supplier_id: string; supplier_name: string; items: PurchaseOrderItem[];
    total_usd: number; total_syp: number; order_date: string; created_by: string;
  }) => void;
}> = ({ suppliers, items, exchangeRate, createdBy, onClose, onSave }) => {
  const [supplierId, setSupplierId] = useState(suppliers[0]?.id || '');
  const [lines, setLines] = useState<PurchaseOrderItem[]>([]);
  const [itemId, setItemId] = useState(items[0]?.id || '');
  const [qty, setQty] = useState(10);

  const total = useMemo(() => lines.reduce((s, l) => s + l.total_usd, 0), [lines]);

  const addLine = () => {
    const it = items.find((i) => i.id === itemId);
    if (!it || qty <= 0) return;
    const cost = it.current_price || 0;
    setLines((prev) => [
      ...prev.filter((l) => l.material_id !== it.id),
      { material_id: it.id, material_name: it.name, quantity: qty, unit: it.unit, unit_cost_usd: cost, total_usd: Math.round(cost * qty * 100) / 100 },
    ]);
  };

  const supplier = suppliers.find((s) => s.id === supplierId);

  return (
    <Overlay onClose={onClose} title="أمر شراء جديد">
      <div className="space-y-3">
        <Field label="المورّد">
          <select className={inputCls} value={supplierId} onChange={(e) => setSupplierId(e.target.value)}>
            {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>

        <div className="bg-gray-50 rounded-xl p-3 space-y-2">
          <Field label="الصنف">
            <select className={inputCls} value={itemId} onChange={(e) => setItemId(e.target.value)}>
              {items.map((i) => <option key={i.id} value={i.id}>{i.name} ({i.unit})</option>)}
            </select>
          </Field>
          <div className="flex items-end gap-2">
            <div className="flex-1">
              <Field label="الكمية"><input type="number" className={inputCls} value={qty} onChange={(e) => setQty(Number(e.target.value))} /></Field>
            </div>
            <button onClick={addLine} className="bg-indigo-600 text-white rounded-xl px-4 py-2.5 text-sm font-bold">إضافة</button>
          </div>
        </div>

        {lines.length > 0 && (
          <div className="space-y-1.5">
            {lines.map((l) => (
              <div key={l.material_id} className="flex items-center justify-between bg-white border border-gray-100 rounded-xl px-3 py-2 text-sm">
                <span className="text-gray-700">{l.material_name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-gray-400 text-xs">{l.quantity} × ${l.unit_cost_usd}</span>
                  <span className="font-bold text-gray-700">${l.total_usd}</span>
                  <button onClick={() => setLines((prev) => prev.filter((x) => x.material_id !== l.material_id))} className="text-red-400">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
            <div className="flex justify-between px-3 pt-2 text-sm font-extrabold">
              <span>الإجمالي</span><span className="text-indigo-600">${Math.round(total * 100) / 100}</span>
            </div>
          </div>
        )}
      </div>

      <button
        disabled={!supplier || lines.length === 0}
        onClick={() => supplier && onSave({
          supplier_id: supplier.id, supplier_name: supplier.name, items: lines,
          total_usd: Math.round(total * 100) / 100, total_syp: Math.round(total * exchangeRate),
          order_date: new Date().toISOString().slice(0, 10), created_by: createdBy,
        })}
        className="w-full mt-4 bg-indigo-600 disabled:opacity-40 text-white rounded-xl py-3 font-bold"
      >
        إنشاء أمر الشراء
      </button>
    </Overlay>
  );
};

/* ── Small shared UI ────────────────────────────────────────── */
const inputCls = 'w-full bg-white border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-300';

const Field: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <label className="block">
    <span className="text-xs text-gray-500 mb-1 block">{label}</span>
    {children}
  </label>
);

const Overlay: React.FC<{ title: string; onClose: () => void; children: React.ReactNode }> = ({ title, onClose, children }) => (
  <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40" onClick={onClose} dir="rtl">
    <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl p-5 max-h-[88vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base font-extrabold text-gray-800">{title}</h3>
        <button aria-label="إغلاق" onClick={onClose} className="text-gray-400"><X size={20} /></button>
      </div>
      {children}
    </div>
  </div>
);

export default SuppliersPage;
