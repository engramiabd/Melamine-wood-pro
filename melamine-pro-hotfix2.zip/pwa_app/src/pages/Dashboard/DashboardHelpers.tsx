/**
 * DashboardHelpers — constants, formatting helpers, and small sub-components
 * used exclusively by DashboardPage. Kept in a separate file to reduce
 * the main component's size without changing any behaviour.
 */
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

/* ─── Constants ──────────────────────────────────────────────────────────── */
export const DAYS_AR = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
export const MONTHS_AR = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];

export const ORDER_STATUS: Record<string, { label: string; bg: string; text: string; dot: string; border: string }> = {
  pending:       { label: 'معلق',        bg: 'bg-amber-50',   text: 'text-amber-700',   dot: '#f59e0b', border: 'border-amber-200'   },
  in_production: { label: 'في الإنتاج', bg: 'bg-blue-50',    text: 'text-blue-700',    dot: '#3b82f6', border: 'border-blue-200'    },
  quality_check: { label: 'مراجعة',      bg: 'bg-violet-50',  text: 'text-violet-700',  dot: '#8b5cf6', border: 'border-violet-200'  },
  completed:     { label: 'مكتمل',       bg: 'bg-emerald-50', text: 'text-emerald-700', dot: '#10b981', border: 'border-emerald-200' },
  cancelled:     { label: 'ملغي',        bg: 'bg-red-50',     text: 'text-red-700',     dot: '#ef4444', border: 'border-red-200'     },
  on_hold:       { label: 'موقوف',       bg: 'bg-gray-50',    text: 'text-gray-600',    dot: '#6b7280', border: 'border-gray-200'    },
};

export const LINE_STATUS = {
  active:      { label: 'نشط',   color: '#10b981', bg: 'bg-emerald-500', ring: 'ring-emerald-200', light: 'bg-emerald-50', pulse: true  },
  idle:        { label: 'خامل',  color: 'var(--text-tertiary)', bg: 'bg-gray-300',    ring: 'ring-gray-100',    light: 'bg-gray-50',    pulse: false },
  maintenance: { label: 'صيانة', color: '#f59e0b', bg: 'bg-amber-400',   ring: 'ring-amber-100',   light: 'bg-amber-50',   pulse: false },
  stopped:     { label: 'متوقف', color: '#ef4444', bg: 'bg-red-400',     ring: 'ring-red-100',     light: 'bg-red-50',     pulse: false },
};

/* ─── Helpers ────────────────────────────────────────────────────────────── */
export function greeting(h = new Date().getHours()) {
  if (h < 5)  return 'مرحباً';
  if (h < 12) return 'صباح الخير';
  if (h < 17) return 'مساء الخير';
  return 'مساء النور';
}
export const fmtTime = (d: Date) => d.toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
export const fmtDate = (d: Date) => `${DAYS_AR[d.getDay()]}، ${d.getDate()} ${MONTHS_AR[d.getMonth()]} ${d.getFullYear()}`;
export const relTime = (dateStr: string) => {
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'الآن';
  if (m < 60) return `منذ ${m} د`;
  const h = Math.floor(m / 60);
  if (h < 24) return `منذ ${h} س`;
  const d = Math.floor(h / 24);
  if (d === 1) return 'أمس';
  return `منذ ${d} أيام`;
};

/* ─── Sub-components ─────────────────────────────────────────────────────── */
export const LiveClock: React.FC = () => {
  const [t, setT] = useState(new Date());
  useEffect(() => { const id = setInterval(() => setT(new Date()), 1000); return () => clearInterval(id); }, []);
  return <span className="font-mono tabular-nums text-blue-200/70 text-[11px] tracking-wide">{fmtTime(t)}</span>;
};

export const PulseDot: React.FC<{ color?: string; size?: number }> = ({ color = 'bg-emerald-400', size = 2.5 }) => (
  <span className="relative flex" style={{ width: size * 4, height: size * 4 }}>
    <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${color} opacity-50`} />
    <span className={`relative inline-flex rounded-full ${color}`} style={{ width: size * 4, height: size * 4 }} />
  </span>
);

export const AnimNum: React.FC<{ value: number; dur?: number; prefix?: string; suffix?: string }> = ({ value, dur = 900, prefix = '', suffix = '' }) => {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const from = 0;
    const tick = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / dur, 1);
      setDisplay(Math.round(from + (value - from) * progress));
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, dur]);
  return <>{prefix}{display.toLocaleString('ar')}{suffix}</>;
};

export const ChartTooltip: React.FC<{ active?: boolean; payload?: Array<{ value: number; name: string; color: string }>; label?: string; fmt?: (v: number) => string }> = ({ active, payload, label, fmt }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-gray-900/95 backdrop-blur-md rounded-2xl p-3 shadow-2xl text-white text-xs min-w-[130px] border border-white/10" dir="rtl">
      <p className="text-gray-400 mb-2 font-semibold text-[10px] uppercase tracking-wide">{label}</p>
      {payload.map((p, i) => (
        <div key={i} className="flex items-center justify-between gap-3 mb-1 last:mb-0">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }} />
            <span className="text-gray-300 text-[10px]">{p.name}</span>
          </div>
          <span className="font-bold text-white">{fmt ? fmt(p.value) : p.value}</span>
        </div>
      ))}
    </div>
  );
};

/* ─── Card Components ────────────────────────────────────────────────────── */
export const MetricCard: React.FC<{
  label: string; value: React.ReactNode; sub?: string;
  icon: React.ReactNode; gradient: string; iconBg?: string;
  trend?: { val: number; positive: boolean; label?: string };
  onClick?: () => void; delay?: number; className?: string;
}> = ({ label, value, sub, icon, gradient, iconBg = 'bg-white/70', trend, onClick, delay = 0, className = '' }) => (
  <motion.div
    initial={{ opacity: 0, y: 20, scale: 0.95 }}
    animate={{ opacity: 1, y: 0, scale: 1 }}
    transition={{ delay, type: 'spring', stiffness: 300, damping: 26 }}
    whileTap={onClick ? { scale: 0.96 } : undefined}
    onClick={onClick}
    className={`${gradient} rounded-2xl p-4 relative overflow-hidden border border-white/60 shadow-sm ${onClick ? 'cursor-pointer active:shadow-none' : ''} ${className}`}
  >
    {/* Decorative circles */}
    <div className="absolute -bottom-5 -left-5 w-24 h-24 rounded-full bg-white/15 pointer-events-none" />
    <div className="absolute -top-2 -right-2 w-14 h-14 rounded-full bg-white/10 pointer-events-none" />

    <div className="relative">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 ${iconBg} backdrop-blur-sm rounded-xl flex items-center justify-center shadow-sm border border-white/30`}>
          {icon}
        </div>
        {trend && (
          <div className={`flex items-center gap-0.5 text-[10px] font-bold px-2 py-1 rounded-xl border ${trend.positive ? 'bg-emerald-100/80 text-emerald-700 border-emerald-200' : 'bg-red-100/80 text-red-600 border-red-200'}`}>
            <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" className={trend.positive ? '' : 'rotate-180'}>
              <polyline points="18 15 12 9 6 15" />
            </svg>
            {trend.val}%{trend.label ? ` ${trend.label}` : ''}
          </div>
        )}
      </div>
      <p className="text-[22px] font-black leading-none mb-1 text-gray-900">{value}</p>
      <p className="text-[12px] font-semibold text-gray-700 opacity-80">{label}</p>
      {sub && <p className="text-[10px] text-gray-500 mt-0.5">{sub}</p>}
    </div>
  </motion.div>
);

export const QuickActionBtn: React.FC<{
  icon: React.ReactNode; label: string; sub?: string;
  gradient: string; onClick: () => void; delay?: number; badge?: number;
}> = ({ icon, label, sub, gradient, onClick, delay = 0, badge }) => (
  <motion.button
    initial={{ opacity: 0, scale: 0.8, y: 10 }}
    animate={{ opacity: 1, scale: 1, y: 0 }}
    transition={{ delay, type: 'spring', stiffness: 340, damping: 24 }}
    whileTap={{ scale: 0.91, transition: { duration: 0.1 } }}
    onClick={onClick}
    className={`${gradient} rounded-2xl p-3.5 text-white shadow-lg relative overflow-hidden flex flex-col items-center gap-2 w-full active:shadow-sm`}
  >
    <div className="absolute -top-3 -right-3 w-14 h-14 rounded-full bg-white/10 pointer-events-none" />
    <div className="absolute -bottom-2 -left-2 w-10 h-10 rounded-full bg-white/10 pointer-events-none" />
    {badge !== undefined && badge > 0 && (
      <span className="absolute top-2 left-2 min-w-[18px] h-[18px] bg-red-500 rounded-full text-[9px] font-black flex items-center justify-center border-2 border-white shadow">
        {badge > 9 ? '9+' : badge}
      </span>
    )}
    <div className="w-11 h-11 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm border border-white/20 relative z-10">
      {icon}
    </div>
    <div className="relative z-10 text-center">
      <p className="text-[11px] font-black leading-tight">{label}</p>
      {sub && <p className="text-[9px] opacity-70 mt-0.5">{sub}</p>}
    </div>
  </motion.button>
);

export const SectionTitle: React.FC<{
  icon: React.ReactNode; title: string; sub?: string;
  action?: { label: string; onClick: () => void }; accent: string;
}> = ({ icon, title, sub, action, accent }) => (
  <div className="flex items-center justify-between">
    <div className="flex items-center gap-3">
      <div className={`w-9 h-9 ${accent} rounded-xl flex items-center justify-center shadow-sm`}>{icon}</div>
      <div>
        <h3 className="font-bold text-gray-900 text-[15px] leading-tight">{title}</h3>
        {sub && <p className="text-[10px] text-gray-400 mt-0">{sub}</p>}
      </div>
    </div>
    {action && (
      <button onClick={action.onClick}
        className="flex items-center gap-1 text-[11px] text-blue-600 font-bold px-3 py-1.5 bg-blue-50 rounded-xl active:bg-blue-100 transition-colors border border-blue-100">
        {action.label}
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="rotate-180"><polyline points="15 18 9 12 15 6" /></svg>
      </button>
    )}
  </div>
);

/* ─── Status Strip Component ─────────────────────────────────────────────── */
export const StatusStrip: React.FC<{ items: { label: string; value: React.ReactNode; icon: React.ReactNode; bg: string; text: string }[] }> = ({ items }) => (
  <div className="grid grid-cols-3 gap-2">
    {items.map((item, i) => (
      <motion.div key={i}
        initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 + i * 0.06, type: 'spring', stiffness: 320, damping: 24 }}
        className={`${item.bg} rounded-2xl p-3 text-center border border-white/40 relative overflow-hidden`}
      >
        <div className="absolute -bottom-3 -right-3 w-12 h-12 rounded-full bg-white/20 pointer-events-none" />
        <div className={`w-7 h-7 bg-white/30 rounded-xl flex items-center justify-center mx-auto mb-1.5 backdrop-blur-sm`}>{item.icon}</div>
        <p className={`${item.text} font-black text-base leading-none`}>{item.value}</p>
        <p className={`${item.text} opacity-80 text-[9px] mt-0.5 font-medium`}>{item.label}</p>
      </motion.div>
    ))}
  </div>
);

