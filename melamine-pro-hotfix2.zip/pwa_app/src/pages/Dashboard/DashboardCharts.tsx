/**
 * DashboardCharts — recharts analytics section of the Dashboard.
 * Isolated so recharts is tree-shaken from the initial JS bundle and
 * only imported when this component first renders.
 */
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip,
  BarChart, Bar, CartesianGrid,
} from 'recharts';
import { SectionTitle, ChartTooltip } from './DashboardHelpers';

interface RevenuePoint { day: string; rev: number; exp: number; profit: number }
interface ProdPoint    { day: string; qty: number; target: number }
interface AttPoint     { day: string; present: number; absent: number }

export interface DashboardChartsProps {
  chartTab:     'revenue' | 'production' | 'attendance';
  setChartTab:  (t: 'revenue' | 'production' | 'attendance') => void;
  canFinance:   boolean;
  revenueData:  RevenuePoint[];
  productionData: ProdPoint[];
  attChartData: AttPoint[];
  profitPct:    string;
  formatUSD:    (v: number) => string;
  onNavigateReports: () => void;
}

export const DashboardCharts: React.FC<DashboardChartsProps> = React.memo(({
  chartTab, setChartTab, canFinance,
  revenueData, productionData, attChartData,
  profitPct, formatUSD, onNavigateReports,
}) => (
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-4 pt-4 pb-2 border-b border-gray-50">
            <SectionTitle
              icon={<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>}
              title="التحليلات" accent="bg-blue-500"
              action={{ label: 'التقارير', onClick: onNavigateReports }}
            />
          </div>
          {/* Tab selector */}
          <div className="flex border-b border-gray-50">
            {[
              { id: 'revenue', label: 'المالية' },
              { id: 'production', label: 'الإنتاج' },
              { id: 'attendance', label: 'الحضور' },
            ].filter(tab => tab.id !== 'revenue' || canFinance).map(tab => (
              <button key={tab.id} onClick={() => setChartTab(tab.id as typeof chartTab)}
                className={`flex-1 py-2.5 text-[12px] font-bold transition-all relative ${chartTab === tab.id ? 'text-blue-600' : 'text-gray-400'}`}>
                {tab.label}
                {chartTab === tab.id && (
                  <motion.div layoutId="chart-tab-indicator"
                    className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-blue-500 rounded-full" />
                )}
              </button>
            ))}
          </div>

          <div className="p-4">
            <AnimatePresence mode="wait">
              {chartTab === 'revenue' && (
                <motion.div key="revenue" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} transition={{ duration: 0.18 }}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3 text-[10px]">
                      <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-blue-500" />إيرادات</span>
                      <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-400" />مصاريف</span>
                      <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />الربح</span>
                    </div>
                    <span className={`text-[11px] font-bold ${Number(profitPct) >= 20 ? 'text-emerald-600' : 'text-amber-600'}`}>هامش {profitPct}%</span>
                  </div>
                  <ResponsiveContainer width="100%" height={160}>
                    <AreaChart data={revenueData} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
                      <defs>
                        <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#3b82f6" stopOpacity={0.25}/><stop offset="100%" stopColor="#3b82f6" stopOpacity={0.02}/></linearGradient>
                        <linearGradient id="expGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#ef4444" stopOpacity={0.2}/><stop offset="100%" stopColor="#ef4444" stopOpacity={0.02}/></linearGradient>
                        <linearGradient id="profGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#10b981" stopOpacity={0.2}/><stop offset="100%" stopColor="#10b981" stopOpacity={0.02}/></linearGradient>
                      </defs>
                      <XAxis dataKey="day" tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
                      <Tooltip content={<ChartTooltip fmt={v => formatUSD(v)} />} />
                      <Area type="monotone" dataKey="rev" name="إيرادات" stroke="#3b82f6" strokeWidth={2} fill="url(#revGrad)" dot={false} />
                      <Area type="monotone" dataKey="exp" name="مصاريف" stroke="#ef4444" strokeWidth={2} fill="url(#expGrad)" dot={false} />
                      <Area type="monotone" dataKey="profit" name="الربح" stroke="#10b981" strokeWidth={1.5} fill="url(#profGrad)" dot={false} strokeDasharray="4 2" />
                    </AreaChart>
                  </ResponsiveContainer>
                </motion.div>
              )}
              {chartTab === 'production' && (
                <motion.div key="production" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} transition={{ duration: 0.18 }}>
                  <div className="flex items-center gap-3 mb-3 text-[10px]">
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-blue-500" />فعلي</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-gray-200" />هدف</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-400" />معيب</span>
                  </div>
                  <ResponsiveContainer width="100%" height={160}>
                    <BarChart data={productionData} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
                      <defs>
                        <linearGradient id="barActual" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9}/><stop offset="100%" stopColor="#6366f1" stopOpacity={0.7}/></linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                      <XAxis dataKey="name" tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
                      <Tooltip content={<ChartTooltip />} />
                      <Bar dataKey="actual" name="فعلي" fill="url(#barActual)" radius={[5, 5, 0, 0]} maxBarSize={32} />
                      <Bar dataKey="target" name="هدف" fill="var(--border-color)" radius={[5, 5, 0, 0]} maxBarSize={32} />
                      <Bar dataKey="defect" name="معيب" fill="#fca5a5" radius={[5, 5, 0, 0]} maxBarSize={32} />
                    </BarChart>
                  </ResponsiveContainer>
                </motion.div>
              )}
              {chartTab === 'attendance' && (
                <motion.div key="attendance" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }} transition={{ duration: 0.18 }}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3 text-[10px]">
                      <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />حاضر</span>
                      <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-amber-400" />متأخر</span>
                    </div>
                    <span className="text-[11px] font-bold text-emerald-600">{attStats.pct}% نسبة الحضور</span>
                  </div>
                  <ResponsiveContainer width="100%" height={160}>
                    <BarChart data={attChartData} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
                      <XAxis dataKey="day" tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
                      <Tooltip content={<ChartTooltip />} />
                      <Bar dataKey="present" name="حاضر" fill="#10b981" radius={[5, 5, 0, 0]} maxBarSize={28} stackId="a" />
                      <Bar dataKey="late" name="متأخر" fill="#f59e0b" radius={[5, 5, 0, 0]} maxBarSize={28} stackId="b" />
                    </BarChart>
                  </ResponsiveContainer>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
));
