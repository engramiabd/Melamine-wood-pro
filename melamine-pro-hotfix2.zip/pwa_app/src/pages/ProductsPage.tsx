import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAppData } from '../contexts/AppDataContext';
import { productSchema, collectErrors } from '../lib/validation';
import { EmptyState } from '../components/ui/EmptyState';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import {
  Search, Plus, Package, Edit2, Trash2, CheckCircle,
  AlertTriangle, Layers, Barcode, Printer,
} from 'lucide-react';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter, CenterModal } from '../components/ui/Modal';
import { Pagination, usePagination } from '../components/ui/Pagination';
import { printProductLabels } from '../utils/barcode';
import type { Product, MelamineThickness, MelamineSize, MelamineFinish } from '../types';

const THICKNESS_OPTS: MelamineThickness[] = ['2.3mm', '3.6mm', '5.5mm', '7mm', '11mm', '13mm', '15.5mm', '17mm', '17.5mm'];
const SIZE_OPTS: MelamineSize[] = ['244x122', '183x122', '244x183'];
const FINISH_OPTS: MelamineFinish[] = ['مطفي', 'لامع', 'خشبي', 'سادة'];
const FACES_OPTS: Array<'وجه' | 'وجهين'> = ['وجه', 'وجهين'];
const GRADE_OPTS: string[] = ['نخب أول', 'نخب ثاني', 'كسر', 'صيني', 'أخضر'];

interface ProductFormState {
  name: string; code: string; thickness: MelamineThickness; size: MelamineSize;
  finish: MelamineFinish; color: string; price_usd: string; price_syp: string;
  cost_usd: string; stock_quantity: string; min_stock: string; description: string;
  faces: 'وجه' | 'وجهين'; grade: string;
}

const EMPTY_FORM: ProductFormState = {
  name: '', code: '', thickness: '17mm', size: '244x122', finish: 'سادة',
  color: '', price_usd: '', price_syp: '', cost_usd: '', stock_quantity: '0',
  min_stock: '40', description: '', faces: 'وجهين', grade: 'نخب أول',
};

export default function ProductsPage() {
  const { managedProducts, addProduct, updateProduct, deleteProduct } = useAppData();
  const { formatUSD, exchangeRate } = useCurrency();
  const { hasRole } = useAuth();
  const canManage = hasRole('admin') || hasRole('manager');

  const [search, setSearch] = useState('');
  const [modal, setModal] = useState<{ mode: 'add' | 'edit'; id?: string } | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [form, setForm] = useState<ProductFormState>(EMPTY_FORM);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return managedProducts;
    return managedProducts.filter(p =>
      p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q));
  }, [managedProducts, search]);

  const PAGE_SIZE = 12;
  const [page, setPage] = useState(1);
  useEffect(() => { setPage(1); }, [search]);
  const { pageItems: paged, safePage } = usePagination(filtered, PAGE_SIZE, page);

  const openAdd = () => { setForm(EMPTY_FORM); setErrors({}); setModal({ mode: 'add' }); };
  const openEdit = (p: Product) => {
    setForm({
      name: p.name, code: p.code, thickness: p.thickness, size: p.size, finish: p.finish,
      color: p.color, price_usd: String(p.price_usd), price_syp: String(p.price_syp),
      cost_usd: String(p.cost_usd), stock_quantity: String(p.stock_quantity),
      min_stock: String(p.min_stock), description: p.description || '',
      faces: p.faces || 'وجهين', grade: p.grade || 'نخب أول',
    });
    setModal({ mode: 'edit', id: p.id });
  };
  const closeModal = () => { setErrors({}); setModal(null); };

  // Auto-calculate SYP price from USD using the live exchange rate when the
  // user hasn't manually overridden it.
  const handleUsdPriceChange = (v: string) => {
    setForm(f => ({ ...f, price_usd: v, price_syp: v ? String(Math.round(parseFloat(v) * exchangeRate)) : f.price_syp }));
  };

  const handleSave = () => {
    const errs = collectErrors(productSchema, {
      name: form.name, code: form.code,
      price_usd: parseFloat(form.price_usd) || 0,
      cost_usd: parseFloat(form.cost_usd) || 0,
    });
    if (errs) { setErrors(errs); return; }
    setErrors({});
    if (!form.name.trim() || !form.code.trim() || !form.price_usd) return;
    const payload = {
      name: form.name.trim(), code: form.code.trim(), thickness: form.thickness,
      size: form.size, finish: form.finish, color: form.color,
      price_usd: parseFloat(form.price_usd) || 0,
      price_syp: parseFloat(form.price_syp) || 0,
      cost_usd: parseFloat(form.cost_usd) || 0,
      stock_quantity: parseFloat(form.stock_quantity) || 0,
      min_stock: parseFloat(form.min_stock) || 0,
      description: form.description || undefined,
      // Factory model fields (drive the real BOM): faces, grade, numeric
      // thickness, and paper colour number (= numeric part of the code).
      faces: form.faces,
      grade: form.grade,
      thickness_mm: parseFloat(String(form.thickness).replace(/[^0-9.]/g, '')) || undefined,
      color_number: parseInt((form.code.match(/\d+/) || ['0'])[0], 10) || undefined,
    };
    if (modal?.mode === 'edit' && modal.id) updateProduct(modal.id, payload);
    else addProduct(payload);
    closeModal();
  };

  return (
    <div style={{ minHeight: '100%', background: 'var(--surface-secondary)' }}>
      <div style={{ background: 'linear-gradient(135deg,#ec4899,#db2777)', padding: '20px 16px 60px' }}>
        <div style={{ marginBottom: 16 }}>
          <h1 style={{ fontSize: 20, fontWeight: 900, color: '#fff' }}>المنتجات</h1>
          <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.8)' }}>{managedProducts.length} منتج في الكتالوج</p>
        </div>
        <div style={{ position: 'relative' }}>
          <Search size={16} style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="ابحث بالاسم أو الكود..."
            style={{ width: '100%', padding: '12px 40px 12px 14px', borderRadius: 14, border: 'none', fontSize: 14, outline: 'none', boxSizing: 'border-box', boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }} />
        </div>
      </div>

      <div style={{ padding: 16, marginTop: -36, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12 }}>
        {paged.map(p => {
          const lowStock = p.stock_quantity <= p.min_stock;
          const margin = p.cost_usd > 0 ? ((p.price_usd - p.cost_usd) / p.cost_usd * 100) : 0;
          return (
            <motion.div key={p.id} layout
              style={{ background: 'var(--surface)', borderRadius: 16, padding: 14, border: '1px solid var(--border-color)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: '#fdf2f8', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Layers size={16} color="#db2777" />
                </div>
                {lowStock && <AlertTriangle size={14} color="#f59e0b" />}
              </div>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 2 }}>{p.name}</div>
              <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 8 }}>{p.code}</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 10 }}>
                <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 99, background: 'var(--border-color)', color: 'var(--text-tertiary)', fontWeight: 600 }}>{p.thickness}</span>
                <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 99, background: 'var(--border-color)', color: 'var(--text-tertiary)', fontWeight: 600 }}>{p.finish}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                <span style={{ fontSize: 16, fontWeight: 800, color: 'var(--text-primary)' }}>{formatUSD(p.price_usd)}</span>
                {p.cost_usd > 0 && <span style={{ fontSize: 10, color: margin >= 20 ? '#16a34a' : '#f59e0b', fontWeight: 700 }}>{margin.toFixed(0)}%</span>}
              </div>
              <div style={{ fontSize: 11, color: lowStock ? '#dc2626' : 'var(--text-tertiary)', marginBottom: 10 }}>
                المخزون: {p.stock_quantity} {lowStock && '(منخفض)'}
              </div>
              <button onClick={() => printProductLabels([{ code: p.code, name: p.name, thickness: p.thickness, faces: p.faces, grade: p.grade }])}
                style={{ width: '100%', padding: '7px', borderRadius: 8, border: '1px solid #c7d2fe', background: '#eef2ff', color: '#4338ca', fontSize: 11, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, marginBottom: 6 }}>
                <Barcode size={12} /> طباعة ملصق
              </button>
              {canManage && (
                <div style={{ display: 'flex', gap: 6 }}>
                  <button onClick={() => openEdit(p)}
                    style={{ flex: 1, padding: '7px', borderRadius: 8, border: '1px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
                    <Edit2 size={11} /> تعديل
                  </button>
                  <button onClick={() => setDeleteConfirm(p.id)}
                    style={{ padding: '7px 10px', borderRadius: 8, border: '1px solid #fecaca', background: '#fef2f2', color: '#dc2626', cursor: 'pointer' }}>
                    <Trash2 size={12} />
                  </button>
                </div>
              )}
            </motion.div>
          );
        })}
        {filtered.length === 0 && (
          <div style={{ gridColumn: '1/-1' }}>
            <EmptyState icon={Package} title="لا توجد منتجات مطابقة" description="جرّب تعديل البحث أو الفلاتر، أو أضِف منتجاً جديداً." />
          </div>
        )}
      </div>
      {filtered.length > 0 && <Pagination page={safePage} totalItems={filtered.length} pageSize={PAGE_SIZE} onPageChange={setPage} />}

      {filtered.length > 0 && (
        <div style={{ padding: '0 16px 16px' }}>
          <button onClick={() => printProductLabels(filtered.slice(0, 120).map(p => ({ code: p.code, name: p.name, thickness: p.thickness, faces: p.faces, grade: p.grade })))}
            style={{ width: '100%', padding: '11px', borderRadius: 12, border: '1px solid #c7d2fe', background: '#eef2ff', color: '#4338ca', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <Printer size={14} /> طباعة ملصقات القائمة ({Math.min(filtered.length, 120)})
          </button>
        </div>
      )}

      {canManage && (
        <button onClick={openAdd}
          style={{
            position: 'fixed', left: 20, bottom: `calc(var(--bottomnav-h) + var(--sab) + 16px)`,
            width: 52, height: 52, borderRadius: '50%',
            background: 'linear-gradient(135deg,#ec4899,#db2777)',
            color: '#fff', border: 'none', cursor: 'pointer', zIndex: 30,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 20px rgba(219,39,119,0.4)',
          }}>
          <Plus size={22} />
        </button>
      )}

      {(modal?.mode === 'add' || modal?.mode === 'edit') && (
        <BottomSheetModal isOpen onClose={closeModal}>
          <SheetHeader onClose={closeModal}>
            <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>
              {modal.mode === 'edit' ? 'تعديل المنتج' : 'إضافة منتج جديد'}
            </div>
          </SheetHeader>
          <SheetBody>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>اسم المنتج *</label>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  placeholder="لوح ميلامين أبيض" style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: `1.5px solid ${errors.name ? '#ef4444' : 'var(--border-color)'}`, fontSize: 16, outline: 'none', boxSizing: 'border-box' }} />
                {errors.name && <span style={{ fontSize: 11, color: '#ef4444', marginTop: 4, display: 'block' }}>{errors.name}</span>}
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>الكود *</label>
                <input value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))}
                  placeholder="MEL-18-WHT" dir="ltr" style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: `1.5px solid ${errors.code ? '#ef4444' : 'var(--border-color)'}`, fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                {errors.code && <span style={{ fontSize: 11, color: '#ef4444', marginTop: 4, display: 'block' }}>{errors.code}</span>}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>السماكة</label>
                  <select value={form.thickness} onChange={e => setForm(f => ({ ...f, thickness: e.target.value as MelamineThickness }))}
                    style={{ width: '100%', padding: '10px 8px', borderRadius: 10, border: '1.5px solid var(--border-color)', fontSize: 13, outline: 'none', background: 'var(--surface)' }}>
                    {THICKNESS_OPTS.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>المقاس</label>
                  <select value={form.size} onChange={e => setForm(f => ({ ...f, size: e.target.value as MelamineSize }))}
                    style={{ width: '100%', padding: '10px 8px', borderRadius: 10, border: '1.5px solid var(--border-color)', fontSize: 13, outline: 'none', background: 'var(--surface)' }}>
                    {SIZE_OPTS.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>اللمسة</label>
                  <select value={form.finish} onChange={e => setForm(f => ({ ...f, finish: e.target.value as MelamineFinish }))}
                    style={{ width: '100%', padding: '10px 8px', borderRadius: 10, border: '1.5px solid var(--border-color)', fontSize: 13, outline: 'none', background: 'var(--surface)' }}>
                    {FINISH_OPTS.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>الأوجه</label>
                  <select value={form.faces} onChange={e => setForm(f => ({ ...f, faces: e.target.value as 'وجه' | 'وجهين' }))}
                    style={{ width: '100%', padding: '10px 8px', borderRadius: 10, border: '1.5px solid var(--border-color)', fontSize: 13, outline: 'none', background: 'var(--surface)' }}>
                    {FACES_OPTS.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>النخب</label>
                  <select value={form.grade} onChange={e => setForm(f => ({ ...f, grade: e.target.value }))}
                    style={{ width: '100%', padding: '10px 8px', borderRadius: 10, border: '1.5px solid var(--border-color)', fontSize: 13, outline: 'none', background: 'var(--surface)' }}>
                    {GRADE_OPTS.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>اللون</label>
                <input value={form.color} onChange={e => setForm(f => ({ ...f, color: e.target.value }))}
                  placeholder="أبيض" style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>سعر البيع ($) *</label>
                  <input type="number" value={form.price_usd} onChange={e => handleUsdPriceChange(e.target.value)}
                    style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: `1.5px solid ${errors.price_usd ? '#ef4444' : 'var(--border-color)'}`, fontSize: 16, outline: 'none', boxSizing: 'border-box' }} />
                  {errors.price_usd && <span style={{ fontSize: 11, color: '#ef4444', marginTop: 4, display: 'block' }}>{errors.price_usd}</span>}
                </div>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>التكلفة ($)</label>
                  <input type="number" value={form.cost_usd} onChange={e => setForm(f => ({ ...f, cost_usd: e.target.value }))}
                    style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: `1.5px solid ${errors.cost_usd ? '#ef4444' : 'var(--border-color)'}`, fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                  {errors.cost_usd && <span style={{ fontSize: 11, color: '#ef4444', marginTop: 4, display: 'block' }}>{errors.cost_usd}</span>}
                </div>
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>السعر بالليرة (محسوب تلقائياً، قابل للتعديل)</label>
                <input type="number" value={form.price_syp} onChange={e => setForm(f => ({ ...f, price_syp: e.target.value }))}
                  style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>الكمية بالمخزون</label>
                  <input type="number" value={form.stock_quantity} onChange={e => setForm(f => ({ ...f, stock_quantity: e.target.value }))}
                    style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                </div>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>الحد الأدنى</label>
                  <input type="number" value={form.min_stock} onChange={e => setForm(f => ({ ...f, min_stock: e.target.value }))}
                    style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                </div>
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>وصف (اختياري)</label>
                <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  rows={2} style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', resize: 'none', boxSizing: 'border-box' }} />
              </div>
            </div>
          </SheetBody>
          <SheetFooter>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={closeModal}
                style={{ flex: 1, padding: '13px', borderRadius: 12, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
                إلغاء
              </button>
              <button onClick={handleSave} disabled={!form.name.trim() || !form.code.trim() || !form.price_usd}
                style={{
                  flex: 2, padding: '13px', borderRadius: 12, border: 'none',
                  background: !form.name.trim() || !form.code.trim() || !form.price_usd ? 'var(--border-color)' : '#db2777',
                  color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                }}>
                <CheckCircle size={15} /> {modal.mode === 'edit' ? 'حفظ التعديلات' : 'إضافة المنتج'}
              </button>
            </div>
          </SheetFooter>
        </BottomSheetModal>
      )}

      {deleteConfirm && (
        <CenterModal isOpen onClose={() => setDeleteConfirm(null)}>
          <div style={{ padding: 24, textAlign: 'center' }}>
            <div style={{ width: 56, height: 56, borderRadius: 16, background: '#fef2f2', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
              <Trash2 size={24} color="#dc2626" />
            </div>
            <h3 style={{ fontSize: 16, fontWeight: 800, color: 'var(--text-primary)', marginBottom: 8 }}>حذف المنتج؟</h3>
            <p style={{ fontSize: 13, color: 'var(--text-tertiary)', marginBottom: 20 }}>سيتم حذف المنتج من الكتالوج نهائياً. الطلبات السابقة لن تتأثر.</p>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setDeleteConfirm(null)}
                style={{ flex: 1, padding: '12px', borderRadius: 12, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
                إلغاء
              </button>
              <button onClick={() => { deleteProduct(deleteConfirm); setDeleteConfirm(null); }}
                style={{ flex: 1, padding: '12px', borderRadius: 12, border: 'none', background: '#dc2626', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>
                حذف نهائياً
              </button>
            </div>
          </div>
        </CenterModal>
      )}
    </div>
  );
}
