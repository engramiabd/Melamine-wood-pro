import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

export const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div
      className="login-page flex flex-col items-center justify-center"
      style={{
        background: 'linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%)',
        padding: '24px',
      }}
      dir="rtl"
    >
      {/* Decorative circles */}
      <div style={{ position: 'fixed', top: '-100px', right: '-100px', width: '300px', height: '300px', borderRadius: '50%', background: 'rgba(37,99,235,0.08)', pointerEvents: 'none' }} />
      <div style={{ position: 'fixed', bottom: '-80px', left: '-80px', width: '240px', height: '240px', borderRadius: '50%', background: 'rgba(37,99,235,0.06)', pointerEvents: 'none' }} />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, type: 'spring', stiffness: 260, damping: 22 }}
        style={{ textAlign: 'center', zIndex: 10 }}
      >
        {/* 404 Number */}
        <motion.div
          animate={{ y: [0, -8, 0] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
          style={{ marginBottom: '24px' }}
        >
          <svg width="160" height="120" viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Factory building */}
            <rect x="20" y="60" width="120" height="55" rx="4" fill="#1e3a5f" stroke="#3b82f6" strokeWidth="1.5"/>
            {/* Windows */}
            <rect x="30" y="72" width="16" height="12" rx="2" fill="#3b82f6" opacity="0.6"/>
            <rect x="52" y="72" width="16" height="12" rx="2" fill="#3b82f6" opacity="0.4"/>
            <rect x="74" y="72" width="16" height="12" rx="2" fill="#3b82f6" opacity="0.6"/>
            <rect x="96" y="72" width="16" height="12" rx="2" fill="#3b82f6" opacity="0.3"/>
            <rect x="118" y="72" width="16" height="12" rx="2" fill="#3b82f6" opacity="0.5"/>
            {/* Door */}
            <rect x="68" y="90" width="24" height="25" rx="2" fill="#0f172a" stroke="#3b82f6" strokeWidth="1"/>
            {/* Chimneys */}
            <rect x="35" y="32" width="12" height="32" rx="2" fill="#1e3a5f" stroke="#3b82f6" strokeWidth="1.5"/>
            <rect x="75" y="22" width="12" height="42" rx="2" fill="#1e3a5f" stroke="#3b82f6" strokeWidth="1.5"/>
            <rect x="115" y="38" width="12" height="26" rx="2" fill="#1e3a5f" stroke="#3b82f6" strokeWidth="1.5"/>
            {/* Smoke */}
            <circle cx="41" cy="26" r="6" fill="rgba(148,163,184,0.2)"/>
            <circle cx="45" cy="18" r="5" fill="rgba(148,163,184,0.15)"/>
            <circle cx="81" cy="16" r="6" fill="rgba(148,163,184,0.2)"/>
            <circle cx="85" cy="8" r="5" fill="rgba(148,163,184,0.15)"/>
            {/* Question mark */}
            <text x="80" y="108" textAnchor="middle" fill="#ef4444" fontSize="18" fontWeight="bold" fontFamily="monospace">!</text>
          </svg>
        </motion.div>

        {/* 404 text */}
        <div style={{ marginBottom: '12px' }}>
          <span style={{
            fontSize: '96px',
            fontWeight: 900,
            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            lineHeight: 1,
            display: 'block',
            letterSpacing: '-4px',
          }}>
            404
          </span>
        </div>

        <h1 style={{ fontSize: '22px', fontWeight: 700, color: 'var(--border-color)', marginBottom: '10px' }}>
          الصفحة غير موجودة
        </h1>
        <p style={{ fontSize: '14px', color: 'var(--text-tertiary)', marginBottom: '36px', lineHeight: 1.6, maxWidth: '280px', margin: '0 auto 36px' }}>
          يبدو أن الصفحة التي تبحث عنها قد انتقلت أو لم تعد موجودة
        </p>

        {/* Buttons */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxWidth: '280px', margin: '0 auto' }}>
          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={() => navigate('/')}
            style={{
              background: 'linear-gradient(135deg, #2563eb, #1d4ed8)',
              color: '#fff',
              border: 'none',
              borderRadius: '16px',
              padding: '14px 24px',
              fontSize: '15px',
              fontWeight: 700,
              cursor: 'pointer',
              boxShadow: '0 4px 20px rgba(37,99,235,0.4)',
              fontFamily: 'inherit',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
            }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
              <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
            العودة للرئيسية
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={() => navigate(-1)}
            style={{
              background: 'rgba(255,255,255,0.07)',
              color: 'var(--text-tertiary)',
              border: '1px solid rgba(255,255,255,0.12)',
              borderRadius: '16px',
              padding: '13px 24px',
              fontSize: '14px',
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: 'inherit',
              backdropFilter: 'blur(8px)',
            }}
          >
            رجوع للصفحة السابقة
          </motion.button>
        </div>

        {/* Footer */}
        <p style={{ marginTop: '48px', fontSize: '11px', color: '#334155' }}>
          ميلامين برو · نظام إدارة المصنع
        </p>
      </motion.div>
    </div>
  );
};
