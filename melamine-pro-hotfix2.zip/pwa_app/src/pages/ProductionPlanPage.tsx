import React, { useMemo, useState } from 'react';
import { CalendarRange, Plus, Search, X, Check, Trash2 } from 'lucide-react';
import { useAppData } from '../contexts/AppDataContext';
import { useAuth } from '../contexts/AuthContext';
import type { PlanItem } from '../types';
import { today } from '../contexts/appData.helpers';

export const ProductionPlanPage: React.FC = () => {
  const { managedProducts, productionBatches, productionPlans, addProductionPlan, updateProductionPlan, deleteProductionPlan } = useAppData();
  const { user } = useAuth();
  const [showNew, setShowNew] = useState(false);

  // produced quantity per product since a given date (from batches)
  const producedSince = useMemo(() => {
    return (productId: string, sinceISO: string) =>
      productionBatches
        .filter(b => b.product_id === productId && (b.start_time || '') >= sinceISO)
        .reduce((s, b) => s + (b.produced_quantity || 0), 0);
  }, [productionBatches]);

  return (
    <div className="min-h-full bg-gray-50 pb-24" dir="rtl">
      <div className="bg-gradient-to-br from-fuchsia-600 to-purple-700 px-5 pt-6 pb-8 text-white">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center"><CalendarRange size={22} /></div>
          <div>
            <h1 className="text-lg font-extrabold">تخطيط الإنتاج</h1>
            <p className="text-xs text-white/70">خطط الإنتاج ومتابعة الإنجاز</p>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-4">
        <button onClick={() => setShowNew(true)} className="w-full bg-white rounded-2xl p-3.5 shadow-sm flex items-center justify-center gap-2 text-fuchsia-600 font-bold text-sm">
          <Plus size={18} /> خطة إنتاج جديدة
        </button>
      </div>

      <div className="px-4 mt-4 space-y-3">
        {productionPlans.length === 0 && <p className="text-center text-gray-400 text-sm py-12">لا توجد خطط إنتاج بعد</p>}
        {productionPlans.map(plan => {
          const totalTarget = plan.items.reduce((s, i) => s + i.target_qty, 0);
          const totalDone = plan.items.reduce((s, i) => s + Math.min(i.target_qty, producedSince(i.product_id, plan.created_at)), 0);
          const pct = totalTarget > 0 ? Math.round((totalDone / totalTarget) * 100) : 0;
          return (
            <div key={plan.id} className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <div className="p-4 pb-2">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-gray-800 text-sm">{plan.title}</h3>
                    <p className="text-[11px] text-gray-400">{plan.plan_date} • {plan.items.length} صنف</p>
                  </div>
                  <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${plan.status === 'completed' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                    {plan.status === 'completed' ? 'مكتملة' : 'نشطة'}
                  </span>
                </div>
                <div className="mt-2 h-2 rounded-full bg-gray-100 overflow-hidden">
                  <div className="h-full rounded-full bg-fuchsia-500" style={{ width: `${pct}%` }} />
                </div>
                <div className="text-[11px] text-gray-400 mt-1">{totalDone.toLocaleString()} / {totalTarget.toLocaleString()} لوح ({pct}%)</div>
              </div>

              <div className="px-4 pb-2 space-y-1">
                {plan.items.map((it, idx) => {
                  const done = producedSince(it.product_id, plan.created_at);
                  const p = totalTarget > 0 ? Math.min(100, Math.round((done / it.target_qty) * 100)) : 0;
                  return (
                    <div key={idx} className="flex items-center justify-between text-xs py-1 border-b border-gray-50 last:border-0">
                      <span className="text-gray-700 truncate flex-1">{it.code} — {it.product_name.replace(`${it.code} `, '')}</span>
                      <span className={`font-bold ${done >= it.target_qty ? 'text-emerald-600' : 'text-gray-500'}`}>{done}/{it.target_qty} ({p}%)</span>
                    </div>
                  );
                })}
              </div>

              <div className="flex border-t border-gray-50">
                {plan.status !== 'completed' && (
                  <button onClick={() => updateProductionPlan(plan.id, { status: 'completed' })} className="flex-1 py-2.5 text-xs font-bold text-emerald-600 flex items-center justify-center gap-1">
                    <Check size={14} /> إنهاء
                  </button>
                )}
                <button onClick={() => deleteProductionPlan(plan.id)} className="flex-1 py-2.5 text-xs font-bold text-red-500 flex items-center justify-center gap-1 border-r border-gray-50">
                  <Trash2 size={14} /> حذف
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {showNew && <NewPlanModal onClose={() => setShowNew(false)} onSave={(title, date, items) => {
        addProductionPlan({ title, plan_date: date, items, created_by: user?.full_name || 'النظام' });
        setShowNew(false);
      }} products={managedProducts} />}
    </div>
  );
};

const NewPlanModal: React.FC<{
  onClose: () => void;
  onSave: (title: string, date: string, items: PlanItem[]) => void;
  products: { id: string; name: string; code: string }[];
}> = ({ onClose, onSave, products }) => {
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(today());
  const [items, setItems] = useState<PlanItem[]>([]);
  const [q, setQ] = useState('');

  const matches = useMemo(() => {
    const s = q.trim();
    if (!s) return [];
    return products.filter(p => p.code.includes(s) || p.name.includes(s)).slice(0, 8);
  }, [q, products]);

  const add = (p: { id: string; name: string; code: string }) => {
    if (items.some(i => i.product_id === p.id)) return;
    setItems(prev => [...prev, { product_id: p.id, product_name: p.name, code: p.code, target_qty: 100 }]);
    setQ('');
  };
  const setQty = (id: string, v: string) => setItems(prev => prev.map(i => i.product_id === id ? { ...i, target_qty: Number(v.replace(/[^0-9]/g, '')) || 0 } : i));
  const remove = (id: string) => setItems(prev => prev.filter(i => i.product_id !== id));

  const canSave = title.trim() && items.length > 0 && items.every(i => i.target_qty > 0);

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end" onClick={onClose}>
      <div className="bg-white w-full rounded-t-3xl max-h-[88vh] overflow-y-auto" dir="rtl" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white px-4 py-3 border-b border-gray-50 flex items-center justify-between">
          <h2 className="font-bold text-gray-800">خطة إنتاج جديدة</h2>
          <button aria-label="إغلاق" onClick={onClose}><X size={20} className="text-gray-400" /></button>
        </div>
        <div className="p-4 space-y-3">
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="عنوان الخطة (مثل: إنتاج الأسبوع)"
            className="w-full bg-gray-50 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-fuchsia-300" />
          <div>
            <label className="text-xs text-gray-400">تاريخ الخطة</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)}
              className="w-full bg-gray-50 rounded-xl px-3 py-2.5 text-sm outline-none mt-1" />
          </div>

          {/* product picker */}
          <div>
            <div className="relative">
              <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={q} onChange={e => setQ(e.target.value)} placeholder="ابحث عن منتج بالرمز أو الاسم…"
                className="w-full bg-gray-50 rounded-xl py-2.5 pr-9 pl-3 text-sm outline-none focus:ring-2 focus:ring-fuchsia-300" />
            </div>
            {matches.length > 0 && (
              <div className="mt-1 bg-white border border-gray-100 rounded-xl shadow-sm max-h-44 overflow-y-auto">
                {matches.map(p => (
                  <button key={p.id} onClick={() => add(p)} className="w-full text-right px-3 py-2 text-sm hover:bg-gray-50 border-b border-gray-50 last:border-0">{p.name}</button>
                ))}
              </div>
            )}
          </div>

          {/* selected items */}
          {items.length > 0 && (
            <div className="space-y-1.5">
              {items.map(it => (
                <div key={it.product_id} className="flex items-center gap-2 bg-gray-50 rounded-xl p-2">
                  <span className="flex-1 text-sm text-gray-700 truncate">{it.product_name}</span>
                  <input value={it.target_qty || ''} onChange={e => setQty(it.product_id, e.target.value)} inputMode="numeric"
                    className="w-20 bg-white rounded-lg px-2 py-1.5 text-sm text-center outline-none" />
                  <button onClick={() => remove(it.product_id)}><X size={16} className="text-gray-400" /></button>
                </div>
              ))}
            </div>
          )}

          <button onClick={() => canSave && onSave(title.trim(), date, items)} disabled={!canSave}
            className="w-full bg-fuchsia-600 text-white rounded-2xl py-3 font-bold text-sm disabled:opacity-40">
            حفظ الخطة
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductionPlanPage;
