import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, Wrench, Power, ChevronDown, ChevronUp,
  AlertTriangle, CheckCircle2, Zap, RefreshCw,
  Plus, Edit2, Trash2, X, Save,
  TrendingUp, Clock, Package2, AlertCircle,
  BarChart3, Settings2, Play, StopCircle, Timer
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, BarChart, Bar, CartesianGrid, Legend
} from 'recharts';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import { Badge } from '../components/ui/Badge';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import { useAppData } from '../contexts/AppDataContext';
import { demoHourlyProduction, ProductionLineExtended, ProductionBatch } from '../lib/demoData';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter, CenterModal } from '../components/ui/Modal';
import { computeOEE, oeeColor } from '../utils/oee';

interface LineFormData {
  name: string;
  code: string;
  capacity_per_day: number;
  operating_cost_usd: number;
  notes: string;
}

const STATUS_CONFIG = {
  active: {
    label: 'يعمل الآن', badge: 'success' as const,
    pathColor: '#10b981', trailColor: '#d1fae5',
    textColor: 'text-emerald-600', bg: 'from-emerald-50 to-green-50',
    border: 'border-emerald-200', dot: 'bg-emerald-500',
    headerBg: 'bg-gradient-to-r from-emerald-500 to-green-600',
    icon: <Play size={14} />,
  },
  stopped: {
    label: 'متوقف', badge: 'danger' as const,
    pathColor: '#ef4444', trailColor: '#fee2e2',
    textColor: 'text-red-600', bg: 'from-red-50 to-rose-50',
    border: 'border-red-200', dot: 'bg-red-500',
    headerBg: 'bg-gradient-to-r from-red-500 to-rose-600',
    icon: <StopCircle size={14} />,
  },
  maintenance: {
    label: 'صيانة', badge: 'warning' as const,
    pathColor: '#f59e0b', trailColor: '#fef3c7',
    textColor: 'text-amber-600', bg: 'from-amber-50 to-yellow-50',
    border: 'border-amber-200', dot: 'bg-amber-500',
    headerBg: 'bg-gradient-to-r from-amber-500 to-yellow-600',
    icon: <Wrench size={14} />,
  },
  idle: {
    label: 'خامل', badge: 'default' as const,
    pathColor: '#6b7280', trailColor: '#f3f4f6',
    textColor: 'text-gray-500', bg: 'from-gray-50 to-slate-50',
    border: 'border-gray-200', dot: 'bg-gray-400',
    headerBg: 'bg-gradient-to-r from-gray-400 to-slate-500',
    icon: <Timer size={14} />,
  },
};

const PRODUCTION_STEPS = [
  { name: 'تحضير المواد الخام', icon: Package2, duration: '30 دقيقة', color: 'text-orange-500' },
  { name: 'الكبس والتسخين', icon: Zap, duration: '45 دقيقة', color: 'text-red-500' },
  { name: 'التبريد والتثبيت', icon: Activity, duration: '20 دقيقة', color: 'text-blue-500' },
  { name: 'القطع والتشكيل', icon: Settings2, duration: '25 دقيقة', color: 'text-purple-500' },
  { name: 'تركيب الحواف', icon: Wrench, duration: '15 دقيقة', color: 'text-indigo-500' },
  { name: 'فحص الجودة', icon: CheckCircle2, duration: '10 دقيقة', color: 'text-emerald-500' },
  { name: 'التغليف', icon: Package2, duration: '10 دقيقة', color: 'text-teal-500' },
];

const ProductionBelt: React.FC<{ isActive: boolean }> = ({ isActive }) => {
  if (!isActive) return null;
  return (
    <div className="relative h-8 bg-gray-100 rounded-lg overflow-hidden my-2">
      <div className="absolute inset-0 flex items-center px-2">
        <div className="w-full h-2 bg-gray-300 rounded relative overflow-hidden">
          <motion.div
            className="absolute top-0 left-0 h-full w-full"
            style={{ background: 'repeating-linear-gradient(90deg,#10b981 0px,#10b981 16px,#d1fae5 16px,#d1fae5 32px)' }}
            animate={{ x: ['0%', '-50%'] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
          />
        </div>
      </div>
      {[0, 1, 2].map(i => (
        <motion.div
          key={i}
          className="absolute w-8 h-5 bg-white border border-emerald-300 rounded-sm shadow-sm flex items-center justify-center"
          initial={{ x: '110%' }}
          animate={{ x: '-30%' }}
          transition={{ duration: 4, repeat: Infinity, delay: i * 1.3, ease: 'linear' }}
          style={{ top: '6px' }}
        >
          <div className="w-5 h-3 bg-emerald-100 rounded-sm border border-emerald-200" />
        </motion.div>
      ))}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-[9px] font-bold text-emerald-700 bg-white/70 px-1.5 py-0.5 rounded-full z-10 flex items-center gap-1">
          <Zap size={9} className="text-emerald-600" /> خط الإنتاج نشط
        </span>
      </div>
    </div>
  );
};

// Stop Line Modal — Portal-based
const StopLineModal: React.FC<{ onConfirm: (reason: string) => void; onClose: () => void }> = ({ onConfirm, onClose }) => {
  const [reason, setReason] = useState('');
  const REASONS = ['نقص في المواد الخام', 'عطل ميكانيكي', 'نقص في الكهرباء', 'صيانة طارئة', 'انتهاء وردية'];
  return (
    <BottomSheetModal isOpen onClose={onClose}>
      <SheetHeader onClose={onClose}>
        <h2 className="text-base font-bold text-gray-900 flex items-center gap-2">
          <StopCircle size={16} className="text-red-500" /> سبب الإيقاف
        </h2>
      </SheetHeader>
      <SheetBody>
        <div className="grid grid-cols-1 gap-2">
          {REASONS.map(r => (
            <button key={r} onClick={() => setReason(r)}
              className={`text-right px-3 py-2.5 rounded-xl text-sm font-medium border transition-all ${reason === r ? 'bg-red-50 border-red-300 text-red-700' : 'bg-gray-50 border-gray-200 text-gray-700'}`}>
              {r}
            </button>
          ))}
        </div>
        <textarea value={reason} onChange={e => setReason(e.target.value)} rows={2}
          placeholder="أو اكتب سببًا مخصصًا..."
          className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-red-400 text-right" />
      </SheetBody>
      <SheetFooter>
        <div className="flex gap-3">
          <button aria-label="إغلاق" onClick={onClose} className="flex-1 py-3.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600">إلغاء</button>
          <button onClick={() => { if (reason.trim()) { onConfirm(reason); onClose(); } }}
            disabled={!reason.trim()}
            className="flex-1 py-3.5 bg-red-600 text-white rounded-xl text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2">
            <StopCircle size={14} /> إيقاف الخط
          </button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

// Line Add/Edit Modal — Portal-based
const LineModal: React.FC<{
  line?: ProductionLineExtended | null;
  onClose: () => void;
  onSave: (data: LineFormData, isEdit: boolean) => void;
}> = ({ line, onClose, onSave }) => {
  const [form, setForm] = useState<LineFormData>({
    name: line?.name ?? '',
    code: line?.code ?? '',
    capacity_per_day: line?.capacity_per_day ?? 200,
    operating_cost_usd: line?.operating_cost_usd ?? 800,
    notes: line?.notes ?? '',
  });
  return (
    <BottomSheetModal isOpen onClose={onClose} maxHeight="90dvh">
      <SheetHeader onClose={onClose}>
        <h2 className="text-base font-bold text-gray-900 flex items-center gap-2">
          {line ? <><Edit2 size={16} className="text-blue-500" /> تعديل خط الإنتاج</>
            : <><Plus size={16} className="text-emerald-500" /> إضافة خط إنتاج جديد</>}
        </h2>
      </SheetHeader>
      <SheetBody>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">اسم خط الإنتاج *</label>
          <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
            placeholder="مثال: خط الإنتاج E"
            className="w-full px-3 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">رمز الخط *</label>
          <input value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))}
            placeholder="LINE-E" dir="ltr"
            className="w-full px-3 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-left" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">الطاقة اليومية (لوح)</label>
            <input type="number" value={form.capacity_per_day}
              onChange={e => setForm(f => ({ ...f, capacity_per_day: +e.target.value }))}
              className="w-full px-3 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-center" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">التكلفة ($)</label>
            <input type="number" value={form.operating_cost_usd}
              onChange={e => setForm(f => ({ ...f, operating_cost_usd: +e.target.value }))}
              className="w-full px-3 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-center" />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">ملاحظات</label>
          <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            rows={3} placeholder="ملاحظات إضافية..."
            className="w-full px-3 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
        </div>
      </SheetBody>
      <SheetFooter>
        <div className="flex gap-3">
          <button aria-label="إغلاق" onClick={onClose} className="flex-1 py-3.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600">إلغاء</button>
          <button onClick={() => onSave(form, !!line)} disabled={!form.name || !form.code}
            className="flex-1 py-3.5 bg-blue-600 text-white rounded-xl text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2">
            <Save size={14} /> {line ? 'حفظ التعديلات' : 'إضافة الخط'}
          </button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

// Delete Modal — Portal-based CenterModal
const DeleteModal: React.FC<{ lineName: string; onConfirm: () => void; onClose: () => void }> = ({ lineName, onConfirm, onClose }) => (
  <CenterModal isOpen onClose={onClose}>
    <div className="p-6 text-center" dir="rtl">
      <div className="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
        <Trash2 size={24} className="text-red-600" />
      </div>
      <h3 className="text-lg font-bold text-gray-900 mb-2">حذف خط الإنتاج</h3>
      <p className="text-sm text-gray-500 mb-6">
        هل أنت متأكد من حذف <span className="font-semibold text-gray-800">"{lineName}"</span>؟
      </p>
      <div className="flex gap-3">
        <button aria-label="إغلاق" onClick={onClose} className="flex-1 py-3 border border-gray-200 rounded-xl text-sm font-medium text-gray-600">إلغاء</button>
        <button onClick={onConfirm} className="flex-1 py-3 bg-red-600 text-white rounded-xl text-sm font-bold">حذف نهائياً</button>
      </div>
    </div>
  </CenterModal>
);

// Add Batch Modal — Portal-based
const AddBatchModal: React.FC<{
  line: ProductionLineExtended;
  products: import('../types').Product[];
  onClose: () => void;
  onSave: (batch: Omit<ProductionBatch, 'id'>) => void;
}> = ({ line, products, onClose, onSave }) => {
  const [selectedProduct, setSelectedProduct] = useState(products[0]);
  const [planned, setPlanned] = useState(100);
  const [produced, setProduced] = useState(95);
  const [defective, setDefective] = useState(2);
  const [shift, setShift] = useState<'morning' | 'evening' | 'night'>('morning');
  const [saving, setSaving] = useState(false);

  const handleSave = () => {
    setSaving(true);
    setTimeout(() => {
      onSave({
        line_id: line.id,
        order_id: '',
        product_name: selectedProduct?.name ?? 'منتج',
        product_id: selectedProduct?.id,
        planned_quantity: planned,
        produced_quantity: produced,
        defective_quantity: defective,
        operator_name: 'المشغل الحالي',
        shift,
        status: 'completed' as const,
        start_time: new Date(Date.now() - 3600000).toISOString(),
        end_time: new Date().toISOString(),
      });
      setSaving(false);
      onClose();
    }, 800);
  };

  return (
    <BottomSheetModal isOpen onClose={onClose} maxHeight="90dvh">
      <SheetHeader onClose={onClose}>
        <h2 className="text-base font-bold text-gray-900 flex items-center gap-2">
          <Package2 size={16} className="text-emerald-500" /> تسجيل دفعة إنتاج — {line.name}
        </h2>
      </SheetHeader>
      <SheetBody>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">المنتج</label>
          <select value={selectedProduct?.id ?? ''} onChange={e => setSelectedProduct(products.find(p => p.id === e.target.value) ?? products[0])}
            className="w-full px-3 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white">
            {products.map(p => <option key={p.id} value={p.id}>{p.name} — {p.thickness} {p.finish}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'المخطط', value: planned, set: setPlanned, color: 'blue' },
            { label: 'المنتج', value: produced, set: setProduced, color: 'emerald' },
            { label: 'المعيب', value: defective, set: setDefective, color: 'red' },
          ].map(({ label, value, set, color }) => (
            <div key={label}>
              <label className={`block text-xs font-bold text-${color}-600 mb-1.5`}>{label}</label>
              <input type="number" min={0} value={value}
                onChange={e => set(+e.target.value)}
                className={`w-full px-3 py-3 border border-${color}-200 bg-${color}-50 rounded-xl text-sm text-center focus:outline-none focus:ring-2 focus:ring-${color}-400 font-bold`} />
            </div>
          ))}
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1.5">الوردية</label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { v: 'morning', l: 'صباحية' },
              { v: 'evening', l: 'مسائية' },
              { v: 'night', l: 'ليلية' },
            ].map(({ v, l }) => (
              <button key={v} onClick={() => setShift(v as typeof shift)}
                className={`py-2.5 rounded-xl text-xs font-bold border transition-all ${shift === v ? 'bg-blue-600 text-white border-blue-600' : 'bg-gray-50 text-gray-600 border-gray-200'}`}>
                {l}
              </button>
            ))}
          </div>
        </div>
        {produced > 0 && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3">
            <p className="text-xs font-bold text-emerald-700 mb-1">ملخص الدفعة</p>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div><p className="text-lg font-black text-emerald-700">{produced}</p><p className="text-[10px] text-gray-500">منتج</p></div>
              <div><p className="text-lg font-black text-red-600">{defective}</p><p className="text-[10px] text-gray-500">معيب</p></div>
              <div><p className="text-lg font-black text-blue-600">{produced > 0 ? ((defective / produced) * 100).toFixed(1) : 0}%</p><p className="text-[10px] text-gray-500">نسبة العيب</p></div>
            </div>
          </div>
        )}
      </SheetBody>
      <SheetFooter>
        <div className="flex gap-3">
          <button aria-label="إغلاق" onClick={onClose} className="flex-1 py-3.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-600">إلغاء</button>
          <button onClick={handleSave} disabled={saving || !selectedProduct}
            className="flex-1 py-3.5 bg-emerald-600 text-white rounded-xl text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2">
            {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <CheckCircle2 size={14} />}
            تسجيل الدفعة
          </button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

// Live stop duration timer
const StopDuration: React.FC<{ startedAt: string }> = ({ startedAt }) => {
  const [dur, setDur] = useState('');
  const ref = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => {
    const calc = () => {
      const diff = Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000);
      const h = Math.floor(diff / 3600).toString().padStart(2, '0');
      const m = Math.floor((diff % 3600) / 60).toString().padStart(2, '0');
      const s = Math.floor(diff % 60).toString().padStart(2, '0');
      setDur(`${h}:${m}:${s}`);
    };
    calc();
    ref.current = setInterval(calc, 1000);
    return () => { if (ref.current) clearInterval(ref.current); };
  }, [startedAt]);
  return <span className="font-mono">{dur}</span>;
};

const ProductionLineCard: React.FC<{
  line: ProductionLineExtended;
  stepProgress: number;
  onAdvanceStep: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onStart: () => void;
  onStop: () => void;
  onAddBatch: () => void;
  isAdmin: boolean;
  isManager: boolean;
  canManageProd: boolean;
  canBatch: boolean;
}> = ({ line, stepProgress, onAdvanceStep, onEdit, onDelete, onStart, onStop, onAddBatch, isAdmin, isManager, canManageProd, canBatch }) => {
  const navigate = useNavigate();
  const { format } = useCurrency();
  const { orders, productionBatches, systemSettings } = useAppData();
  const oee = computeOEE(line, { workStartTime: systemSettings.workStartTime, workEndTime: systemSettings.workEndTime });
  const [expanded, setExpanded] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const cfg = STATUS_CONFIG[line.status];
  const currentOrder = orders.find(o => o.id === line.current_order_id);
  const batches = productionBatches.filter(b => b.line_id === line.id);
  const defectRate = line.total_produced_today > 0
    ? ((line.total_defective_today / line.total_produced_today) * 100).toFixed(1) : '0.0';
  const progressPercent = Math.round((stepProgress / PRODUCTION_STEPS.length) * 100);

  return (
    <motion.div layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
      className={`rounded-3xl overflow-hidden shadow-lg border-2 ${cfg.border} bg-white`}>
      {/* Header */}
      <div className={`${cfg.headerBg} px-4 py-3`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className={`w-3.5 h-3.5 rounded-full ${cfg.dot} border-2 border-white/50`} />
              {line.status === 'active' && <div className="absolute inset-0 w-3.5 h-3.5 rounded-full bg-emerald-400 animate-ping opacity-70" />}
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">{line.name}</h3>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-white/70 text-[10px]">{line.code}</span>
                <span className="text-white/50 text-[10px]">•</span>
                <span className="text-white/80 text-[10px] flex items-center gap-1">{cfg.icon} {cfg.label}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            {isAdmin && (
              <>
                <button onClick={onEdit} className="p-1.5 rounded-xl bg-white/20 hover:bg-white/30 transition-colors"><Edit2 size={13} className="text-white" /></button>
                <button onClick={onDelete} className="p-1.5 rounded-xl bg-white/20 hover:bg-red-500/60 transition-colors"><Trash2 size={13} className="text-white" /></button>
              </>
            )}
            <button onClick={() => setExpanded(e => !e)} className="p-1.5 rounded-xl bg-white/20 hover:bg-white/30 transition-colors">
              {expanded ? <ChevronUp size={14} className="text-white" /> : <ChevronDown size={14} className="text-white" />}
            </button>
          </div>
        </div>
      </div>

      <div className="px-4"><ProductionBelt isActive={line.status === 'active'} /></div>

      <div className="px-4 pb-4 space-y-3">
        {/* KPIs */}
        <div className="grid grid-cols-4 gap-2">
          <div className="col-span-1 flex flex-col items-center">
            <div className="w-16 h-16">
              <CircularProgressbar value={line.efficiency_percentage} text={`${line.efficiency_percentage}%`}
                styles={buildStyles({ textSize: '22px', pathColor: cfg.pathColor, textColor: cfg.pathColor, trailColor: cfg.trailColor, pathTransitionDuration: 1.2 })} />
            </div>
            <span className="text-[10px] text-gray-500 mt-1">الكفاءة</span>
          </div>
          <div className="col-span-3 grid grid-cols-3 gap-1.5">
            {[
              { val: line.total_produced_today, label: 'أُنتج اليوم', bg: `bg-gradient-to-b ${cfg.bg}`, color: line.status === 'active' ? 'text-emerald-700' : 'text-gray-600' },
              { val: `${defectRate}%`, label: 'المعيب', bg: 'bg-red-50', color: 'text-red-600' },
              { val: line.capacity_per_day, label: 'طاقة/يوم', bg: 'bg-blue-50', color: 'text-blue-600' },
              { val: format(line.operating_cost_usd), label: 'تكلفة تشغيل', bg: 'bg-purple-50', color: 'text-purple-600' },
              { val: line.production_speed, label: 'لوح/ساعة', bg: 'bg-orange-50', color: 'text-orange-600' },
              { val: line.temperature ? `${line.temperature}°` : '—', label: 'حرارة الكبس', bg: 'bg-rose-50', color: 'text-rose-500' },
            ].map((kpi, i) => (
              <div key={i} className={`${kpi.bg} rounded-xl p-2 text-center`}>
                <p className={`text-sm font-bold ${kpi.color}`}>{kpi.val}</p>
                <p className="text-[9px] text-gray-500">{kpi.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Efficiency Bar */}
        <div>
          <div className="flex items-center justify-between text-[11px] text-gray-500 mb-1">
            <span>مستوى الكفاءة التشغيلية</span>
            <span className={`font-bold ${cfg.textColor}`}>{line.efficiency_percentage}%</span>
          </div>
          <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden">
            <motion.div className="h-2.5 rounded-full" style={{ backgroundColor: cfg.pathColor }}
              initial={{ width: 0 }} animate={{ width: `${line.efficiency_percentage}%` }} transition={{ duration: 1.2, ease: 'easeOut' }} />
          </div>
        </div>

        {/* OEE — Overall Equipment Effectiveness */}
        <div className="bg-gray-50 rounded-2xl p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] text-gray-500">الفعالية الكلية (OEE)</span>
            <span className="text-sm font-extrabold" style={{ color: oeeColor(oee.oee) }}>{Math.round(oee.oee * 100)}%</span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            {[
              { label: 'التوافر', val: oee.availability },
              { label: 'الأداء', val: oee.performance },
              { label: 'الجودة', val: oee.quality },
            ].map((m) => (
              <div key={m.label} className="bg-white rounded-xl py-1.5">
                <div className="text-[13px] font-bold text-gray-700">{Math.round(m.val * 100)}%</div>
                <div className="text-[9px] text-gray-400">{m.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Stopped Alert */}
        {line.status === 'stopped' && (
          <motion.div className="bg-red-50 border border-red-200 rounded-2xl p-3 space-y-2" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-red-100 rounded-xl flex items-center justify-center"><AlertCircle size={14} className="text-red-600" /></div>
              <span className="text-sm font-bold text-red-700">سبب الإيقاف</span>
              <Badge variant="danger" className="mr-auto text-[10px] flex items-center gap-1">
                <Clock size={9} />
                {line.stop_started_at ? <StopDuration startedAt={line.stop_started_at} /> : line.stop_duration}
              </Badge>
            </div>
            <p className="text-xs text-red-600 pr-9">{line.stop_reason}</p>
            {line.stop_started_at && (
              <div className="flex items-center gap-1.5 pr-9">
                <Clock size={11} className="text-red-400" />
                <span className="text-[10px] text-red-400">
                  توقف منذ: {new Date(line.stop_started_at).toLocaleTimeString('ar-SY', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            )}
          </motion.div>
        )}

        {/* Maintenance Note */}
        {line.status === 'maintenance' && line.notes && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3">
            <div className="flex items-center gap-2 mb-1"><Wrench size={13} className="text-amber-600" /><span className="text-xs font-bold text-amber-700">سبب الصيانة</span></div>
            <p className="text-xs text-amber-600">{line.notes}</p>
          </div>
        )}

        {/* Current Order */}
        {currentOrder && (
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-2xl p-3 cursor-pointer hover:from-blue-100 hover:to-indigo-100 transition-all"
            onClick={() => navigate(`/orders/${currentOrder.id}`)}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5"><Zap size={12} className="text-blue-600" /><span className="text-xs font-bold text-blue-800">الطلب الحالي</span></div>
              <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-mono">{currentOrder.order_number}</span>
            </div>
            <p className="text-sm font-bold text-gray-800">{currentOrder.customer_name}</p>
            <p className="text-xs text-gray-500 mt-0.5">{currentOrder.items[0]?.product?.name} • {currentOrder.items[0]?.quantity} قطعة</p>
            {line.status === 'active' && (
              <div className="mt-2.5">
                <div className="flex items-center justify-between text-[11px] mb-1">
                  <span className="text-blue-700 font-medium flex items-center gap-1">
                    {stepProgress < PRODUCTION_STEPS.length
                      ? <>{React.createElement(PRODUCTION_STEPS[stepProgress]?.icon, { size: 10 })} {PRODUCTION_STEPS[stepProgress]?.name}</>
                      : <><CheckCircle2 size={10} className="text-emerald-500" /> اكتمل الإنتاج</>}
                  </span>
                  <span className="text-blue-600 font-bold">{progressPercent}%</span>
                </div>
                <div className="w-full bg-blue-200 rounded-full h-2 overflow-hidden">
                  <motion.div className="h-2 bg-blue-600 rounded-full" initial={{ width: 0 }}
                    animate={{ width: `${progressPercent}%` }} transition={{ duration: 0.8 }} />
                </div>
                <div className="flex gap-1 mt-1.5">
                  {PRODUCTION_STEPS.map((_, i) => (
                    <div key={i} className={`flex-1 h-1 rounded-full transition-all duration-300 ${i < stepProgress ? 'bg-blue-600' : i === stepProgress ? 'bg-blue-400 animate-pulse' : 'bg-blue-100'}`} />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Action Buttons */}
        {(canManageProd || canBatch) && (
          <div className="flex gap-2 flex-wrap">
            {canManageProd && line.status === 'active' && stepProgress < PRODUCTION_STEPS.length && (
              <button onClick={onAdvanceStep}
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-blue-600 text-white text-xs font-bold rounded-2xl hover:bg-blue-700 transition-colors shadow-md shadow-blue-200">
                <RefreshCw size={12} /> الخطوة التالية
              </button>
            )}
            {canManageProd && (line.status === 'idle' || line.status === 'stopped') && (
              <button onClick={onStart}
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-emerald-600 text-white text-xs font-bold rounded-2xl hover:bg-emerald-700 transition-colors shadow-md shadow-emerald-200">
                <Power size={12} /> {line.status === 'stopped' ? 'استئناف الإنتاج' : 'تشغيل الخط'}
              </button>
            )}
            {canManageProd && line.status === 'active' && (
              <button onClick={onStop}
                className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-red-500 text-white text-xs font-bold rounded-2xl hover:bg-red-600 transition-colors">
                <StopCircle size={12} /> إيقاف
              </button>
            )}
            {canManageProd && line.status === 'active' && (
              <button className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-amber-500 text-white text-xs font-bold rounded-2xl hover:bg-amber-600 transition-colors">
                <Wrench size={12} />
              </button>
            )}
            {canBatch && line.status === 'active' && (
              <button onClick={onAddBatch}
                className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-teal-600 text-white text-xs font-bold rounded-2xl hover:bg-teal-700 transition-colors">
                <Package2 size={12} /> دفعة
              </button>
            )}
            <button onClick={() => setShowStats(s => !s)}
              className="flex items-center justify-center px-3 py-2.5 bg-gray-100 text-gray-600 text-xs rounded-2xl hover:bg-gray-200 transition-colors">
              <BarChart3 size={13} />
            </button>
          </div>
        )}

        {/* Mini Stats Chart */}
        <AnimatePresence>
          {showStats && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="pt-2">
                <p className="text-xs font-bold text-gray-700 mb-2 flex items-center gap-1.5"><BarChart3 size={12} className="text-blue-500" /> الإنتاج بالساعة اليوم</p>
                <ResponsiveContainer width="100%" height={100}>
                  <AreaChart data={demoHourlyProduction} margin={{ top: 5, right: 0, bottom: 0, left: -30 }}>
                    <defs>
                      <linearGradient id={`grad-${line.id}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={cfg.pathColor} stopOpacity={0.3} />
                        <stop offset="95%" stopColor={cfg.pathColor} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="hour" tick={{ fontSize: 9 }} />
                    <YAxis tick={{ fontSize: 9 }} />
                    <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                    <Area type="monotone" dataKey={line.id === 'pl1' ? 'lineA' : 'lineB'} stroke={cfg.pathColor} fill={`url(#grad-${line.id})`} strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Expanded Steps */}
        <AnimatePresence>
          {expanded && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
              <div className="border-t border-gray-100 pt-3">
                <p className="text-xs font-bold text-gray-700 mb-3 flex items-center gap-1.5"><RefreshCw size={12} className="text-blue-500" /> مراحل الإنتاج التفصيلية</p>
                <div className="space-y-1.5">
                  {PRODUCTION_STEPS.map((step, idx) => {
                    const done = idx < stepProgress;
                    const current = idx === stepProgress && line.status === 'active';
                    return (
                      <motion.div key={idx} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: idx * 0.05 }}
                        className={`flex items-center gap-3 px-3 py-2 rounded-xl transition-all ${current ? 'bg-blue-50 border border-blue-200 shadow-sm' : done ? 'bg-emerald-50' : 'bg-gray-50'}`}>
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${done ? 'bg-emerald-500 text-white' : current ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-400'}`}>
                          {done ? <CheckCircle2 size={14} /> : current ? <Activity size={14} /> : <span className="text-xs font-bold">{idx + 1}</span>}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`text-xs font-semibold flex items-center gap-1.5 ${done ? 'text-emerald-700' : current ? 'text-blue-700' : 'text-gray-400'}`}>
                            <step.icon size={11} className={done || current ? '' : step.color} />{step.name}
                          </p>
                          <p className="text-[10px] text-gray-400">{step.duration}</p>
                        </div>
                        {current && <div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse shrink-0" />}
                        {done && <CheckCircle2 size={12} className="text-emerald-500 shrink-0" />}
                      </motion.div>
                    );
                  })}
                </div>
                {batches.length > 0 && (
                  <div className="mt-3">
                    <p className="text-xs font-bold text-gray-700 mb-2 flex items-center gap-1.5"><Package2 size={12} className="text-gray-500" /> سجل الدفعات</p>
                    <div className="space-y-1">
                      {batches.map(batch => (
                        <div key={batch.id} className="flex items-center justify-between bg-gray-50 rounded-xl px-3 py-2">
                          <div>
                            <p className="text-[11px] font-medium text-gray-700">{batch.product_name}</p>
                            <p className="text-[10px] text-gray-400">
                              {batch.operator_name} • {batch.shift === 'morning' ? 'صباحي' : batch.shift === 'evening' ? 'مسائي' : 'ليلي'}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-[11px] font-bold text-gray-800">{batch.produced_quantity}/{batch.planned_quantity}</p>
                            <p className="text-[10px] text-red-500">{batch.defective_quantity} معيب</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export const ProductionLinesPage: React.FC = () => {
  const { user } = useAuth();
  const { format } = useCurrency();
  const {
    productionLines, productionBatches, products,
    updateProductionLine, addProductionLine, deleteProductionLine,
    startProductionLine, stopProductionLine,
    addProductionBatch, addNotification, can,
  } = useAppData();

  const [stepProgress, setStepProgress] = useState<Record<string, number>>({ pl1: 4, pl2: 2 });
  const [filter, setFilter] = useState<'all' | 'active' | 'maintenance' | 'idle' | 'stopped'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingLine, setEditingLine] = useState<ProductionLineExtended | null>(null);
  const [deletingLine, setDeletingLine] = useState<ProductionLineExtended | null>(null);
  const [stoppingLine, setStoppingLine] = useState<ProductionLineExtended | null>(null);
  const [addingBatchLine, setAddingBatchLine] = useState<ProductionLineExtended | null>(null);
  const [activeTab, setActiveTab] = useState<'lines' | 'analytics'>('lines');

  const isAdmin = user?.role === 'admin';
  const isManager = ['admin', 'manager', 'production_supervisor'].includes(user?.role ?? '');
  const canManageProd = can('production.manage');
  const canBatch = can('production.batch');
  const lines = productionLines;
  const filteredLines = filter === 'all' ? lines : lines.filter(l => l.status === filter);

  const counts = {
    active: lines.filter(l => l.status === 'active').length,
    stopped: lines.filter(l => l.status === 'stopped').length,
    maintenance: lines.filter(l => l.status === 'maintenance').length,
    idle: lines.filter(l => l.status === 'idle').length,
  };

  const totalProduced = lines.reduce((s, l) => s + l.total_produced_today, 0);
  const totalDefective = lines.reduce((s, l) => s + l.total_defective_today, 0);
  const activeLines = lines.filter(l => l.status === 'active');
  const avgEfficiency = activeLines.length > 0
    ? Math.round(activeLines.reduce((s, l) => s + l.efficiency_percentage, 0) / activeLines.length) : 0;
  const totalCost = lines.reduce((s, l) => s + l.operating_cost_usd, 0);

  const handleSave = (data: LineFormData, isEdit: boolean) => {
    if (isEdit && editingLine) {
      updateProductionLine(editingLine.id, data);
    } else {
      addProductionLine({
        status: 'idle', efficiency_percentage: 0,
        total_produced_today: 0, total_defective_today: 0, production_speed: 0,
        ...data,
      } as any);
    }
    setEditingLine(null);
    setShowAddModal(false);
  };

  const handleDelete = () => {
    if (deletingLine) { deleteProductionLine(deletingLine.id); setDeletingLine(null); }
  };

  const handleStart = (lineId: string) => { startProductionLine(lineId); };
  const handleStop = (line: ProductionLineExtended) => { setStoppingLine(line); };
  const handleStopConfirm = (lineId: string, reason: string) => {
    stopProductionLine(lineId, reason);
    addNotification({ type: 'warning', title: 'خط متوقف', message: `${lines.find(l => l.id === lineId)?.name}: ${reason}`, role_target: 'production_supervisor' });
  };

  const comparisonData = lines.map(l => ({ name: l.code, 'أُنتج': l.total_produced_today, 'الهدف': l.capacity_per_day, 'معيب': l.total_defective_today }));

  // Live: update stop_duration every minute.
  // Use a ref for the latest `lines` so the interval isn't torn down and
  // recreated every time updateProductionLine changes `lines` (which would
  // otherwise reset the 60s timer on every tick).
  const linesRef = useRef(lines);
  linesRef.current = lines;
  useEffect(() => {
    const interval = setInterval(() => {
      linesRef.current.forEach(l => {
        if (l.status === 'stopped' && l.stop_started_at) {
          const diff = Math.floor((Date.now() - new Date(l.stop_started_at).getTime()) / 1000);
          const h = Math.floor(diff / 3600).toString().padStart(2, '0');
          const m = Math.floor((diff % 3600) / 60).toString().padStart(2, '0');
          const s = Math.floor(diff % 60).toString().padStart(2, '0');
          updateProductionLine(l.id, { stop_duration: `${h}:${m}:${s}` });
        }
      });
    }, 60000);
    return () => clearInterval(interval);
  }, [updateProductionLine]);

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      <div className="bg-white px-4 pt-4 pb-3 border-b border-gray-100">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-lg font-bold text-gray-900">خطوط الإنتاج</h1>
            <p className="text-xs text-gray-500">{counts.active} نشطة من أصل {lines.length} خط</p>
          </div>
          {isAdmin && (
            <button onClick={() => { setEditingLine(null); setShowAddModal(true); }}
              className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 text-white text-sm font-bold rounded-2xl shadow-md shadow-blue-200 hover:bg-blue-700 transition-colors">
              <Plus size={15} /> خط جديد
            </button>
          )}
        </div>

        <div className="flex gap-1 mb-3">
          {[{ id: 'lines', label: 'الخطوط' }, { id: 'analytics', label: 'التحليلات' }].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === tab.id ? 'bg-blue-600 text-white shadow-md shadow-blue-200' : 'bg-gray-100 text-gray-600'}`}>
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'lines' && (
          <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-1">
            {[
              { value: 'all', label: `الكل (${lines.length})`, color: '' },
              { value: 'active', label: `نشطة (${counts.active})`, color: 'text-emerald-600' },
              { value: 'stopped', label: `متوقفة (${counts.stopped})`, color: 'text-red-600' },
              { value: 'maintenance', label: `صيانة (${counts.maintenance})`, color: 'text-amber-600' },
              { value: 'idle', label: `خاملة (${counts.idle})`, color: 'text-gray-500' },
            ].map(f => (
              <button key={f.value} onClick={() => setFilter(f.value as typeof filter)}
                className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${filter === f.value ? 'bg-blue-600 text-white shadow-sm' : `bg-gray-100 ${f.color} hover:bg-gray-200`}`}>
                {f.label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="px-4 py-4 space-y-4 pb-28">
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: Package2, label: 'إجمالي الإنتاج اليوم', val: totalProduced, sub: 'لوح ميلامين', from: 'from-emerald-500', to: 'to-green-600' },
            { icon: TrendingUp, label: 'متوسط الكفاءة', val: `${avgEfficiency}%`, sub: 'للخطوط النشطة', from: 'from-blue-500', to: 'to-indigo-600' },
            { icon: AlertTriangle, label: 'إجمالي المعيب', val: totalDefective, sub: `${totalProduced > 0 ? ((totalDefective / totalProduced) * 100).toFixed(1) : 0}% من الإنتاج`, from: 'from-red-500', to: 'to-rose-600' },
            { icon: Settings2, label: 'إجمالي التكاليف', val: format(totalCost), sub: 'تكلفة تشغيلية', from: 'from-purple-500', to: 'to-violet-600' },
          ].map((kpi, i) => (
            <div key={i} className={`bg-gradient-to-br ${kpi.from} ${kpi.to} rounded-2xl p-3 text-white`}>
              <div className="flex items-center gap-2 mb-2"><kpi.icon size={16} className="opacity-80" /><span className="text-xs opacity-80">{kpi.label}</span></div>
              <p className="text-2xl font-black">{kpi.val}</p>
              <p className="text-[10px] opacity-70 mt-0.5">{kpi.sub}</p>
            </div>
          ))}
        </div>

        {activeTab === 'lines' ? (
          <AnimatePresence mode="popLayout">
            {filteredLines.length === 0 ? (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-16">
                <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-3"><Activity size={36} className="text-gray-300" /></div>
                <p className="text-gray-500 font-medium">لا توجد خطوط إنتاج بهذه الحالة</p>
              </motion.div>
            ) : filteredLines.map(line => (
              <ProductionLineCard key={line.id} line={line}
                stepProgress={stepProgress[line.id] ?? 0}
                onAdvanceStep={() => setStepProgress(prev => ({ ...prev, [line.id]: Math.min((prev[line.id] ?? 0) + 1, PRODUCTION_STEPS.length) }))}
                onEdit={() => { setEditingLine(line); setShowAddModal(true); }}
                onDelete={() => setDeletingLine(line)}
                onStart={() => handleStart(line.id)}
                onStop={() => handleStop(line)}
                onAddBatch={() => setAddingBatchLine(line)}
                isAdmin={isAdmin} isManager={isManager}
                canManageProd={canManageProd} canBatch={canBatch}
              />
            ))}
          </AnimatePresence>
        ) : (
          <motion.div key="analytics" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
              <h3 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2"><BarChart3 size={15} className="text-blue-500" /> مقارنة الإنتاج مقابل الهدف</h3>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={comparisonData} margin={{ top: 5, right: 10, bottom: 5, left: -20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 10, border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="أُنتج" fill="#10b981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="الهدف" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="معيب" fill="#f87171" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
              <h3 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2"><Timer size={15} className="text-purple-500" /> الإنتاج بالساعة</h3>
              <ResponsiveContainer width="100%" height={160}>
                <AreaChart data={demoHourlyProduction} margin={{ top: 5, right: 10, bottom: 5, left: -20 }}>
                  <defs>
                    <linearGradient id="gradA2" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} /><stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradB2" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} /><stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="hour" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 10, border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Area type="monotone" dataKey="lineA" name="خط A" stroke="#10b981" fill="url(#gradA2)" strokeWidth={2} />
                  <Area type="monotone" dataKey="lineB" name="خط B" stroke="#3b82f6" fill="url(#gradB2)" strokeWidth={2} />
                  <Area type="monotone" dataKey="target" name="الهدف" stroke="#f59e0b" strokeDasharray="5 5" fill="none" strokeWidth={1.5} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
              <h3 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2"><TrendingUp size={15} className="text-emerald-500" /> مقارنة كفاءة الخطوط</h3>
              <div className="space-y-3">
                {lines.map(line => {
                  const lcfg = STATUS_CONFIG[line.status];
                  const batches2 = productionBatches.filter(b => b.line_id === line.id);
                  return (
                    <div key={line.id} className="flex items-center gap-3">
                      <div className="w-16 h-16 shrink-0">
                        <CircularProgressbar value={line.efficiency_percentage} text={`${line.efficiency_percentage}%`}
                          styles={buildStyles({ textSize: '24px', pathColor: lcfg.pathColor, textColor: lcfg.pathColor, trailColor: lcfg.trailColor })} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-bold text-gray-800">{line.name}</p>
                        <p className="text-xs text-gray-500">{line.total_produced_today} لوح • {batches2.length} دفعة</p>
                        <div className="flex items-center gap-2 mt-1.5">
                          <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                            <motion.div className="h-2 rounded-full" style={{ backgroundColor: lcfg.pathColor }}
                              initial={{ width: 0 }} animate={{ width: `${line.efficiency_percentage}%` }} transition={{ duration: 1, delay: 0.2 }} />
                          </div>
                          <Badge variant={lcfg.badge} className="text-[10px] shrink-0">{lcfg.label}</Badge>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
              <h3 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2"><Wrench size={15} className="text-amber-500" /> سجل الصيانة</h3>
              <div className="space-y-2">
                {lines.map(line => (
                  <div key={line.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                    <div>
                      <p className="text-xs font-semibold text-gray-800">{line.code}</p>
                      <p className="text-[10px] text-gray-500">{line.last_maintenance ? new Date(line.last_maintenance).toLocaleDateString('ar-SY') : 'لم تتم صيانة'}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-gray-500">
                        {line.last_maintenance ? `${Math.floor((Date.now() - new Date(line.last_maintenance).getTime()) / (1000 * 3600 * 24))} يوم` : '—'}
                      </p>
                      <Badge variant={STATUS_CONFIG[line.status].badge} className="text-[9px]">{STATUS_CONFIG[line.status].label}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {showAddModal && (
        <LineModal line={editingLine} onClose={() => { setShowAddModal(false); setEditingLine(null); }} onSave={handleSave} />
      )}
      {deletingLine && (
        <DeleteModal lineName={deletingLine.name} onConfirm={handleDelete} onClose={() => setDeletingLine(null)} />
      )}
      {stoppingLine && (
        <StopLineModal
          onConfirm={(reason) => handleStopConfirm(stoppingLine.id, reason)}
          onClose={() => setStoppingLine(null)}
        />
      )}
      {addingBatchLine && (
        <AddBatchModal
          line={addingBatchLine}
          products={products}
          onClose={() => setAddingBatchLine(null)}
          onSave={(batch) => {
            addProductionBatch(batch);
            addNotification({ type: 'success', title: 'دفعة جديدة', message: `تم تسجيل دفعة إنتاج في ${addingBatchLine.name}`, role_target: 'production_supervisor' });
            setAddingBatchLine(null);
          }}
        />
      )}
    </div>
  );
};

export default React.memo(ProductionLinesPage);
