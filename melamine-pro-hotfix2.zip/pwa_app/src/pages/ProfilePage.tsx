import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User, Edit3, Save, X, Camera, Shield, Phone, Mail,
  Building, Calendar, Award, TrendingUp, Clock,
  CheckCircle, Lock, Eye, EyeOff, LogOut, Star,
  DollarSign, Activity, Key, AlertCircle, RefreshCw, Trash2,
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '../contexts/AuthContext';
import { useAppData } from '../contexts/AppDataContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { useNavigate } from 'react-router-dom';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { Avatar } from '../components/ui/Avatar';
import { fileToAvatarDataUrl, setAvatar, removeAvatar, getAvatar } from '../lib/avatar';

const ROLE_LABELS: Record<string, string> = {
  admin: 'مدير النظام', manager: 'مدير الإنتاج',
  production_supervisor: 'مشرف الإنتاج', worker: 'عامل الإنتاج',
  accountant: 'محاسب', hr: 'موارد بشرية',
};

const ROLE_GRADIENTS: Record<string, string> = {
  admin: 'from-red-500 to-rose-600',
  manager: 'from-blue-500 to-indigo-600',
  production_supervisor: 'from-purple-500 to-violet-600',
  worker: 'from-emerald-500 to-teal-600',
  accountant: 'from-amber-500 to-orange-600',
  hr: 'from-pink-500 to-rose-500',
};

const PERMISSIONS: Record<string, string[]> = {
  admin:                 ['لوحة التحكم', 'إدارة المستخدمين', 'الإعدادات', 'التقارير', 'الإنتاج', 'المالية', 'الموارد البشرية'],
  manager:               ['لوحة التحكم', 'الطلبات', 'الإنتاج', 'المخزون', 'التقارير', 'المحفظة'],
  production_supervisor: ['الإنتاج', 'الطلبات', 'الحضور', 'خطوط الإنتاج'],
  worker:                ['الحضور', 'محفظتي'],
  accountant:            ['السجل المحاسبي', 'التقارير المالية', 'المبيعات'],
  hr:                    ['الموارد البشرية', 'الرواتب', 'الإجازات', 'الحضور'],
};

export const ProfilePage: React.FC = () => {
  const { user, logout, isDemoMode, updateUser } = useAuth();
  const { employees, attendanceRecords, wallets, getWallet, saveUserProfile, changePassword, walletTransactions } = useAppData();
  const { formatUSD, formatSYP, exchangeRate } = useCurrency();
  const navigate = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);
  const [photo, setPhoto] = useState<string | null>(() => getAvatar(user?.id));
  const [photoBusy, setPhotoBusy] = useState(false);

  const handlePhotoPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow re-picking the same file
    if (!file || !user) return;
    setPhotoBusy(true);
    try {
      const url = await fileToAvatarDataUrl(file);
      setAvatar(user.id, url);
      updateUser({ avatar_url: url });
      setPhoto(url);
      toast.success('تم تحديث صورة الحساب');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'تعذّر تحميل الصورة');
    } finally {
      setPhotoBusy(false);
    }
  };

  const handlePhotoRemove = () => {
    if (!user) return;
    removeAvatar(user.id);
    updateUser({ avatar_url: undefined });
    setPhoto(null);
    toast.success('تمت إزالة صورة الحساب');
  };

  const [tab, setTab]             = useState<'info' | 'stats' | 'security'>('info');
  const [editing, setEditing]     = useState(false);
  const [saved, setSaved]         = useState(false);
  const [showPwdModal, setShowPwdModal] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPwd, setShowNewPwd]   = useState(false);
  const [name, setName]           = useState(user?.full_name || '');
  const [phone, setPhone]         = useState(user?.phone || '');
  const [currentPwd, setCurrentPwd]   = useState('');
  const [newPwd, setNewPwd]       = useState('');
  const [pwdError, setPwdError]   = useState('');
  const [pwdSuccess, setPwdSuccess] = useState(false);
  const [saving, setSaving]       = useState(false);

  if (!user) return null;

  const gradient = ROLE_GRADIENTS[user.role] ?? 'from-slate-600 to-slate-800';
  const employee  = employees.find(e => e.user_id === user.id);
  const wallet    = getWallet(user.id);
  const myTxs     = walletTransactions.filter(t => t.worker_id === user.id);
  const todayStr  = new Date().toISOString().split('T')[0];
  const myAttendance = attendanceRecords.filter(a => a.worker_id === user.id);
  const presentDays  = myAttendance.filter(a => a.status === 'present' || a.status === 'late').length;
  const lateDays     = myAttendance.filter(a => a.status === 'late').length;
  const totalHours   = myAttendance.reduce((sum, r) => {
    if (!r.check_in) return sum;
    const ms = r.check_out ? new Date(r.check_out).getTime() - new Date(r.check_in).getTime() : 0;
    return sum + ms / 3600000;
  }, 0);
  const todayRecord = myAttendance.find(a => a.date === todayStr);
  const yearsService = employee ? Math.max(0, new Date().getFullYear() - new Date(employee.hire_date).getFullYear()) : 0;
  const totalBonus = myTxs.filter(t => t.type === 'bonus').reduce((s, t) => s + t.amount_usd, 0);
  const totalAdvance = myTxs.filter(t => t.type === 'advance').reduce((s, t) => s + t.amount_usd, 0);

  const handleSave = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    saveUserProfile({ full_name: name, phone, email: user.email });
    setSaving(false);
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleChangePassword = async () => {
    setPwdError('');
    if (!currentPwd || !newPwd) { setPwdError('يرجى ملء جميع الحقول'); return; }
    if (newPwd.length < 6) { setPwdError('كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل'); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    const result = await changePassword(currentPwd, newPwd);
    setSaving(false);
    if (result.success) { setPwdSuccess(true); setCurrentPwd(''); setNewPwd(''); setTimeout(() => { setPwdSuccess(false); setShowPwdModal(false); }, 2000); }
    else { setPwdError(result.error || 'خطأ في تغيير كلمة المرور'); }
  };

  const handleLogout = () => { logout(); navigate('/login'); };

  const perms = PERMISSIONS[user.role] || [];

  return (
    <div className="min-h-full bg-gray-50 pb-10" dir="rtl">

      {/* ── Hero ────────────────────────────────────────────────── */}
      <div className={`bg-gradient-to-br ${gradient} px-5 pt-6 pb-20 relative overflow-hidden`}>
        <div className="absolute -top-10 -left-10 w-40 h-40 bg-white/5 rounded-full" />
        <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-white/5 rounded-full" />

        {/* Success toast */}
        <AnimatePresence>
          {saved && (
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
              className="absolute top-4 left-4 right-4 bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2.5 flex items-center gap-2 border border-white/30 z-10"
            >
              <CheckCircle size={16} className="text-white" />
              <span className="text-white text-sm font-medium">تم حفظ البيانات بنجاح</span>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="relative flex items-start justify-between mb-5">
          <div className="flex items-center gap-4">
            {/* Avatar */}
            <div className="relative">
              <div style={{
                width: 80, height: 80, borderRadius: 24,
                border: '2px solid rgba(255,255,255,0.35)',
                boxShadow: '0 8px 22px rgba(0,0,0,0.18)', overflow: 'hidden',
                background: 'rgba(255,255,255,0.18)',
              }}>
                <Avatar
                  userId={user.id}
                  name={user.full_name}
                  role={user.role}
                  size={80}
                  radius={22}
                  photo={photo}
                  fallbackPhoto={user.avatar_url}
                />
              </div>

              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoPick}
                style={{ display: 'none' }}
              />

              {/* Change photo */}
              <button
                onClick={() => fileRef.current?.click()}
                disabled={photoBusy}
                aria-label="تغيير صورة الحساب"
                className="absolute -bottom-1 -left-1 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md active:scale-90 transition-transform"
              >
                {photoBusy
                  ? <div className="w-3.5 h-3.5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                  : <Camera size={14} className="text-gray-700" />}
              </button>

              {/* Remove photo (only when a photo exists) */}
              {photo && !photoBusy && (
                <button
                  onClick={handlePhotoRemove}
                  aria-label="إزالة صورة الحساب"
                  className="absolute -top-1 -left-1 w-7 h-7 bg-red-500 rounded-full flex items-center justify-center shadow-md active:scale-90 transition-transform"
                >
                  <Trash2 size={12} className="text-white" />
                </button>
              )}
            </div>
            <div>
              {editing ? (
                <input value={name} onChange={e => setName(e.target.value)}
                  className="text-lg font-black text-white bg-white/20 rounded-xl px-3 py-1.5 border border-white/30 outline-none w-40 mb-1"
                  placeholder="الاسم الكامل"
                />
              ) : (
                <h1 className="text-xl font-black text-white mb-1">{name || user.full_name}</h1>
              )}
              <span className="bg-white/20 text-white/90 text-xs px-3 py-1 rounded-full font-medium border border-white/20">
                {ROLE_LABELS[user.role]}
              </span>
              {isDemoMode && (
                <span className="mr-2 bg-amber-400/30 text-amber-100 text-[10px] px-2 py-0.5 rounded-full border border-amber-300/30">تجريبي</span>
              )}
            </div>
          </div>

          <div className="flex gap-2">
            {editing ? (
              <>
                <button onClick={() => setEditing(false)} className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center text-white border border-white/30">
                  <X size={16} />
                </button>
                <button onClick={handleSave} disabled={saving} className="w-9 h-9 bg-white rounded-xl flex items-center justify-center text-gray-700 shadow-md">
                  {saving ? <div className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" /> : <Save size={16} />}
                </button>
              </>
            ) : (
              <button onClick={() => setEditing(true)} className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center text-white border border-white/30">
                <Edit3 size={16} />
              </button>
            )}
          </div>
        </div>

        {/* Stats strip */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: 'أيام الحضور', val: presentDays, icon: <CheckCircle size={13}/> },
            { label: 'ساعات العمل', val: `${totalHours.toFixed(0)}س`, icon: <Clock size={13}/> },
            { label: 'سنوات الخدمة', val: `${yearsService}س`, icon: <Award size={13}/> },
          ].map((s, i) => (
            <div key={i} className="bg-white/10 backdrop-blur-sm rounded-2xl p-3 text-center border border-white/15">
              <div className="flex justify-center text-white/70 mb-1">{s.icon}</div>
              <p className="text-xl font-black text-white tabular-nums">{s.val}</p>
              <p className="text-white/60 text-[10px]">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Tabs ─────────────────────────────────────────────────── */}
      <div className="-mt-4 mx-4">
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="flex border-b border-gray-100">
            {(['info', 'stats', 'security'] as const).map(t => (
              <button key={t} onClick={() => setTab(t)}
                className={`flex-1 py-3.5 text-xs font-bold transition-colors relative ${tab === t ? 'text-blue-600' : 'text-gray-500'}`}
              >
                {t === 'info' ? 'المعلومات' : t === 'stats' ? 'الإحصائيات' : 'الأمان'}
                {tab === t && <motion.div layoutId="profile-tab-indicator" className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.15 }}>

              {/* ── Info Tab ── */}
              {tab === 'info' && (
                <div className="p-4 space-y-4">
                  {/* Contact */}
                  <div className="space-y-0 divide-y divide-gray-50">
                    {[
                      { icon: <Mail size={16} className="text-blue-500" />, label: 'البريد الإلكتروني', val: user.email, editable: false },
                      { icon: <Phone size={16} className="text-emerald-500" />, label: 'رقم الهاتف', val: phone, editable: true, setter: setPhone },
                      { icon: <Shield size={16} className="text-purple-500" />, label: 'الدور الوظيفي', val: ROLE_LABELS[user.role], editable: false },
                      { icon: <Building size={16} className="text-amber-500" />, label: 'القسم', val: employee?.department || 'الإنتاج', editable: false },
                    ].map((row, i) => (
                      <div key={i} className="flex items-center gap-3 py-3.5">
                        <div className="w-8 h-8 bg-gray-50 rounded-xl flex items-center justify-center shrink-0">{row.icon}</div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[11px] text-gray-400 mb-0.5">{row.label}</p>
                          {editing && row.editable && row.setter ? (
                            <input value={row.val} onChange={e => row.setter!(e.target.value)}
                              className="text-sm font-medium text-gray-800 bg-gray-50 rounded-lg px-2 py-1 border border-gray-200 outline-none w-full"
                            />
                          ) : (
                            <p className="text-sm font-medium text-gray-800 truncate">{row.val}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Employment info */}
                  {employee && (
                    <div className="bg-gray-50 rounded-2xl p-4 space-y-3">
                      <p className="text-xs font-bold text-gray-500 uppercase tracking-wider">معلومات التوظيف</p>
                      <div className="grid grid-cols-2 gap-3">
                        {[
                          { label: 'تاريخ التوظيف', val: new Date(employee.hire_date).toLocaleDateString('ar-SY') },
                          { label: 'ساعات العمل', val: `${employee.working_hours} ساعة` },
                          { label: 'الراتب الأساسي', val: formatUSD(employee.salary_usd) },
                          { label: 'المسمى الوظيفي', val: employee.position },
                        ].map((item, i) => (
                          <div key={i} className="bg-white rounded-xl p-2.5 border border-gray-100">
                            <p className="text-[10px] text-gray-400 mb-0.5">{item.label}</p>
                            <p className="text-xs font-bold text-gray-800">{item.val}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Permissions */}
                  <div className="bg-blue-50 rounded-2xl p-4">
                    <p className="text-xs font-bold text-blue-700 mb-2.5 flex items-center gap-1.5"><Shield size={13} />الصلاحيات الممنوحة</p>
                    <div className="flex flex-wrap gap-1.5">
                      {perms.map((p, i) => (
                        <span key={i} className="bg-white text-blue-700 text-[11px] font-medium px-2.5 py-1 rounded-lg border border-blue-100 flex items-center gap-1">
                          <CheckCircle size={9} className="text-blue-500" />{p}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* ── Stats Tab ── */}
              {tab === 'stats' && (
                <div className="p-4 space-y-4">
                  {/* Wallet card */}
                  <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-4 text-white">
                    <div className="flex items-center gap-2 mb-3">
                      <DollarSign size={16} className="text-emerald-200" />
                      <span className="text-emerald-100 text-sm font-medium">رصيد المحفظة</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <p className="text-2xl font-black tabular-nums">{formatUSD(wallet.balanceUSD)}</p>
                        <p className="text-emerald-200 text-xs">دولار أمريكي</p>
                      </div>
                      <div>
                        <p className="text-2xl font-black tabular-nums">{(wallet.balanceSYP / 1000000).toFixed(2)}م</p>
                        <p className="text-emerald-200 text-xs">ليرة سورية</p>
                      </div>
                    </div>
                  </div>

                  {/* Stats grid */}
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'أيام الحضور', val: presentDays, icon: <CheckCircle size={16}/>, color: 'bg-emerald-50 text-emerald-600' },
                      { label: 'أيام التأخر',  val: lateDays,    icon: <Clock size={16}/>,       color: 'bg-amber-50 text-amber-600' },
                      { label: 'مجموع المكافآت', val: formatUSD(totalBonus),   icon: <Star size={16}/>,       color: 'bg-purple-50 text-purple-600' },
                      { label: 'إجمالي السلف',  val: formatUSD(totalAdvance), icon: <TrendingUp size={16}/>, color: 'bg-blue-50 text-blue-600' },
                    ].map((s, i) => (
                      <div key={i} className={`${s.color.split(' ')[0]} rounded-2xl p-4 border border-white`}>
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center mb-2 ${s.color}`}>{s.icon}</div>
                        <p className="text-xl font-black text-gray-800 tabular-nums">{s.val}</p>
                        <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
                      </div>
                    ))}
                  </div>

                  {/* Monthly performance */}
                  <div className="bg-white rounded-2xl border border-gray-100 p-4">
                    <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">مؤشرات الأداء</p>
                    {[
                      { label: 'الانضباط',   pct: Math.max(0, 100 - lateDays * 10), color: 'bg-emerald-500' },
                      { label: 'الإنتاجية',  pct: Math.min(100, presentDays * 5),   color: 'bg-blue-500' },
                      { label: 'التواصل',    pct: 82,                               color: 'bg-purple-500' },
                    ].map((p, i) => (
                      <div key={i} className="mb-3 last:mb-0">
                        <div className="flex justify-between text-xs mb-1.5">
                          <span className="text-gray-600 font-medium">{p.label}</span>
                          <span className="font-bold text-gray-800">{p.pct}%</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <motion.div initial={{ width: 0 }} animate={{ width: `${p.pct}%` }} transition={{ duration: 1, delay: i * 0.1 }}
                            className={`h-full rounded-full ${p.color}`}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Recent transactions */}
                  {myTxs.length > 0 && (
                    <div className="bg-white rounded-2xl border border-gray-100 p-4">
                      <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">آخر المعاملات</p>
                      <div className="space-y-2.5">
                        {myTxs.slice(0, 5).map(tx => (
                          <div key={tx.id} className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0 ${
                              tx.type === 'salary' ? 'bg-blue-500' :
                              tx.type === 'bonus'  ? 'bg-emerald-500' :
                              tx.type === 'advance'? 'bg-amber-500' : 'bg-red-500'
                            }`}>
                              {tx.type === 'salary' ? 'ر' : tx.type === 'bonus' ? 'م' : tx.type === 'advance' ? 'س' : 'خ'}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-gray-800 truncate">{tx.description}</p>
                              <p className="text-[10px] text-gray-400">{new Date(tx.created_at).toLocaleDateString('ar-SY')}</p>
                            </div>
                            <span className={`text-sm font-bold tabular-nums ${['salary','bonus'].includes(tx.type) ? 'text-emerald-600' : 'text-red-500'}`}>
                              {['salary','bonus'].includes(tx.type) ? '+' : '-'}{formatUSD(tx.amount_usd)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ── Security Tab ── */}
              {tab === 'security' && (
                <div className="p-4 space-y-3">
                  {/* Session info */}
                  <div className="bg-gray-50 rounded-2xl p-4 space-y-3">
                    <p className="text-xs font-bold text-gray-500 uppercase tracking-wider">معلومات الجلسة</p>
                    {[
                      { label: 'معرف المستخدم', val: user.id.slice(0, 12) + '...', icon: <Key size={13}/> },
                      { label: 'الدور',          val: ROLE_LABELS[user.role],       icon: <Shield size={13}/> },
                      { label: 'البريد الإلكتروني', val: user.email,              icon: <Mail size={13}/> },
                      { label: 'حالة الحساب',   val: 'نشط',                       icon: <Activity size={13}/> },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <div className="w-7 h-7 bg-white rounded-lg flex items-center justify-center text-gray-500 border border-gray-200 shrink-0">{item.icon}</div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[10px] text-gray-400">{item.label}</p>
                          <p className="text-xs font-medium text-gray-700 truncate">{item.val}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Change password */}
                  <button onClick={() => setShowPwdModal(true)}
                    className="w-full bg-white rounded-2xl border border-gray-200 p-4 flex items-center gap-3 active:bg-gray-50 transition-colors"
                  >
                    <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center shrink-0">
                      <Lock size={18} className="text-amber-500" />
                    </div>
                    <div className="flex-1 text-right">
                      <p className="text-sm font-bold text-gray-800">تغيير كلمة المرور</p>
                      <p className="text-xs text-gray-400">تحديث كلمة المرور الخاصة بك</p>
                    </div>
                    <div className="w-6 h-6 bg-gray-100 rounded-lg flex items-center justify-center">
                      <span className="text-gray-400 text-xs">←</span>
                    </div>
                  </button>

                  {isDemoMode && (
                    <div className="bg-amber-50 rounded-2xl p-4 flex items-start gap-3 border border-amber-100">
                      <AlertCircle size={16} className="text-amber-500 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-bold text-amber-700">وضع تجريبي</p>
                        <p className="text-xs text-amber-600 mt-0.5">أنت في وضع تجريبي. البيانات محلية فقط.</p>
                      </div>
                    </div>
                  )}

                  {/* Logout */}
                  <button onClick={handleLogout}
                    className="w-full bg-red-50 rounded-2xl border border-red-100 p-4 flex items-center gap-3 active:bg-red-100 transition-colors"
                  >
                    <div className="w-10 h-10 bg-red-500 rounded-xl flex items-center justify-center shrink-0">
                      <LogOut size={18} className="text-white" />
                    </div>
                    <div className="flex-1 text-right">
                      <p className="text-sm font-bold text-red-700">تسجيل الخروج</p>
                      <p className="text-xs text-red-400">إنهاء الجلسة الحالية</p>
                    </div>
                  </button>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* ── Change Password Modal ─────────────────────────────────── */}
      <BottomSheetModal isOpen={showPwdModal} onClose={() => setShowPwdModal(false)}>
        <SheetHeader onClose={() => setShowPwdModal(false)}>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-amber-100 rounded-xl flex items-center justify-center">
              <Lock size={16} className="text-amber-600" />
            </div>
            <span className="font-bold text-gray-800">تغيير كلمة المرور</span>
          </div>
        </SheetHeader>
        <SheetBody>
          <div className="space-y-4">
            {pwdSuccess ? (
              <div className="flex flex-col items-center gap-4 py-8">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center">
                  <CheckCircle size={32} className="text-emerald-500" />
                </div>
                <p className="text-emerald-700 font-bold text-base">تم تغيير كلمة المرور بنجاح</p>
              </div>
            ) : (
              <>
                {pwdError && (
                  <div className="bg-red-50 rounded-xl p-3 flex items-center gap-2 border border-red-100">
                    <AlertCircle size={14} className="text-red-500 shrink-0" />
                    <p className="text-xs text-red-700">{pwdError}</p>
                  </div>
                )}
                {isDemoMode && (
                  <div className="bg-amber-50 rounded-xl p-3 text-xs text-amber-700 border border-amber-100">
                    كلمة المرور الحالية للوضع التجريبي: <strong>demo123</strong>
                  </div>
                )}
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block">كلمة المرور الحالية</label>
                    <div className="relative">
                      <input type={showPassword ? 'text' : 'password'} value={currentPwd} onChange={e => setCurrentPwd(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 pr-10"
                        placeholder="أدخل كلمة المرور الحالية"
                      />
                      <button onClick={() => setShowPassword(!showPassword)} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block">كلمة المرور الجديدة</label>
                    <div className="relative">
                      <input type={showNewPwd ? 'text' : 'password'} value={newPwd} onChange={e => setNewPwd(e.target.value)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 pr-10"
                        placeholder="أدخل كلمة المرور الجديدة"
                      />
                      <button onClick={() => setShowNewPwd(!showNewPwd)} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                        {showNewPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                    {newPwd && (
                      <div className="mt-1.5 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full transition-all ${
                          newPwd.length < 6 ? 'w-1/4 bg-red-400' :
                          newPwd.length < 8 ? 'w-1/2 bg-amber-400' :
                          newPwd.length < 10 ? 'w-3/4 bg-blue-400' : 'w-full bg-emerald-500'
                        }`} />
                      </div>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </SheetBody>
        {!pwdSuccess && (
          <SheetFooter>
            <div className="flex gap-3">
              <button onClick={() => setShowPwdModal(false)}
                className="flex-1 py-3.5 rounded-xl border-2 border-gray-200 text-gray-600 font-bold text-sm active:scale-95 transition-all"
              >إلغاء</button>
              <button onClick={handleChangePassword} disabled={saving}
                className="flex-1 py-3.5 rounded-xl bg-amber-500 text-white font-bold text-sm shadow-lg shadow-amber-200 active:scale-95 transition-all disabled:opacity-60"
              >
                {saving ? <RefreshCw size={16} className="animate-spin mx-auto" /> : 'تغيير كلمة المرور'}
              </button>
            </div>
          </SheetFooter>
        )}
      </BottomSheetModal>

    </div>
  );
};

// Missing import for RefreshCw
export default ProfilePage;
