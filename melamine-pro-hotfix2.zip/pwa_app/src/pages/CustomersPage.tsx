import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAppData } from '../contexts/AppDataContext';
import { customerSchema, collectErrors } from '../lib/validation';
import { EmptyState } from '../components/ui/EmptyState';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import {
  Search, Plus, Phone, Mail, MapPin, Building2,
  Star, Edit2, Trash2, X, CheckCircle, ChevronLeft,
  ShoppingBag, FileText, TrendingUp, AlertCircle, Printer, MessageCircle,
  Package, BarChart3,
} from 'lucide-react';
import { BottomSheetModal, SheetHeader, SheetBody, SheetFooter, CenterModal } from '../components/ui/Modal';
import { Pagination, usePagination } from '../components/ui/Pagination';
import { printCustomerStatement } from '../utils/print';
import { sendWhatsApp, paymentReminderMessage } from '../utils/whatsapp';
import { toast } from 'sonner';
import type { Customer, CustomerStatus } from '../types';

const STATUS_CFG: Record<CustomerStatus, { label: string; bg: string; text: string }> = {
  active:   { label: 'نشط',  bg: '#eff6ff', text: '#1d4ed8' },
  vip:      { label: 'VIP',  bg: '#fffbeb', text: '#b45309' },
  inactive: { label: 'غير نشط', bg: 'var(--border-color)', text: 'var(--text-tertiary)' },
};

interface CustomerFormState {
  name: string; phone: string; phone2: string; email: string;
  address: string; city: string; company: string;
  status: CustomerStatus; credit_limit_usd: string; notes: string;
}

const EMPTY_FORM: CustomerFormState = {
  name: '', phone: '', phone2: '', email: '', address: '', city: '',
  company: '', status: 'active', credit_limit_usd: '1000', notes: '',
};

export default function CustomersPage() {
  const { customers, orders, invoices, addCustomer, updateCustomer, deleteCustomer, systemSettings, managedProducts } = useAppData();
  const { formatUSD } = useCurrency();
  const { hasRole } = useAuth();
  const navigate = useNavigate();
  const canManage = hasRole('admin') || hasRole('manager');

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | CustomerStatus>('all');
  const [modal, setModal] = useState<{ mode: 'add' | 'edit' | 'detail'; id?: string } | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [form, setForm] = useState<CustomerFormState>(EMPTY_FORM);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return customers.filter(c => {
      const matchSearch = !q ||
        c.name.toLowerCase().includes(q) ||
        c.phone.includes(q) ||
        (c.company || '').toLowerCase().includes(q);
      const matchStatus = statusFilter === 'all' || c.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [customers, search, statusFilter]);

  const PAGE_SIZE = 15;
  const [page, setPage] = useState(1);
  useEffect(() => { setPage(1); }, [search, statusFilter]);
  const { pageItems: paged, safePage } = usePagination(filtered, PAGE_SIZE, page);

  const selectedCustomer = modal?.id ? customers.find(c => c.id === modal.id) : undefined;

  const openAdd = () => { setForm(EMPTY_FORM); setErrors({}); setModal({ mode: 'add' }); };
  const openEdit = (c: Customer) => {
    setForm({
      name: c.name, phone: c.phone, phone2: c.phone2 || '', email: c.email || '',
      address: c.address || '', city: c.city || '', company: c.company || '',
      status: c.status, credit_limit_usd: String(c.credit_limit_usd), notes: c.notes || '',
    });
    setModal({ mode: 'edit', id: c.id });
  };
  const openDetail = (id: string) => setModal({ mode: 'detail', id });
  const closeModal = () => { setErrors({}); setModal(null); };

  const handleSave = () => {
    const errs = collectErrors(customerSchema, { name: form.name, phone: form.phone, email: form.email });
    if (errs) { setErrors(errs); return; }
    setErrors({});
    if (!form.name.trim() || !form.phone.trim()) return;
    const payload = {
      name: form.name.trim(), phone: form.phone.trim(), phone2: form.phone2 || undefined,
      email: form.email || undefined, address: form.address || undefined, city: form.city || undefined,
      company: form.company || undefined, status: form.status,
      credit_limit_usd: parseFloat(form.credit_limit_usd) || 0,
      notes: form.notes || undefined,
    };
    if (modal?.mode === 'edit' && modal.id) {
      updateCustomer(modal.id, payload);
    } else {
      addCustomer({ ...payload, balance_usd: 0 });
    }
    closeModal();
  };

  // Customer order/invoice history for detail view
  const customerOrders = useMemo(() =>
    selectedCustomer ? orders.filter(o => o.customer_id ? o.customer_id === selectedCustomer.id : o.customer_name === selectedCustomer.name) : [],
  [orders, selectedCustomer]);
  const customerInvoices = useMemo(() =>
    selectedCustomer ? invoices.filter(i => i.customer_id === selectedCustomer.id) : [],
  [invoices, selectedCustomer]);

  // Per-customer reporting: products bought + monthly activity.
  const customerReport = useMemo(() => {
    const products = new Map<string, { name: string; qty: number; total: number }>();
    const monthly = new Map<string, { orders: number; total: number }>();
    for (const o of customerOrders) {
      const m = (o.created_at || '').slice(0, 7); // YYYY-MM
      if (m) {
        const mm = monthly.get(m) || { orders: 0, total: 0 };
        mm.orders += 1; mm.total += o.total_usd || 0; monthly.set(m, mm);
      }
      for (const it of o.items || []) {
        const prod = managedProducts.find(p => p.id === it.product_id);
        const name = prod?.name || it.product?.name || 'منتج';
        const key = it.product_id || name;
        const pp = products.get(key) || { name, qty: 0, total: 0 };
        pp.qty += it.quantity || 0; pp.total += it.total_usd || 0; products.set(key, pp);
      }
    }
    const topProducts = Array.from(products.values()).sort((a, b) => b.total - a.total);
    const months = Array.from(monthly.entries())
      .sort((a, b) => (a[0] < b[0] ? 1 : -1)).slice(0, 6)
      .map(([month, v]) => ({ month, ...v }));
    const maxMonth = Math.max(1, ...months.map(m => m.total));
    const totalValue = customerOrders.reduce((s, o) => s + (o.total_usd || 0), 0);
    return { topProducts, months, maxMonth, totalValue };
  }, [customerOrders, managedProducts]);

  const monthLabel = (ym: string) => {
    const [y, m] = ym.split('-');
    const names = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    return `${names[Number(m) - 1] || m} ${y}`;
  };

  return (
    <div style={{ minHeight: '100%', background: 'var(--surface-secondary)' }}>
      {/* Header */}
      <div style={{ background: 'linear-gradient(135deg,#3b82f6,#2563eb)', padding: '20px 16px 60px', position: 'relative' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div>
            <h1 style={{ fontSize: 20, fontWeight: 900, color: '#fff' }}>العملاء</h1>
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.8)' }}>{customers.length} عميل مسجّل</p>
          </div>
        </div>
        <div style={{ position: 'relative' }}>
          <Search size={16} style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="ابحث بالاسم أو رقم الهاتف أو الشركة..."
            style={{ width: '100%', padding: '12px 40px 12px 14px', borderRadius: 14, border: 'none', fontSize: 14, outline: 'none', boxSizing: 'border-box', boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }} />
        </div>
      </div>

      {/* Filters */}
      <div style={{ padding: '0 16px', marginTop: -36 }}>
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
          {(['all', 'active', 'vip', 'inactive'] as const).map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              style={{
                padding: '8px 16px', borderRadius: 99, border: 'none', whiteSpace: 'nowrap',
                background: statusFilter === s ? 'var(--surface)' : 'rgba(255,255,255,0.7)',
                color: statusFilter === s ? '#1d4ed8' : 'var(--text-tertiary)',
                fontSize: 12, fontWeight: 700, cursor: 'pointer',
                boxShadow: statusFilter === s ? '0 2px 8px rgba(0,0,0,0.12)' : 'none',
              }}>
              {s === 'all' ? 'الكل' : STATUS_CFG[s].label}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {filtered.length === 0 ? (
          <EmptyState icon={Building2} title="لا يوجد عملاء مطابقين" description="جرّب تغيير البحث أو الفلتر، أو أضِف عميلاً جديداً." />
        ) : (
          paged.map(c => (
            <motion.div key={c.id} layout
              onClick={() => openDetail(c.id)}
              style={{ background: 'var(--surface)', borderRadius: 16, padding: 14, border: '1px solid var(--border-color)', cursor: 'pointer', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{
                  width: 44, height: 44, borderRadius: 12, flexShrink: 0,
                  background: c.status === 'vip' ? 'linear-gradient(135deg,#f59e0b,#d97706)' : 'linear-gradient(135deg,#3b82f6,#2563eb)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 16,
                }}>
                  {c.name.charAt(0)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.name}</span>
                    {c.status === 'vip' && <Star size={12} fill="#f59e0b" color="#f59e0b" />}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 2 }} dir="ltr">{c.phone}</div>
                </div>
                <div style={{ textAlign: 'left' }}>
                  <span style={{ fontSize: 10, padding: '3px 8px', borderRadius: 99, background: STATUS_CFG[c.status].bg, color: STATUS_CFG[c.status].text, fontWeight: 700 }}>
                    {STATUS_CFG[c.status].label}
                  </span>
                  {c.balance_usd > 0 && (
                    <div style={{ fontSize: 11, color: '#dc2626', fontWeight: 700, marginTop: 4 }}>مستحق: {formatUSD(c.balance_usd)}</div>
                  )}
                </div>
                <ChevronLeft size={16} color="#cbd5e1" />
              </div>
            </motion.div>
          ))
        )}
        {filtered.length > 0 && <Pagination page={safePage} totalItems={filtered.length} pageSize={PAGE_SIZE} onPageChange={setPage} />}
      </div>

      {/* FAB */}
      {canManage && (
        <button onClick={openAdd}
          style={{
            position: 'fixed', left: 20, bottom: `calc(var(--bottomnav-h) + var(--sab) + 16px)`,
            width: 52, height: 52, borderRadius: '50%',
            background: 'linear-gradient(135deg,#3b82f6,#2563eb)',
            color: '#fff', border: 'none', cursor: 'pointer', zIndex: 30,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 20px rgba(37,99,235,0.4)',
          }}>
          <Plus size={22} />
        </button>
      )}

      {/* Add/Edit Modal */}
      {(modal?.mode === 'add' || modal?.mode === 'edit') && (
        <BottomSheetModal isOpen onClose={closeModal}>
          <SheetHeader onClose={closeModal}>
            <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>
              {modal.mode === 'edit' ? 'تعديل بيانات العميل' : 'إضافة عميل جديد'}
            </div>
          </SheetHeader>
          <SheetBody>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>اسم العميل *</label>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  placeholder="أحمد محمد" style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: `1.5px solid ${errors.name ? '#ef4444' : 'var(--border-color)'}`, fontSize: 16, outline: 'none', boxSizing: 'border-box' }} />
                {errors.name && <span style={{ fontSize: 11, color: '#ef4444', marginTop: 4, display: 'block' }}>{errors.name}</span>}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>الهاتف *</label>
                  <input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                    placeholder="+963 9XX XXX XXX" dir="ltr" style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: `1.5px solid ${errors.phone ? '#ef4444' : 'var(--border-color)'}`, fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                  {errors.phone && <span style={{ fontSize: 11, color: '#ef4444', marginTop: 4, display: 'block' }}>{errors.phone}</span>}
                </div>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>هاتف إضافي</label>
                  <input value={form.phone2} onChange={e => setForm(f => ({ ...f, phone2: e.target.value }))}
                    dir="ltr" style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                </div>
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>البريد الإلكتروني</label>
                <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                  dir="ltr" style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: `1.5px solid ${errors.email ? '#ef4444' : 'var(--border-color)'}`, fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                {errors.email && <span style={{ fontSize: 11, color: '#ef4444', marginTop: 4, display: 'block' }}>{errors.email}</span>}
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>الشركة / المؤسسة</label>
                <input value={form.company} onChange={e => setForm(f => ({ ...f, company: e.target.value }))}
                  style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>المدينة</label>
                  <input value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))}
                    style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                </div>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>التصنيف</label>
                  <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as CustomerStatus }))}
                    style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', background: 'var(--surface)', boxSizing: 'border-box' }}>
                    <option value="active">نشط</option>
                    <option value="vip">VIP</option>
                    <option value="inactive">غير نشط</option>
                  </select>
                </div>
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>الحد الائتماني ($)</label>
                <input type="number" value={form.credit_limit_usd} onChange={e => setForm(f => ({ ...f, credit_limit_usd: e.target.value }))}
                  style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 16, outline: 'none', boxSizing: 'border-box' }} />
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>العنوان</label>
                <textarea value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
                  rows={2} style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', resize: 'none', boxSizing: 'border-box' }} />
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 6 }}>ملاحظات</label>
                <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                  rows={2} style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', resize: 'none', boxSizing: 'border-box' }} />
              </div>
            </div>
          </SheetBody>
          <SheetFooter>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={closeModal}
                style={{ flex: 1, padding: '13px', borderRadius: 12, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
                إلغاء
              </button>
              <button onClick={handleSave} disabled={!form.name.trim() || !form.phone.trim()}
                style={{
                  flex: 2, padding: '13px', borderRadius: 12, border: 'none',
                  background: !form.name.trim() || !form.phone.trim() ? 'var(--border-color)' : '#3b82f6',
                  color: '#fff', fontSize: 14, fontWeight: 700, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                }}>
                <CheckCircle size={15} /> {modal.mode === 'edit' ? 'حفظ التعديلات' : 'إضافة العميل'}
              </button>
            </div>
          </SheetFooter>
        </BottomSheetModal>
      )}

      {/* Detail Modal */}
      {modal?.mode === 'detail' && selectedCustomer && (
        <BottomSheetModal isOpen onClose={closeModal}>
          <SheetHeader onClose={closeModal}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 40, height: 40, borderRadius: 12,
                background: selectedCustomer.status === 'vip' ? 'linear-gradient(135deg,#f59e0b,#d97706)' : 'linear-gradient(135deg,#3b82f6,#2563eb)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800,
              }}>{selectedCustomer.name.charAt(0)}</div>
              <div>
                <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>{selectedCustomer.name}</div>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{selectedCustomer.company || 'عميل فردي'}</div>
              </div>
            </div>
          </SheetHeader>
          <SheetBody>
            {/* Contact info */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
              <InfoRow icon={<Phone size={14} />} label={selectedCustomer.phone} />
              {selectedCustomer.email && <InfoRow icon={<Mail size={14} />} label={selectedCustomer.email} />}
              {selectedCustomer.address && <InfoRow icon={<MapPin size={14} />} label={`${selectedCustomer.address}${selectedCustomer.city ? `, ${selectedCustomer.city}` : ''}`} />}
            </div>

            {/* Financial summary */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
              <div style={{ background: 'var(--surface-secondary)', borderRadius: 12, padding: 12 }}>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 4 }}>الحد الائتماني</div>
                <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--text-primary)' }}>{formatUSD(selectedCustomer.credit_limit_usd)}</div>
              </div>
              <div style={{ background: selectedCustomer.balance_usd > 0 ? '#fef2f2' : '#f0fdf4', borderRadius: 12, padding: 12 }}>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 4 }}>الرصيد المستحق</div>
                <div style={{ fontSize: 16, fontWeight: 800, color: selectedCustomer.balance_usd > 0 ? '#dc2626' : '#16a34a' }}>{formatUSD(selectedCustomer.balance_usd)}</div>
              </div>
            </div>
            {selectedCustomer.balance_usd > selectedCustomer.credit_limit_usd && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', background: '#fef2f2', borderRadius: 10, marginBottom: 16 }}>
                <AlertCircle size={14} color="#dc2626" />
                <span style={{ fontSize: 11, color: '#b91c1c', fontWeight: 600 }}>تجاوز العميل حد الائتمان المسموح</span>
              </div>
            )}

            {/* Order history */}
            <div style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
                <ShoppingBag size={14} color="var(--text-tertiary)" />
                <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)' }}>الطلبات ({customerOrders.length})</span>
                {customerReport.totalValue > 0 && (
                  <span style={{ fontSize: 11, fontWeight: 700, color: '#2563eb', marginInlineStart: 'auto' }}>{formatUSD(customerReport.totalValue)}</span>
                )}
              </div>
              {customerOrders.length === 0 ? (
                <p style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>لا توجد طلبات لهذا العميل</p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {customerOrders.slice(0, 5).map(o => (
                    <div key={o.id} onClick={() => navigate(`/orders/${o.id}`)}
                      style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 10px', background: 'var(--surface-secondary)', borderRadius: 10, cursor: 'pointer' }}>
                      <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{o.order_number}</span>
                      <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-primary)' }}>{formatUSD(o.total_usd)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Products bought — report */}
            {customerReport.topProducts.length > 0 && (
              <div style={{ marginBottom: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
                  <Package size={14} color="var(--text-tertiary)" />
                  <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)' }}>المنتجات الأكثر طلباً</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {customerReport.topProducts.slice(0, 6).map((p, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 10px', background: 'var(--surface-secondary)', borderRadius: 10 }}>
                      <span style={{ fontSize: 12, color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '55%' }}>{p.name}</span>
                      <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{p.qty} وحدة</span>
                      <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-primary)' }}>{formatUSD(p.total)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Monthly activity — report */}
            {customerReport.months.length > 0 && (
              <div style={{ marginBottom: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
                  <BarChart3 size={14} color="var(--text-tertiary)" />
                  <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)' }}>النشاط الشهري</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {customerReport.months.map((m) => (
                    <div key={m.month}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 }}>
                        <span style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{monthLabel(m.month)} • {m.orders} طلب</span>
                        <span style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--text-primary)' }}>{formatUSD(m.total)}</span>
                      </div>
                      <div style={{ height: 6, borderRadius: 99, background: 'var(--surface-secondary)', overflow: 'hidden' }}>
                        <div style={{ height: '100%', width: `${Math.round((m.total / customerReport.maxMonth) * 100)}%`, background: 'linear-gradient(90deg,#3b82f6,#2563eb)', borderRadius: 99 }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Invoice history */}
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
                <FileText size={14} color="var(--text-tertiary)" />
                <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)' }}>الفواتير ({customerInvoices.length})</span>
              </div>
              {customerInvoices.length === 0 ? (
                <p style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>لا توجد فواتير لهذا العميل</p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {customerInvoices.slice(0, 5).map(inv => (
                    <div key={inv.id} onClick={() => navigate(`/invoices/${inv.id}`)}
                      style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 10px', background: 'var(--surface-secondary)', borderRadius: 10, cursor: 'pointer' }}>
                      <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{inv.invoice_number}</span>
                      <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-primary)' }}>{formatUSD(inv.total_usd)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </SheetBody>
          <SheetFooter>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <button onClick={() => printCustomerStatement(selectedCustomer, customerOrders, customerInvoices, systemSettings.factoryName)}
                style={{ width: '100%', padding: '13px', borderRadius: 12, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <Printer size={14} /> طباعة كشف الحساب
              </button>
              {selectedCustomer.phone && selectedCustomer.balance_usd > 0 && (
                <button onClick={() => {
                  const ok = sendWhatsApp(selectedCustomer.phone, paymentReminderMessage({
                    factory: systemSettings.factoryName,
                    customerName: selectedCustomer.name,
                    amount: formatUSD(selectedCustomer.balance_usd),
                  }));
                  if (!ok) toast.error('رقم هاتف غير صالح');
                }}
                  style={{ width: '100%', padding: '13px', borderRadius: 12, border: 'none', background: '#25d366', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                  <MessageCircle size={14} /> تذكير دفع عبر واتساب
                </button>
              )}
              {canManage && (
                <div style={{ display: 'flex', gap: 10 }}>
                  <button onClick={() => { closeModal(); setTimeout(() => setDeleteConfirm(selectedCustomer.id), 100); }}
                    style={{ flex: 1, padding: '13px', borderRadius: 12, border: '1.5px solid #fecaca', background: '#fef2f2', color: '#dc2626', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                    <Trash2 size={14} /> حذف
                  </button>
                  <button onClick={() => { closeModal(); setTimeout(() => openEdit(selectedCustomer), 100); }}
                    style={{ flex: 2, padding: '13px', borderRadius: 12, border: 'none', background: '#3b82f6', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                    <Edit2 size={14} /> تعديل البيانات
                  </button>
                </div>
              )}
            </div>
          </SheetFooter>
        </BottomSheetModal>
      )}

      {/* Delete confirmation */}
      {deleteConfirm && (
        <CenterModal isOpen onClose={() => setDeleteConfirm(null)}>
          <div style={{ padding: 24, textAlign: 'center' }}>
            <div style={{ width: 56, height: 56, borderRadius: 16, background: '#fef2f2', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
              <Trash2 size={24} color="#dc2626" />
            </div>
            <h3 style={{ fontSize: 16, fontWeight: 800, color: 'var(--text-primary)', marginBottom: 8 }}>حذف العميل؟</h3>
            <p style={{ fontSize: 13, color: 'var(--text-tertiary)', marginBottom: 20 }}>سيتم حذف بيانات العميل نهائياً. لن يؤثر هذا على الطلبات أو الفواتير السابقة.</p>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setDeleteConfirm(null)}
                style={{ flex: 1, padding: '12px', borderRadius: 12, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
                إلغاء
              </button>
              <button onClick={() => { deleteCustomer(deleteConfirm); setDeleteConfirm(null); }}
                style={{ flex: 1, padding: '12px', borderRadius: 12, border: 'none', background: '#dc2626', color: '#fff', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>
                حذف نهائياً
              </button>
            </div>
          </div>
        </CenterModal>
      )}
    </div>
  );
}

const InfoRow: React.FC<{ icon: React.ReactNode; label: string }> = ({ icon, label }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--text-secondary)' }}>
    <span style={{ color: 'var(--text-tertiary)' }}>{icon}</span>
    <span dir="auto">{label}</span>
  </div>
);
