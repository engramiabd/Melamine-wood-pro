import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ChevronRight, Phone, MapPin, Calendar, Clock,
  Package, CheckCircle, XCircle, AlertTriangle,
  User, Factory, Edit, Printer, Share2,
  TrendingUp, FileText, ChevronLeft, Zap,
  Save, X, ChevronDown, Play, Pause, Star,
  MessageSquare, ArrowRight, Hash, BarChart2, DollarSign, MessageCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { useAuth } from '../contexts/AuthContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { Card, CardBody, CardHeader } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { useAppData } from '../contexts/AppDataContext';
import { resolveActorName } from '../lib/workers';
import { CenterModal, BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { OrderStatus } from '../types';
import { printOrder, shareOrder } from '../utils/print';
import { sendWhatsApp, orderStatusMessage } from '../utils/whatsapp';


import {
  STATUS_CONFIG, PRIORITY_DOT, PRIORITY_LABELS, PRIORITY_BG, STATUS_ORDER,
  ConfirmModal, AssignLineModal, QualityCheckModal, RecordPaymentModal, AddNoteModal,
} from './OrderDetail/OrderDetailModals';

// ── Main Component ──────────────────────────────────────────────────────────
export const OrderDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { format, exchangeRate } = useCurrency();
  const { getOrder, updateOrderStatus, updateOrderFields, productionLines, updateProductionLine, addNotification, orderPayments, addOrderPayment, systemSettings, employees, generateInvoiceFromOrder, invoices } = useAppData();

  const order = getOrder(id || '');

  const [confirmModal, setConfirmModal] = useState<{
    open: boolean; type: 'accept' | 'reject' | 'hold' | 'complete' | null;
  }>({ open: false, type: null });
  const [isActing, setIsActing] = useState(false);
  const [localStatus, setLocalStatus] = useState<OrderStatus | null>(null);
  const [showAssignLine, setShowAssignLine] = useState(false);
  const [showQualityCheck, setShowQualityCheck] = useState(false);
  const [showAddNote, setShowAddNote] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [localNotes, setLocalNotes] = useState(order?.notes || '');
  const [localLineId, setLocalLineId] = useState(order?.production_line_id || '');
  const [rejectNote, setRejectNote] = useState('');
  const [showItems, setShowItems] = useState(true);

  useEffect(() => {
    if (order) {
      setLocalNotes(order.notes || '');
      setLocalLineId(order.production_line_id || '');
    }
  }, [order]);

  if (!order) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-8 text-center" dir="rtl">
        <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-4">
          <Package size={32} className="text-gray-300" />
        </div>
        <h3 className="font-bold text-gray-700 mb-2">الطلب غير موجود</h3>
        <Button onClick={() => navigate('/orders')} variant="outline">العودة للطلبات</Button>
      </div>
    );
  }

  const currentStatus = localStatus || order.status;
  const sc = STATUS_CONFIG[currentStatus];
  const StatusIcon = sc.icon;
  const currentStatusIndex = STATUS_ORDER.indexOf(currentStatus);
  const productionLine = productionLines.find(l => l.id === (localLineId || order.production_line_id));

  const canManage = user?.role && ['admin', 'manager'].includes(user.role);
  const canSupervisor = user?.role && ['admin', 'manager', 'production_supervisor'].includes(user.role);

  const handleAction = async (type: 'accept' | 'reject' | 'hold' | 'complete') => {
    setIsActing(true);
    await new Promise(r => setTimeout(r, 800));
    const newStatus: OrderStatus = type === 'accept' ? 'in_production'
      : type === 'reject' ? 'cancelled'
        : type === 'hold' ? 'on_hold'
          : 'completed';
    setLocalStatus(newStatus);
    const note = type === 'reject' ? rejectNote : undefined;
    updateOrderStatus(order.id, newStatus, note);
    setConfirmModal({ open: false, type: null });
    setIsActing(false);
    setRejectNote('');
    const msgs = {
      accept: 'تم قبول الطلب وإدخاله في الإنتاج',
      reject: 'تم رفض الطلب',
      hold: 'تم إيقاف الطلب مؤقتاً',
      complete: 'تم إكمال الطلب بنجاح',
    };
    toast.success(msgs[type]);
  };

  const handleAssignLine = (lineId: string) => {
    setLocalLineId(lineId);
    updateOrderFields(order.id, { production_line_id: lineId });
    const line = productionLines.find(l => l.id === lineId);
    addNotification({
      title: 'تعيين خط إنتاج',
      message: `تم تعيين الطلب ${order.order_number} لـ ${line?.name}`,
      type: 'info',
      role_target: 'production_supervisor',
    });
    toast.success(`تم تعيين الطلب لـ ${line?.name}`);
  };

  const handleQualityPass = (notes: string) => {
    setLocalStatus('completed');
    updateOrderStatus(order.id, 'completed', notes || 'اجتاز فحص الجودة بنجاح');
    toast.success('تم اعتماد الجودة وإكمال الطلب');
  };

  const handleQualityFail = (notes: string) => {
    setLocalStatus('in_production');
    updateOrderStatus(order.id, 'in_production', `رُفض في فحص الجودة: ${notes}`);
    toast.error('تم إعادة الطلب للإنتاج');
  };

  const handleSaveNote = (notes: string) => {
    setLocalNotes(notes);
    updateOrderStatus(order.id, currentStatus, notes);
    toast.success('تم حفظ الملاحظة');
  };

  // Calculate days overdue / remaining
  const dueDate = order.due_date ? new Date(order.due_date) : null;
  const now = new Date();
  const daysRemaining = dueDate ? Math.ceil((dueDate.getTime() - now.getTime()) / 86400000) : null;
  const isOverdue = daysRemaining !== null && daysRemaining < 0 && currentStatus !== 'completed' && currentStatus !== 'cancelled';

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl" style={{ paddingBottom: 'var(--page-pb)' }}>
      {/* ── Hero Status Header ──────────────────────────────────── */}
      <div className={`bg-gradient-to-br ${sc.gradient} text-white px-4 pt-3 pb-8 relative overflow-hidden`}>
        {/* Decorative circles */}
        <div className="absolute -top-8 -left-8 w-32 h-32 rounded-full bg-white/10" />
        <div className="absolute top-12 -right-6 w-20 h-20 rounded-full bg-white/5" />

        {/* Nav */}
        <div className="flex items-center gap-3 mb-5 relative z-10">
          <button
            onClick={() => navigate('/orders')}
            className="w-9 h-9 bg-white/15 backdrop-blur-sm rounded-xl flex items-center justify-center"
          >
            <ChevronRight size={18} />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="font-black text-white text-sm">{order.order_number}</h1>
            <p className="text-white/70 text-xs">
              {new Date(order.created_at).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              className="w-9 h-9 bg-white/15 rounded-xl flex items-center justify-center"
              onClick={() => { printOrder(order, exchangeRate); toast.success('جاري فتح نافذة الطباعة...'); }}
            >
              <Printer size={15} />
            </button>
            <button
              className="w-9 h-9 bg-white/15 rounded-xl flex items-center justify-center"
              onClick={() => { shareOrder(order); toast.success('تم نسخ بيانات الطلب'); }}
            >
              <Share2 size={15} />
            </button>
            {order.customer_phone && (
              <button
                className="w-9 h-9 bg-white/15 rounded-xl flex items-center justify-center"
                aria-label="إبلاغ العميل عبر واتساب"
                onClick={() => {
                  const ok = sendWhatsApp(order.customer_phone || '', orderStatusMessage({
                    factory: systemSettings.factoryName,
                    customerName: order.customer_name,
                    orderNumber: order.order_number,
                    status: currentStatus,
                  }));
                  if (ok) toast.success('جارٍ فتح واتساب…'); else toast.error('رقم هاتف غير صالح');
                }}
              >
                <MessageCircle size={15} />
              </button>
            )}
          </div>
        </div>

        {/* Status + Priority */}
        <div className="relative z-10 flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-white/15 backdrop-blur-sm rounded-2xl flex items-center justify-center">
            <StatusIcon size={22} className="text-white" />
          </div>
          <div className="flex-1">
            <p className="text-white/70 text-xs">الحالة</p>
            <p className="text-white font-black text-base leading-tight">{sc.label}</p>
          </div>
          <div className={`px-3 py-1.5 rounded-full text-xs font-bold ${PRIORITY_BG[order.priority]}`}>
            {PRIORITY_LABELS[order.priority]}
          </div>
        </div>

        {/* Amount + Due Date */}
        <div className="relative z-10 bg-white/10 backdrop-blur-sm rounded-2xl p-4 grid grid-cols-2 gap-4">
          <div>
            <p className="text-white/60 text-[11px] mb-1">إجمالي الطلب</p>
            <p className="text-xl font-black text-white">{format(order.total_usd, order.total_syp)}</p>
            <p className="text-white/50 text-[10px]">
              {order.total_syp.toLocaleString('ar-SY')} ل.س
            </p>
          </div>
          <div className="text-left">
            <p className="text-white/60 text-[11px] mb-1">تاريخ التسليم</p>
            {dueDate ? (
              <>
                <p className="text-sm font-bold text-white">
                  {dueDate.toLocaleDateString('ar-SY', { month: 'short', day: 'numeric' })}
                </p>
                <p className={`text-[11px] font-semibold ${isOverdue ? 'text-red-200' : daysRemaining! <= 2 ? 'text-amber-200' : 'text-white/60'}`}>
                  {isOverdue ? `متأخر ${Math.abs(daysRemaining!)} يوم` : daysRemaining === 0 ? 'اليوم' : `بعد ${daysRemaining} يوم`}
                </p>
              </>
            ) : (
              <p className="text-sm text-white/40">غير محدد</p>
            )}
          </div>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* ── Payment Status ────────────────────────────────────── */}
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
              <div className="w-7 h-7 bg-emerald-100 rounded-lg flex items-center justify-center">
                <DollarSign size={13} className="text-emerald-600" />
              </div>
              حالة الدفع
            </h3>
            <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
              order.payment_status === 'paid' ? 'bg-emerald-50 text-emerald-600' :
              order.payment_status === 'partial' ? 'bg-amber-50 text-amber-600' :
              'bg-red-50 text-red-600'
            }`}>
              {order.payment_status === 'paid' ? 'مدفوع بالكامل' : order.payment_status === 'partial' ? 'مدفوع جزئياً' : 'غير مدفوع'}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div className="bg-gray-50 rounded-xl p-3">
              <p className="text-[11px] text-gray-400 mb-1">المدفوع</p>
              <p className="text-sm font-black text-emerald-600">{format(order.paid_usd, order.paid_usd * exchangeRate)}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-3">
              <p className="text-[11px] text-gray-400 mb-1">المتبقي</p>
              <p className={`text-sm font-black ${order.total_usd - order.paid_usd > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                {format(order.total_usd - order.paid_usd, (order.total_usd - order.paid_usd) * exchangeRate)}
              </p>
            </div>
          </div>
          {orderPayments.filter(p => p.order_id === order.id).length > 0 && (
            <div className="space-y-1.5 mb-3">
              {orderPayments.filter(p => p.order_id === order.id).slice(0, 3).map(p => (
                <div key={p.id} className="flex items-center justify-between text-xs px-3 py-2 bg-gray-50 rounded-lg">
                  <span className="text-gray-500">{new Date(p.date).toLocaleDateString('ar-SY')}</span>
                  <span className="font-bold text-gray-700">${p.amount_usd.toFixed(2)}</span>
                </div>
              ))}
            </div>
          )}
          {order.payment_status !== 'paid' && (
            <button onClick={() => setShowPayment(true)}
              className="w-full py-3 rounded-xl bg-emerald-600 text-white text-sm font-bold flex items-center justify-center gap-2 active:scale-[0.98] transition-transform">
              <DollarSign size={15} /> تسجيل دفعة
            </button>
          )}
        </div>

        {/* ── Timeline ──────────────────────────────────────────── */}
        {currentStatus !== 'cancelled' && currentStatus !== 'on_hold' && (
          <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-800 text-sm mb-4 flex items-center gap-2">
              <div className="w-7 h-7 bg-blue-100 rounded-lg flex items-center justify-center">
                <TrendingUp size={13} className="text-blue-600" />
              </div>
              خط زمني الطلب
            </h3>
            <div className="relative">
              <div className="absolute right-4 top-5 bottom-5 w-0.5 bg-gray-100" />
              <div className="space-y-4">
                {timeline.map((t, i) => {
                  const done = i <= currentStatusIndex;
                  const active = i === currentStatusIndex;
                  const TIcon = t.icon;
                  return (
                    <motion.div
                      key={t.key}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.08 }}
                      className="flex items-center gap-4 relative"
                    >
                      <div className={`relative z-10 w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                        done
                          ? active ? 'bg-blue-600 shadow-md shadow-blue-200' : 'bg-emerald-500'
                          : 'bg-gray-100'
                      }`}>
                        {done && !active
                          ? <CheckCircle size={16} className="text-white" />
                          : <TIcon size={15} className={done ? 'text-white' : 'text-gray-400'} />
                        }
                        {active && (
                          <span className="absolute inset-0 rounded-xl animate-ping bg-blue-400 opacity-30" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className={`text-sm font-bold leading-tight ${
                          done ? active ? 'text-blue-600' : 'text-emerald-600' : 'text-gray-400'
                        }`}>{t.label}</p>
                        <p className={`text-[11px] ${active ? 'text-blue-400' : 'text-gray-400'}`}>
                          {active ? 'الآن' : done ? 'مكتمل' : t.sub}
                        </p>
                      </div>
                      {active && (
                        <motion.div
                          animate={{ scale: [1, 1.3, 1] }}
                          transition={{ repeat: Infinity, duration: 1.8 }}
                          className="w-2.5 h-2.5 bg-blue-500 rounded-full"
                        />
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ── Customer Info ──────────────────────────────────────── */}
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-800 text-sm mb-3 flex items-center gap-2">
            <div className="w-7 h-7 bg-indigo-100 rounded-lg flex items-center justify-center">
              <User size={13} className="text-indigo-600" />
            </div>
            بيانات العميل
          </h3>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-2xl flex items-center justify-center shrink-0">
                <span className="text-white font-black text-lg">{order.customer_name.charAt(0)}</span>
              </div>
              <div>
                <p className="font-black text-gray-900">{order.customer_name}</p>
                <p className="text-xs text-gray-500">رقم الطلب: {order.order_number}</p>
              </div>
            </div>
            {order.customer_phone && (
              <a href={`tel:${order.customer_phone}`}
                className="flex items-center gap-3 bg-emerald-50 rounded-2xl p-3 transition-colors">
                <div className="w-9 h-9 bg-emerald-100 rounded-xl flex items-center justify-center shrink-0">
                  <Phone size={15} className="text-emerald-600" />
                </div>
                <div>
                  <p className="text-[11px] text-gray-500">رقم الهاتف</p>
                  <p className="font-semibold text-gray-900 text-sm" dir="ltr">{order.customer_phone}</p>
                </div>
                <ChevronLeft size={14} className="text-gray-400 mr-auto" />
              </a>
            )}
            {order.customer_address && (
              <div className="flex items-center gap-3 bg-gray-50 rounded-2xl p-3">
                <div className="w-9 h-9 bg-blue-100 rounded-xl flex items-center justify-center shrink-0">
                  <MapPin size={15} className="text-blue-600" />
                </div>
                <div>
                  <p className="text-[11px] text-gray-500">العنوان</p>
                  <p className="font-medium text-gray-900 text-sm">{order.customer_address}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ── Products List ─────────────────────────────────────── */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
          <button
            onClick={() => setShowItems(!showItems)}
            className="w-full p-4 flex items-center justify-between"
          >
            <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
              <div className="w-7 h-7 bg-amber-100 rounded-lg flex items-center justify-center">
                <Package size={13} className="text-amber-600" />
              </div>
              المنتجات ({order.items.length})
            </h3>
            <ChevronDown
              size={16}
              className={`text-gray-400 transition-transform ${showItems ? 'rotate-180' : ''}`}
            />
          </button>

          <AnimatePresence>
            {showItems && (
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: 'auto' }}
                exit={{ height: 0 }}
                className="overflow-hidden"
              >
                <div className="px-4 pb-4 space-y-3">
                  {order.items.map((item, idx) => {
                    const product = item.product;
                    return (
                      <div key={item.id} className="bg-gray-50 rounded-2xl p-3">
                        <div className="flex items-start gap-3">
                          <div className="w-9 h-9 bg-blue-100 rounded-xl flex items-center justify-center shrink-0">
                            <span className="text-blue-700 font-black text-sm">{idx + 1}</span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-gray-900 leading-tight">
                              {product?.name || `منتج ${item.product_id}`}
                            </p>
                            {product && (
                              <p className="text-[11px] text-gray-500 mt-0.5">
                                {product.thickness} · {product.size} · {product.finish} · {product.color}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-2 mt-3">
                          <div className="bg-white rounded-xl p-2 text-center">
                            <p className="text-[10px] text-gray-500">الكمية</p>
                            <p className="text-sm font-black text-gray-900">{item.quantity}</p>
                          </div>
                          <div className="bg-white rounded-xl p-2 text-center">
                            <p className="text-[10px] text-gray-500">سعر الوحدة</p>
                            <p className="text-xs font-bold text-gray-900">{format(item.unit_price_usd, item.unit_price_syp)}</p>
                          </div>
                          <div className="bg-blue-50 rounded-xl p-2 text-center">
                            <p className="text-[10px] text-blue-600">الإجمالي</p>
                            <p className="text-xs font-black text-blue-800">{format(item.total_usd, item.total_syp)}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {/* Total Summary */}
                  <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl p-4">
                    <div className="flex items-center justify-between">
                      <p className="text-white/80 text-sm font-semibold">إجمالي الطلب</p>
                      <div className="text-left">
                        <p className="text-xl font-black text-white">{format(order.total_usd, order.total_syp)}</p>
                        <p className="text-white/60 text-[11px]">{order.total_syp.toLocaleString('ar-SY')} ل.س</p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ── Production Line ───────────────────────────────────── */}
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
              <div className="w-7 h-7 bg-emerald-100 rounded-lg flex items-center justify-center">
                <Factory size={13} className="text-emerald-600" />
              </div>
              خط الإنتاج
            </h3>
            {canSupervisor && currentStatus !== 'completed' && currentStatus !== 'cancelled' && (
              <button
                onClick={() => setShowAssignLine(true)}
                className="flex items-center gap-1.5 text-xs text-blue-600 font-semibold bg-blue-50 px-3 py-1.5 rounded-xl"
              >
                <Edit size={11} />
                {productionLine ? 'تغيير' : 'تعيين'}
              </button>
            )}
          </div>

          {productionLine ? (
            <div className={`rounded-2xl p-4 ${
              productionLine.status === 'active' ? 'bg-emerald-50 border border-emerald-200' :
              productionLine.status === 'stopped' ? 'bg-red-50 border border-red-200' :
              'bg-gray-50 border border-gray-200'
            }`}>
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  productionLine.status === 'active' ? 'bg-emerald-100' : 'bg-gray-100'
                }`}>
                  <Factory size={18} className={productionLine.status === 'active' ? 'text-emerald-600' : 'text-gray-400'} />
                </div>
                <div className="flex-1">
                  <p className="font-bold text-gray-900 text-sm">{productionLine.name}</p>
                  <p className="text-xs text-gray-500">{productionLine.code}</p>
                </div>
                <span className={`text-xs px-2.5 py-1 rounded-full font-bold ${
                  productionLine.status === 'active' ? 'bg-emerald-100 text-emerald-700' :
                  productionLine.status === 'stopped' ? 'bg-red-100 text-red-700' :
                  'bg-gray-100 text-gray-500'
                }`}>
                  {productionLine.status === 'active' ? 'يعمل' : productionLine.status === 'stopped' ? 'متوقف' : 'خامل'}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-white/70 rounded-xl p-2 text-center">
                  <p className="text-[10px] text-gray-500">الكفاءة</p>
                  <p className="text-sm font-black text-gray-900">{productionLine.efficiency_percentage}%</p>
                </div>
                <div className="bg-white/70 rounded-xl p-2 text-center">
                  <p className="text-[10px] text-gray-500">أُنتج اليوم</p>
                  <p className="text-sm font-black text-gray-900">{productionLine.total_produced_today}</p>
                </div>
                <div className="bg-white/70 rounded-xl p-2 text-center">
                  <p className="text-[10px] text-gray-500">الطاقة/يوم</p>
                  <p className="text-sm font-black text-gray-900">{productionLine.capacity_per_day}</p>
                </div>
              </div>
            </div>
          ) : (
            <button
              onClick={() => canSupervisor && setShowAssignLine(true)}
              className="w-full py-6 border-2 border-dashed border-gray-200 rounded-2xl flex flex-col items-center gap-2 text-gray-400 hover:border-blue-300 hover:text-blue-400 transition-colors"
            >
              <Factory size={24} />
              <p className="text-sm font-medium">لم يُعيَّن خط إنتاج بعد</p>
              {canSupervisor && <p className="text-xs">اضغط لتعيين خط إنتاج</p>}
            </button>
          )}
        </div>

        {/* ── Notes Section ─────────────────────────────────────── */}
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800 text-sm flex items-center gap-2">
              <div className="w-7 h-7 bg-violet-100 rounded-lg flex items-center justify-center">
                <MessageSquare size={13} className="text-violet-600" />
              </div>
              الملاحظات
            </h3>
            {canManage && (
              <button
                onClick={() => setShowAddNote(true)}
                className="flex items-center gap-1.5 text-xs text-violet-600 font-semibold bg-violet-50 px-3 py-1.5 rounded-xl"
              >
                <Edit size={11} />
                تعديل
              </button>
            )}
          </div>
          {localNotes ? (
            <p className="text-sm text-gray-700 leading-relaxed bg-gray-50 rounded-2xl p-3">{localNotes}</p>
          ) : (
            <p className="text-sm text-gray-400 text-center py-4">لا توجد ملاحظات</p>
          )}
        </div>

        {/* ── Order Meta ───────────────────────────────────────── */}
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-800 text-sm mb-3 flex items-center gap-2">
            <div className="w-7 h-7 bg-slate-100 rounded-lg flex items-center justify-center">
              <Hash size={13} className="text-slate-600" />
            </div>
            معلومات الطلب
          </h3>
          <div className="space-y-2">
            {[
              { label: 'رقم الطلب', value: order.order_number, icon: Hash },
              { label: 'أنشأ الطلب', value: resolveActorName(order.created_by), icon: User },
              { label: 'تاريخ الإنشاء', value: new Date(order.created_at).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }), icon: Calendar },
              ...(order.accepted_by ? [{ label: 'قبِل الطلب', value: `${resolveActorName(order.accepted_by)}${order.accepted_at ? ' • ' + new Date(order.accepted_at).toLocaleDateString('ar-SY', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''}`, icon: User }] : []),
              { label: 'آخر تحديث', value: new Date(order.updated_at).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }), icon: Clock },
              ...(order.due_date ? [{ label: 'تاريخ التسليم', value: new Date(order.due_date).toLocaleDateString('ar-SY', { year: 'numeric', month: 'long', day: 'numeric' }), icon: Calendar }] : []),
            ].map((row, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-2">
                  <row.icon size={13} className="text-gray-400" />
                  <p className="text-xs text-gray-500">{row.label}</p>
                </div>
                <p className="text-xs font-semibold text-gray-800">{row.value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── Action Buttons ────────────────────────────────────── */}
        {canManage && (
          <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100 space-y-3">
            <h3 className="font-bold text-gray-800 text-sm mb-3">الإجراءات المتاحة</h3>

            {currentStatus === 'pending' && (
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="success"
                  fullWidth
                  leftIcon={<CheckCircle size={15} />}
                  onClick={() => setConfirmModal({ open: true, type: 'accept' })}
                >
                  قبول الطلب
                </Button>
                <Button
                  variant="danger"
                  fullWidth
                  leftIcon={<XCircle size={15} />}
                  onClick={() => setConfirmModal({ open: true, type: 'reject' })}
                >
                  رفض الطلب
                </Button>
              </div>
            )}

            {currentStatus === 'in_production' && (
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="primary"
                  fullWidth
                  leftIcon={<Star size={15} />}
                  onClick={() => setShowQualityCheck(true)}
                >
                  مراجعة الجودة
                </Button>
                <Button
                  variant="warning"
                  fullWidth
                  leftIcon={<Pause size={15} />}
                  onClick={() => setConfirmModal({ open: true, type: 'hold' })}
                >
                  إيقاف مؤقت
                </Button>
              </div>
            )}

            {currentStatus === 'quality_check' && (
              <div className="grid grid-cols-1 gap-3">
                <Button
                  variant="success"
                  fullWidth
                  leftIcon={<CheckCircle size={15} />}
                  onClick={() => setShowQualityCheck(true)}
                >
                  إدخال نتيجة الجودة
                </Button>
              </div>
            )}

            {currentStatus === 'on_hold' && (
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="primary"
                  fullWidth
                  leftIcon={<Play size={15} />}
                  onClick={() => {
                    setLocalStatus('in_production');
                    updateOrderStatus(order.id, 'in_production');
                    toast.success('تم استئناف الطلب');
                  }}
                >
                  استئناف الطلب
                </Button>
                <Button
                  variant="danger"
                  fullWidth
                  leftIcon={<XCircle size={15} />}
                  onClick={() => setConfirmModal({ open: true, type: 'reject' })}
                >
                  إلغاء الطلب
                </Button>
              </div>
            )}

            {(currentStatus === 'completed' || currentStatus === 'cancelled') && (
              <div className="flex items-center gap-3 bg-gray-50 rounded-2xl p-4">
                <StatusIcon size={20} className={currentStatus === 'completed' ? 'text-emerald-500' : 'text-red-500'} />
                <p className="text-sm text-gray-600">
                  {currentStatus === 'completed' ? 'تم إكمال هذا الطلب بنجاح' : 'تم إلغاء هذا الطلب'}
                </p>
              </div>
            )}

            {/* Invoicing is a separate, deliberate step — a production order does
                not imply a sale. Offer it only once the order is completed. */}
            {currentStatus === 'completed' && (() => {
              const existing = invoices.find(inv => inv.order_id === order.id);
              return existing ? (
                <Button
                  variant="outline"
                  fullWidth
                  leftIcon={<FileText size={15} />}
                  onClick={() => navigate('/invoices')}
                >
                  عرض الفاتورة {existing.invoice_number}
                </Button>
              ) : (
                <Button
                  variant="primary"
                  fullWidth
                  leftIcon={<FileText size={15} />}
                  onClick={() => {
                    const inv = generateInvoiceFromOrder(order);
                    if (inv) { toast.success(`تم إصدار الفاتورة ${inv.invoice_number}`); navigate('/invoices'); }
                    else toast.error('تعذّر إصدار الفاتورة');
                  }}
                >
                  إصدار فاتورة لهذا الطلب
                </Button>
              );
            })()}
          </div>
        )}
      </div>

      {/* ── Confirm Modals ──────────────────────────────────────── */}
      <ConfirmModal
        open={confirmModal.open && confirmModal.type === 'accept'}
        title="قبول الطلب"
        message={`هل تريد قبول الطلب ${order.order_number} وإدخاله في الإنتاج؟`}
        confirmLabel="نعم، قبول الطلب"
        confirmVariant="success"
        onConfirm={() => handleAction('accept')}
        onCancel={() => setConfirmModal({ open: false, type: null })}
        isLoading={isActing}
      />

      <ConfirmModal
        open={confirmModal.open && confirmModal.type === 'reject'}
        title="رفض الطلب"
        message={`هل تريد رفض الطلب ${order.order_number}؟`}
        confirmLabel="نعم، رفض الطلب"
        confirmVariant="danger"
        onConfirm={() => handleAction('reject')}
        onCancel={() => setConfirmModal({ open: false, type: null })}
        isLoading={isActing}
      >
        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1.5">سبب الرفض (اختياري)</label>
          <textarea
            value={rejectNote}
            onChange={e => setRejectNote(e.target.value)}
            rows={2}
            placeholder="أدخل سبب الرفض..."
            className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-red-500"
          />
        </div>
      </ConfirmModal>

      <ConfirmModal
        open={confirmModal.open && confirmModal.type === 'hold'}
        title="إيقاف الطلب مؤقتاً"
        message="هل تريد إيقاف هذا الطلب مؤقتاً؟ يمكنك استئنافه لاحقاً."
        confirmLabel="إيقاف مؤقت"
        confirmVariant="danger"
        onConfirm={() => handleAction('hold')}
        onCancel={() => setConfirmModal({ open: false, type: null })}
        isLoading={isActing}
      />

      {/* ── Assign Line Modal ──────────────────────────────────── */}
      <AssignLineModal
        open={showAssignLine}
        currentLineId={localLineId}
        lines={productionLines}
        onSave={handleAssignLine}
        onClose={() => setShowAssignLine(false)}
      />

      {/* ── Quality Check Modal ────────────────────────────────── */}
      <QualityCheckModal
        open={showQualityCheck}
        onPass={handleQualityPass}
        onFail={handleQualityFail}
        onClose={() => setShowQualityCheck(false)}
      />

      {/* ── Add Note Modal ─────────────────────────────────────── */}
      <AddNoteModal
        open={showAddNote}
        currentNotes={localNotes}
        onSave={handleSaveNote}
        onClose={() => setShowAddNote(false)}
      />

      {/* ── Record Payment Modal ───────────────────────────────── */}
      <RecordPaymentModal
        open={showPayment}
        remainingUsd={order.total_usd - order.paid_usd}
        exchangeRate={exchangeRate}
        onSave={(amountUsd, method) => {
          addOrderPayment({
            order_id: order.id,
            amount_usd: amountUsd,
            amount_syp: amountUsd * exchangeRate,
            method, date: new Date().toISOString(),
          });
        }}
        onClose={() => setShowPayment(false)}
      />
    </div>
  );
};

export default React.memo(OrderDetailPage);
