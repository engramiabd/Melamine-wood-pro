import React, { useState, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppData } from '../contexts/AppDataContext';
import { EmptyState } from '../components/ui/EmptyState';
import { useCurrency } from '../contexts/CurrencyContext';
import { useAuth } from '../contexts/AuthContext';
import {
  Package, AlertTriangle, TrendingDown, Plus,
  Search, Grid3X3, List,
  Edit2, Trash2, ShoppingCart, ArrowDownLeft,
  X, BarChart2, Download,
  Info, DollarSign, Eye, Warehouse
} from 'lucide-react';
import { WarehousesPanel } from './WarehousesPanel';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';
import { exportToCSV } from '../utils/print';
import {
  ViewMode, FilterStatus, ModalMode, TransactionEntry,
  CATEGORIES, UNITS, CATEGORY_COLORS, getStatus, STATUS_CONFIG,
  AnimNum, CircleProgress, StockBar,
} from '../components/inventory/shared';
import { TxModal } from '../components/inventory/TxModal';
import { DetailModal } from '../components/inventory/DetailModal';
import { AddEditModal } from '../components/inventory/AddEditModal';
import type { InventoryFormState } from '../components/inventory/AddEditModal';

// ── InventoryPage ──────────────────────────────────────────────────────────
export default function InventoryPage() {
  const { inventoryItems, addInventoryTransaction, addInventoryItem, updateInventoryItem, deleteInventoryItem, addNotification } = useAppData();
  const { format, formatUSD, formatSYP, exchangeRate } = useCurrency();
  const { user, hasRole } = useAuth();
  const isAdmin = hasRole('admin') || hasRole('manager');

  const [view, setView] = useState<ViewMode>('cards');
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('الكل');
  const [statusFilter, setStatusFilter] = useState<FilterStatus>('all');
  const [sortBy, setSortBy] = useState<'name' | 'qty' | 'value' | 'status'>('status');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [modal, setModal] = useState<{ mode: ModalMode; itemId: string } | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  // form states
  const [txQty, setTxQty] = useState('');
  const [txPrice, setTxPrice] = useState('');
  const [txNote, setTxNote] = useState('');
  const [txSupplier, setTxSupplier] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // add/edit form
  const [form, setForm] = useState<InventoryFormState>({
    name: '', unit: 'كغ', category: 'مواد أساسية',
    stock_quantity: '', reorder_level: '', max_quantity: '',
    current_price: '', supplier: '', storage_location: '', description: '',
  });

  const fileRef = useRef<HTMLInputElement>(null);

  // ── computed ──────────────────────────────────────────────────────────────
  const items = useMemo(() => {
    let list = [...inventoryItems];
    if (search) list = list.filter(i => i.name.includes(search));
    if (category !== 'الكل') list = list.filter(i => (i as any).category === category);
    if (statusFilter !== 'all') list = list.filter(i => getStatus(i.stock_quantity, i.reorder_level) === statusFilter);
    list.sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'qty') return b.stock_quantity - a.stock_quantity;
      if (sortBy === 'value') return (b.stock_quantity * b.current_price) - (a.stock_quantity * a.current_price);
      // status: critical first
      const order = { critical: 0, low: 1, good: 2 };
      return order[getStatus(a.stock_quantity, a.reorder_level)] - order[getStatus(b.stock_quantity, b.reorder_level)];
    });
    return list;
  }, [inventoryItems, search, category, statusFilter, sortBy]);

  const stats = useMemo(() => ({
    total: inventoryItems.length,
    good: inventoryItems.filter(i => getStatus(i.stock_quantity, i.reorder_level) === 'good').length,
    low: inventoryItems.filter(i => getStatus(i.stock_quantity, i.reorder_level) === 'low').length,
    critical: inventoryItems.filter(i => getStatus(i.stock_quantity, i.reorder_level) === 'critical').length,
    totalValue: inventoryItems.reduce((s, i) => s + i.stock_quantity * i.current_price, 0),
  }), [inventoryItems]);

  const selectedItem = modal ? inventoryItems.find(i => i.id === modal.itemId) : null;

  // category chart data
  const categoryData = useMemo(() => {
    const map: Record<string, { total: number; value: number }> = {};
    inventoryItems.forEach(i => {
      const cat = (i as any).category || 'أخرى';
      if (!map[cat]) map[cat] = { total: 0, value: 0 };
      map[cat].total += i.stock_quantity;
      map[cat].value += i.stock_quantity * i.current_price;
    });
    return Object.entries(map).map(([cat, d]) => ({ cat, ...d }));
  }, [inventoryItems]);

  const top5ByValue = useMemo(() =>
    [...inventoryItems].sort((a, b) => (b.stock_quantity * b.current_price) - (a.stock_quantity * a.current_price)).slice(0, 5),
    [inventoryItems]);

  // ── handlers ──────────────────────────────────────────────────────────────
  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(''), 2500);
  };

  const closeModal = () => {
    setModal(null);
    setTxQty(''); setTxPrice(''); setTxNote(''); setTxSupplier('');
    setForm({ name: '', unit: 'كغ', category: 'مواد أساسية', stock_quantity: '', reorder_level: '', max_quantity: '', current_price: '', supplier: '', storage_location: '', description: '' });
  };

  const handleTransaction = async () => {
    if (!modal || !selectedItem) return;
    const qty = parseFloat(txQty);
    if (!qty || qty <= 0) return;
    if (modal.mode === 'use' && qty > selectedItem.stock_quantity) return;
    setIsSaving(true);
    await new Promise(r => setTimeout(r, 600));
    addInventoryTransaction(selectedItem.id, modal.mode === 'buy' ? 'in' : 'out', qty, parseFloat(txPrice) || selectedItem.current_price, txNote || (modal.mode === 'buy' ? 'شراء مواد' : 'صرف للإنتاج'));
    addNotification({ type: modal.mode === 'buy' ? 'success' : 'info', title: modal.mode === 'buy' ? 'تم الشراء' : 'تم الصرف', message: `${qty} ${selectedItem.unit} ${modal.mode === 'buy' ? 'مضافة لـ' : 'مصروفة من'} ${selectedItem.name}`, role_target: 'all' });
    setIsSaving(false);
    closeModal();
    showSuccess(modal.mode === 'buy' ? `✓ تم إضافة ${qty} ${selectedItem.unit} بنجاح` : `✓ تم صرف ${qty} ${selectedItem.unit} بنجاح`);
  };

  const handleAddItem = async () => {
    if (!form.name || !form.stock_quantity) return;
    setIsSaving(true);
    await new Promise(r => setTimeout(r, 600));
    addInventoryItem({
      name: form.name, unit: form.unit,
      stock_quantity: parseFloat(form.stock_quantity) || 0,
      reorder_level: parseFloat(form.reorder_level) || 10,
      max_quantity: parseFloat(form.max_quantity) || 100,
      current_price: parseFloat(form.current_price) || 0,
      category: form.category, supplier: form.supplier,
      storage_location: form.storage_location, description: form.description,
    } as any);
    addNotification({ type: 'success', title: 'مادة جديدة', message: `تم إضافة ${form.name} للمخزون`, role_target: 'all' });
    setIsSaving(false);
    closeModal();
    showSuccess(`✓ تم إضافة ${form.name} بنجاح`);
  };

  const handleEditItem = async () => {
    if (!modal || !selectedItem) return;
    setIsSaving(true);
    await new Promise(r => setTimeout(r, 600));
    updateInventoryItem(selectedItem.id, {
      name: form.name || selectedItem.name,
      reorder_level: parseFloat(form.reorder_level) || selectedItem.reorder_level,
      max_quantity: parseFloat(form.max_quantity) || selectedItem.max_quantity,
      current_price: parseFloat(form.current_price) || selectedItem.current_price,
    } as any);
    setIsSaving(false);
    closeModal();
    showSuccess('✓ تم تحديث البيانات بنجاح');
  };

  const handleDelete = (id: string) => {
    if (!window.confirm('هل أنت متأكد من حذف هذه المادة؟')) return;
    deleteInventoryItem(id);
    showSuccess('✓ تم حذف المادة');
  };

  const openEdit = (itemId: string) => {
    const item = inventoryItems.find(i => i.id === itemId);
    if (!item) return;
    setForm({
      name: item.name, unit: item.unit,
      stock_quantity: String(item.stock_quantity),
      reorder_level: String(item.reorder_level),
      max_quantity: String(item.max_quantity),
      current_price: String(item.current_price),
      supplier: (item as any).supplier || '',
      storage_location: (item as any).storage_location || '',
      description: (item as any).description || '',
      category: (item as any).category || 'مواد أساسية',
    });
    setModal({ mode: 'edit', itemId });
  };

  const handleExport = () => {
    exportToCSV(inventoryItems.map(i => ({
      الاسم: i.name, الوحدة: i.unit, الكمية: i.stock_quantity,
      'حد إعادة الطلب': i.reorder_level, 'الكمية القصوى': i.max_quantity,
      'السعر الحالي $': i.current_price, 'القيمة الإجمالية $': (i.stock_quantity * i.current_price).toFixed(2),
      الحالة: STATUS_CONFIG[getStatus(i.stock_quantity, i.reorder_level)].label,
    })), 'inventory');
  };

  // ── CARD ──────────────────────────────────────────────────────────────────
  const InventoryCard = ({ item }: { item: typeof inventoryItems[0] }) => {
    const status = getStatus(item.stock_quantity, item.reorder_level);
    const cfg = STATUS_CONFIG[status];
    const pct = item.max_quantity > 0 ? Math.min((item.stock_quantity / item.max_quantity) * 100, 100) : 0;
    const value = item.stock_quantity * item.current_price;
    const isExpanded = expandedId === item.id;

    return (
      <motion.div layout initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
        style={{
          background: 'var(--surface)', borderRadius: 16, border: '1px solid var(--border-color)',
          boxShadow: '0 1px 4px rgba(0,0,0,0.06)', overflow: 'hidden',
          borderTop: `3px solid ${cfg.color}`,
        }}>
        {/* Header */}
        <div style={{ padding: '14px 14px 10px' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
            {/* Icon */}
            <div style={{
              width: 44, height: 44, borderRadius: 12, flexShrink: 0,
              background: `${cfg.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Package size={20} color={cfg.color} />
            </div>
            {/* Info */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)' }}>{item.name}</span>
                <span style={{
                  fontSize: 10, fontWeight: 600, padding: '1px 6px', borderRadius: 99,
                  background: cfg.bg, color: cfg.text, border: `1px solid ${cfg.border}`,
                  flexShrink: 0,
                }}>
                  {status === 'critical' && <span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: cfg.color, marginLeft: 3, animation: 'ping 1s infinite' }} />}
                  {cfg.label}
                </span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>
                  {(item as any).category || 'مواد'} • {item.unit}
                </span>
              </div>
            </div>
            {/* Circle Progress */}
            <div style={{ position: 'relative', flexShrink: 0 }}>
              <CircleProgress pct={pct} color={cfg.color} size={48} />
              <div style={{
                position: 'absolute', inset: 0, display: 'flex',
                alignItems: 'center', justifyContent: 'center',
                fontSize: 9, fontWeight: 700, color: cfg.color,
              }}>
                {Math.round(pct)}%
              </div>
            </div>
          </div>

          {/* Stock bar */}
          <div style={{ marginTop: 10 }}>
            <StockBar qty={item.stock_quantity} reorder={item.reorder_level} max={item.max_quantity} />
          </div>

          {/* KPIs */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 10 }}>
            {[
              { label: 'الحالي', value: `${item.stock_quantity.toFixed(1)} ${item.unit}`, color: cfg.color },
              { label: 'حد الطلب', value: `${item.reorder_level} ${item.unit}`, color: 'var(--text-tertiary)' },
              { label: 'القيمة', value: formatUSD(value), color: '#3b82f6' },
            ].map(kpi => (
              <div key={kpi.label} style={{
                background: 'var(--surface-secondary)', borderRadius: 10, padding: '6px 8px', textAlign: 'center',
              }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: kpi.color }}>{kpi.value}</div>
                <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginTop: 1 }}>{kpi.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div style={{
          display: 'flex', gap: 6, padding: '0 14px 12px',
          borderTop: '1px solid var(--surface-secondary)', paddingTop: 10,
        }}>
          {isAdmin && (<>
          <button onClick={() => setModal({ mode: 'buy', itemId: item.id })}
            style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
              padding: '7px 0', borderRadius: 10, border: 'none', cursor: 'pointer',
              background: '#f0fdf4', color: '#15803d', fontSize: 12, fontWeight: 600,
            }}>
            <ShoppingCart size={13} /> شراء
          </button>
          <button onClick={() => setModal({ mode: 'use', itemId: item.id })}
            style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
              padding: '7px 0', borderRadius: 10, border: 'none', cursor: 'pointer',
              background: '#fff7ed', color: '#c2410c', fontSize: 12, fontWeight: 600,
            }}>
            <ArrowDownLeft size={13} /> صرف
          </button>
          </>)}
          <button onClick={() => setModal({ mode: 'detail', itemId: item.id })}
            style={{
              width: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
              borderRadius: 10, border: 'none', cursor: 'pointer',
              background: '#eff6ff', color: '#2563eb',
            }}>
            <Eye size={14} />
          </button>
          {isAdmin && (
            <button onClick={() => openEdit(item.id)}
              style={{
                width: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
                borderRadius: 10, border: 'none', cursor: 'pointer',
                background: 'var(--surface-secondary)', color: 'var(--text-secondary)',
              }}>
              <Edit2 size={14} />
            </button>
          )}
          {isAdmin && (
            <button onClick={() => handleDelete(item.id)}
              style={{
                width: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
                borderRadius: 10, border: 'none', cursor: 'pointer',
                background: '#fef2f2', color: '#dc2626',
              }}>
              <Trash2 size={14} />
            </button>
          )}
        </div>
      </motion.div>
    );
  };

  // ── TABLE ROW ─────────────────────────────────────────────────────────────
  const TableRow = ({ item }: { item: typeof inventoryItems[0] }) => {
    const status = getStatus(item.stock_quantity, item.reorder_level);
    const cfg = STATUS_CONFIG[status];
    const pct = item.max_quantity > 0 ? Math.min((item.stock_quantity / item.max_quantity) * 100, 100) : 0;
    return (
      <tr style={{ borderBottom: '1px solid var(--border-color)' }}
        onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface-secondary)')}
        onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
        <td style={{ padding: '10px 12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: cfg.color, flexShrink: 0 }} />
            <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{item.name}</span>
          </div>
        </td>
        <td style={{ padding: '10px 12px', fontSize: 12, color: 'var(--text-tertiary)', textAlign: 'center' }}>
          {(item as any).category || '—'}
        </td>
        <td style={{ padding: '10px 12px', textAlign: 'center' }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
            <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>
              {item.stock_quantity.toFixed(1)} {item.unit}
            </span>
            <div style={{ width: 80 }}>
              <StockBar qty={item.stock_quantity} reorder={item.reorder_level} max={item.max_quantity} />
            </div>
          </div>
        </td>
        <td style={{ padding: '10px 12px', textAlign: 'center' }}>
          <span style={{
            fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 99,
            background: cfg.bg, color: cfg.text, border: `1px solid ${cfg.border}`,
          }}>{cfg.label}</span>
        </td>
        <td style={{ padding: '10px 12px', fontSize: 12, color: '#3b82f6', textAlign: 'center', fontWeight: 600 }}>
          {formatUSD(item.stock_quantity * item.current_price)}
        </td>
        <td style={{ padding: '10px 12px' }}>
          <div style={{ display: 'flex', gap: 4, justifyContent: 'center' }}>
            {isAdmin && (<>
            <button onClick={() => setModal({ mode: 'buy', itemId: item.id })}
              style={{ padding: '4px 8px', borderRadius: 6, border: 'none', background: '#f0fdf4', color: '#15803d', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>
              شراء
            </button>
            <button onClick={() => setModal({ mode: 'use', itemId: item.id })}
              style={{ padding: '4px 8px', borderRadius: 6, border: 'none', background: '#fff7ed', color: '#c2410c', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>
              صرف
            </button>
            </>)}
            <button onClick={() => setModal({ mode: 'detail', itemId: item.id })}
              style={{ padding: '4px 8px', borderRadius: 6, border: 'none', background: '#eff6ff', color: '#2563eb', fontSize: 11, cursor: 'pointer' }}>
              <Eye size={12} />
            </button>
          </div>
        </td>
      </tr>
    );
  };

  // ── ANALYTICS ─────────────────────────────────────────────────────────────
  const Analytics = () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {[
          { label: 'إجمالي المواد', value: stats.total, color: '#3b82f6', icon: <Package size={16} /> },
          { label: 'القيمة الإجمالية', value: formatUSD(stats.totalValue), color: '#10b981', icon: <DollarSign size={16} /> },
          { label: 'مواد منخفضة', value: stats.low, color: '#f59e0b', icon: <TrendingDown size={16} /> },
          { label: 'مواد حرجة', value: stats.critical, color: '#ef4444', icon: <AlertTriangle size={16} /> },
        ].map(s => (
          <div key={s.label} style={{
            background: 'var(--surface)', borderRadius: 14, padding: '14px', border: '1px solid var(--border-color)',
            boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <div style={{ width: 32, height: 32, borderRadius: 10, background: `${s.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: s.color }}>
                {s.icon}
              </div>
              <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{s.label}</span>
            </div>
            <div style={{ fontSize: 20, fontWeight: 800, color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Stock levels bar chart */}
      <div style={{ background: 'var(--surface)', borderRadius: 16, padding: 16, border: '1px solid var(--border-color)' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 12 }}>أعلى 5 مواد بالقيمة</div>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={top5ByValue.map(i => ({ name: i.name.slice(0, 8), value: +(i.stock_quantity * i.current_price).toFixed(0), qty: i.stock_quantity }))}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
            <XAxis dataKey="name" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 10 }} />
            <Tooltip formatter={(v: number) => formatUSD(v)} />
            <Bar dataKey="value" fill="#3b82f6" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Category distribution */}
      <div style={{ background: 'var(--surface)', borderRadius: 16, padding: 16, border: '1px solid var(--border-color)' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 12 }}>توزيع المخزون حسب الفئة</div>
        <ResponsiveContainer width="100%" height={180}>
          <PieChart>
              <Pie data={categoryData} dataKey="value" nameKey="cat" cx="50%" cy="50%" outerRadius={70} label={({ name, percent }: any) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}>
              {categoryData.map((_, i) => (
                <Cell key={i} fill={Object.values(CATEGORY_COLORS)[i % Object.values(CATEGORY_COLORS).length]} />
              ))}
            </Pie>
            <Tooltip formatter={(v: number) => formatUSD(v)} />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Stock health overview */}
      <div style={{ background: 'var(--surface)', borderRadius: 16, padding: 16, border: '1px solid var(--border-color)' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 12 }}>صحة المخزون</div>
        {[
          { label: 'مواد جيدة', count: stats.good, color: '#22c55e', pct: (stats.good / stats.total) * 100 },
          { label: 'مواد منخفضة', count: stats.low, color: '#f59e0b', pct: (stats.low / stats.total) * 100 },
          { label: 'مواد حرجة', count: stats.critical, color: '#ef4444', pct: (stats.critical / stats.total) * 100 },
        ].map(row => (
          <div key={row.label} style={{ marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{row.label}</span>
              <span style={{ fontSize: 12, fontWeight: 700, color: row.color }}>{row.count} مادة</span>
            </div>
            <div style={{ height: 8, background: 'var(--border-color)', borderRadius: 99, overflow: 'hidden' }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${row.pct}%` }} transition={{ duration: 0.8 }}
                style={{ height: '100%', background: row.color, borderRadius: 99 }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // ── RENDER ────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: '100%', background: 'var(--surface-secondary)' }}>
      {/* Success toast */}
      <AnimatePresence>
        {successMsg && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
            style={{
              position: 'fixed', top: 70, left: '50%', transform: 'translateX(-50%)',
              background: '#0f172a', color: '#fff', padding: '10px 20px', borderRadius: 99,
              fontSize: 13, fontWeight: 600, zIndex: 300, whiteSpace: 'nowrap',
              boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
            }}>
            {successMsg}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Alerts */}
      {stats.critical > 0 && (
        <div style={{ margin: '0 0 0 0', padding: '10px 16px', background: '#fef2f2', borderBottom: '1px solid #fecaca', display: 'flex', alignItems: 'center', gap: 8 }}>
          <AlertTriangle size={14} color="#ef4444" />
          <span style={{ fontSize: 12, color: '#b91c1c', fontWeight: 600 }}>
            {stats.critical} مادة بمستوى حرج تحتاج شراء فوري
          </span>
        </div>
      )}
      {stats.low > 0 && stats.critical === 0 && (
        <div style={{ padding: '10px 16px', background: '#fffbeb', borderBottom: '1px solid #fde68a', display: 'flex', alignItems: 'center', gap: 8 }}>
          <AlertTriangle size={14} color="#f59e0b" />
          <span style={{ fontSize: 12, color: '#b45309', fontWeight: 600 }}>
            {stats.low} مادة بمستوى منخفض — يُنصح بالشراء قريباً
          </span>
        </div>
      )}

      {/* Header */}
      <div style={{ padding: '16px 16px 0' }}>
        {/* KPIs */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
          {[
            { label: 'إجمالي المواد', value: stats.total, sub: `${stats.good} جيدة`, color: '#3b82f6', icon: <Package size={18} /> },
            { label: 'القيمة الإجمالية', value: formatUSD(stats.totalValue), sub: formatSYP(stats.totalValue * exchangeRate), color: '#10b981', icon: <DollarSign size={18} /> },
            { label: 'مواد منخفضة', value: stats.low, sub: 'تحتاج انتباه', color: '#f59e0b', icon: <TrendingDown size={18} /> },
            { label: 'مواد حرجة', value: stats.critical, sub: 'شراء فوري', color: '#ef4444', icon: <AlertTriangle size={18} /> },
          ].map((kpi, i) => (
            <motion.div key={kpi.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
              style={{ background: 'var(--surface)', borderRadius: 14, padding: '12px 14px', border: '1px solid var(--border-color)', boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                <div style={{ width: 32, height: 32, borderRadius: 10, background: `${kpi.color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: kpi.color, flexShrink: 0 }}>
                  {kpi.icon}
                </div>
                <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{kpi.label}</span>
              </div>
              <div style={{ fontSize: 18, fontWeight: 800, color: kpi.color }}>{kpi.value}</div>
              <div style={{ fontSize: 10, color: 'var(--text-tertiary)', marginTop: 2 }}>{kpi.sub}</div>
            </motion.div>
          ))}
        </div>

        {/* Search */}
        <div style={{ position: 'relative', marginBottom: 10 }}>
          <Search size={15} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)', pointerEvents: 'none' }} />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="بحث في المواد..."
            style={{ width: '100%', padding: '11px 40px 11px 40px', borderRadius: 12, border: '1.5px solid var(--border-color)', fontSize: 14, outline: 'none', boxSizing: 'border-box', background: 'var(--surface)' }} />
          {search && (
            <button onClick={() => setSearch('')}
              style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)', padding: 2 }}>
              <X size={14} />
            </button>
          )}
        </div>

        {/* Toolbar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14, overflowX: 'auto' }}>
          {/* Category filter pills */}
          <div style={{ display: 'flex', gap: 6, flex: 1, overflowX: 'auto' }}>
            {CATEGORIES.map(cat => (
              <button key={cat} onClick={() => setCategory(cat)}
                style={{
                  padding: '6px 12px', borderRadius: 99, border: 'none', cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0,
                  background: category === cat ? '#3b82f6' : 'var(--border-color)',
                  color: category === cat ? 'var(--surface)' : 'var(--text-tertiary)',
                  fontSize: 12, fontWeight: 600,
                }}>
                {cat}
              </button>
            ))}
          </div>

          {/* View toggle */}
          <div style={{ display: 'flex', background: 'var(--border-color)', borderRadius: 10, padding: 3, flexShrink: 0 }}>
            {([['cards', <Grid3X3 size={14} />], ['table', <List size={14} />], ['analytics', <BarChart2 size={14} />], ['warehouses', <Warehouse size={14} />]] as const).map(([v, icon]) => (
              <button key={v} onClick={() => setView(v as ViewMode)}
                style={{
                  width: 32, height: 32, borderRadius: 8, border: 'none', cursor: 'pointer',
                  background: view === v ? 'var(--surface)' : 'transparent',
                  color: view === v ? '#3b82f6' : 'var(--text-tertiary)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: view === v ? '0 1px 4px rgba(0,0,0,0.12)' : 'none',
                }}>
                {icon}
              </button>
            ))}
          </div>

          {/* Actions */}
          <button onClick={handleExport}
            style={{ width: 36, height: 36, borderRadius: 10, border: '1.5px solid var(--border-color)', background: 'var(--surface)', color: 'var(--text-tertiary)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Download size={15} />
          </button>
        </div>

        {/* Status filter */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 14, overflowX: 'auto' }}>
          {([
            ['all', 'الكل', '#3b82f6'],
            ['good', 'جيد', '#22c55e'],
            ['low', 'منخفض', '#f59e0b'],
            ['critical', 'حرج', '#ef4444'],
          ] as const).map(([s, label, color]) => {
            const count = s === 'all' ? stats.total : stats[s as keyof typeof stats] as number;
            return (
              <button key={s} onClick={() => setStatusFilter(s as FilterStatus)}
                style={{
                  padding: '5px 12px', borderRadius: 99, border: 'none', cursor: 'pointer', flexShrink: 0,
                  background: statusFilter === s ? color : 'var(--border-color)',
                  color: statusFilter === s ? 'var(--surface)' : 'var(--text-tertiary)',
                  fontSize: 12, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4,
                }}>
                {label}
                <span style={{ fontSize: 11, background: statusFilter === s ? 'rgba(255,255,255,0.3)' : 'var(--border-color)', padding: '0 5px', borderRadius: 99 }}>
                  {count}
                </span>
              </button>
            );
          })}
          {/* Sort */}
          <select value={sortBy} onChange={e => setSortBy(e.target.value as any)}
            style={{ marginRight: 'auto', padding: '5px 10px', borderRadius: 99, border: '1.5px solid var(--border-color)', background: 'var(--surface)', fontSize: 12, color: 'var(--text-secondary)', outline: 'none', cursor: 'pointer', flexShrink: 0 }}>
            <option value="status">ترتيب: الحالة</option>
            <option value="name">ترتيب: الاسم</option>
            <option value="qty">ترتيب: الكمية</option>
            <option value="value">ترتيب: القيمة</option>
          </select>
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: '0 16px', paddingBottom: 'var(--page-pb)' }}>
        {view === 'cards' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 12 }}>
            <AnimatePresence>
              {items.map(item => <InventoryCard key={item.id} item={item} />)}
            </AnimatePresence>
            {items.length === 0 && (
              <div style={{ gridColumn: '1/-1' }}>
                <EmptyState icon={Package} title="لا توجد مواد" description="جرّب تعديل الفلتر أو البحث." />
              </div>
            )}
          </div>
        )}

        {view === 'table' && (
          <div style={{ background: 'var(--surface)', borderRadius: 16, border: '1px solid var(--border-color)', overflow: 'hidden' }}>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 600 }}>
                <thead>
                  <tr style={{ background: 'var(--surface-secondary)', borderBottom: '1px solid var(--border-color)' }}>
                    {['المادة', 'الفئة', 'الكمية', 'الحالة', 'القيمة', 'إجراءات'].map(h => (
                      <th key={h} style={{ padding: '10px 12px', fontSize: 12, fontWeight: 600, color: 'var(--text-tertiary)', textAlign: h === 'إجراءات' || h === 'القيمة' || h === 'الحالة' ? 'center' : 'right' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {items.map(item => <TableRow key={item.id} item={item} />)}
                </tbody>
              </table>
            </div>
            {items.length === 0 && (
              <EmptyState compact icon={Package} title="لا توجد مواد مطابقة" />
            )}
          </div>
        )}

        {view === 'analytics' && <Analytics />}

        {view === 'warehouses' && (
          <div style={{ padding: '0 16px' }}>
            <WarehousesPanel />
          </div>
        )}
      </div>

      {/* FAB */}
      {isAdmin && (
        <button onClick={() => setModal({ mode: 'add', itemId: '' })}
          style={{
            position: 'fixed', left: 20, bottom: `calc(var(--bottomnav-h) + var(--sab) + 16px)`,
            width: 52, height: 52, borderRadius: '50%',
            background: 'linear-gradient(135deg,#3b82f6,#2563eb)',
            color: '#fff', border: 'none', cursor: 'pointer', zIndex: 30,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 20px rgba(37,99,235,0.4)',
          }}>
          <Plus size={22} />
        </button>
      )}

      {/* Modals */}
      {modal && selectedItem && (modal.mode === 'buy' || modal.mode === 'use') && (
        <TxModal
          modal={modal} selectedItem={selectedItem}
          txQty={txQty} setTxQty={setTxQty}
          txPrice={txPrice} setTxPrice={setTxPrice}
          txNote={txNote} setTxNote={setTxNote}
          isSaving={isSaving} exchangeRate={exchangeRate}
          formatUSD={formatUSD} formatSYP={formatSYP}
          onClose={closeModal} onConfirm={handleTransaction}
        />
      )}
      {modal && selectedItem && modal.mode === 'detail' && (
        <DetailModal
          selectedItem={selectedItem} isAdmin={isAdmin} formatUSD={formatUSD}
          onClose={closeModal} onOpenModal={setModal} onOpenEdit={openEdit}
        />
      )}
      {modal && (modal.mode === 'add' || modal.mode === 'edit') && (
        <AddEditModal
          modal={modal} form={form} setForm={setForm} isSaving={isSaving}
          onClose={closeModal} onSubmit={modal.mode === 'edit' ? handleEditItem : handleAddItem}
        />
      )}
    </div>
  );
}
