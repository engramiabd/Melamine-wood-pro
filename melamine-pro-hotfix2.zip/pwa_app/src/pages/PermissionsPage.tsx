import React, { useState } from 'react';
import { ShieldCheck, RotateCcw } from 'lucide-react';
import { useAppData } from '../contexts/AppDataContext';
import { PERMISSION_GROUPS, DEFAULT_ROLE_PERMISSIONS } from '../lib/permissions';
import type { UserRole } from '../types';

const ROLE_LABELS: Record<UserRole, string> = {
  admin: 'مدير النظام',
  manager: 'مدير',
  production_supervisor: 'مشرف إنتاج',
  worker: 'عامل',
  accountant: 'محاسب',
  hr: 'موارد بشرية',
};

const ROLES = Object.keys(ROLE_LABELS) as UserRole[];

export const PermissionsPage: React.FC = () => {
  const { rolePermissions, toggleRolePermission, resetRolePermissions } = useAppData();
  const [role, setRole] = useState<UserRole>('manager');
  const [confirmReset, setConfirmReset] = useState(false);

  const granted = rolePermissions[role] || DEFAULT_ROLE_PERMISSIONS[role] || [];
  const has = (key: string) => granted.includes(key);
  const isAdmin = role === 'admin';
  const totalKeys = PERMISSION_GROUPS.reduce((s, g) => s + g.perms.length, 0);
  const grantedCount = isAdmin ? totalKeys : granted.length;

  return (
    <div className="min-h-full bg-gray-50 pb-24" dir="rtl">
      {/* Hero */}
      <div className="bg-gradient-to-br from-rose-600 to-red-700 px-5 pt-6 pb-8 text-white">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center">
            <ShieldCheck size={22} />
          </div>
          <div>
            <h1 className="text-lg font-extrabold">الصلاحيات الدقيقة</h1>
            <p className="text-xs text-white/70">تحكّم بما يستطيع كل دور فعله</p>
          </div>
        </div>
      </div>

      {/* Role selector */}
      <div className="px-4 -mt-4">
        <div className="bg-white rounded-2xl shadow-sm p-2 flex gap-1.5 overflow-x-auto">
          {ROLES.map((r) => (
            <button
              key={r}
              onClick={() => setRole(r)}
              className={`shrink-0 px-3 py-2 rounded-xl text-xs font-bold transition ${role === r ? 'bg-rose-600 text-white' : 'bg-gray-50 text-gray-500'}`}
            >
              {ROLE_LABELS[r]}
            </button>
          ))}
        </div>
      </div>

      {/* Granted count */}
      <div className="px-4 mt-3">
        <p className="text-xs text-gray-500 text-center">
          الدور «{ROLE_LABELS[role]}» يملك <span className="font-bold text-gray-700">{grantedCount}</span> من {totalKeys} صلاحية
        </p>
      </div>

      {isAdmin && (
        <div className="px-4 mt-4">
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 text-amber-800 text-xs">
            مدير النظام يملك جميع الصلاحيات بشكل دائم ولا يمكن تقييده.
          </div>
        </div>
      )}

      {/* Permission groups */}
      <div className="px-4 mt-4 space-y-3">
        {PERMISSION_GROUPS.map((g) => (
          <div key={g.group} className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="px-4 py-2.5 bg-gray-50 text-xs font-bold text-gray-500">{g.group}</div>
            <div className="divide-y divide-gray-50">
              {g.perms.map((p) => {
                const checked = isAdmin || has(p.key);
                return (
                  <label key={p.key} className={`flex items-center justify-between px-4 py-3 ${isAdmin ? 'opacity-60' : 'cursor-pointer'}`}>
                    <span className="text-sm text-gray-700">{p.label}</span>
                    <button
                      type="button"
                      disabled={isAdmin}
                      onClick={() => !isAdmin && toggleRolePermission(role, p.key, !has(p.key))}
                      className={`w-11 h-6 rounded-full transition relative ${checked ? 'bg-emerald-500' : 'bg-gray-300'}`}
                    >
                      <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-all ${checked ? 'right-0.5' : 'right-[22px]'}`} />
                    </button>
                  </label>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Reset */}
      <div className="px-4 mt-5">
        {confirmReset ? (
          <div className="bg-white border border-rose-200 rounded-2xl p-3 space-y-2">
            <p className="text-xs text-gray-600 text-center">سيُعاد ضبط صلاحيات كل الأدوار إلى الافتراضي. متابعة؟</p>
            <div className="flex gap-2">
              <button onClick={() => setConfirmReset(false)}
                className="flex-1 bg-gray-100 text-gray-600 rounded-xl py-2.5 font-bold text-sm">إلغاء</button>
              <button onClick={() => { resetRolePermissions(); setConfirmReset(false); }}
                className="flex-1 bg-rose-600 text-white rounded-xl py-2.5 font-bold text-sm">تأكيد إعادة الضبط</button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setConfirmReset(true)}
            className="w-full bg-white border border-gray-200 text-gray-600 rounded-2xl py-3 font-bold text-sm flex items-center justify-center gap-2"
          >
            <RotateCcw size={16} /> إعادة الضبط الافتراضي لكل الأدوار
          </button>
        )}
      </div>
    </div>
  );
};

export default PermissionsPage;
