import React, { useState, useMemo } from 'react';
import {
  CheckCircle, XCircle, Clock, AlertTriangle,
  MapPin, Calendar, TrendingUp, ChevronDown,
  Download, RefreshCw, Search,
  Users, UserCheck, UserX, Timer, Activity,
  Wifi, Shield,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip,
  CartesianGrid, LineChart, Line,
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppData } from '../contexts/AppDataContext';
import { printAttendance, exportCSV } from '../utils/print';

const WORKER_NAMES: Record<string, string> = {
  'demo-admin-001':      'أحمد المدير',
  'demo-manager-002':    'محمد المشرف',
  'demo-supervisor-003': 'خالد المراقب',
  'demo-worker-004':     'علي العامل',
  'demo-accountant-005': 'سمر المحاسبة',
  'demo-hr-006':         'ريم الموارد البشرية',
};

const WORKER_ROLES: Record<string, string> = {
  'demo-admin-001':      'مدير عام',
  'demo-manager-002':    'مدير إنتاج',
  'demo-supervisor-003': 'مشرف إنتاج',
  'demo-worker-004':     'عامل إنتاج',
  'demo-accountant-005': 'محاسب',
  'demo-hr-006':         'موارد بشرية',
};

const WORKER_AVATARS: Record<string, string> = {
  'demo-admin-001':      'from-red-500 to-rose-600',
  'demo-manager-002':    'from-blue-500 to-indigo-600',
  'demo-supervisor-003': 'from-emerald-500 to-teal-600',
  'demo-worker-004':     'from-amber-500 to-orange-600',
  'demo-accountant-005': 'from-purple-500 to-violet-600',
  'demo-hr-006':         'from-pink-500 to-rose-500',
};

const STATUS_CONFIG = {
  present:  { label: 'حاضر',  bg: 'bg-emerald-50', border: 'border-emerald-200', text: 'text-emerald-700', dot: 'bg-emerald-500', icon: UserCheck,  gradient: 'from-emerald-500 to-teal-500'     },
  absent:   { label: 'غائب',  bg: 'bg-red-50',     border: 'border-red-200',     text: 'text-red-700',     dot: 'bg-red-500',     icon: UserX,      gradient: 'from-red-500 to-rose-500'         },
  late:     { label: 'متأخر', bg: 'bg-amber-50',   border: 'border-amber-200',   text: 'text-amber-700',   dot: 'bg-amber-500',   icon: Timer,      gradient: 'from-amber-500 to-orange-500'     },
  on_leave: { label: 'إجازة', bg: 'bg-blue-50',    border: 'border-blue-200',    text: 'text-blue-700',    dot: 'bg-blue-500',    icon: Calendar,   gradient: 'from-blue-500 to-indigo-500'      },
};

const DAYS_AR = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; name: string; color: string }>; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-gray-900/95 backdrop-blur-md text-white text-xs rounded-xl px-3 py-2 shadow-xl border border-white/10" dir="rtl">
      <p className="font-bold text-gray-300 mb-1">{label}</p>
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-gray-400">{p.name}:</span>
          <span className="font-bold">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export const AttendanceDashboardPage: React.FC = () => {
  const { attendanceRecords, employees, leaveRequests } = useAppData();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  // Today's records
  const todayRecords = useMemo(() =>
    attendanceRecords.filter(r => r.date === todayStr),
  [attendanceRecords, todayStr]);

  // Build employee status list
  const employeeStatusList = useMemo(() => {
    const onLeaveIds = leaveRequests
      .filter(l => l.status === 'approved' && l.start_date <= todayStr && l.end_date >= todayStr)
      .map(l => l.employee_id);

    return employees.map(emp => {
      const record = todayRecords.find(r => r.worker_id === emp.user_id);
      const isOnLeave = onLeaveIds.includes(emp.id);
      let status: 'present' | 'absent' | 'late' | 'on_leave' = 'absent';
      if (isOnLeave) status = 'on_leave';
      else if (record) status = record.status as 'present' | 'late';

      const checkIn  = record?.check_in  ? (record.check_in.includes('T')  ? record.check_in.split('T')[1]?.slice(0,5)  : record.check_in)  : null;
      const checkOut = record?.check_out ? (record.check_out.includes('T') ? record.check_out.split('T')[1]?.slice(0,5) : record.check_out) : null;

      let hoursWorked = '—';
      if (checkIn && checkOut) {
        const [ih, im] = checkIn.split(':').map(Number);
        const [oh, om] = checkOut.split(':').map(Number);
        const mins = (oh * 60 + om) - (ih * 60 + im);
        hoursWorked = `${Math.floor(mins / 60)}:${String(mins % 60).padStart(2, '0')}`;
      } else if (checkIn) {
        hoursWorked = 'جاري العمل';
      }

      return {
        id: emp.user_id,
        empId: emp.id,
        name: WORKER_NAMES[emp.user_id] || `موظف ${emp.id}`,
        role: WORKER_ROLES[emp.user_id] || emp.position || 'موظف',
        avatar: WORKER_AVATARS[emp.user_id] || 'from-gray-500 to-gray-600',
        status,
        checkIn,
        checkOut,
        hoursWorked,
        lat: record?.location_lat || null,
        lng: record?.location_lng || null,
        location: record ? 'داخل النطاق' : isOnLeave ? 'إجازة' : 'غير مسجل',
      };
    });
  }, [employees, todayRecords, leaveRequests, todayStr]);

  // Summary counts
  const summary = useMemo(() => {
    const present  = employeeStatusList.filter(e => e.status === 'present').length;
    const absent   = employeeStatusList.filter(e => e.status === 'absent').length;
    const late     = employeeStatusList.filter(e => e.status === 'late').length;
    const on_leave = employeeStatusList.filter(e => e.status === 'on_leave').length;
    const total    = employeeStatusList.length || 1;
    const rate     = Math.round(((present + late) / total) * 100);
    return { present, absent, late, on_leave, total, rate };
  }, [employeeStatusList]);

  // Weekly chart data — last 7 days
  const weeklyData = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      const ds = d.toISOString().split('T')[0];
      const dayRecs = attendanceRecords.filter(r => r.date === ds);
      const present = dayRecs.filter(r => r.status === 'present').length;
      const late    = dayRecs.filter(r => r.status === 'late').length;
      const absent  = Math.max(0, employees.length - present - late);
      return {
        day: i === 6 ? 'اليوم' : DAYS_AR[d.getDay()],
        present: present + late,
        absent,
        late,
      };
    });
  }, [attendanceRecords, employees]);

  // Monthly trend — last 4 weeks
  const monthlyTrend = useMemo(() => {
    return Array.from({ length: 4 }, (_, i) => {
      const weekStart = new Date();
      weekStart.setDate(weekStart.getDate() - (3 - i) * 7);
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      const ws = weekStart.toISOString().split('T')[0];
      const we = weekEnd.toISOString().split('T')[0];
      const weekRecs = attendanceRecords.filter(r => r.date >= ws && r.date <= we);
      const expectedDays = employees.length * 7;
      const rate = expectedDays > 0 ? Math.round((weekRecs.length / expectedDays) * 100) : 85;
      return { week: `الأسبوع ${i + 1}`, rate: Math.min(100, rate || [95, 88, 92, 85][i]) };
    });
  }, [attendanceRecords, employees]);

  // Filtered list
  const filteredList = useMemo(() => {
    let list = employeeStatusList;
    if (filterStatus !== 'all') list = list.filter(e => e.status === filterStatus);
    if (searchQuery) list = list.filter(e =>
      e.name.includes(searchQuery) || e.role.includes(searchQuery)
    );
    return list;
  }, [employeeStatusList, filterStatus, searchQuery]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    if (navigator.vibrate) navigator.vibrate(10);
    setTimeout(() => setIsRefreshing(false), 1200);
  };

  const handleExport = () => {
    exportCSV(
      employeeStatusList.map(e => ({
        'الاسم': e.name, 'الدور': e.role,
        'الحالة': STATUS_CONFIG[e.status]?.label || e.status,
        'دخول': e.checkIn || '—', 'خروج': e.checkOut || '—',
        'ساعات العمل': e.hoursWorked,
      })),
      `attendance-${todayStr}`
    );
  };

  const handlePrint = () => {
    printAttendance(attendanceRecords.filter(r => r.date === todayStr), todayStr);
  };

  const circumference = 2 * Math.PI * 42;
  const dashOffset = circumference * (1 - summary.rate / 100);

  return (
    <div className="page-wrapper" dir="rtl">

      {/* ── Hero ─────────────────────────────────────────────────────────────── */}
      <div className="relative bg-gradient-to-br from-slate-800 via-slate-900 to-gray-950 overflow-hidden mb-4 mx-4 rounded-3xl">
        <div className="absolute inset-0 opacity-[0.06]" style={{
          backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.5) 1px, transparent 0)',
          backgroundSize: '20px 20px',
        }} />
        <div className="absolute top-4 left-4 w-32 h-32 rounded-full bg-blue-500/10 blur-2xl" />

        <div className="relative p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-white font-black text-lg">لوحة الحضور</h1>
              <p className="text-slate-400 text-[12px] mt-0.5">
                {new Date().toLocaleDateString('ar-SY', { weekday: 'long', day: 'numeric', month: 'long' })}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={handlePrint}
                className="w-9 h-9 bg-white/10 rounded-xl flex items-center justify-center text-white border border-white/15"
                title="طباعة">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              </button>
              <button onClick={handleExport}
                className="w-9 h-9 bg-white/10 rounded-xl flex items-center justify-center text-white border border-white/15"
                title="تصدير CSV">
                <Download size={15} />
              </button>
              <button onClick={handleRefresh}
                className="w-9 h-9 bg-white/10 rounded-xl flex items-center justify-center text-white border border-white/15">
                <RefreshCw size={15} className={isRefreshing ? 'animate-spin' : ''} />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-5">
            {/* Circular progress */}
            <div className="relative w-24 h-24 flex-shrink-0">
              <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="8" />
                <circle cx="50" cy="50" r="42" fill="none" stroke="#10b981" strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={dashOffset}
                  style={{ transition: 'stroke-dashoffset 1s ease' }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-white font-black text-xl tabular-nums">{summary.rate}%</span>
                <span className="text-slate-400 text-[9px]">الحضور</span>
              </div>
            </div>

            {/* KPI pills */}
            <div className="flex-1 grid grid-cols-2 gap-2">
              {[
                { label: 'حاضر',  value: summary.present,  icon: UserCheck, color: 'text-emerald-400', key: 'present'  },
                { label: 'غائب',  value: summary.absent,   icon: UserX,     color: 'text-red-400',     key: 'absent'   },
                { label: 'متأخر', value: summary.late,     icon: Timer,     color: 'text-amber-400',   key: 'late'     },
                { label: 'إجازة', value: summary.on_leave, icon: Calendar,  color: 'text-blue-400',    key: 'on_leave' },
              ].map(({ label, value, icon: Icon, color, key }) => (
                <button key={key}
                  onClick={() => setFilterStatus(f => f === key ? 'all' : key)}
                  className={`flex items-center gap-1.5 bg-white/10 rounded-xl px-2.5 py-2 border transition-all ${filterStatus === key ? 'border-white/40 bg-white/20' : 'border-white/10'}`}
                >
                  <Icon size={13} className={color} />
                  <div className="text-right">
                    <p className="text-white font-black text-sm leading-none">{value}</p>
                    <p className="text-slate-400 text-[9px]">{label}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Indicators */}
          <div className="flex items-center gap-3 mt-4 text-[11px]">
            <span className="flex items-center gap-1 text-slate-400"><Activity size={11} className="text-blue-400" /> مباشر</span>
            <span className="flex items-center gap-1 text-slate-400"><Wifi size={11} className="text-emerald-400" /> {summary.present + summary.late} حاضر</span>
            <span className="flex items-center gap-1 text-slate-400"><Shield size={11} className="text-violet-400" /> {summary.total} إجمالي</span>
          </div>
        </div>
      </div>

      {/* ── Charts ───────────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 px-4 mb-4">
        {/* Weekly Bar Chart */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 bg-blue-500 rounded-xl flex items-center justify-center">
              <TrendingUp size={13} className="text-white" />
            </div>
            <h3 className="font-bold text-gray-800 text-[13px]">حضور الأسبوع</h3>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <BarChart data={weeklyData} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
              <XAxis dataKey="day" tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="present" name="حاضر" fill="#10b981" radius={[3,3,0,0]} maxBarSize={20} />
              <Bar dataKey="absent"  name="غائب"  fill="#ef4444" radius={[3,3,0,0]} maxBarSize={20} />
              <Bar dataKey="late"    name="متأخر"  fill="#f59e0b" radius={[3,3,0,0]} maxBarSize={20} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Monthly Trend */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 bg-violet-500 rounded-xl flex items-center justify-center">
              <Activity size={13} className="text-white" />
            </div>
            <h3 className="font-bold text-gray-800 text-[13px]">معدل الحضور الشهري</h3>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <LineChart data={monthlyTrend} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
              <defs>
                <linearGradient id="trendLine" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
              <XAxis dataKey="week" tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 9, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} domain={[60, 100]} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="rate" name="معدل الحضور %" stroke="url(#trendLine)" strokeWidth={2.5} dot={{ r: 4, fill: '#3b82f6', strokeWidth: 2, stroke: 'white' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ── Search + Filter ───────────────────────────────────────────────────── */}
      <div className="px-4 mb-3 space-y-2">
        <div className="relative">
          <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="بحث عن موظف..."
            className="w-full h-10 bg-white border border-gray-200 rounded-2xl pr-9 pl-4 text-sm outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-50"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute left-3 top-1/2 -translate-y-1/2">
              <XCircle size={14} className="text-gray-400" />
            </button>
          )}
        </div>

        <div className="filter-row">
          {[
            { key: 'all',      label: `الكل (${summary.total})` },
            { key: 'present',  label: `حاضر (${summary.present})` },
            { key: 'absent',   label: `غائب (${summary.absent})` },
            { key: 'late',     label: `متأخر (${summary.late})` },
            { key: 'on_leave', label: `إجازة (${summary.on_leave})` },
          ].map(({ key, label }) => (
            <button key={key} onClick={() => setFilterStatus(key)}
              className={`filter-pill whitespace-nowrap ${filterStatus === key ? 'active' : ''}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Employee List ─────────────────────────────────────────────────────── */}
      <div className="px-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-[12px] font-bold text-gray-600">
            الموظفون ({filteredList.length})
          </span>
          <span className="text-[11px] text-gray-400">
            {todayStr}
          </span>
        </div>

        <AnimatePresence>
          {filteredList.map((emp, i) => {
            const cfg = STATUS_CONFIG[emp.status] || STATUS_CONFIG.absent;
            const StatusIcon = cfg.icon;
            const isExpanded = expandedId === emp.id;
            const initials = emp.name.split(' ').map((w: string) => w[0]).slice(0, 2).join('');

            return (
              <motion.div key={emp.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ delay: i * 0.04 }}
                className={`bg-white rounded-3xl border ${cfg.border} shadow-sm overflow-hidden`}
              >
                {/* Status bar */}
                <div className={`h-0.5 w-full bg-gradient-to-r ${cfg.gradient}`} />

                <button
                  onClick={() => setExpandedId(isExpanded ? null : emp.id)}
                  className="w-full flex items-center gap-3 p-4 text-right"
                >
                  {/* Avatar */}
                  <div className={`relative w-11 h-11 rounded-2xl bg-gradient-to-br ${emp.avatar} flex items-center justify-center text-white font-bold text-sm flex-shrink-0`}>
                    {initials}
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full ${cfg.dot} border-2 border-white flex items-center justify-center`}>
                      <StatusIcon size={7} className="text-white" />
                    </div>
                  </div>

                  <div className="flex-1 min-w-0 text-right">
                    <p className="text-[13px] font-bold text-gray-900 truncate">{emp.name}</p>
                    <p className="text-[11px] text-gray-500">{emp.role}</p>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <div className="text-left">
                      <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-lg ${cfg.bg} ${cfg.text}`}>
                        {cfg.label}
                      </span>
                      {emp.checkIn && (
                        <p className="text-[10px] text-gray-400 mt-0.5 text-center">{emp.checkIn}</p>
                      )}
                    </div>
                    <motion.div animate={{ rotate: isExpanded ? 180 : 0 }} transition={{ duration: 0.2 }}>
                      <ChevronDown size={16} className="text-gray-400" />
                    </motion.div>
                  </div>
                </button>

                {/* Expanded details */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      className="overflow-hidden"
                    >
                      <div className={`px-4 pb-4 pt-1 ${cfg.bg} border-t ${cfg.border}`}>
                        <div className="grid grid-cols-2 gap-2 mb-3">
                          {[
                            { label: 'تسجيل الدخول',  value: emp.checkIn  || '—', icon: <CheckCircle size={13} className="text-emerald-500" /> },
                            { label: 'تسجيل الخروج',  value: emp.checkOut || '—', icon: <XCircle     size={13} className="text-red-400"     /> },
                            { label: 'ساعات العمل',    value: emp.hoursWorked,     icon: <Clock       size={13} className="text-blue-500"    /> },
                            { label: 'الموقع',         value: emp.location,        icon: <MapPin      size={13} className="text-violet-500"  /> },
                          ].map(({ label, value, icon }, j) => (
                            <div key={j} className="bg-white rounded-2xl p-2.5 border border-gray-100">
                              <div className="flex items-center gap-1.5 mb-1">{icon}<span className="text-[10px] text-gray-500">{label}</span></div>
                              <p className="text-[12px] font-bold text-gray-800">{value}</p>
                            </div>
                          ))}
                        </div>

                        {/* Map preview */}
                        {emp.lat && emp.lng && (
                          <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                            <div className="h-20 bg-gradient-to-br from-blue-50 to-emerald-50 relative flex items-center justify-center">
                              <svg viewBox="0 0 200 80" className="w-full h-full">
                                <defs>
                                  <radialGradient id="factoryZone">
                                    <stop offset="0%" stopColor="#10b981" stopOpacity="0.3" />
                                    <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
                                  </radialGradient>
                                </defs>
                                <circle cx="100" cy="40" r="30" fill="url(#factoryZone)" stroke="#10b981" strokeWidth="1" strokeDasharray="4 2" />
                                <circle cx="100" cy="40" r="3" fill="#10b981" />
                                <circle cx={100 + (emp.lng - 36.2765) * 500} cy={40 + (emp.lat - 33.5138) * -500} r="5" fill="#3b82f6" />
                                <circle cx={100 + (emp.lng - 36.2765) * 500} cy={40 + (emp.lat - 33.5138) * -500} r="10" fill="#3b82f6" fillOpacity="0.2" />
                              </svg>
                              <div className="absolute bottom-1 right-2 text-[9px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-full font-medium">
                                داخل النطاق
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {filteredList.length === 0 && (
          <div className="bg-white rounded-3xl border border-gray-100 p-8 text-center">
            <Users size={32} className="text-gray-300 mx-auto mb-2" />
            <p className="text-gray-500 font-semibold text-sm">لا توجد نتائج</p>
            <p className="text-gray-400 text-xs mt-1">جرب تغيير معايير البحث أو الفلتر</p>
          </div>
        )}

        {/* Alerts */}
        {summary.absent > 0 && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="bg-red-50 border border-red-200 rounded-3xl p-4 flex items-start gap-3">
            <AlertTriangle size={18} className="text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-red-700 font-bold text-sm">تنبيه غياب</p>
              <p className="text-red-600 text-[12px] mt-0.5">
                {summary.absent} موظف غائب اليوم. يرجى المتابعة والتواصل معهم.
              </p>
            </div>
          </motion.div>
        )}

        {summary.late > 0 && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="bg-amber-50 border border-amber-200 rounded-3xl p-4 flex items-start gap-3">
            <Clock size={18} className="text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-amber-700 font-bold text-sm">تأخير في الحضور</p>
              <p className="text-amber-600 text-[12px] mt-0.5">
                {summary.late} موظف وصل متأخراً اليوم.
              </p>
            </div>
          </motion.div>
        )}

        <div style={{ height: 8 }} />
      </div>
    </div>
  );
};

export default AttendanceDashboardPage;
