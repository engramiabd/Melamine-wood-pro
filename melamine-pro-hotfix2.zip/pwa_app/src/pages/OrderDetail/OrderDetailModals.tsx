/**
 * OrderDetailModals — config constants and modal sub-components for OrderDetailPage.
 * Extracted to keep the main component under 500 lines.
 */
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ChevronRight, Phone, MapPin, Calendar, Clock,
  Package, CheckCircle, XCircle, AlertTriangle,
  User, Factory, Edit, Printer, Share2,
  TrendingUp, FileText, ChevronLeft, Zap,
  Save, X, ChevronDown, Play, Pause, Star,
  MessageSquare, ArrowRight, Hash, BarChart2, DollarSign, MessageCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { useAuth } from '../contexts/AuthContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { Card, CardBody, CardHeader } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { useAppData } from '../contexts/AppDataContext';
import { resolveActorName } from '../lib/workers';
import { CenterModal, BottomSheetModal, SheetHeader, SheetBody, SheetFooter } from '../components/ui/Modal';
import { OrderStatus } from '../types';
import { printOrder, shareOrder } from '../utils/print';
import { sendWhatsApp, orderStatusMessage } from '../utils/whatsapp';


// ── Config ──────────────────────────────────────────────────────────────────
export const STATUS_CONFIG: Record<OrderStatus, {
  label: string;
  variant: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple';
  icon: React.FC<{ size?: number; className?: string }>;
  gradient: string;
}> = {
  pending: { label: 'معلق - ينتظر القبول', variant: 'warning', icon: Clock, gradient: 'from-amber-500 to-orange-600' },
  in_production: { label: 'قيد التنفيذ', variant: 'info', icon: Factory, gradient: 'from-blue-500 to-indigo-600' },
  quality_check: { label: 'مراجعة الجودة', variant: 'purple', icon: AlertTriangle, gradient: 'from-purple-500 to-violet-600' },
  completed: { label: 'مكتمل', variant: 'success', icon: CheckCircle, gradient: 'from-emerald-500 to-teal-600' },
  cancelled: { label: 'ملغي', variant: 'danger', icon: XCircle, gradient: 'from-red-500 to-rose-600' },
  on_hold: { label: 'موقوف مؤقتاً', variant: 'default', icon: Clock, gradient: 'from-gray-500 to-slate-600' },
};

export const PRIORITY_DOT: Record<string, string> = {
  low: 'bg-gray-400', normal: 'bg-emerald-500',
  high: 'bg-amber-400', urgent: 'bg-red-500',
};
export const PRIORITY_LABELS: Record<string, string> = {
  low: 'منخفضة', normal: 'عادية', high: 'عالية', urgent: 'عاجل',
};
export const PRIORITY_BG: Record<string, string> = {
  low: 'bg-gray-100 text-gray-600', normal: 'bg-emerald-100 text-emerald-700',
  high: 'bg-amber-100 text-amber-700', urgent: 'bg-red-100 text-red-700',
};

const timeline = [
  { key: 'pending', label: 'إنشاء الطلب', sub: 'بانتظار الموافقة', icon: FileText },
  { key: 'in_production', label: 'بدء الإنتاج', sub: 'جاري التصنيع', icon: Factory },
  { key: 'quality_check', label: 'مراجعة الجودة', sub: 'فحص المنتج', icon: AlertTriangle },
  { key: 'completed', label: 'اكتمال الطلب', sub: 'تم التسليم', icon: CheckCircle },
];
export const STATUS_ORDER: OrderStatus[] = ['pending', 'in_production', 'quality_check', 'completed'];

// ── Confirm Modal ─────────────────────────────────────────────────────────────
export const ConfirmModal: React.FC<{
  open: boolean; title: string; message: string;
  confirmLabel: string; confirmVariant?: 'primary' | 'danger' | 'success';
  onConfirm: () => void; onCancel: () => void; isLoading?: boolean;
  children?: React.ReactNode;
}> = ({ open, title, message, confirmLabel, confirmVariant = 'primary', onConfirm, onCancel, isLoading, children }) => (
  <CenterModal isOpen={open} onClose={onCancel} title={title}>
    <div className="p-5">
      <p className="text-sm text-gray-600 mb-4 leading-relaxed">{message}</p>
      {children}
      <div className="flex gap-3 mt-4">
        <Button variant="outline" fullWidth onClick={onCancel} disabled={isLoading}>إلغاء</Button>
        <Button variant={confirmVariant} fullWidth onClick={onConfirm} isLoading={isLoading}>{confirmLabel}</Button>
      </div>
    </div>
  </CenterModal>
);

// ── Assign Line Modal ─────────────────────────────────────────────────────────
export const AssignLineModal: React.FC<{
  open: boolean;
  currentLineId?: string;
  lines: ReturnType<typeof useAppData>['productionLines'];
  onSave: (lineId: string) => void;
  onClose: () => void;
}> = ({ open, currentLineId, lines, onSave, onClose }) => {
  const [selected, setSelected] = useState(currentLineId || '');
  const activeLine = lines.filter(l => l.status === 'active' || l.status === 'idle');

  return (
    <BottomSheetModal isOpen={open} onClose={onClose}>
      <SheetHeader title="تعيين خط الإنتاج" onClose={onClose} />
      <SheetBody>
        <div className="space-y-2 p-4">
          {activeLine.length === 0 && (
            <div className="text-center py-8 text-gray-500 text-sm">لا توجد خطوط متاحة حالياً</div>
          )}
          {activeLine.map(line => {
            const isActive = line.status === 'active';
            return (
              <button
                key={line.id}
                onClick={() => setSelected(line.id)}
                className={`w-full flex items-center gap-3 p-3.5 rounded-2xl border-2 transition-all text-right ${
                  selected === line.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-100 bg-white hover:border-gray-200'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  isActive ? 'bg-emerald-100' : 'bg-gray-100'
                }`}>
                  <Factory size={18} className={isActive ? 'text-emerald-600' : 'text-gray-400'} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-gray-900">{line.name}</p>
                  <p className="text-xs text-gray-500">
                    الكفاءة: {line.efficiency_percentage}% · {line.total_produced_today} لوح اليوم
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-500'
                  }`}>
                    {isActive ? 'نشط' : 'خامل'}
                  </span>
                  {selected === line.id && (
                    <CheckCircle size={14} className="text-blue-500" />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </SheetBody>
      <SheetFooter>
        <div className="flex gap-3 p-4">
          <Button variant="outline" fullWidth onClick={onClose}>إلغاء</Button>
          <Button variant="primary" fullWidth onClick={() => { if (selected) { onSave(selected); onClose(); } }} disabled={!selected}>
            تعيين الخط
          </Button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

// ── Quality Check Modal ───────────────────────────────────────────────────────
export const QualityCheckModal: React.FC<{
  open: boolean;
  onPass: (notes: string) => void;
  onFail: (notes: string) => void;
  onClose: () => void;
}> = ({ open, onPass, onFail, onClose }) => {
  const [notes, setNotes] = useState('');
  const [result, setResult] = useState<'pass' | 'fail' | null>(null);

  const handleSubmit = () => {
    if (!result) return;
    if (result === 'pass') onPass(notes);
    else onFail(notes);
    onClose();
  };

  return (
    <BottomSheetModal isOpen={open} onClose={onClose}>
      <SheetHeader title="نتيجة مراجعة الجودة" onClose={onClose} />
      <SheetBody>
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setResult('pass')}
              className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${
                result === 'pass' ? 'border-emerald-500 bg-emerald-50' : 'border-gray-200 bg-white'
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                result === 'pass' ? 'bg-emerald-500' : 'bg-gray-100'
              }`}>
                <CheckCircle size={22} className={result === 'pass' ? 'text-white' : 'text-gray-400'} />
              </div>
              <p className={`text-sm font-bold ${result === 'pass' ? 'text-emerald-700' : 'text-gray-500'}`}>
                اجتاز الفحص
              </p>
              <p className="text-[11px] text-gray-400 text-center">المنتج مطابق للمواصفات</p>
            </button>
            <button
              onClick={() => setResult('fail')}
              className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${
                result === 'fail' ? 'border-red-500 bg-red-50' : 'border-gray-200 bg-white'
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                result === 'fail' ? 'bg-red-500' : 'bg-gray-100'
              }`}>
                <XCircle size={22} className={result === 'fail' ? 'text-white' : 'text-gray-400'} />
              </div>
              <p className={`text-sm font-bold ${result === 'fail' ? 'text-red-700' : 'text-gray-500'}`}>
                رفض الجودة
              </p>
              <p className="text-[11px] text-gray-400 text-center">يحتاج إعادة تصنيع</p>
            </button>
          </div>

          {result && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
              <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                ملاحظات الجودة {result === 'fail' && <span className="text-red-500">*</span>}
              </label>
              <textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                rows={3}
                placeholder={result === 'pass' ? 'ملاحظات اختيارية...' : 'سبب الرفض والإجراءات المطلوبة...'}
                className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </motion.div>
          )}
        </div>
      </SheetBody>
      <SheetFooter>
        <div className="flex gap-3 p-4">
          <Button variant="outline" fullWidth onClick={onClose}>إلغاء</Button>
          <Button
            variant={result === 'pass' ? 'success' : result === 'fail' ? 'danger' : 'primary'}
            fullWidth
            onClick={handleSubmit}
            disabled={!result || (result === 'fail' && !notes.trim())}
          >
            {result === 'pass' ? 'تأكيد الاجتياز' : result === 'fail' ? 'تأكيد الرفض' : 'اختر النتيجة'}
          </Button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

// ── Record Payment Modal ─────────────────────────────────────────────────────
export const RecordPaymentModal: React.FC<{
  open: boolean;
  remainingUsd: number;
  exchangeRate: number;
  onSave: (amountUsd: number, method: 'cash' | 'bank_transfer' | 'check' | 'other') => void;
  onClose: () => void;
}> = ({ open, remainingUsd, exchangeRate, onSave, onClose }) => {
  const [amount, setAmount] = useState(String(remainingUsd));
  const [method, setMethod] = useState<'cash' | 'bank_transfer' | 'check' | 'other'>('cash');
  const amountNum = parseFloat(amount) || 0;
  const valid = amountNum > 0 && amountNum <= remainingUsd;

  useEffect(() => { if (open) { setAmount(String(remainingUsd)); setMethod('cash'); } }, [open, remainingUsd]);

  return (
    <BottomSheetModal isOpen={open} onClose={onClose}>
      <SheetHeader title="تسجيل دفعة" onClose={onClose} />
      <SheetBody>
        <div className="p-4">
          <div className="bg-gray-50 rounded-xl p-3 mb-4 text-center">
            <p className="text-[11px] text-gray-400 mb-1">المبلغ المتبقي</p>
            <p className="text-xl font-black text-red-600">${remainingUsd.toFixed(2)}</p>
          </div>
          <div className="mb-3">
            <label className="text-xs font-semibold text-gray-600 mb-1.5 block">المبلغ المدفوع ($) *</label>
            <input type="number" value={amount} onChange={e => setAmount(e.target.value)}
              className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-lg font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500" />
            {amountNum > remainingUsd && <p className="text-[11px] text-red-600 mt-1">المبلغ أكبر من المتبقي</p>}
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-600 mb-1.5 block">طريقة الدفع</label>
            <div className="grid grid-cols-4 gap-2">
              {([['cash', 'نقدي'], ['bank_transfer', 'تحويل'], ['check', 'شيك'], ['other', 'أخرى']] as const).map(([v, l]) => (
                <button key={v} onClick={() => setMethod(v)}
                  className={`py-2 rounded-lg text-[11px] font-bold border transition-colors ${
                    method === v ? 'border-emerald-500 bg-emerald-50 text-emerald-600' : 'border-gray-200 text-gray-500'
                  }`}>
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>
      </SheetBody>
      <SheetFooter>
        <div className="p-4">
          <Button variant="primary" fullWidth disabled={!valid} onClick={() => { onSave(amountNum, method); onClose(); }}>
            تأكيد الدفعة
          </Button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};


export const AddNoteModal: React.FC<{
  open: boolean;
  currentNotes?: string;
  onSave: (notes: string) => void;
  onClose: () => void;
}> = ({ open, currentNotes, onSave, onClose }) => {
  const [notes, setNotes] = useState(currentNotes || '');
  return (
    <BottomSheetModal isOpen={open} onClose={onClose}>
      <SheetHeader title="إضافة ملاحظة" onClose={onClose} />
      <SheetBody>
        <div className="p-4">
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            rows={5}
            placeholder="أدخل ملاحظاتك هنا..."
            className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            autoFocus
          />
        </div>
      </SheetBody>
      <SheetFooter>
        <div className="flex gap-3 p-4">
          <Button variant="outline" fullWidth onClick={onClose}>إلغاء</Button>
          <Button variant="primary" fullWidth onClick={() => { onSave(notes); onClose(); }}>
            حفظ الملاحظة
          </Button>
        </div>
      </SheetFooter>
    </BottomSheetModal>
  );
};

